import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.MessageDigest;
import java.util.Arrays;

public class CCAvenueCryptoUtil {

    private static final byte[] INIT_VECTOR = new byte[] {
            0x00, 0x01, 0x02, 0x03,
            0x04, 0x05, 0x06, 0x07,
            0x08, 0x09, 0x0a, 0x0b,
            0x0c, 0x0d, 0x0e, 0x0f
    };

    public static String encrypt(String plainText, String workingKey) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, getSecretKey(workingKey), new IvParameterSpec(INIT_VECTOR));
        return bytesToHex(cipher.doFinal(plainText.getBytes("UTF-8")));
    }

    public static String decrypt(String encryptedHex, String workingKey) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.DECRYPT_MODE, getSecretKey(workingKey), new IvParameterSpec(INIT_VECTOR));
        return new String(cipher.doFinal(hexToBytes(encryptedHex)), "UTF-8");
    }

    private static SecretKeySpec getSecretKey(String workingKey) throws Exception {
        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] digest = md.digest(workingKey.getBytes("UTF-8"));
        byte[] keyBytes = Arrays.copyOf(digest, 16);
        return new SecretKeySpec(keyBytes, "AES");
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder result = new StringBuilder();
        for (byte b : bytes) {
            result.append(String.format("%02x", b & 0xff));
        }
        return result.toString();
    }

    private static byte[] hexToBytes(String hex) {
        int len = hex.length();
        byte[] result = new byte[len / 2];

        for (int i = 0; i < len; i += 2) {
            result[i / 2] = (byte) (
                    (Character.digit(hex.charAt(i), 16) << 4)
                            + Character.digit(hex.charAt(i + 1), 16)
            );
        }

        return result;
    }
}