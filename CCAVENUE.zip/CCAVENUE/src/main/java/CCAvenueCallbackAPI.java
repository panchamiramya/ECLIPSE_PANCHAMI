import org.json.JSONObject;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.*;
import java.net.URLDecoder;
import java.sql.*;
import java.util.Properties;
import java.util.logging.*;

@WebServlet("/CCAvenueCallbackAPI")
public class CCAvenueCallbackAPI extends HttpServlet {

    private static final Logger logger = Logger.getLogger(CCAvenueCallbackAPI.class.getName());

    private String workingKey;

    @Override
    public void init() throws ServletException {
        try {
            setupLogger();
            loadProperties();
            logger.info("CCAvenueCallbackAPI initialized successfully");
        } catch (Exception e) {
            throw new ServletException("CCAvenueCallbackAPI initialization failed", e);
        }
    }

    private void setupLogger() throws IOException {
        File logDir = new File("/var/log/ccavenue");
        if (!logDir.exists()) {
            logDir.mkdirs();
        }

        FileHandler fileHandler = new FileHandler(
                "/var/log/ccavenue/ccavenue-callback-api-%g.log",
                10 * 1024 * 1024,
                10,
                true
        );

        fileHandler.setFormatter(new SimpleFormatter());
        logger.addHandler(fileHandler);
        logger.setLevel(Level.INFO);
    }

    private void loadProperties() throws Exception {
        Properties props = new Properties();

        InputStream inputStream = getClass().getClassLoader()
                .getResourceAsStream("resources/ccavenue.properties");

        if (inputStream == null) {
            inputStream = getClass().getClassLoader()
                    .getResourceAsStream("ccavenue.properties");
        }

        if (inputStream == null) {
            throw new FileNotFoundException("ccavenue.properties not found");
        }

        try {
            props.load(inputStream);
            workingKey = props.getProperty("ccavenue.working.key", "").trim();

            if (workingKey.length() == 0) {
                throw new Exception("ccavenue.working.key missing");
            }
        } finally {
            inputStream.close();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        JSONObject finalResp = new JSONObject();

        try {
            String encResp = request.getParameter("encResp");

            if (encResp == null || encResp.trim().length() == 0) {
                encResp = request.getParameter("enc_response");
            }

            if (encResp == null || encResp.trim().length() == 0) {
                throw new Exception("encResp missing");
            }

            encResp = URLDecoder.decode(encResp, "UTF-8");

            String decryptedResponse = CCAvenueCryptoUtil.decrypt(encResp, workingKey);

            logger.info("CCAvenue callback decrypted response: " + decryptedResponse);

            JSONObject data = parseKeyValueResponse(decryptedResponse);

            saveCallback(data, decryptedResponse);

            finalResp.put("status", "SUCCESS");
            finalResp.put("message", "Callback received");
            finalResp.put("order_id", data.optString("order_id", ""));
            finalResp.put("tracking_id", data.optString("tracking_id", ""));
            finalResp.put("order_status", data.optString("order_status", ""));

            response.setStatus(HttpServletResponse.SC_OK);
            response.getWriter().write(finalResp.toString());

        } catch (Exception e) {
            logger.log(Level.SEVERE, "Callback processing failed", e);

            finalResp.put("status", "FAILED");
            finalResp.put("message", e.getMessage());

            response.setStatus(HttpServletResponse.SC_OK);
            response.getWriter().write(finalResp.toString());
        }
    }

    private JSONObject parseKeyValueResponse(String decryptedResponse) throws Exception {
        JSONObject json = new JSONObject();

        String[] pairs = decryptedResponse.split("&");

        for (String pair : pairs) {
            int index = pair.indexOf("=");

            if (index > -1) {
                String key = pair.substring(0, index).trim();
                String value = pair.substring(index + 1).trim();
                json.put(key, value);
            }
        }

        return json;
    }

    private void saveCallback(JSONObject data, String rawResponse) throws Exception {

        Connection conn = null;
        PreparedStatement ps = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/ccavenue",
                    "ccavenue",
                    "cc@venue"
            );

            String sql = "INSERT INTO ccavenue_payment_callback " +
                    "(order_id, tracking_id, bank_ref_no, order_status, failure_message, payment_mode, currency, amount, billing_tel, billing_email, raw_response) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            ps = conn.prepareStatement(sql);

            ps.setString(1, data.optString("order_id", ""));
            ps.setString(2, data.optString("tracking_id", ""));
            ps.setString(3, data.optString("bank_ref_no", ""));
            ps.setString(4, data.optString("order_status", ""));
            ps.setString(5, data.optString("failure_message", ""));
            ps.setString(6, data.optString("payment_mode", ""));
            ps.setString(7, data.optString("currency", ""));
            ps.setString(8, data.optString("amount", ""));
            ps.setString(9, data.optString("billing_tel", ""));
            ps.setString(10, data.optString("billing_email", ""));
            ps.setString(11, rawResponse);

            ps.executeUpdate();

        } finally {
            if (ps != null) ps.close();
            if (conn != null) conn.close();
        }
    }
}