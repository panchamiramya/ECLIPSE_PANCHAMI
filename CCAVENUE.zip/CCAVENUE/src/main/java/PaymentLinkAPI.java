import org.json.JSONObject;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.net.URLDecoder;
import java.util.Properties;
import java.util.logging.*;

// DB imports
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

@WebServlet("/PaymentLinkAPI")
public class PaymentLinkAPI extends HttpServlet {

    private static final Logger logger = Logger.getLogger(PaymentLinkAPI.class.getName());

    private String ccavenueUrl;
    private String accessCode;
    private String workingKey;
    private String version;
    private String command;

    @Override
    public void init() throws ServletException {
        try {
            setupLogger();
            loadProperties();
            logger.info("PaymentLinkAPI initialized successfully");
        } catch (Exception e) {
            throw new ServletException("PaymentLinkAPI initialization failed", e);
        }
    }

    private void setupLogger() throws IOException {
        LogManager.getLogManager().reset();

        File logDir = new File("/var/log/ccavenue");
        if (!logDir.exists()) {
            logDir.mkdirs();
        }

        FileHandler fileHandler = new FileHandler(
                "/var/log/ccavenue/payment-link-api-%g.log",
                10 * 1024 * 1024,
                10,
                true
        );

        fileHandler.setFormatter(new SimpleFormatter());
        logger.addHandler(fileHandler);
        logger.setLevel(Level.INFO);
    }

    private void loadProperties() throws Exception {
        Properties props = new Properties();

        InputStream inputStream = getClass().getClassLoader()
                .getResourceAsStream("resources/ccavenue.properties");

        if (inputStream == null) {
            throw new FileNotFoundException("ccavenue.properties not found inside WEB-INF/classes");
        }

        try {
            props.load(inputStream);

            ccavenueUrl = props.getProperty("ccavenue.api.url");
            accessCode = props.getProperty("ccavenue.access.code");
            workingKey = props.getProperty("ccavenue.working.key");
            version = props.getProperty("ccavenue.version", "1.2");
            command = props.getProperty("ccavenue.command", "generateQuickInvoice");

            if (isBlank(ccavenueUrl) || isBlank(accessCode) || isBlank(workingKey)) {
                throw new Exception("CCAvenue properties missing");
            }

        } finally {
            inputStream.close();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        JSONObject finalResponse = new JSONObject();
        String requestBody = "";
        String requestCode = "NA";

        try {
            requestBody = readRequestBody(request);
            logger.info("Incoming API request received");

            JSONObject inputJson = new JSONObject(requestBody);

            String name = inputJson.optString("name", "").trim();
            String email = inputJson.optString("email", "").trim();
            String mobile = inputJson.optString("mobile", "").trim();
            String amountStr = inputJson.optString("amount", "").trim();
            String referenceNo = inputJson.optString("reference_no", "").trim();

            // ONLY CHANGE → reference_no mandatory
            if (isBlank(referenceNo)) {
                throw new Exception("reference_no is mandatory");
            }

            requestCode = referenceNo;

            validateInput(name, email, mobile, amountStr);

            JSONObject ccavenueResponse = generatePaymentLink(
                    name, email, mobile, amountStr, referenceNo
            );

            // DB log success
            logToDB(requestCode, requestBody, ccavenueResponse.toString(), "SUCCESS");

            response.setStatus(HttpServletResponse.SC_OK);
            response.getWriter().write(ccavenueResponse.toString());

        } catch (Exception e) {
            logger.log(Level.SEVERE, "Payment link generation failed", e);

            finalResponse.put("status", "FAILED");
            finalResponse.put("message", "Unable to generate payment link");
            finalResponse.put("error", e.getMessage());

            // DB log failure
            logToDB(requestCode, requestBody, finalResponse.toString(), "FAILED");

            response.setStatus(HttpServletResponse.SC_OK);
            response.getWriter().write(finalResponse.toString());
        }
    }

    // DB logging
    private void logToDB(String requestCode, String request, String response, String status) {
        try (Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/ccavenue", "ccavenue", "cc@venue");
             PreparedStatement ps = con.prepareStatement(
                     "INSERT INTO payment_api_log(request_code, request_payload, response_payload, status) VALUES (?,?,?,?)")) {

            ps.setString(1, requestCode);
            ps.setString(2, request);
            ps.setString(3, response);
            ps.setString(4, status);
            ps.executeUpdate();

        } catch (Exception e) {
            logger.log(Level.SEVERE, "DB log failed", e);
        }
    }

    private JSONObject generatePaymentLink(
            String name,
            String email,
            String mobile,
            String amountStr,
            String referenceNo
    ) throws Exception {

        BigDecimal amount = new BigDecimal(amountStr).setScale(2, BigDecimal.ROUND_HALF_UP);

        JSONObject invoiceRequest = new JSONObject();

        // ORIGINAL FIELDS (unchanged)
        invoiceRequest.put("customer_name", name);
        invoiceRequest.put("customer_email_id", email);
        invoiceRequest.put("customer_mobile_no", mobile);
        invoiceRequest.put("customer_email_subject", "Payment Link");
        invoiceRequest.put("valid_for", "2");
        invoiceRequest.put("valid_type", "days");
        invoiceRequest.put("currency", "INR");
        invoiceRequest.put("amount", amount.toString());
        invoiceRequest.put("invoice_description", "Voice bot payment link");
        invoiceRequest.put("merchant_reference_no", referenceNo);
        invoiceRequest.put("bill_delivery_type", "SMS");
        invoiceRequest.put("sms_content",
                "Pls pay your LegalEntity_Name bill # Invoice_ID for Invoice_Currency Invoice_Amount online at Pay_Link.");

        logger.info("Preparing CCAvenue invoice request. Reference No: " + referenceNo);

        String encryptedRequest = CCAvenueCryptoUtil.encrypt(invoiceRequest.toString(), workingKey);

        String postData =
                "enc_request=" + URLEncoder.encode(encryptedRequest, "UTF-8") +
                "&access_code=" + URLEncoder.encode(accessCode, "UTF-8") +
                "&command=" + URLEncoder.encode(command, "UTF-8") +
                "&request_type=JSON" +
                "&response_type=JSON" +
                "&version=" + URLEncoder.encode(version, "UTF-8");

        String rawResponse = callCCAvenue(postData);

        logger.info("Raw response received from CCAvenue");

        JSONObject ccavenueOuterResponse = parseCCAvenueResponse(rawResponse);

        String status = ccavenueOuterResponse.optString("status", "");
        String encResponse = ccavenueOuterResponse.optString("enc_response", "");
        String encErrorCode = ccavenueOuterResponse.optString("enc_error_code", "");

        if ("1".equals(status)) {
            JSONObject errorResponse = new JSONObject();
            errorResponse.put("status", "FAILED");
            errorResponse.put("message", encResponse);
            errorResponse.put("error_code", encErrorCode);
            return errorResponse;
        }

        if (isBlank(encResponse)) {
            throw new Exception("CCAvenue enc_response is blank. Raw Response: " + rawResponse);
        }

        String decryptedResponse = CCAvenueCryptoUtil.decrypt(encResponse, workingKey);

        logger.info("CCAvenue response decrypted successfully");

        JSONObject invoiceResponse = new JSONObject(decryptedResponse);

        String tinyUrl = invoiceResponse.optString("tiny_url", "");
        String invoiceId = invoiceResponse.optString("invoice_id", "");
        String errorDesc = invoiceResponse.optString("error_desc", "");
        String errorCode = invoiceResponse.optString("error_code", "");
        int invoiceStatus = invoiceResponse.optInt("invoice_status", -1);

        JSONObject finalResponse = new JSONObject();

        if (!isBlank(tinyUrl)) {
            finalResponse.put("status", "SUCCESS");
            finalResponse.put("tiny_url", tinyUrl);
            finalResponse.put("invoice_id", invoiceId);
            finalResponse.put("reference_no", referenceNo);
        } else {
            finalResponse.put("status", "FAILED");
            finalResponse.put("message", errorDesc);
            finalResponse.put("error_code", errorCode);
            finalResponse.put("invoice_status", invoiceStatus);
        }

        return finalResponse;
    }

    private String callCCAvenue(String postData) throws Exception {
        HttpURLConnection connection = null;

        try {
            URL url = new URL(ccavenueUrl);
            connection = (HttpURLConnection) url.openConnection();

            connection.setRequestMethod("POST");
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(30000);
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

            OutputStream outputStream = null;

            try {
                outputStream = connection.getOutputStream();
                outputStream.write(postData.getBytes("UTF-8"));
                outputStream.flush();
            } finally {
                if (outputStream != null) {
                    outputStream.close();
                }
            }

            int responseCode = connection.getResponseCode();

            InputStream inputStream;

            if (responseCode >= 200 && responseCode < 300) {
                inputStream = connection.getInputStream();
            } else {
                inputStream = connection.getErrorStream();
            }

            String responseText = readStream(inputStream);

            if (responseCode < 200 || responseCode >= 300) {
                throw new Exception("CCAvenue HTTP Error: " + responseCode + ", Response: " + responseText);
            }

            return responseText;

        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    private JSONObject parseCCAvenueResponse(String rawResponse) throws Exception {
        JSONObject jsonObject = new JSONObject();

        if (isBlank(rawResponse)) {
            throw new Exception("Blank response from CCAvenue");
        }

        String[] parts = rawResponse.split("&");

        for (String part : parts) {
            int index = part.indexOf("=");

            if (index > -1) {
                String key = URLDecoder.decode(part.substring(0, index), "UTF-8");
                String value = URLDecoder.decode(part.substring(index + 1), "UTF-8");
                jsonObject.put(key, value);
            }
        }

        return jsonObject;
    }

    private String readRequestBody(HttpServletRequest request) throws IOException {
        StringBuilder sb = new StringBuilder();

        BufferedReader reader = request.getReader();

        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }

        return sb.toString();
    }

    private String readStream(InputStream inputStream) throws IOException {
        if (inputStream == null) return "";

        StringBuilder sb = new StringBuilder();
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));

        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }

        reader.close();
        return sb.toString();
    }

    private void validateInput(String name, String email, String mobile, String amountStr) throws Exception {
        if (isBlank(name)) throw new Exception("name is required");
        if (isBlank(email) || !email.contains("@")) throw new Exception("valid email is required");
        if (isBlank(mobile) || !mobile.matches("\\d{10}")) throw new Exception("valid 10 digit mobile is required");
        if (isBlank(amountStr)) throw new Exception("amount is required");

        BigDecimal amount = new BigDecimal(amountStr);
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new Exception("amount should be greater than zero");
        }
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }
}