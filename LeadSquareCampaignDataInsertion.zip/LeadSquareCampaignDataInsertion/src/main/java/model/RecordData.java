package model;

public class RecordData {
    private String msisdn;
    private String unique_ref_no;
    private String lan_no;
    private String agent_id;
    private String agent_msisdn;
    private String isagentwise;

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public String getUnique_ref_no() {
        return unique_ref_no;
    }

    public void setUnique_ref_no(String unique_ref_no) {
        this.unique_ref_no = unique_ref_no;
    }

    public String getLan_no() {
        return lan_no;
    }

    public void setLan_no(String lan_no) {
        this.lan_no = lan_no;
    }

    public String getAgent_id() {
        return agent_id;
    }

    public void setAgent_id(String agent_id) {
        this.agent_id = agent_id;
    }
    
    public String getAgent_msisdn() {
        return agent_msisdn;
    }

    public void setAgent_msisdn(String agent_msisdn) {
        this.agent_msisdn = agent_msisdn;
    }
   
}
