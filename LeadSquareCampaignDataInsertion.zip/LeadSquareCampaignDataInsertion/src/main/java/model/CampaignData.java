package model;

import java.util.List;

public class CampaignData {
    private String campaign_name;
    private String campaign_type;
    private String is_agent_wise;
    private List<RecordData> records;

    public String getCampaign_name() {
        return campaign_name;
    }

    public void setCampaign_name(String campaign_name) {
        this.campaign_name = campaign_name;
    }

    public String getCampaign_type() {
        return campaign_type;
    }

    public void setCampaign_type(String campaign_type) {
        this.campaign_type = campaign_type;
    }

    public String getIs_agent_wise() {
        return is_agent_wise;
    }

    public void setIs_agent_wise(String is_agent_wise) {
        this.is_agent_wise = is_agent_wise;
    }

    public List<RecordData> getRecords() {
        return records;
    }

    public void setRecords(List<RecordData> records) {
        this.records = records;
    }
}
