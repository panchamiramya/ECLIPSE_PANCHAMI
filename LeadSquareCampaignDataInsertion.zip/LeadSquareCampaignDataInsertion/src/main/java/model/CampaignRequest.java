package model;

import java.util.List;

public class CampaignRequest {
    private String account_id;
    private String auth_token;
    private List<CampaignData> campaigns;

    public String getAccount_id() {
        return account_id;
    }

    public void setAccount_id(String account_id) {
        this.account_id = account_id;
    }

    public String getAuth_token() {
        return auth_token;
    }

    public void setAuth_token(String auth_token) {
        this.auth_token = auth_token;
    }

    public List<CampaignData> getCampaigns() {
        return campaigns;
    }

    public void setCampaigns(List<CampaignData> campaigns) {
        this.campaigns = campaigns;
    }
}
