package db;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {

    private static final String HOST = "jdbc:mysql://localhost:3306/";
    private static final String USER = "ls";
    private static final String PASSWORD = "ls@321";

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Connection getConnection(String dbName) throws Exception {
        return DriverManager.getConnection(
                HOST + dbName + "?useSSL=false&serverTimezone=UTC&autoReconnect=true",
                USER,
                PASSWORD
        );
    }
}
