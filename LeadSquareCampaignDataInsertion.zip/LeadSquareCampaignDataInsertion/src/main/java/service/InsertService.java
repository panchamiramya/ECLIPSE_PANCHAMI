package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.List;

import db.DBConnection;
import model.CampaignData;
import model.RecordData;
import util.DBUtil;
import util.ValidationUtil;

public class InsertService {

    public static void processCampaign(String accountId, CampaignData campaign) throws Exception {

        String campaignName = campaign.getCampaign_name();
        String campaignType = campaign.getCampaign_type();
        String isAgentWise = campaign.getIs_agent_wise();

        if (!ValidationUtil.isValidTableName(campaignName)) {
            throw new Exception("Invalid campaign name: " + campaignName);
        }

        String dbName = DBUtil.getDatabaseByCampaignType(campaignType);
        String tableName = campaignName + "_tab";

        String campSql = "INSERT INTO " + tableName
                + " (msisdn, record_id, crn, campaign_name, inserted_by, created_on, file_name, account_id, record_status, agent_id, agent_msisdn) "
                + " VALUES (?, ?, ?, ?, ?, NOW(), 'api.xlsx', ?, 'active', ?, ?)";

        String outboundSql = "INSERT INTO account_outbound "
                + " (account_id, request_date, msisdn, record_status, campaign_name, listfilename, record_id, ismaster, lan, server_id, agent_id, isagentwise, agent_msisdn, campaign_type) "
                + " VALUES (?, NOW(), ?, 'active', ?, 'api.xlsx', ?, 1, ?, 'bng_pred',?,?,?,?)";

        Connection conn = null;
        PreparedStatement campPs = null;
        PreparedStatement outboundPs = null;

        try {
            conn = DBConnection.getConnection(dbName);
            conn.setAutoCommit(false);

            if (!DBUtil.isTableExists(conn, tableName)) {
                throw new Exception("Campaign table not found: " + tableName + " in " + dbName);
            }

            List<RecordData> records = campaign.getRecords();
            if (records == null || records.isEmpty()) {
                throw new Exception("No records found for campaign: " + campaignName);
            }

            campPs = conn.prepareStatement(campSql);
            outboundPs = conn.prepareStatement(outboundSql);

            for (RecordData record : records) {
                String msisdn = record.getMsisdn();
                String uniqueRefNo = record.getUnique_ref_no();
                String lanNo = record.getLan_no();
                String agentId = record.getAgent_id();
                String agentMsisdn = record.getAgent_msisdn();
                System.out.println(agentMsisdn+" SUDSUDSUD "+record);

                if (!ValidationUtil.isValidMobile(msisdn)) {
                    throw new Exception("Invalid mobile number: " + msisdn + ". It must be exactly 10 digits.");
                }
                
                
                campPs.setString(1, msisdn);
                campPs.setString(2, uniqueRefNo);
                campPs.setString(3, lanNo);
                campPs.setString(4, campaignName);
                campPs.setString(5, accountId+"_api");
                campPs.setString(6, accountId);

                if ("yes".equalsIgnoreCase(isAgentWise)) {
                    if (ValidationUtil.isBlank(agentId)) {
                        campPs.setNull(7, Types.VARCHAR);
                        
                    } else {
                        campPs.setString(7, agentId);
                    }
                } else {
                    campPs.setNull(7, Types.VARCHAR);
                }
                campPs.setString(8, agentMsisdn);
                campPs.addBatch();

                outboundPs.setString(1, accountId);
                outboundPs.setString(2, msisdn);
                outboundPs.setString(3, campaignName);
                outboundPs.setString(4, uniqueRefNo);
                outboundPs.setString(5, lanNo);
                outboundPs.setString(6, agentId);
                outboundPs.setString(7, isAgentWise);
                outboundPs.setString(8, agentMsisdn);
                outboundPs.setString(9, campaignType);
                outboundPs.addBatch();
            }

            campPs.executeBatch();
            outboundPs.executeBatch();
            conn.commit();

        } catch (Exception e) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (Exception rollbackEx) {
                    rollbackEx.printStackTrace();
                }
            }
            throw e;
        } finally {
            try {
                if (campPs != null) campPs.close();
            } catch (Exception e) {
                e.printStackTrace();
            }

            try {
                if (outboundPs != null) outboundPs.close();
            } catch (Exception e) {
                e.printStackTrace();
            }

            try {
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
