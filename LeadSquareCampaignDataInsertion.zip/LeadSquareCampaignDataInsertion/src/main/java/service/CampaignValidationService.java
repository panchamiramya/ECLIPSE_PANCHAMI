package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import db.DBConnection;
import util.DBUtil;

public class CampaignValidationService {

    public static String validateCampaign(String accountId, String campaignName, String campaignType) throws Exception {

        String dbName = DBUtil.getDatabaseByCampaignType(campaignType);
        String sql = "SELECT is_predictive FROM campaign_status WHERE campaign_name = ? AND account_id = ?";

        try (Connection conn = DBConnection.getConnection(dbName);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, campaignName);
            ps.setString(2, accountId);

            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    return "Campaign name not found for account_id in " + dbName;
                }

                String isPredictive = rs.getString("is_predictive");

                if ("predictive".equalsIgnoreCase(campaignType)) {
                    if (!"yes".equalsIgnoreCase(isPredictive)) {
                        return "Campaign type mismatch. campaign_status is not predictive in " + dbName;
                    }
                } else if ("progressive".equalsIgnoreCase(campaignType)) {
                    if (!"no".equalsIgnoreCase(isPredictive)) {
                        return "Campaign type mismatch. campaign_status is not progressive in " + dbName;
                    }
                } else {
                    return "Invalid campaign_type";
                }

                return "VALID";
            }
        }
    }
}
