package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;

import db.DBConnection;

public class AuthService {

    public static String validateToken(String accountId, String authToken) {
        String sql = "SELECT authtoken, valid_date FROM api_authtoken "
                   + "WHERE account_id = ? AND authtoken = ? LIMIT 1";

        try (Connection conn = DBConnection.getConnection("smartivr_cloud");
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, accountId);
            ps.setString(2, authToken);

            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    return "106";
                }

                Timestamp validDate = rs.getTimestamp("valid_date");
                Timestamp now = new Timestamp(System.currentTimeMillis());

                if (now.after(validDate)) {
                    return "107";
                }
            }

            return "0";

        } catch (Exception e) {
            e.printStackTrace();
            return "500";
        }
    }
}
