package util;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;

public class DBUtil {

    public static boolean isTableExists(Connection conn, String tableName) throws Exception {
        DatabaseMetaData metaData = conn.getMetaData();
        try (ResultSet rs = metaData.getTables(null, null, tableName, new String[]{"TABLE"})) {
            return rs.next();
        }
    }

    public static String getDatabaseByCampaignType(String campaignType) throws Exception {
        if ("predictive".equalsIgnoreCase(campaignType)) {
            return "campaign_leadsquare";
        } else if ("progressive".equalsIgnoreCase(campaignType)) {
            return "campaign_leadsquare";
        } else {
            throw new Exception("Invalid campaign_type: " + campaignType);
        }
    }
}
