package util;

public class ResponseUtil {

    public static String success(String message) {
        return "{"
                + "\"result\":{"
                + "\"status\":{"
                + "\"statusCode\":\"0\","
                + "\"errorCode\":\"0\","
                + "\"errorMessage\":\"" + escape(message) + "\""
                + "}"
                + "}"
                + "}";
    }

    public static String error(String code, String message) {
        return "{"
                + "\"result\":{"
                + "\"status\":{"
                + "\"statusCode\":\"1\","
                + "\"errorCode\":\"" + escape(code) + "\","
                + "\"errorMessage\":\"" + escape(message) + "\""
                + "}"
                + "}"
                + "}";
    }

    private static String escape(String value) {
        if (value == null) return "";
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
