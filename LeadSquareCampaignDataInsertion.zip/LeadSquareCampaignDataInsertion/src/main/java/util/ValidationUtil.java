package util;

public class ValidationUtil {

    public static boolean isValidMobile(String msisdn) {
        return msisdn != null && msisdn.matches("\\d{10}");
    }

    public static boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }

    public static boolean isValidTableName(String campaignName) {
        return campaignName != null && campaignName.matches("[a-zA-Z0-9_]+");
    }
}
