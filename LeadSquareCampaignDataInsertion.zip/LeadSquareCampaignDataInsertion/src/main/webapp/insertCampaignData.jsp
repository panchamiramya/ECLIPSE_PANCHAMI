<%@ page import="java.io.BufferedReader" %>
<%@ page import="com.google.gson.Gson" %>
<%@ page import="model.CampaignData" %>
<%@ page import="model.CampaignRequest" %>
<%@ page import="service.AuthService" %>
<%@ page import="service.CampaignValidationService" %>
<%@ page import="service.InsertService" %>
<%@ page import="util.ResponseUtil" %>
<%@ page contentType="application/json; charset=UTF-8" pageEncoding="UTF-8" %>
<%
String responseJson = "";

try {
    if (!"POST".equalsIgnoreCase(request.getMethod())) {
        responseJson = ResponseUtil.error("405", "Only POST method allowed");
        out.print(responseJson);
        return;
    }

    StringBuilder requestBody = new StringBuilder();
    BufferedReader reader = request.getReader();
    String line;

    while ((line = reader.readLine()) != null) {
        requestBody.append(line);
    }

    Gson gson = new Gson();
    CampaignRequest apiRequest = gson.fromJson(requestBody.toString(), CampaignRequest.class);

    if (apiRequest == null) {
        responseJson = ResponseUtil.error("100", "Invalid request body");
        out.print(responseJson);
        return;
    }

    if (apiRequest.getAccount_id() == null || apiRequest.getAccount_id().trim().isEmpty()) {
        responseJson = ResponseUtil.error("101", "Missing account_id");
        out.print(responseJson);
        return;
    }

    if (apiRequest.getAuth_token() == null || apiRequest.getAuth_token().trim().isEmpty()) {
        responseJson = ResponseUtil.error("102", "Missing auth_token");
        out.print(responseJson);
        return;
    }

    if (apiRequest.getCampaigns() == null || apiRequest.getCampaigns().isEmpty()) {
        responseJson = ResponseUtil.error("103", "Campaign data missing");
        out.print(responseJson);
        return;
    }

    String tokenStatus = AuthService.validateToken(apiRequest.getAccount_id(), apiRequest.getAuth_token());

    if ("106".equals(tokenStatus)) {
        responseJson = ResponseUtil.error("106", "Invalid or missing authtoken");
        out.print(responseJson);
        return;
    }

    if ("107".equals(tokenStatus)) {
        responseJson = ResponseUtil.error("107", "Authtoken expired");
        out.print(responseJson);
        return;
    }

    if ("500".equals(tokenStatus)) {
        responseJson = ResponseUtil.error("500", "Token validation failed");
        out.print(responseJson);
        return;
    }

    for (CampaignData campaign : apiRequest.getCampaigns()) {
        String campaignValidationMsg = CampaignValidationService.validateCampaign(
                apiRequest.getAccount_id(),
                campaign.getCampaign_name(),
                campaign.getCampaign_type()
        );

        if (!"VALID".equalsIgnoreCase(campaignValidationMsg)) {
            responseJson = ResponseUtil.error("108", campaignValidationMsg + " : " + campaign.getCampaign_name());
            out.print(responseJson);
            return;
        }

        InsertService.processCampaign(apiRequest.getAccount_id(), campaign);
    }

    responseJson = ResponseUtil.success("Data inserted successfully");
    out.print(responseJson);

} catch (Exception e) {
    e.printStackTrace();
    responseJson = ResponseUtil.error("500", "Internal server error: " + e.getMessage());
    out.print(responseJson);
}
%>
