import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class TATACAPMFI_PDM_RPTMAIL {

    public static void main(String[] args) {
        Connection conn = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(
                    "jdbc:mysql://172.31.43.6:3306/tclmfi?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Asia/Kolkata",
                    "reportnha",
                    "India@456"
            );

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String toDate = sdf.format(new Date());
            String firstOfMonth = toDate.substring(0, 8) + "01";

            Workbook wb = new XSSFWorkbook();
            Sheet langSheet = wb.createSheet("Language Wise");
            Sheet zoneSheet = wb.createSheet("Zone Wise");

            generatePivotSheet(conn, wb, langSheet, firstOfMonth, toDate, "calling_language");
            generatePivotSheet(conn, wb, zoneSheet, firstOfMonth, toDate, "zone");

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            wb.write(baos);
            wb.close();
            File file = new File("TATACAP_MFI_PDM_Report_" + toDate + ".xlsx");
            try (FileOutputStream fos = new FileOutputStream(file)) {
                baos.writeTo(fos);
            }

            sendEmailWithAttachment(conn, file, firstOfMonth, toDate);

            if (file.exists()) file.delete();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }
    }

    private static void generatePivotSheet(Connection conn, Workbook wb, Sheet sheet, String firstOfMonth, String toDate, String groupColumn) throws SQLException {
        String sql =
            "SELECT " + groupColumn + " AS Category, " +
            "SUM(CASE WHEN ao.record_status IN ('active','finished','fetched') THEN 1 ELSE 0 END) AS Allocated, " +
            "SUM(CASE WHEN ao.record_status IN ('fetched','finished') THEN 1 ELSE 0 END) AS Attempted, " +
            "SUM(CASE WHEN ao.record_status='active' THEN 1 ELSE 0 END) AS Unattempted, " +
            "SUM(CASE WHEN ao.record_status='finished' AND ci.system_disposition='answered' THEN 1 ELSE 0 END) AS Connected, " +
            "SUM(CASE WHEN ao.record_status='finished' AND ci.system_disposition='notanswered' THEN 1 ELSE 0 END) AS NotConnected " +
            "FROM tclmfi.customer_info_call_history ci " +
            "JOIN campaign_tclmfi.account_outbound ao ON ci.record_id = ao.record_id " +
            "WHERE ci.created_on BETWEEN '" + firstOfMonth + " 00:00:00' AND '" + toDate + " 23:59:59' " +
            "AND ao.campaign_name LIKE '%PDM%' " +
            "GROUP BY " + groupColumn + " ORDER BY " + groupColumn;

        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(sql);

        List<String> categories = new ArrayList<>();
        Map<String, Map<String, Integer>> data = new LinkedHashMap<>();

        while (rs.next()) {
            String cat = rs.getString("Category");
            categories.add(cat);

            Map<String, Integer> map = new LinkedHashMap<>();
            map.put("Allocated", rs.getInt("Allocated"));
            map.put("Attempted", rs.getInt("Attempted"));
            map.put("Un-attempted", rs.getInt("Unattempted"));
            map.put("Connected", rs.getInt("Connected"));
            map.put("Not Connected", rs.getInt("NotConnected"));
            data.put(cat, map);
        }

        rs.close();
        stmt.close();

        categories.add("Total");

        String[] metrics = {"Allocated", "Attempted", "Un-attempted", "Connected", "Not Connected", "Contactability"};

        CellStyle headerStyle = wb.createCellStyle();
        Font boldFont = wb.createFont();
        boldFont.setBold(true);
        headerStyle.setFont(boldFont);
        headerStyle.setFillForegroundColor(IndexedColors.SKY_BLUE.getIndex());
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        headerStyle.setAlignment(HorizontalAlignment.CENTER);

        CellStyle percentStyle = wb.createCellStyle();
        percentStyle.setDataFormat(wb.createDataFormat().getFormat("0.00%"));

        Row header = sheet.createRow(0);
        header.createCell(0).setCellValue(groupColumn.equals("calling_language") ? "Language" : "Zone");
        header.getCell(0).setCellStyle(headerStyle);

        int colIndex = 1;
        for (String c : categories) {
            Cell cell = header.createCell(colIndex++);
            cell.setCellValue(c == null ? "Unknown" : c);
            cell.setCellStyle(headerStyle);
        }

        int rowNum = 1;
        for (String metric : metrics) {
            Row row = sheet.createRow(rowNum++);
            Cell metricCell = row.createCell(0);
            metricCell.setCellValue(metric);
            metricCell.setCellStyle(headerStyle);

            double total = 0;
            int col = 1;

            for (int i = 0; i < categories.size() - 1; i++) {
                String cat = categories.get(i);
                Map<String, Integer> vals = data.get(cat);
                double val = 0;

                if (vals != null) {
                    if (metric.equals("Contactability")) {
                        double connected = vals.get("Connected");
                        double attempted = vals.get("Attempted");
                        val = attempted > 0 ? (connected / attempted) : 0; 
                    } else {
                        val = vals.get(metric) != null ? vals.get(metric) : 0;
                    }
                }

                total += metric.equals("Contactability") ? 0 : val;
                Cell cell = row.createCell(col++);
                if (metric.equals("Contactability")) {
                    cell.setCellValue(val); 
                    cell.setCellStyle(percentStyle);
                } else {
                    cell.setCellValue(val);
                }
            }

            Cell totalCell = row.createCell(col);
            if (metric.equals("Contactability")) {
                double totalConnected = 0, totalAttempted = 0;
                for (Map<String, Integer> vals : data.values()) {
                    totalConnected += vals.get("Connected");
                    totalAttempted += vals.get("Attempted");
                }
                double contact = totalAttempted > 0 ? (totalConnected / totalAttempted) : 0;
                totalCell.setCellValue(contact);
                totalCell.setCellStyle(percentStyle);
            } else {
                totalCell.setCellValue(total);
            }
        }

        for (int i = 0; i <= categories.size(); i++) {
            sheet.autoSizeColumn(i);
        }
    }

    private static void sendEmailWithAttachment(Connection conn,File file, String firstOfMonth, String toDate) {
    	List<String> emailList = new ArrayList<>();
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT email FROM tatacap_dpd_recipients WHERE status = 'active'")) {

            while (rs.next()) {
                emailList.add(rs.getString("email"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (emailList.isEmpty()) {
            System.out.println("⚠️ No active recipients found in database!");
            return;
        }

        String TO = String.join(",", emailList);
        final String SMTP_HOST = "email-smtp.eu-west-1.amazonaws.com";
        final String FROM = "info@ikontel.com";
        //String TO = "sudeshna@ikontel.com,panchami.c@ikontel.com,priti.chaturvedi@ikontel.com,vijaykumar@ikontel.com";
        final String SMTP_USERNAME = "AKIAJXDE5LZYJEHFLACQ";
        final String SMTP_PASSWORD = "Ai0zhtdrRG065i8+xdUAAMa9I7U/xvxmJ+Oc3tHlqZCb";

        Properties props = new Properties();
        props.put("mail.transport.protocol", "smtp");
        props.put("mail.smtp.host", SMTP_HOST);
        props.put("mail.smtp.port", "465");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.ssl.enable", "true");
        props.put("mail.smtp.socketFactory.port", "465");
        props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");

        Session session = Session.getInstance(props,
                new Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(SMTP_USERNAME, SMTP_PASSWORD);
                    }
                });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(FROM));

            String[] recipientList = TO.split(",");
            InternetAddress[] toAddresses = new InternetAddress[recipientList.length];
            for (int i = 0; i < recipientList.length; i++) {
                toAddresses[i] = new InternetAddress(recipientList[i].trim());
            }
            message.setRecipients(Message.RecipientType.TO, toAddresses);

            message.setSubject("TATACAP MFI PDM RPT - " + firstOfMonth + " to " + toDate);

            MimeBodyPart textPart = new MimeBodyPart();
            textPart.setText("Dear Team,\n\nPlease find attached the PDM report from " + firstOfMonth + " to " + toDate + ".");

            MimeBodyPart attachmentPart = new MimeBodyPart();
            attachmentPart.attachFile(file);

            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(textPart);
            multipart.addBodyPart(attachmentPart);
            message.setContent(multipart);

            Transport.send(message);
            System.out.println("Email sent successfully!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
