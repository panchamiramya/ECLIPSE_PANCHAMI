import java.io.ByteArrayOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.mail.*;
import javax.mail.internet.*;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class TataCapEkanshDispositionMailExcel {

    public static void main(String[] args) {
        Connection conn = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(
                "jdbc:mysql://172.31.43.6:3306/tclmfi?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Asia/Kolkata",
                "reportnha",
                "India@456"
            );

            DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
            String toDate = df.format(new Date());
            String firstOfMonth = toDate.substring(0, 8) + "01";
            String subject = "TATACAP MFI Ekansh Disposition Wise Count (" + firstOfMonth + " to " + toDate + ")";

            String sql = "SELECT disposition AS Disposition, COUNT(*) AS Count " +
                         "FROM customer_info_call_history " +
                         "WHERE created_on BETWEEN '" + firstOfMonth + " 00:00:00' AND '" + toDate + " 23:59:59' AND campaign_name LIKE '%Ekansh%' " +
                         "GROUP BY disposition ORDER BY disposition,Count DESC";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            Workbook workbook = new XSSFWorkbook();
            Sheet sheet = workbook.createSheet("Disposition Report");

            CellStyle headerStyle = workbook.createCellStyle();
            Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerStyle.setFont(headerFont);
            headerStyle.setFillForegroundColor(IndexedColors.SKY_BLUE.getIndex());
            headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

            Row header = sheet.createRow(0);
            header.createCell(0).setCellValue("Disposition");
            header.createCell(1).setCellValue("Count");
            header.getCell(0).setCellStyle(headerStyle);
            header.getCell(1).setCellStyle(headerStyle);

            int rowIndex = 1;
            int total = 0;
            while (rs.next()) {
                Row row = sheet.createRow(rowIndex++);
                row.createCell(0).setCellValue(rs.getString("Disposition"));
                int count = rs.getInt("Count");
                row.createCell(1).setCellValue(count);
                total += count;
            }

            Row totalRow = sheet.createRow(rowIndex);
            CellStyle totalStyle = workbook.createCellStyle();
            Font boldFont = workbook.createFont();
            boldFont.setBold(true);
            totalStyle.setFont(boldFont);
            totalRow.createCell(0).setCellValue("Total");
            totalRow.createCell(1).setCellValue(total);
            totalRow.getCell(0).setCellStyle(totalStyle);
            totalRow.getCell(1).setCellStyle(totalStyle);

            sheet.autoSizeColumn(0);
            sheet.autoSizeColumn(1);

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            workbook.write(baos);
            workbook.close();

            // ======= FETCH EMAIL RECIPIENTS DYNAMICALLY =======
            List<String> emailList = new ArrayList<>();
            String emailSql = "SELECT email FROM tatacap_dpd_recipients WHERE status = 'active'";
            ResultSet emailRs = stmt.executeQuery(emailSql);

            while (emailRs.next()) {
                emailList.add(emailRs.getString("email"));
            }

            if (emailList.isEmpty()) {
                System.out.println("No active recipients found!!.");
                return;
            }

            String to = String.join(",", emailList);
            
            String host = "email-smtp.eu-west-1.amazonaws.com";
            String from = "info@ikontel.com";
            //String to = "sudeshna@ikontel.com,panchami.c@ikontel.com,priti.chaturvedi@ikontel.com,vijaykumar@ikontel.com";
            final String SMTP_USERNAME = "AKIAJXDE5LZYJEHFLACQ";
            final String SMTP_PASSWORD = "Ai0zhtdrRG065i8+xdUAAMa9I7U/xvxmJ+Oc3tHlqZCb";

            Properties props = new Properties();
            props.put("mail.transport.protocol", "smtp");
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.port", "465");
            props.put("mail.smtp.host", host);
            props.put("mail.smtp.socketFactory.port", "465");
            props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
            props.put("mail.smtp.ssl.protocols", "TLSv1.2");

            Session session = Session.getInstance(props, new Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(SMTP_USERNAME, SMTP_PASSWORD);
                }
            });

            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
            message.setSubject(subject);

            MimeBodyPart messageBodyPart = new MimeBodyPart();
            String htmlBody = "<p>Dear Team,</p>"
                    + "<p>Please find attached the Disposition Wise Count report from <b>" + firstOfMonth + "</b> to <b>" + toDate + "</b>.</p>";
            messageBodyPart.setContent(htmlBody, "text/html; charset=utf-8");

            MimeBodyPart attachmentPart = new MimeBodyPart();
            attachmentPart.setFileName("TATACAPMFI_Ekansh_Disposition_Report_" + toDate + ".xlsx");
            attachmentPart.setContent(baos.toByteArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(messageBodyPart);
            multipart.addBodyPart(attachmentPart);

            message.setContent(multipart);
            Transport.send(message);

            System.out.println("Mail sent successfully");

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Failed to send mail.");
        } finally {
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }
    }
}
