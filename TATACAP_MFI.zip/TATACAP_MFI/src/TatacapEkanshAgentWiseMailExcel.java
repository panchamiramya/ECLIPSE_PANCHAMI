import java.io.ByteArrayOutputStream;
import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;

import javax.mail.*;
import javax.mail.internet.*;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class TatacapEkanshAgentWiseMailExcel {

    public static void main(String[] args) {
        Connection conn = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(
                    "jdbc:mysql://172.31.43.6:3306/tclmfi?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Asia/Kolkata",
                    "reportnha",
                    "India@456"
            );

            DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
            String toDate = df.format(new Date());
            Calendar cal = Calendar.getInstance();
            cal.setTime(df.parse(toDate));
            int today = cal.get(Calendar.DAY_OF_MONTH);
            String firstOfMonth = toDate.substring(0, 8) + "01";

            String subject = "TATACAP MFI EKANSH Agent Wise Report (" + firstOfMonth + " to " + toDate + ")";

            String sql = "SELECT agent_name, DAY(created_on) AS day, COUNT(*) AS count " +
                         "FROM customer_info_call_history " +
                         "WHERE created_on BETWEEN '" + firstOfMonth + " 00:00:00' AND '" + toDate + " 23:59:59' AND campaign_name LIKE '%Ekansh%'" +
                         "GROUP BY agent_name, DAY(created_on) " +
                         "ORDER BY agent_name, day";

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            TreeSet<String> agents = new TreeSet<>();
            Map<String, Map<Integer, Integer>> data = new HashMap<>();

            while (rs.next()) {
                String agent = rs.getString("agent_name");
                int day = rs.getInt("day");
                int count = rs.getInt("count");

                agents.add(agent);
                data.computeIfAbsent(agent, k -> new HashMap<>()).put(day, count);
            }

            Workbook workbook = new XSSFWorkbook();
            Sheet sheet = workbook.createSheet("Agent Wise Report");

            CellStyle headerStyle = workbook.createCellStyle();
            Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerStyle.setFont(headerFont);
            headerStyle.setFillForegroundColor(IndexedColors.SKY_BLUE.getIndex());
            headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

            CellStyle boldStyle = workbook.createCellStyle();
            Font boldFont = workbook.createFont();
            boldFont.setBold(true);
            boldStyle.setFont(boldFont);

            Row header = sheet.createRow(0);
            header.createCell(0).setCellValue("Agent Name");
            for (int d = 1; d <= today; d++) {
                header.createCell(d).setCellValue(d);
                header.getCell(d).setCellStyle(headerStyle);
            }
            header.createCell(today + 1).setCellValue("Total");
            header.getCell(0).setCellStyle(headerStyle);
            header.getCell(today + 1).setCellStyle(headerStyle);

            int rowIndex = 1;
            int[] dayTotals = new int[today];
            int grandTotal = 0;

            for (String agent : agents) {
                Row row = sheet.createRow(rowIndex++);
                row.createCell(0).setCellValue(agent);
                int agentTotal = 0;

                for (int d = 1; d <= today; d++) {
                    int count = data.getOrDefault(agent, Collections.emptyMap()).getOrDefault(d, 0);
                    row.createCell(d).setCellValue(count);
                    agentTotal += count;
                    dayTotals[d - 1] += count;
                }

                row.createCell(today + 1).setCellValue(agentTotal);
                row.getCell(today + 1).setCellStyle(boldStyle);
                grandTotal += agentTotal;
            }

            Row totalRow = sheet.createRow(rowIndex);
            totalRow.createCell(0).setCellValue("Total");
            totalRow.getCell(0).setCellStyle(boldStyle);

            for (int d = 1; d <= today; d++) {
                Cell cell = totalRow.createCell(d);
                cell.setCellValue(dayTotals[d - 1]);
                cell.setCellStyle(boldStyle);
            }
            Cell grandTotalCell = totalRow.createCell(today + 1);
            grandTotalCell.setCellValue(grandTotal);
            grandTotalCell.setCellStyle(boldStyle);

            for (int i = 0; i <= today + 1; i++) {
                sheet.autoSizeColumn(i);
            }

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            workbook.write(baos);
            workbook.close();
            
            // ======= FETCH EMAIL RECIPIENTS DYNAMICALLY =======
            List<String> emailList = new ArrayList<>();
            String emailSql = "SELECT email FROM tatacap_dpd_recipients WHERE status = 'active'";
            ResultSet emailRs = stmt.executeQuery(emailSql);

            while (emailRs.next()) {
                emailList.add(emailRs.getString("email"));
            }

            if (emailList.isEmpty()) {
                System.out.println("No active recipients found!!.");
                return;
            }

            String to = String.join(",", emailList);	
            
            String host = "email-smtp.eu-west-1.amazonaws.com";
            String from = "info@ikontel.com";
            //String to = "sudeshna@ikontel.com,panchami.c@ikontel.com,priti.chaturvedi@ikontel.com,vijaykumar@ikontel.com";
            final String SMTP_USERNAME = "AKIAJXDE5LZYJEHFLACQ";
            final String SMTP_PASSWORD = "Ai0zhtdrRG065i8+xdUAAMa9I7U/xvxmJ+Oc3tHlqZCb";

            Properties props = new Properties();
            props.put("mail.transport.protocol", "smtp");
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.port", "465");
            props.put("mail.smtp.host", host);
            props.put("mail.smtp.socketFactory.port", "465");
            props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
            props.put("mail.smtp.ssl.protocols", "TLSv1.2");

            Session session = Session.getInstance(props, new Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(SMTP_USERNAME, SMTP_PASSWORD);
                }
            });

            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
            message.setSubject(subject);

            MimeBodyPart messageBodyPart = new MimeBodyPart();
            String htmlBody = "<p>Dear Team,</p>"
                    + "<p>Please find attached the Agent Wise report from <b>" + firstOfMonth + "</b> to <b>" + toDate + "</b>.</p>";
            messageBodyPart.setContent(htmlBody, "text/html; charset=utf-8");

            MimeBodyPart attachmentPart = new MimeBodyPart();
            attachmentPart.setFileName("TATACAPMFI_Ekansh_Agent_Wise_Report_" + toDate + ".xlsx");
            attachmentPart.setContent(baos.toByteArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(messageBodyPart);
            multipart.addBodyPart(attachmentPart);

            message.setContent(multipart);
            Transport.send(message);

            System.out.println("Mail sent successfully");

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Failed to send mail.");
        } finally {
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }
    }
}
