<%@page import="helper.WhatsAppMessage"%>
<%@page import="java.util.Random"%>
<%@page import="java.util.Calendar"%>
<%@page import="java.util.UUID"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.text.DateFormat"%>
<%@page import="java.lang.Math.*"%>
<%@page import="java.io.OutputStream"%>
<%@page import="java.io.FileOutputStream"%>
<%@page import="java.io.File"%>
<%@page import="java.io.InputStream"%>
<%@page import="javax.naming.InitialContext"%>
<%@page import="javax.naming.Context"%>
<%@ page import = "java.util.Map" %>
<%@ page import = "java.util.Enumeration" %>
<%@ page import = "org.json.JSONObject" %>
<%@ page import = "org.json.JSONArray" %>
<%@ page import = "java.net.HttpURLConnection" %>
<%@ page import = "java.net.URL" %>
<%@ page import = "java.net.URLConnection" %>
<%@ page import = "java.net.URLDecoder" %>
<%@ page import = "java.net.URLEncoder" %>
<%@ page import = "javax.net.ssl.HttpsURLConnection" %>













<%@page contentType="text/html" pageEncoding="UTF-8"%> <%@page import="javax.sql.DataSource"%><%@page import="java.io.*"%>  <%@page import="java.sql.*" %><%@page import="org.json.*" %>

<%!
public String sendMessage(String session_id,String msisdn, String msg,String whatsapp_token,Connection conn)
{
	 
		  String contact_id=msisdn;
	
		  
      String json="{\n"
      		+ "  \"recipient_type\": \"individual\",\n"
      		+ "   \"type\": \"text\",\n"
      		+ "  \"to\": \""+contact_id+"\",\n"
      		+ "\"text\": {\n"
      		+ "    \"body\": \""+msg+"\"\n"
      		+ "  }\n"
      		+ "  \n"
      		+ "  \n"
      		+ "  \n"
      		+ " \n"
      		+ "  \n"
      		+ "}";
    
      return sendWhatsappMsg(session_id, json,msisdn,whatsapp_token,conn);
  }

public  String getResponseWhatsapp(String session_id,String json,String whatsapp_key)
{
    String xml=json;
    String res="";
     BufferedReader in=null;
/*    */       OutputStream out=null;
/*    */       Writer wout=null;
String url="https://waba.360dialog.io/v1/messages";
//   OutputStream out=null;
    try {
           URL url1 = new URL(url);
           System.out.println("url="+url+json);
/* 50 */       URLConnection connection = url1.openConnection();
/* 51 */       HttpsURLConnection httpConn = ((HttpsURLConnection)connection);
/* 52 */       httpConn.setReadTimeout(20000);
/* 53 */       httpConn.setConnectTimeout(20000);
/* 55 */       httpConn.setRequestProperty("d360-api-key", whatsapp_key);
/* 55 */       httpConn.setRequestProperty("cache-control", "no-cache");
            httpConn.setRequestProperty("content-type", "application/json");



/* 56 */       httpConn.setRequestMethod("POST");
           httpConn.setDoInput(true);
/* 57 */       httpConn.setDoOutput(true);

out = httpConn.getOutputStream();
out.write(xml.getBytes());
           //httpConn.connect();
/* 58 */      


/*    */
/* 60 */      // out = httpConn.getOutputStream();
/* 61 */      // wout = new OutputStreamWriter(out);
/* 62 */      // wout.flush();
//out = httpConn.getOutputStream();
//out.write(xml.getBytes());
           System.out.println("code="+httpConn.getResponseCode());
          
/* 64 */       InputStreamReader isr = new InputStreamReader(httpConn.getInputStream());
/*    */
/* 66 */       in = new BufferedReader(isr);
/* 67 */       String temp = "";
/* 68 */       res = "";
/* 69 */       while ((temp = in.readLine()) != null)
/* 70 */         res += temp;
           System.out.println("res_ok="+res);
           return res;
         
           
            

/*    */     }
/*    */     catch (Exception ex) {
	          
/* 73 */       ex.printStackTrace();
return "IOEXP";
/* 74 */
/*    */     }
/*    */     finally
/*    */     {
/*    */       try {
/* 79 */         in.close();
/* 80 */         wout.close();
/* 81 */         out.close();
/*    */       }
/*    */       catch (Exception tx)
/*    */       {
/*    */       }
/*    */     }
/*    */
/*    */



}


public String  sendWhatsappMsg(String session_id, String json,String msisdn,String whatsapp_token,Connection conn)
{
	try
	{
		
		String id="";
	
	String resp= getResponseWhatsapp(session_id, json,whatsapp_token);
	 JSONObject jb = new JSONObject(resp);
	    
	    JSONArray ids= jb.getJSONArray("messages");
		  if ( ids ==null || ids.length()==0)
		  {
			 
				String sql ="insert into whatsapp.outgoing_message(session_id,msg,to_msisdn) values(?,?,?)";
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setString(1, session_id);
				ps.setString(2, json);
				ps.setString(3, msisdn);

				ps.executeUpdate();
			  return "error";
		  }
		  else
		  {
			  JSONObject jb1 = ids.getJSONObject(0);
			 
				   id= jb1.getString("id");
				 
					String sql ="insert into whatsapp.outgoing_message(session_id,msg,msg_id,to_msisdn) values(?,?,?,?)";
					PreparedStatement ps = conn.prepareStatement(sql);
					ps.setString(1, session_id);
					ps.setString(2, json);
					ps.setString(3, id);
					ps.setString(4, msisdn);


					ps.executeUpdate();
				   return resp;
			  
			
		  }
	}
	catch( Exception ex)
	{
		ex.printStackTrace();
		return "error";
	}
	
}

%>
<%
response.setContentType("text/html");
response.addHeader("Freeflow","FC");
java.util.Date mydt = new java.util.Date();
response.setDateHeader("Date", mydt.getTime());
Connection conn=null;
Context ctx = new InitialContext();

 if (ctx == null)
 {
    throw new Exception("Boom - No Context");
 }
 Context envCtx = (Context) ctx.lookup("java:comp/env");

 DataSource ds =(DataSource)envCtx.lookup("jdbc/whatsapp_tatacap");
 
  
    if (ds != null) {
        try{
        conn = ds.getConnection();
            }catch(Exception ex)
                         {
                           
                       }

 }

%>
<%!

%>
<%
String user_name="";
JSONObject jout= new JSONObject();
JSONObject jres=new JSONObject();
JSONObject jstat= new JSONObject();


try {
	
String reg_id="";
String email_id="";
String report_date="";


//st= "select wavfilename from upload_wavfile_log"
String msisdn=request.getParameter("msisdn");
String template_id=request.getParameter("template_id").trim();
String subchannel=request.getParameter("subchannel");
String amount =request.getParameter("amount");
String name =request.getParameter("name");
String due_date =request.getParameter("due_date");
String loan_type =request.getParameter("loan_type");
String tclink = request.getParameter("tclink");
String param4 = request.getParameter("param4");
String roi = request.getParameter("roi");
String product = request.getParameter("product");
String rcm_name = request.getParameter("rcm_name");
String rcm_designation = request.getParameter("rcm_designation");
String rcm_phone = request.getParameter("rcm_phone");
String ref_date = request.getParameter("ref_date");

String account_id = application.getInitParameter("account_id");

String lan=request.getParameter("lan");
String audience_id=request.getParameter("audience_id");
String campaign_id=request.getParameter("campaign_id");
String journey_id=request.getParameter("journey_id");
String authtoken=request.getParameter("authtoken");
if ( !authtoken.equals("XYz12345678@897"))
{
	jstat.put("statusCode", "1");
    jstat.put("errorCode","100");
    jstat.put("errorMessage","Invalid credential");
    jres.put("status", jstat);
    jout.put("result", jres);
   out.println( jout.toString());
   return;
	
}

String whatsapp_token="";

Statement st1= conn.createStatement();
String uuid= UUID.randomUUID().toString();
String sql="insert into whatsapp_sfmc_req(msisdn,template_id,channel,subchannel,amount,lan,audience_id,campaign_id,journey_id,uuid,name,due_date,loan_type)"+
"values('"+msisdn+"','"+template_id+"','"+"whatsapp"+"','"+subchannel+"','"+amount+"','"+lan+"','"+audience_id+"','"+campaign_id+
		"','"+journey_id+"','"+uuid+"','"+name+"','"+due_date+"','"+loan_type+"')";
System.out.println("SQL="+sql);

st1.executeUpdate(sql);

WhatsAppMessage wa = new WhatsAppMessage();
if (lan == null) lan = "";
String last_4_digit = lan.length() > 4 ? lan.substring(lan.length() - 4) : lan;

String resp="";


if (template_id.equals("quickpay_welcome")) {
	resp = wa.sendQuickPaymsg(msisdn, last_4_digit, amount, "send_quickpay", conn);
} else if (template_id.equals("tatacap_bktx_payment")) {
	resp = wa.sendQuickPaymsg(msisdn, last_4_digit, amount, "tatacap_bktx_payment", conn);

} else if (template_id.equals("tatacap_bucket1plus_payment")) {
	resp = wa.sendQuickPaymsg(msisdn, last_4_digit, amount, "tatacap_bucket1plus_payment", conn);
	

} else if (template_id.equals("gnpa1")) {
	resp = wa.sendQuickPaymsg12(msisdn, last_4_digit, amount, "gnpa1", tclink,conn);


} else if (template_id.equals("reminder_predictive_1")) {
	//ArrayList<String > arr = new ArrayList<String>();
	// resp=wa.sendQuickPaymsg(msisdn,reminder_predictive_1, lan, amount,due_date);

} else if (template_id.equals("emi_rem_low_risk")) {
	resp = wa.sendEmiLow(msisdn, amount, due_date, last_4_digit, account_id, conn);

} else if (template_id.equals("emi_rem_mid_risk")) {
	resp = wa.sendEMIMid(msisdn, last_4_digit, amount, due_date, account_id, conn);

} else if (template_id.equals("emi_rem_high_risk")) {
	resp = wa.sendEMIHigh(msisdn, amount, last_4_digit, due_date, account_id, conn);

} else if (template_id.equals("rebanking_sms")) {
	resp = wa.sendRebanking(msisdn, amount, lan, due_date, tclink, account_id, conn);

} else if (template_id.equals("customer_awarness")) {
	resp = wa.sendCustAwarness(msisdn, name, loan_type, lan, tclink, account_id, conn);

} else if (template_id.equals("paynimo_link")) {
	resp = wa.sendPaynimoLink(msisdn, lan, tclink, account_id, conn);

} else if (template_id.equals("bounce_mailer")) {
	resp = wa.sendBounceMail(msisdn, amount, last_4_digit, tclink, account_id, conn);

} else if (template_id.equals("not_banked_sms__email")) {
	resp = wa.sendNotBanked(msisdn, lan, tclink, account_id, conn);

} else if (template_id.equals("apology_mailer")) {
	resp = wa.sendApology(msisdn, ref_date, account_id, conn);

} else if (template_id.equals("charges_recovery")) {
	resp = wa.sendChargesRecovery(msisdn, tclink, lan, account_id, conn);

} else if (template_id.equals("3by3_emi")) {
	resp = wa.send3By3(msisdn, lan, tclink, account_id, conn);

} else if (template_id.equals("customer_awarness_2")) {
	resp = wa.sendCustAwarness2(msisdn, account_id, conn);

} else if (template_id.equals("npa_stamped")) {
	resp = wa.sendNpaStamped(msisdn, lan, rcm_name, rcm_designation, rcm_phone, tclink, account_id, conn);

} else if (template_id.equals("woff_stamped")) {
	resp = wa.sendWoffStamped(msisdn, lan, rcm_name, rcm_designation, rcm_phone, tclink, account_id, conn);

} else if (template_id.equals("emi_rem_low_risk_gt_1")) {
	resp = wa.sendEMILowGt(msisdn, last_4_digit, amount, due_date, account_id, conn);

} else if (template_id.equals("emi_rem_mid_risk_gt")) {
	resp = wa.sendEMIMidGt(msisdn, last_4_digit, amount, due_date, account_id, conn);

} else if (template_id.equals("emi_rem_high_risk_gt")) {
	resp = wa.sendEMIHighGt(msisdn, last_4_digit, amount, due_date, account_id, conn);

} else if (template_id.equals("emi_rem_low_risk_mh")) {
	resp = wa.sendEMILowMH(msisdn, last_4_digit, amount, due_date, account_id, conn);

} else if (template_id.equals("emi_rem_mid_risk_mh")) {
	resp = wa.sendEMIMidMH(msisdn, last_4_digit, amount, due_date, account_id, conn);

} else if (template_id.equals("emi_rem_high_risk_mh")) {
	resp = wa.sendEMIHighMH(msisdn, last_4_digit, amount, due_date, account_id, conn);

} else if (template_id.equals("emi_overdue")) {
	resp = wa.sendEMIOverDue(msisdn, tclink, account_id, conn);

} else if (template_id.equals("collection_page_1")) {
	resp = wa.sendCollPg1(msisdn, tclink, lan, account_id, conn);

} else if (template_id.equals("collection_page_2")) {
	resp = wa.sendCollPg2(msisdn, lan, tclink, account_id, conn);

} else if (template_id.equals("collection_page_3")) {
	resp = wa.sendCollPg3(msisdn, lan, tclink, account_id, conn);

} else if (template_id.equals("collection_page_4")) {
	resp = wa.sendCollPg4(msisdn, lan, tclink, account_id, conn);

} else if (template_id.equals("collection_page_5")) {
	resp = wa.sendCollPg5(msisdn, lan, tclink, account_id, conn);

} else {
	throw new Exception("Invalid template_id:" + template_id);
}

sql = "update whatsapp_sfmc_req set resp=? where uuid=?";
PreparedStatement ps = conn.prepareStatement(sql);
ps.setString(1, resp);
ps.setString(2, uuid);
ps.executeUpdate();
jstat.put("statusCode", "0");

jres.put("status", jstat);
jout.put("result", jres);
out.println(jout.toString());
return;

} catch (Exception e) {

e.printStackTrace();

jstat.put("statusCode", "1");
jstat.put("errorCode", "101");
jstat.put("errorMessage", e.getMessage());
jres.put("status", jstat);
jout.put("result", jres);
out.println(jout.toString());

/* 18 */
/*    */ } finally {
try {
	conn.close();
} catch (Exception exx) {

}
}
%>

