<%@page import="org.json.JSONObject"%>
<%@page import="helper.MyMenu"%>
<%@page import="java.util.Random"%>
<%@page import="java.util.Calendar"%>
<%@page import="helper.WhatsAppMessage"%>

<%@page import="java.util.UUID"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.text.DateFormat"%>
<%@page import="java.lang.Math.*"%>
<%@page import="java.io.OutputStream"%>
<%@page import="java.io.FileOutputStream"%>
<%@page import="java.io.File"%>
<%@page import="java.io.InputStream"%>
<%@page import="javax.naming.InitialContext"%>
<%@page import="javax.naming.Context"%>
<%@ page import="java.util.Map"%>
<%@ page import="java.util.Date"%>


<%@ page import="java.util.Enumeration"%>
<%@ page import="java.util.ArrayList"%>

<%@ page import="org.json.simple.JSONArray"%>




<%@ page import="org.json.simple.parser.JSONParser"%>







<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="javax.sql.DataSource"%><%@page import="java.io.*"%>
<%@page import="java.sql.*"%>
<%
	response.setContentType("text/html");
response.addHeader("Freeflow", "FC");
java.util.Date mydt = new java.util.Date();
response.setDateHeader("Date", mydt.getTime());
Connection conn = null;
Context ctx = new InitialContext();

if (ctx == null) {
	throw new Exception("Boom - No Context");
}
Context envCtx = (Context) ctx.lookup("java:comp/env");

DataSource ds = (DataSource) envCtx.lookup("jdbc/whatsapp_tatacap");

if (ds != null) {
	try {
		conn = ds.getConnection();
	} catch (Exception ex) {

	}

}
%>
<%
	String user_name = "";

final String ACCOUNT_SID = "AC01f0c97858ce79906d4855d840ef32cc";
final String AUTH_TOKEN = "59bfedb7bd610fc04cf9ea98f01ca22a";
final String campaign_name="quickpay";
final String db_userid="wtatacap";
final String db_passwd="tatacap123";


try {
	String authtoken=application.getInitParameter("authtoken");
	String account_id=application.getInitParameter("account_id");
	DateFormat df = new SimpleDateFormat("yyyy-MM-dd");

	Map<String, String[]> parameters = request.getParameterMap();
	for (String parameter : parameters.keySet()) {
		{
	String[] values = parameters.get(parameter);
	System.out.println(values[0]);
	//your code here
		}
	}

	Enumeration<String> headerNames = request.getHeaderNames();

	while (headerNames.hasMoreElements()) {

		String headerName = headerNames.nextElement();
		System.out.print(headerName + " = ");
		String headerValue = request.getHeader(headerName);
		System.out.println(headerValue);
	}

	String uid = UUID.randomUUID().toString();

	String reg_id = "";
	String msisdn = "";
	String email_id = "";
	String report_date = "";

	//st= "select wavfilename from upload_wavfile_log"
			
			
InputStream is = request.getInputStream();
String  cldfilename="";

JSONParser jsonParser = new JSONParser();
org.json.simple.JSONObject jsonObject = (org.json.simple.JSONObject)jsonParser.parse(
      new InputStreamReader(is, "UTF-8"));

//{"statuses":[{"id":"gBEGkZdBQRCHAglCL08Zx7t5hss","conversation":{"id":"bee2d03aee293c9614298433b48ea479"},"pricing":{"pricing_model":"NBP","billable":true},"recipient_id":"919741411087","status":"delivered","timestamp":"1627904134"}]}
System.out.println(jsonObject.toString());

org.json.simple.JSONArray jarr=null;
try
{
	//org.json.JSONObject jbsession=new org.json.JSONObject();
	//jbsession =new org.json.JSONObject();
	org.json.simple.JSONArray jenrty=(	org.json.simple.JSONArray) jsonObject.get("entry");
	org.json.simple.JSONObject jb1=(org.json.simple.JSONObject)jenrty.get(0);
	org.json.simple.JSONArray jarr_chgs= (org.json.simple.JSONArray) jb1.get("changes");
	org.json.simple.JSONObject jb2=(org.json.simple.JSONObject)jarr_chgs.get(0);
	org.json.simple.JSONObject values =(org.json.simple.JSONObject)jb2.get("value");

	
//	jarr=(org.json.simple.JSONArray)jsonObject.get("statuses");

		
	
		
		
	jarr=(org.json.simple.JSONArray)values.get("statuses");
	//jarr=(org.json.simple.JSONArray)jb2.get("statuses");

	
	if ( jarr==null)
	{
		
		 jenrty=(	org.json.simple.JSONArray) jsonObject.get("entry");
	jb1=(org.json.simple.JSONObject)jenrty.get(0);
		jarr_chgs= (org.json.simple.JSONArray) jb1.get("changes");
		
		System.out.println("jarr_chgs"+jarr_chgs.toString());
		
		 jb2=(org.json.simple.JSONObject)jarr_chgs.get(0);
		System.out.println("JSONObject"+jb2.toString());
		
	//	((org.json.simple.JSONObject)jarr_chgs.get(0)).get("messages")
		
		 values =(org.json.simple.JSONObject)jb2.get("value");
		
	
		
		
		org.json.simple.JSONArray jarr_msgs=(org.json.simple.JSONArray)values.get("messages");
		
		org.json.simple.JSONObject jb=(org.json.simple.JSONObject)jarr_msgs.get(0);
		String msgid="";
		try
		{
		
		org.json.simple.JSONObject jbcontext=(org.json.simple.JSONObject)jb.get("context");
		 msgid=(String)jbcontext.get("id");
		}
		catch ( Exception ex)
		{
			
		}
		String from=(String)jb.get("from");
		String id="";
		if ( msgid==null)
		{
	      id=(String)jb.get("id");
		}
		else
		{
			id=msgid;
		}
		
		String conversation_id="";
		try
		{
			conversation_id=(String)((org.json.simple.JSONObject)jb.get("conversation")).get("id");
		}
		catch ( Exception ex)
		{
		}

		
	
		
		String body=jb.toJSONString();
		String type="";
		String status="";
		if (jb.get("status")==null )
		{
		   type="incoming";
		   status="";
		}
		else
		{
			type="outgoing";
			status=(String)jb.get("status");
			 WhatsAppMessage wa = new WhatsAppMessage();
			
			 org.json.JSONObject	js= new org.json.JSONObject();
			 if (!conversation_id.equals("") )
			 {
			// js.put("session_id",conversation_id);
			// wa.updateSessionInfo(from, conn, js,account_id);
			 }
				
			
		
			
			
		}

	

	String pssql = "insert into incoming_message_axis(from_msisdn,message,msg_id,call_type,msg_status) values(?,?,?,?,?)";
	PreparedStatement ps = conn.prepareStatement(pssql);
	ps.setString(1, from);
	ps.setString(2, body);
	ps.setString(3, id);
	ps.setString(4, type);
	ps.setString(5, status);
	ps.executeUpdate();

	if (type.equals("incoming")) {
		WhatsAppMessage wa = new WhatsAppMessage();
		String resp = wa.getIntent(body, from, conn,account_id);

		System.out.println("RESP=" + resp);
		if (resp.startsWith("menu")) {
			String menu = resp.split("\\:")[1];

			System.out.println("MENU Selected:" + menu);
			if (menu.equals("invalid")) {
				wa.sendMessage360("121212122", from, "You have entered an invalid value",
						WhatsAppMessage.whatsapp_key, conn,campaign_name,account_id);

			}
			// The menu is invoked from a outgoing whatsapp campaign

			if (menu.equals("paynow")) {
				new Thread(new Runnable() {

					public void run() {
						Connection conn = null;
						try {
							Class.forName("com.mysql.jdbc.Driver");
							conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/whatsapp_tatacap",
									db_userid, db_passwd);
							org.json.JSONObject jbsession = wa.getSessionInfo(from, conn,account_id);

							org.json.JSONArray jarr1 = wa.getBankDetail(from,
									jbsession.getString("session_id"));
							if (jarr1 == null || jarr1.length() == 0) {
								try {
									WhatsAppMessage wa = new WhatsAppMessage();

									wa.sendMessage360("121212122", from,
											"Sorry, there is no loan account associated with this number.",
											WhatsAppMessage.whatsapp_key, conn,campaign_name,account_id);
								} catch (Exception ex) {
									ex.printStackTrace();
								}

							} else {
								jbsession.put("proddetail", jarr1);
								wa.updateSessionInfo(from, conn, jbsession,account_id);
								ArrayList arr = new ArrayList();
								for (int i = 0; i < jarr1.length(); i++) {
									MyMenu mm = new MyMenu();
									mm.id = i + "";
									mm.product = jarr1.getJSONObject(i).getString("product");
									mm.contract_id = jarr1.getJSONObject(i).getString("contract_no");

									arr.add(mm);
								}

								String jsonw = wa.formList(from,
										"Please choose the amount you would like to pay", arr,
										"Select Loan Account", "PROD");
								//String json1=wa.sendMessage360("121222", from, "Hi, Welcome  to GoGas Scheme Enrollment.", WhatsAppMessage.whatsapp_key, conn);
								wa.sendWhatsappMsg("121212", jsonw, from, WhatsAppMessage.whatsapp_key, conn,campaign_name,account_id);
								return;

							}
						} catch (Exception ex1) {
							ex1.printStackTrace();
						} finally {
							try {
								conn.close();
							} catch (Exception ex) {
							}
						}

					}
				}).start();
				return;

			} else if (menu.toLowerCase().equals("stop")) { //subscriber sent "STOP" message

				// wa.sendMessage360("121212122", from,"We are facing some issue. Please try again", WhatsAppMessage.whatsapp_key, conn);
				// We need to reply immeditely respond to whatsapp, other wise it will keep on sending the message
				//Need to create a new thread and handle the message

				new Thread(new Runnable() {

					public void run() {
						Connection conn = null;
						try {
							String msg = wa.removeFromWhatsapp(from);
							if (msg.contains("consent_value")) {
								wa.sendMessage360("121212122", from,
										"We have taken your request for unsubscription from whatsapp messages. This will be processed within 2 working days.",
										WhatsAppMessage.whatsapp_key, conn,campaign_name,account_id);
							} else {

								WhatsAppMessage wa = new WhatsAppMessage();
								Class.forName("com.mysql.jdbc.Driver");
								conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/whatsapp_tatacap",
										"whatsapp", "whatsapp123");

								wa.sendMessage360("121212122", from,
										"Facing Technical Error. We will get back to you soon",
										WhatsAppMessage.whatsapp_key, conn,campaign_name,account_id);
							}
						} catch (Exception ex) {
							ex.printStackTrace();
						} finally {
							try {
								conn.close();
							} catch (Exception ex) {
							}
						}

					}
				}).start();

			} else if (menu.equals("reselectamt")) {
				//Reselect the amount.

				new Thread(new Runnable() {
					public void run() {
						Connection conn = null;
						try {
							Class.forName("com.mysql.jdbc.Driver");
							conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/whatsapp_tatacap",
									db_userid, db_passwd);

							org.json.JSONObject jbsession = wa.getSessionInfo(from, conn,account_id);
							org.json.JSONArray proddetail = jbsession.getJSONArray("proddetail");
							ArrayList arr = new ArrayList();

							int index = Integer.parseInt(jbsession.getString("selectindex"));

							MyMenu mm = new MyMenu();

							String gcid = proddetail.getJSONObject(index).getString("gcid");

							String contract_id = proddetail.getJSONObject(index).getString("contract_no");
							String COMPANY_NAME = proddetail.getJSONObject(index).getString("COMPANY_NAME");

							System.out.println("CONTRACT_CHOOSEN=" + contract_id);

							wa.sendMessage360("121212122", from,
									"Please wait while we are fetching your details",
									WhatsAppMessage.whatsapp_key, conn,campaign_name,account_id);

							org.json.JSONArray jarr1 = wa.getBankOutStandingDetailFromPG(contract_id,
									COMPANY_NAME, jbsession.getString("session_id"));
							if ( jarr1.getJSONObject(0).getString("error_code").equals("400"))
							{
								wa.sendMessage360("121212122", from,
										"There is no overdue amount in your Loan Account",
										WhatsAppMessage.whatsapp_key, conn,campaign_name,account_id);
								return;
							}
							String outstandingamt = jarr1.getJSONObject(1).getString("od");
							String due_amt = jarr1.getJSONObject(1).getString("due_amt");
							String overdueamt = jarr1.getJSONObject(1).getString("overdueAmount");
							String odcharges = jarr1.getJSONObject(1).getString("odcharges");
							String source_system = jarr1.getJSONObject(1).getString("source_system");
							// String product=jarr1.getJSONObject(0).getString("product");

							System.out.println("OUTSTANDING AMT=" + outstandingamt);

							String cust_name = proddetail.getJSONObject(index).getString("cust_name");
							String email = proddetail.getJSONObject(index).getString("email");

							String PROD_CODE = proddetail.getJSONObject(index).getString("PRODUCT_CODE");
							String product = proddetail.getJSONObject(index).getString("product");
							String contract_id1 = proddetail.getJSONObject(index).getString("contract_no");

							JSONObject pgdetail = new JSONObject();
							pgdetail.put("contract_id", contract_id);
							pgdetail.put("outstandingamt", outstandingamt);
							pgdetail.put("due_amt", due_amt);

							pgdetail.put("odcharges", odcharges);
							pgdetail.put("source_system", source_system);

							jbsession.put("pgdetail", pgdetail);
							wa.updateSessionInfo(from, conn, jbsession,account_id);

							String od_charges = "0";
							String total_amount = due_amt;
							String total_paid_total = due_amt;

							WhatsAppMessage wa = new WhatsAppMessage();
							wa.SelectAmout(from, due_amt, outstandingamt, contract_id, od_charges, cust_name,
									email, product, COMPANY_NAME, PROD_CODE, total_amount, total_paid_total,campaign_name,account_id);

						} catch (Exception ex1) {
							ex1.printStackTrace();

							try {
								WhatsAppMessage wa = new WhatsAppMessage();

								wa.sendMessage360("121212122", from,
										"Facing Technical Error. We will get back to you soon",
										WhatsAppMessage.whatsapp_key, conn,campaign_name,account_id);
							} catch (Exception ex) {
							}
						} finally {
							try {
								conn.close();
							} catch (Exception ex) {
							}
						}

					}
				}).start();


			}

			else if (menu.equals("selectamt"))

			{
				//Select the amount 
				new Thread(new Runnable() {
					public void run() {
						Connection conn = null;
						try {
							Class.forName("com.mysql.jdbc.Driver");
							conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/whatsapp_tatacap",
									db_userid, db_passwd);
							org.json.JSONObject jbsession = wa.getSessionInfo(from, conn,account_id);
							org.json.JSONArray proddetail = jbsession.getJSONArray("proddetail");
							ArrayList arr = new ArrayList();
							int index = Integer.parseInt(resp.split("\\:")[2]);

							MyMenu mm = new MyMenu();
							System.out.println("SELECTED INDEX=" + index);

							jbsession.put("selectindex", index + "");
							wa.updateSessionInfo(from, conn, jbsession,account_id);

							String gcid = proddetail.getJSONObject(index).getString("gcid");

							String contract_id = proddetail.getJSONObject(index).getString("contract_no");
							String COMPANY_NAME = proddetail.getJSONObject(index).getString("COMPANY_NAME");

							System.out.println("CONTRACT_CHOOSEN=" + contract_id);

							wa.sendMessage360("121212122", from,
									"Please wait while we are fetching your details",
									WhatsAppMessage.whatsapp_key, conn,campaign_name,account_id);

							org.json.JSONArray jarr1 = wa.getBankOutStandingDetailFromPG(contract_id,
									COMPANY_NAME, jbsession.getString("session_id"));
							
							if ( jarr1.getJSONObject(0).getString("error_code").equals("400"))
							{
								wa.sendMessage360("121212122", from,
										"There is no overdue amount in your Loan Account",
										WhatsAppMessage.whatsapp_key, conn,campaign_name,account_id);
								
								return;
							}
							
							
							String outstandingamt = jarr1.getJSONObject(1).getString("od");
							String due_amt = jarr1.getJSONObject(1).getString("due_amt");
							String overdueamt = jarr1.getJSONObject(1).getString("overdueAmount");
							String odcharges = jarr1.getJSONObject(1).getString("odcharges");
							String source_system = jarr1.getJSONObject(1).getString("source_system");
							// String product=jarr1.getJSONObject(0).getString("product");

							System.out.println("OUTSTANDING AMT=" + outstandingamt);

							String cust_name = proddetail.getJSONObject(index).getString("cust_name");
							String email = proddetail.getJSONObject(index).getString("email");
							String mobileno = proddetail.getJSONObject(index).getString("mobileno");

							String PROD_CODE = proddetail.getJSONObject(index).getString("PRODUCT_CODE");
							String product = proddetail.getJSONObject(index).getString("product");
							String contract_id1 = proddetail.getJSONObject(index).getString("contract_no");

							JSONObject pgdetail = new JSONObject();
							pgdetail.put("contract_id", contract_id);
							pgdetail.put("outstandingamt", outstandingamt);
							pgdetail.put("due_amt", due_amt);

							pgdetail.put("odcharges", odcharges);
							pgdetail.put("source_system", source_system);

							jbsession.put("pgdetail", pgdetail);
							wa.updateSessionInfo(from, conn, jbsession,account_id);

							String od_charges = "0";
							String total_amount = due_amt;
							String total_paid_total = due_amt;

							WhatsAppMessage wa = new WhatsAppMessage();
							wa.SelectAmout(from, due_amt, outstandingamt, contract_id, od_charges, cust_name,
									email, product, COMPANY_NAME, PROD_CODE, total_amount, total_paid_total,campaign_name,account_id);

							/*	 makePaymentLink(String contract_id,String amount,String cust_name,String email_id,String msisdn,
											String prod_name,String company,String product_code,String source_system,
											String od_charges,String total_amount, String paid_total, 
											String trans_type, String channel,String unique_trans_id,String return_url)*/

							/*	wa.doHeavy(from,due_amt,outstandingamt,contract_id,od_charges,cust_name,email,
										from,product,COMPANY_NAME,PROD_CODE,total_amount,total_paid_total);*/
						} catch (Exception ex1) {
							ex1.printStackTrace();

							try {
								WhatsAppMessage wa = new WhatsAppMessage();

								wa.sendMessage360("121212122", from,
										"Facing Technical Error. We will get back to you soon",
										WhatsAppMessage.whatsapp_key, conn,campaign_name,account_id);
							} catch (Exception ex) {
							}

						} finally {
							try {
								conn.close();
							} catch (Exception ex) {
							}

						}
					}
				}).start();

			}

			else if (menu.equals("CONFIRMAMNT")) {
				//confirm the amount before pay.

				org.json.JSONObject jbsession = wa.getSessionInfo(from, conn,account_id);
				MyMenu mm = new MyMenu();
				ArrayList arr = new ArrayList();

				mm.id = "0";
				mm.product = org.json.simple.JSONObject.escape("YES");
				arr.add(mm);

				mm = new MyMenu();

				mm.id = "1";

				mm.product = org.json.simple.JSONObject.escape("NO");
				arr.add(mm);

				String choosen_amt = jbsession.getString("choosen_amount");

				String jsonw = wa.formList(from,
						"Do you want to continue with the payment of Rs." + choosen_amt, arr, "Confirm",
						"CNFF");
				wa.sendWhatsappMsg("121212", jsonw, from, WhatsAppMessage.whatsapp_key, conn,campaign_name,account_id);

			} else if (menu.equals("DUEAMOUNT")) {
				//Due amount for the loan

				org.json.JSONObject jbsession =null;
				ArrayList arr = new ArrayList();

				jbsession = wa.getSessionInfo(from, conn,account_id);
				org.json.JSONArray proddetail = jbsession.getJSONArray("proddetail");

				MyMenu mm = new MyMenu();
				int index = Integer.parseInt(jbsession.getString("selectindex"));
				System.out.println("SELECTED INDEX=" + index);

				String gcid = proddetail.getJSONObject(index).getString("gcid");

				String contract_id = proddetail.getJSONObject(index).getString("contract_no");
				String COMPANY_NAME = proddetail.getJSONObject(index).getString("COMPANY_NAME");

				String cust_name = proddetail.getJSONObject(index).getString("cust_name");
				String email = proddetail.getJSONObject(index).getString("email");

				String PROD_CODE = proddetail.getJSONObject(index).getString("PRODUCT_CODE");
				String product = proddetail.getJSONObject(index).getString("product");
				String contract_id1 = proddetail.getJSONObject(index).getString("contract_no");
				JSONObject pgdetail = jbsession.getJSONObject("pgdetail");
				String mycontractid = pgdetail.getString("contract_id");
				String outstandingamt = pgdetail.getString("outstandingamt");
				String odcharges = pgdetail.getString("odcharges");

				mm.id = "0";
				mm.product = org.json.simple.JSONObject.escape("YES");
				arr.add(mm);

				mm = new MyMenu();

				mm.id = "1";

				mm.product = org.json.simple.JSONObject.escape("NO");
				arr.add(mm);

				jbsession = wa.getSessionInfo(from, conn,account_id);
				jbsession.put("choosen_amount", outstandingamt);
				wa.updateSessionInfo(from, conn, jbsession,account_id);

				String jsonw = wa.formList(from,
						"Do you want to continue with the payment of Rs." + outstandingamt, arr, "Confirm",
						"CNFF");
				wa.sendWhatsappMsg("121212", jsonw, from, WhatsAppMessage.whatsapp_key, conn,campaign_name,account_id);
			}

			else if (menu.equals("AMTCHOOSEN")) {
				//Choosen amount
				org.json.JSONObject jbsession = wa.getSessionInfo(from, conn,account_id);
				ArrayList arr = new ArrayList();

				org.json.JSONArray proddetail = jbsession.getJSONArray("proddetail");

				MyMenu mm = new MyMenu();
				int index = Integer.parseInt(jbsession.getString("selectindex"));
				System.out.println("SELECTED INDEX=" + index);

				String gcid = proddetail.getJSONObject(index).getString("gcid");

				String contract_id = proddetail.getJSONObject(index).getString("contract_no");
				String COMPANY_NAME = proddetail.getJSONObject(index).getString("COMPANY_NAME");

				String cust_name = proddetail.getJSONObject(index).getString("cust_name");
				String email = proddetail.getJSONObject(index).getString("email");

				String PROD_CODE = proddetail.getJSONObject(index).getString("PRODUCT_CODE");
				String product = proddetail.getJSONObject(index).getString("product");
				String contract_id1 = proddetail.getJSONObject(index).getString("contract_no");
				String mobileno = proddetail.getJSONObject(index).getString("mobileno").split(",")[0];

				JSONObject pgdetail = jbsession.getJSONObject("pgdetail");
				String mycontractid = pgdetail.getString("contract_id");
				String outstandingamt = pgdetail.getString("outstandingamt");
				String odcharges = pgdetail.getString("odcharges");
				String source_system = pgdetail.getString("source_system");
				String due_amt = pgdetail.getString("due_amt");

				System.out.println("CONTRACT_CHOOSEN=" + contract_id);

				String choosen_amt = jbsession.getString("choosen_amount");

				System.out.println("AMTCHOOSEN=" + "Please click the below link to pay");
				// wa.sendMessage360("121212122", from,"*Please click on the link below to make payment 👇*", WhatsAppMessage.whatsapp_key, conn);

				new Thread(new Runnable() {
					public void run() {
						WhatsAppMessage wa = new WhatsAppMessage();
						wa.doHeavy(from, due_amt, outstandingamt, contract_id, odcharges, cust_name, email,
								product, COMPANY_NAME, PROD_CODE, outstandingamt, choosen_amt, source_system,
								mobileno,campaign_name,account_id);

					}
				}).start();

				return;

			} else if (menu.equals("otheramount")) {
				//other amount choosen
				org.json.JSONObject jbsession = wa.getSessionInfo(from, conn,account_id);
				jbsession.put("menu_choosen", "otheramount");
				wa.updateSessionInfo(from, conn, jbsession,account_id);
				wa.sendMessage360("121212122", from, "*Please enter the amount you wish to pay*",
						WhatsAppMessage.whatsapp_key, conn,campaign_name,account_id);
				return;
				//}

			} else if (menu.equals("invalidamount")) {
				//select an invalid amount
				org.json.JSONObject jbsession = wa.getSessionInfo(from, conn,account_id);

				jbsession.put("menu_choosen", "otheramount");
				JSONObject pgdetail = jbsession.getJSONObject("pgdetail");
				String mycontractid = pgdetail.getString("contract_id");
				String outstandingamt = pgdetail.getString("outstandingamt");
				wa.updateSessionInfo(from, conn, jbsession,account_id);
				wa.sendMessage360("121212122", from,
						"*Please Enter the amount to pay between Rs. 1 to Rs." + outstandingamt + "*",
						WhatsAppMessage.whatsapp_key, conn,campaign_name,account_id);
				return;

			}

			else if (menu.toLowerCase().startsWith("welcomeback")) {
				//If the user sends a hi message to whatsapp business account
				//arr.add("Detail");
				new Thread(new Runnable() {
					public void run() {
						Connection conn = null;
						try {
							Class.forName("com.mysql.jdbc.Driver");
							conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/whatsapp_tatacap",
									db_userid, db_passwd);

							org.json.JSONObject jbsession = null;
							

							jbsession = wa.getSessionInfo(from, conn, account_id);

							String json1 = wa.sendMessage360("121222", from,
									"Welcome back to QuickPay. Please select a Loan Account Number to proceed.",
									WhatsAppMessage.whatsapp_key, conn,campaign_name,account_id);

							org.json.JSONArray jarr1 = wa.getBankDetail(from,
									jbsession.getString("session_id"));
							if (jarr1 == null || jarr1.length() == 0) {
								//wa.sendMessage360("121212122", from,"Facing Technical Error. We will get back to you soon", WhatsAppMessage.whatsapp_key, conn);

								try {
									WhatsAppMessage wa = new WhatsAppMessage();

									wa.sendMessage360("121212122", from,
											"Facing Technical Error. We will get back to you soon",
											WhatsAppMessage.whatsapp_key, conn,campaign_name,account_id);
								} catch (Exception ex) {
								}

							} else {
								jbsession.put("proddetail", jarr1);
								wa.updateSessionInfo(from, conn, jbsession,account_id);
								ArrayList arr = new ArrayList();
								for (int i = 0; i < jarr1.length(); i++) {
									MyMenu mm = new MyMenu();
									mm.id = i + "";
									mm.product = jarr1.getJSONObject(i).getString("product");
									mm.contract_id = jarr1.getJSONObject(i).getString("contract_no");

									arr.add(mm);
								}

								String jsonw = wa.formList(from, "Please choose from below account", arr,
										"Select Loan Account", "PROD");
								//String json1=wa.sendMessage360("121222", from, "Hi, Welcome  to GoGas Scheme Enrollment.", WhatsAppMessage.whatsapp_key, conn);
								wa.sendWhatsappMsg("121212", jsonw, from, WhatsAppMessage.whatsapp_key, conn,campaign_name,account_id);
								return;

							}
						} catch (Exception ex) {
						} finally {
							try {
								conn.close();
							} catch (Exception ex) {
							}
						}
					}

				}).start();

			}

			else if (menu.toLowerCase().startsWith("welcome")) {
				//If the user sends a hi message to whatsapp business account

				//arr.add("Detail");

				new Thread(new Runnable() {
					public void run() {
						Connection conn = null;
						try {
							conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/whatsapp_tatacap",
									db_userid, db_passwd);

							org.json.JSONObject jbsession =null;
						//	jbsession = new org.json.JSONObject();
						//	jbsession.put("session_id", UUID.randomUUID().toString());

						jbsession = wa.getSessionInfo(from, conn, account_id);

							String json1 = wa.sendMessage360("121222", from,
									"Hi, Welcome to QuickPay. Please select a Loan Account Number to proceed.",
									WhatsAppMessage.whatsapp_key, conn,campaign_name,account_id);

							org.json.JSONArray jarr1 = wa.getBankDetail(from,
									jbsession.getString("session_id"));
							if (jarr1 == null || jarr1.length() == 0) {
								try {
									WhatsAppMessage wa = new WhatsAppMessage();
									wa.sendMessage360("121212122", from,
											"Facing Technical Error. We will get back to you soon",
											WhatsAppMessage.whatsapp_key, conn,campaign_name,account_id);
								} catch (Exception ex) {

								}

							} else {
								jbsession.put("proddetail", jarr1);
								wa.updateSessionInfo(from, conn, jbsession,account_id);
								ArrayList arr = new ArrayList();
								for (int i = 0; i < jarr1.length(); i++) {
									MyMenu mm = new MyMenu();
									mm.id = i + "";
									mm.product = jarr1.getJSONObject(i).getString("product");
									mm.contract_id = jarr1.getJSONObject(i).getString("contract_no");

									arr.add(mm);
								}

								String jsonw = wa.formList(from, "Please choose from below account", arr,
										"Select Loan 	", "PROD");
								//String json1=wa.sendMessage360("121222", from, "Hi, Welcome  to GoGas Scheme Enrollment.", WhatsAppMessage.whatsapp_key, conn);
								wa.sendWhatsappMsg("121212", jsonw, from, WhatsAppMessage.whatsapp_key, conn,campaign_name,account_id);
								return;

							}
						} catch (Exception ex) {
						} finally {
							try {
								conn.close();
							} catch (Exception ex) {
							}
						}
					}

				}).start();

			} else if (menu.toLowerCase().startsWith("bye")) {
				wa.sendMessage360("121222", from, "Thanks. Bye.", WhatsAppMessage.whatsapp_key, conn,campaign_name,account_id);
			} else {

			}

		}

	}

	//org.json.simple.JSONArray jarr1=(org.json.simple.JSONArray)jsonObject.get("contacts");

		} else {
	//"statuses":[{"id":"gBEGkZdBQRCHAgnKpPfNAmsHdUA","type":"message","conversation":{"id":"8891a5c7dc85633757b9281e9f83119a"},"pricing":{"pricing_model":"NBP","billable":false},"recipient_id":"919741411087","status":"delivered","timestamp":"1636536278"}]}
	
		
		/////////
		org.json.simple.JSONObject jb=(org.json.simple.JSONObject)jarr.get(0);
		String msg_id=(String)jb.get("id");
		String body=jb.toJSONString();
		String to_num="";
		try
		{
		  to_num=(String)jb.get("recipient_id");
		}
		catch ( Exception ex)
		{
		}
		String status=(String)jb.get("status");
		
		String conversation_id="";
		
		try
		{
		conversation_id=(String)((org.json.simple.JSONObject)jb.get("conversation")).get("id");
		}
		catch ( Exception ex)
		{
		}
		
		if ( body.contains("user_initiated") ||  body.contains("business_initiated"))
		{
		
		/* WhatsAppMessage wa = new WhatsAppMessage();
		 org.json.JSONObject js= wa.getSessionInfo(to_num, conn,account_id);
		 if ( js==null)
		 {
			
			js= new org.json.JSONObject();
		  js.put("session_id",conversation_id);
		   wa.updateSessionInfo(to_num, conn, js,account_id);
		}*/
		 
		 
		 
		 
		}
		String sql="select * from outgoing_whatsapp_log where msg_id='"+msg_id+"'";
		Statement st= conn.createStatement();
		ResultSet rs= st.executeQuery(sql);
		if ( !rs.next())
		{
		
		String pssql="insert into outgoing_whatsapp_log(to_msisdn,message,msg_id,call_type,msg_status,conversation_id,account_id) values(?,?,?,?,?,?,?)";
		PreparedStatement ps=conn.prepareStatement(pssql);
		ps.setString(1,to_num);
		ps.setString(2,body);
		ps.setString(3,msg_id);
		ps.setString(4,"outgoing");
		ps.setString(5,status);
		ps.setString(6,conversation_id);
		ps.setString(7,account_id);

		

		ps.executeUpdate();
		}
		else
		{
			  WhatsAppMessage wa = new WhatsAppMessage();

		
			// wa.updateCallBackURL(msg_id,status, to_num.substring(2), "NA");

		
	    sql="update outgoing_whatsapp_log set conversation_id='"+conversation_id+"', msg_status='"+status+"' where msg_id='"+msg_id+"'";
	    
		Statement stupd=conn.createStatement();
		stupd.executeUpdate(sql);
		
		}
		
		
////////////
	

		}
	} catch (Exception ex) {
		ex.printStackTrace();

	}

} catch (Exception e) {

	e.printStackTrace();
	JSONObject jstat = new JSONObject();
	JSONObject jres = new JSONObject();
	JSONObject jout = new JSONObject();

	jstat.put("statusCode", "1");
	jstat.put("errorCode", "101");
	jstat.put("errorMessage", "UNKNOWN_ERROR");
	jres.put("status", jstat);
	jout.put("result", jres);
	out.println(jout.toString());

	/* 18 */
	/*    */ } finally {
	try {
		conn.close();
	} catch (Exception exx) {

	}
}
%>

