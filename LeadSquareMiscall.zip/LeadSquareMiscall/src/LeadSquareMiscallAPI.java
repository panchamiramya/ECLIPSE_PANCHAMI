import java.sql.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.JSONArray;
import org.json.JSONObject;

public class LeadSquareMiscallAPI {

    public static void main(String[] args) {
        processMiscalls();
    }

    public static void processMiscalls() {

        try {
            Class.forName("com.mysql.jdbc.Driver");

            Connection conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/smartivr_cloud",
                    "oditata",
                    "PowTata@987"
            );

            String query = "SELECT * FROM leadsquare_miscall WHERE miscall_flag = 0 AND account_id='217'";
            PreparedStatement ps = conn.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                int id = rs.getInt("id");
                String incomingNo = rs.getString("incoming_no");

                Timestamp ts = rs.getTimestamp("miscall_date_time");
                String miscallDateTime;

                if (ts != null) {
                    miscallDateTime = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(ts);
                } else {
                    miscallDateTime = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
                            .format(new java.util.Date());
                }

                System.out.println("Processing ID: " + id);

                JSONObject retrieveResponse = callRetrieveAPI(incomingNo);

                if (retrieveResponse == null || retrieveResponse.optInt("RecordCount") == 0) {
                    System.out.println("Retrying with +91 format...");
                    retrieveResponse = callRetrieveAPI("+91-" + incomingNo);
                }

                PreparedStatement storeRetrieve = conn.prepareStatement(
                        "UPDATE leadsquare_miscall SET retrieve_response=? WHERE id=?"
                );
                storeRetrieve.setString(1, retrieveResponse != null ? retrieveResponse.toString() : null);
                storeRetrieve.setInt(2, id);
                storeRetrieve.executeUpdate();

                if (retrieveResponse == null) {

                    PreparedStatement failUpdate = conn.prepareStatement(
                            "UPDATE leadsquare_miscall SET miscall_flag=20 WHERE id=?"
                    );
                    failUpdate.setInt(1, id);
                    failUpdate.executeUpdate();

                    System.out.println("Retrieve API failed: " + id);
                    continue;
                }

    
                if (retrieveResponse.optInt("RecordCount") == 0) {

                    PreparedStatement noDataUpdate = conn.prepareStatement(
                            "UPDATE leadsquare_miscall SET miscall_flag=10 WHERE id=?"
                    );
                    noDataUpdate.setInt(1, id);
                    noDataUpdate.executeUpdate();

                    System.out.println("No Lead found: " + incomingNo);
                    continue;
                }

                JSONArray list = retrieveResponse.getJSONArray("List");
                JSONObject obj = list.getJSONObject(0);

                String opportunityId = obj.getString("OpportunityId");
                String prospectId = obj.getString("RelatedProspectId");

                PreparedStatement update1 = conn.prepareStatement(
                        "UPDATE leadsquare_miscall SET opportunity_id=?, prospect_id=? WHERE id=?"
                );
                update1.setString(1, opportunityId);
                update1.setString(2, prospectId);
                update1.setInt(3, id);
                update1.executeUpdate();

      
                JSONObject activityResponse = callActivityAPI(prospectId, opportunityId, miscallDateTime);

                if (activityResponse != null && "Success".equals(activityResponse.optString("Status"))) {

                    JSONObject msg = activityResponse.getJSONObject("Message");

                    PreparedStatement successUpdate = conn.prepareStatement(
                            "UPDATE leadsquare_miscall SET activityId=?, relatedId=?, miscall_flag=1 WHERE id=?"
                    );
                    successUpdate.setString(1, msg.getString("Id"));
                    successUpdate.setString(2, msg.getString("RelatedId"));
                    successUpdate.setInt(3, id);
                    successUpdate.executeUpdate();

                    System.out.println("Success ID: " + id);

                } else {

                    PreparedStatement failUpdate = conn.prepareStatement(
                            "UPDATE leadsquare_miscall SET miscall_flag=20 WHERE id=?"
                    );
                    failUpdate.setInt(1, id);
                    failUpdate.executeUpdate();

                    System.out.println("Activity API failed: " + id);
                }
            }

            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

 
    public static JSONObject callRetrieveAPI(String phone) throws Exception {

        String urlStr = "https://api-in21.leadsquared.com/v2/OpportunityManagement.svc/Retrieve/BySearchParameter?accessKey=u%24r2594750399e952e2fb5d278e259c0775&secretKey=3e8db4351acbcc5efa75ca38901fcababa638e9d";


        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();

        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);

        JSONObject body = new JSONObject();
        body.put("OpportunityEventCode", 12000);

        String advSearch = "{"
                + "\"GrpConOp\":\"And\","
                + "\"Conditions\":["
                + "{"
                + "\"Type\":\"Activity\","
                + "\"ConOp\":\"and\","
                + "\"RowCondition\":[{"
                + "\"SubConOp\":\"And\","
                + "\"LSO\":\"ActivityEvent\","
                + "\"LSO_Type\":\"PAEvent\","
                + "\"Operator\":\"eq\","
                + "\"RSO\":\"12000\""
                + "}]"
                + "},"
                + "{"
                + "\"Type\":\"Lead\","
                + "\"ConOp\":\"and\","
                + "\"RowCondition\":[{"
                + "\"SubConOp\":\"And\","
                + "\"LSO\":\"Phone\","
                + "\"LSO_Type\":\"string\","
                + "\"Operator\":\"eq\","
                + "\"RSO\":\"" + phone + "\""
                + "}]"
                + "}"
                + "],"
                + "\"QueryTimeZone\":\"India Standard Time\""
                + "}";

        body.put("AdvancedSearch", advSearch);

        JSONObject paging = new JSONObject();
        paging.put("PageIndex", 1);
        paging.put("PageSize", 10);

        body.put("Paging", paging);

        OutputStream os = conn.getOutputStream();
        os.write(body.toString().getBytes());
        os.flush();

        return readResponse(conn, "Retrieve API");
    }


    public static JSONObject callActivityAPI(String prospectId, String opportunityId, String miscallDateTime) throws Exception {

        String urlStr = "https://api-in21.leadsquared.com/v2/ProspectActivity.svc/Create?accessKey=u%24r2594750399e952e2fb5d278e259c0775&secretKey=3e8db4351acbcc5efa75ca38901fcababa638e9d";

        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();

        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);

        JSONObject body = new JSONObject();

        body.put("RelatedProspectId", prospectId);
        body.put("RelatedOpportunityId", opportunityId);
        body.put("ActivityEvent", 208);
        body.put("ActivityNote", "Leadsquare Miscall");
        body.put("ActivityDateTime", miscallDateTime);

        JSONArray fields = new JSONArray();
        JSONObject field = new JSONObject();
        field.put("SchemaName", "ActivityEvent_Note");
        field.put("Value", "Leadsquare Miscall");

        fields.put(field);
        body.put("Fields", fields);

        OutputStream os = conn.getOutputStream();
        os.write(body.toString().getBytes());
        os.flush();

        return readResponse(conn, "Activity API");
    }


    public static JSONObject readResponse(HttpURLConnection conn, String apiName) throws Exception {

        int responseCode = conn.getResponseCode();

        InputStream is;
        if (responseCode >= 200 && responseCode < 300) {
            is = conn.getInputStream();
        } else {
            is = conn.getErrorStream();
            System.out.println("❌ " + apiName + " Error Code: " + responseCode);
        }

        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        StringBuilder response = new StringBuilder();
        String line;

        while ((line = br.readLine()) != null) {
            response.append(line);
        }

        System.out.println("🔹 " + apiName + " Response: " + response.toString());

        return new JSONObject(response.toString());
    }
}