<%@page import="java.sql.Time"%>
<%@page import="java.sql.Date"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.Connection"%>
<%@page import="prajna.DBConnection"%>
<%@ page language="java" contentType="application/xml; charset=UTF-8"
	pageEncoding="ISO-8859-1"%>

<?xml�version='1.0'�encoding='utf-8'?>
<UpsertResponses>
����<JobApplicationUpsertResponse>	
<%
	String candidate_full_name = request.getParameter("CANDIDATE_FULL_NAME");
	String job_req_title = request.getParameter("JOB_REQ_TITLE");
	String job_req_id = request.getParameter("JOB_REQ_ID");
	String interview_date = request.getParameter("INTERVIEW_DATE");
	String interview_time = request.getParameter("INTERVIEW_TIME");
	String interview_location = request.getParameter("INTERVIEW_SCHEDULING_INTERVIEW_LOCATION");
	String recruiter_full_name = request.getParameter("RECRUITER_FULL_NAME");
	String status = request.getParameter("Status");
	String msisdn = request.getParameter("msisdn");
	String inserted;
	System.out.println(candidate_full_name+" : "+job_req_id+" : "+job_req_title+" : "+interview_date+" : "+interview_time+" : "+interview_location+" : "+recruiter_full_name+" : "+status);
	if(candidate_full_name.isEmpty() || job_req_title.isEmpty() || job_req_title.isEmpty() || interview_date.isEmpty() || interview_time.isEmpty() || interview_location.isEmpty() || recruiter_full_name.isEmpty() || status.isEmpty() || msisdn.isEmpty())
	{
		inserted = "ERROR";
%>
		<editStatus><%=inserted%></editStatus>
��������<message>Application�Insert Failed as a Field was missing</message>
��������<index�type="Edm.Int32">0</index>
��������<httpCode�type="Edm.Int32">201</httpCode>
��������<inlineResults�type="Bag(SFOData.UpsertResult)"/>
<%		
	}
	else
	{
		Connection con = null;
		try
		{
			con = DBConnection.getConnection();
			String sql = "INSERT INTO shortlisted (job_id, job_title, candidate_name, interview_date, interview_time, interview_location, recruiter_name,status,msisdn) VALUES(?,?,?,?,?,?,?,?,?);";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1,job_req_id);
			pstmt.setString(2,job_req_title);
			pstmt.setString(3,candidate_full_name);
			pstmt.setDate(4,Date.valueOf(interview_date));
			pstmt.setTime(5,Time.valueOf(interview_time));
			pstmt.setString(6,interview_location);
			pstmt.setString(7,recruiter_full_name);
			pstmt.setString(8,status);
			pstmt.setString(9,msisdn);
			int count = pstmt.executeUpdate();
			if(count > 0)
			{
				inserted = "INSERTED";
%>		
		<key>JobApplication/applicationId=<%=job_req_id %></key>
��������<status><%=status%></status>
��������<editStatus><%=inserted%></editStatus>
��������<message>Application�has�been�inserted�successfully</message>
��������<index�type="Edm.Int32">0</index>
��������<httpCode�type="Edm.Int32">201</httpCode>
��������<inlineResults�type="Bag(SFOData.UpsertResult)"/>
<%	
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
%>
		<editStatus>ERROR</editStatus>
��������<message>Application�Insert failed because <%= e.getMessage()%></message>
��������<index�type="Edm.Int32">0</index>
��������<httpCode�type="Edm.Int32">201</httpCode>
��������<inlineResults�type="Bag(SFOData.UpsertResult)"/>
<%
		}
		finally
		{
			con.close();
		}
	}
%>
����</JobApplicationUpsertResponse>
</UpsertResponses>
