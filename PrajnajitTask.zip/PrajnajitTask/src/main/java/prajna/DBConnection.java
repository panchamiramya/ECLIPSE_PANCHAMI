package prajna;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	
	private static final String url = "jdbc:mysql://localhost:3306/prajnajit";
	private static final String username = "root";
	private static final String password = "";
	

	public static Connection getConnection()
	{
		try {
			return DriverManager.getConnection(url,username,password);
		}
		catch (SQLException e) {	
			e.printStackTrace();
			System.out.println("Connection is not open : run your xampp server");
		}
		return null;
	}
}
