import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Properties;
import javax.mail.Address;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.net.ssl.SSLSocket;

public class ConsolidatedMail {
    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("connection established");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/farmer_registration_iplbio", "root", "Ikontel@987");
            System.out.println("Connected");
            String from = "info@ikontel.com";
            String formattedDate = "";
            String strDateFormat = "yyyy-MM-dd";
            Date date = new Date();
            DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
            formattedDate = dateFormat.format(date);
            String sub = "IPLBIO CONSOLIDATED MISCALL REPORT AS ON " + formattedDate;
            String subsql = "SELECT manager_msisdn, COUNT(staff_msisdn) AS no_tsl, manager_name, state FROM staff_detail GROUP BY manager_msisdn, manager_name, state ORDER BY state";
            Statement substmt = conn.createStatement();
            ResultSet subrs = substmt.executeQuery(subsql);
            String text = "Dear Team ,<br /><br >Below is the miscall count of your Manager.<br /><br />";
            String resultBody = "";
            while (subrs.next()) {
            	String managerMsisdn = subrs.getString("manager_msisdn");
                String tsl_no = subrs.getString("no_tsl");
                String managerName = subrs.getString("manager_name");
                String state = subrs.getString("state"); 
               // String miscallsqltoday = "select count(id) as miscallcounttoday from miscall_unique where date(miscall_date)=date(now()) and manager_msisdn = '" + managerMsisdn + "'";
                String miscallsqltoday = "select count(mu.id) as miscallcounttoday from staff_detail sd join miscall_unique mu on SUBSTRING(mu.miscall_no, -10) = sd.miscall_no  where date(miscall_date)=date(now()) and mu.manager_msisdn = '" + managerMsisdn + "' and sd.state ='"+state+"'";
                Statement miscallstmt = conn.createStatement();
                ResultSet miscallrs = miscallstmt.executeQuery(miscallsqltoday);
                while (miscallrs.next()) {
                    String miscallcounttoday = miscallrs.getString("miscallcounttoday"); 
                    //String miscallsqltilldate = "select count(id) as miscallcounttilldate from miscall_unique where manager_msisdn = '" + managerMsisdn + "'";
                    String miscallsqltilldate = "select count(mu.id) as miscallcounttilldate from staff_detail sd join miscall_unique mu on SUBSTRING(mu.miscall_no, -10) = sd.miscall_no where mu.manager_msisdn='"+managerMsisdn+"' and sd.state ='"+state+"'";
                    Statement miscallstmttilldate = conn.createStatement();
                    ResultSet miscallrstilldate = miscallstmttilldate.executeQuery(miscallsqltilldate);
                    while (miscallrstilldate.next()) {
                        String miscallcounttilldate = miscallrstilldate.getString("miscallcounttilldate");
                        resultBody += "<tr>";
                        resultBody += "<td>" + state + "</td>";
                        resultBody += "<td>" + managerName + "</td>";
                        resultBody += "<td>" + tsl_no + "</td>";
                        resultBody += "<td>" + miscallcounttoday + "</td>";
                        resultBody += "<td>" + miscallcounttilldate + "</td>";
                        resultBody += "</tr>";
                    }
                }
            }

            text += "<table border='1' cellpadding='5' cellspacing='0' style='font-size: 9pt;font-family: sans-serif;color:black'>";
            text += "<thead>";
            text += "<tr style='background:lightblue;'>";
            text += "<th>STATE</th>";
            text += "<th>ABL</th>";
            text += "<th>NO. Of TSL/TDL/MDO</th>";
            text += "<th>MISCALL COUNT FOR TODAY</th>";
            text += "<th>MISCALL COUNT TILL DATE</th>";
            text += "</tr>";
            text += "</thead>";
            text += "<tbody>";
            text += resultBody;
            text += "</tbody>";
            text += "</table>";
            System.out.println(text);
            

            // Mail configuration
            Transport transport = null;
            String host = "email-smtp.eu-west-1.amazonaws.com";
            Properties props = System.getProperties();
            int PORT = 465;
            String SMTP_USERNAME = "AKIAJXDE5LZYJEHFLACQ"; 
            String SMTP_PASSWORD = "Ai0zhtdrRG065i8+xdUAAMa9I7U/xvxmJ+Oc3tHlqZCb"; 

            props.put("mail.transport.protocol", "smtp");
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.socketFactory.port", Integer.valueOf(465));
            props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.port", "465");
            props.put("mail.smtp.host", "email-smtp.eu-west-1.amazonaws.com");
            props.put("mail.smtp.starttls.enable", "true"); // Enable STARTTLS
            props.put("mail.smtp.ssl.protocols", "TLSv1.2");
            props.put("line.separator", "\r\n");
            props.put("mail.debug", "true");

            Session session = Session.getDefaultInstance(props, new Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(SMTP_USERNAME, SMTP_PASSWORD);
                }
            });

            try {
            	transport = session.getTransport();
                MimeMessage message = new MimeMessage(session);
                message.setFrom(new InternetAddress(from));
                message.addRecipients(Message.RecipientType.TO, InternetAddress.parse("rahul.mathur@iplbiologicals.com,sandeep.salke@iplbiologicals.com,subhash.thakur@iplbiologicals.com,shailendra.mishra@iplbiologicals.com,reena.batra@iplbiologicals.com,kamlesh.chaturvedi@iplbiologicals.com"));
                message.setRecipients(Message.RecipientType.CC, InternetAddress.parse("sikharani.parida@ikontel.com,sudeshna@ikontel.com,panchami.c@ikontel.com,shakti.pradhan@ikontel.com"));
                //message.addRecipients(Message.RecipientType.TO, InternetAddress.parse("panchami.c@ikontel.com"));
                message.setSubject(sub);
                message.setContent(text, "text/html; charset=utf-8");
                Transport.send(message);
                System.out.println("Success in sending mail");
            } catch (Exception ex) {
                ex.printStackTrace();
                System.out.println("Error in sending mail");
            } finally {
                conn.close();
            }
        } catch (SQLException se) {
            se.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
