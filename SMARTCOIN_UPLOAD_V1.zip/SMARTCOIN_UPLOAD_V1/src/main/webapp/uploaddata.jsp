<%@page import="smartcoin.LeadData"%>
<%@page import="java.io.*"%>
<%@page import="javax.servlet.*"%>
<%@page import="javax.servlet.http.*"%>
<%@page import="javax.json.*"%>
<%@page import="javax.naming.InitialContext"%>
<%@page import="javax.naming.Context"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="javax.sql.DataSource"%>
<%@page import="java.sql.*"%>

<%
    response.setContentType("application/json");
    response.addHeader("Freeflow", "FC");
    java.util.Date mydt = new java.util.Date();
    response.setDateHeader("Date", mydt.getTime());
    
    Connection conn = null;
   
    
    try {
    	Class.forName("com.mysql.jdbc.Driver");
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/campaign_cloud", "root", "");

        StringBuilder requestData = new StringBuilder();
        try (BufferedReader br = request.getReader()) {
            String line;
            while ((line = br.readLine()) != null) {
                requestData.append(line);
            }
        }

        if (requestData.toString().trim().isEmpty()) {
            out.println("{\"result\": {\"status\": {\"statusCode\": 105, \"status\": \"error\", \"message\": \"Empty JSON data.\"}}}");
            return;
        }

        try (JsonReader jsonReader = Json.createReader(new StringReader(requestData.toString()))) {
        	
            JsonObject jsonData = jsonReader.readObject();
            
            String campaign_name = jsonData.getString("campaign_name");
            String isagentwise = jsonData.getString("isagentwise");

            LeadData ld = new LeadData();
            String chkmsg = ld.processData("2aehkdfwlnu7ts2asd", campaign_name, isagentwise, requestData.toString(), conn)
                                .replace("\\", "").replace("\n", "");
            out.println(chkmsg);
        }

    } catch (Exception e) {
        e.printStackTrace();
        out.println("{\"result\": {\"status\": {\"statusCode\": 401, \"status\": \"error\", \"message\": \"Internal Server Error.\"}}}");
    } finally {
        try {
            if (conn != null) {
                conn.close();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
%>
