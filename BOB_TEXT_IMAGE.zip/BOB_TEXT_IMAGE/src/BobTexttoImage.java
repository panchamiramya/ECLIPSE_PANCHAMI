import org.xhtmlrenderer.pdf.ITextRenderer;
import com.lowagie.text.DocumentException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.PDFRenderer;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.imageio.ImageIO;

public class BobTexttoImage {
    public static void main(String[] args) {
        // Sample HTML template with placeholders
    	String htmlTemplate = "<html><body><p>Dear <Name></p><p>Please find below activity update for the day –</p>"
    	        + "<p>Product  - <Product></p>"
    	        + "<p>SMA 0 Performance<br/>Resolution  % <Resolution><br/>Norm % <Norm><br/>Stab % <Stab></p>"
    	        + "<p>SMA 1 Performance<br/>Resolution % <Resolution1><br/>Norm % <Norm1><br/>Roll Back % <RollBack1><br/>Flow % <Flow1></p>"
    	        + "<p>SMA 2 Performance<br/>Resolution % <Resolution2><br/>Norm % <Norm2><br/>Roll Back % <RollBack2><br/>Flow % <Flow2></p>"
    	        + "<p>Thanks &amp; Regards<br/>Receivables Management<br/>Projects &amp; Process Team<br/>BCC- Mumbai<br/><br/>"
    	        + "Kindly contact Rajnish Kumar- 7573984757 in case of any query &amp; discussion.</p></body></html>";



        // Replace placeholders with actual data
        Map<String, String> dataMap = new HashMap<>();
        dataMap.put("<Name>", "John Doe");
        dataMap.put("<Product>", "Product XYZ");
        dataMap.put("<Resolution>", "95%");
        dataMap.put("<Norm>", "80%");
        dataMap.put("<Stab>", "85%");
        dataMap.put("<Resolution1>", "90%");
        dataMap.put("<Norm1>", "75%");
        dataMap.put("<RollBack1>", "10%");
        dataMap.put("<Flow1>", "60%");
        dataMap.put("<Resolution2>", "88%");
        dataMap.put("<Norm2>", "70%");
        dataMap.put("<RollBack2>", "15%");
        dataMap.put("<Flow2>", "55%");

        String html = replacePlaceholders(htmlTemplate, dataMap);

        int width = 800;
        int height = 600;

        try {
            // Convert HTML to PDF using ITextRenderer
            File pdfFile = new File("temp.pdf");
            ITextRenderer renderer = new ITextRenderer();
            renderer.setDocumentFromString(html);
            renderer.layout();
            try (FileOutputStream pdfStream = new FileOutputStream(pdfFile)) {
                renderer.createPDF(pdfStream);
            }

            // Convert PDF to BufferedImage
            PDDocument pdfDocument = PDDocument.load(pdfFile);
            PDFRenderer pdfRenderer = new PDFRenderer(pdfDocument);
            BufferedImage image = pdfRenderer.renderImageWithDPI(0, 300); // Set DPI here

            pdfDocument.close();
            pdfFile.delete(); // Clean up temporary PDF file

            // Write BufferedImage to image file (e.g., PNG)
            File imageFile = new File("/home/test/Documents/html_to_image.png");
            ImageIO.write(image, "png", imageFile);

            System.out.println("HTML to image conversion complete.");
        } catch (IOException | DocumentException e) {
            e.printStackTrace();
        }
    }

    // Function to replace placeholders in HTML with actual data
    private static String replacePlaceholders(String htmlTemplate, Map<String, String> dataMap) {
        String html = htmlTemplate;
        for (Map.Entry<String, String> entry : dataMap.entrySet()) {
            html = html.replace(entry.getKey(), entry.getValue());
        }
        return html;
    }
}
