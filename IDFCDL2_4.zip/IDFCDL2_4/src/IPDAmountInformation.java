
public class IPDAmountInformation {
	String failed_req;
	String id;

	public String getReq() {
		return failed_req;
	}

	public void setRequest(String failed_req) {
		this.failed_req = failed_req;
	}

	public void setID(String id) {
		this.id = id;
	}

	public String getID() {
		return this.id;
	}
}
