
public class LinkInfo {
	String quicklink_part1;
	String quicklink_part2;

}
