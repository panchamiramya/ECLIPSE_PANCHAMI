import java.util.LinkedList;

public class ThreadPool {
  private LinkedList<Runnable> tasks = new LinkedList<>();
  
  public static int stopflag = 0;
  
  public static int noofstops = 0;
  
  private int no_of_complete_tasks = 0;
  
  public synchronized void setNoOfCompletedTasks() {
    this.no_of_complete_tasks++;
  }
  
  public int getNoOfCompletedTasks() {
    return this.no_of_complete_tasks;
  }
  
  public int getNoTasks() {
    int count = 0;
    synchronized (this.tasks) {
      count = this.tasks.size();
    } 
    return count;
  }
  
  public ThreadPool(int size) {
    for (int i = 0; i < size; i++) {
      Thread thread = new ThreadTask(this);
      thread.start();
    } 
  }
  
  public void run(Runnable task) {
    synchronized (this.tasks) {
      this.tasks.addLast(task);
      this.tasks.notify();
    } 
  }
  
  public void notifyme() {
    this.tasks.notify();
  }
  
  public void notifyall() {
    synchronized (this.tasks) {
      this.tasks.notifyAll();
    } 
  }
  
  public Runnable getNext() {
    Runnable returnVal = null;
    synchronized (this.tasks) {
      while (this.tasks.isEmpty()) {
        try {
          if (stopflag == 1) {
            noofstops++;
            System.out.println("Stop processed..Thread is waiting now");
            this.tasks.wait();
          } 
          this.tasks.wait();
        } catch (InterruptedException ex) {
          System.err.println("Interrupted");
        } 
      } 
      returnVal = this.tasks.removeFirst();
    } 
    return returnVal;
  }
}
