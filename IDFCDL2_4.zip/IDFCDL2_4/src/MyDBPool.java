import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import org.apache.commons.dbcp2.BasicDataSource;

public class MyDBPool {

	/**
	 * @param args
	 */

	private BasicDataSource ds;

	public MyDBPool(int minidle, int maxidle, String userid, String passwd, String dburl)
			throws IOException, SQLException, PropertyVetoException {
		ds = new BasicDataSource();
		ds.setDriverClassName("com.mysql.jdbc.Driver");
		ds.setUsername(userid);
		ds.setPassword(passwd);
		ds.setUrl(dburl);

		// the settings below are optional -- dbcp can work with defaults
		ds.setMinIdle(minidle);
		ds.setMaxIdle(maxidle);
		ds.setMaxOpenPreparedStatements(180);

	}

	public Connection getConnection() throws SQLException {
		return this.ds.getConnection();

	}

}
