import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;
import javax.net.ssl.HttpsURLConnection;

public class HTTPRequest {
  public static String getResponse(String url) {
    String xml = "Thankyou";
    String res = "";
    BufferedReader in = null;
    OutputStream out = null;
    Writer wout = null;
    try {
      URL url1 = new URL(url);
      System.out.println("url=" + url);
      URLConnection connection = url1.openConnection();
      HttpURLConnection httpConn = (HttpURLConnection)connection;
      httpConn.setReadTimeout(20000);
      httpConn.setConnectTimeout(20000);
      httpConn.setRequestProperty("Accept", "text/html");
      httpConn.setRequestProperty("Content-Type", "text/html");
      httpConn.setRequestMethod("GET");
      httpConn.setDoInput(true);
      httpConn.setDoOutput(true);
      System.out.println("code=" + httpConn.getResponseCode());
      if (httpConn.getResponseCode() == 200) {
        InputStreamReader isr = new InputStreamReader(httpConn.getInputStream());
        in = new BufferedReader(isr);
        String temp = "";
        res = "";
        while ((temp = in.readLine()) != null)
          res = String.valueOf(res) + temp; 
        System.out.println("res_ok=" + res);
      } else {
        InputStreamReader isr = new InputStreamReader(httpConn.getErrorStream());
        in = new BufferedReader(isr);
        String temp = "";
        res = "";
        while ((temp = in.readLine()) != null)
          res = String.valueOf(res) + temp; 
        System.out.println("res_err=" + res);
      } 
    } catch (Exception ex) {
      ex.printStackTrace();
      return "IOEXP";
    } finally {
      try {
        in.close();
        wout.close();
        out.close();
      } catch (Exception exception) {}
    } 
    String decoderes = "";
    try {
      decoderes = URLDecoder.decode(res, "utf8");
      System.out.println("decoderes" + decoderes);
    } catch (Exception ex) {
      ex.printStackTrace();
    } 
    return decoderes;
  }
  
  public static String getResponse1(String url, String msg) {
    String res = "";
    URLConnection connection = null;
    HttpURLConnection httpConn = null;
    System.out.println("URL=" + url);
    BufferedReader in = null;
    OutputStream out = null;
    try {
      URL url1 = new URL(url);
      connection = url1.openConnection();
      httpConn = (HttpURLConnection)connection;
      httpConn.setReadTimeout(30000);
      httpConn.setConnectTimeout(30000);
      httpConn.setRequestMethod("POST");
      httpConn.setDoInput(true);
      httpConn.setDoOutput(true);
      httpConn.setRequestProperty("SOAPAction", 
          "http://123.63.20.164:8001/soa-infra/services/Bihar/EsselCCBBHGetBillDetails/EsselCCBGetBillSvc/GetBillDetails");
      httpConn.setRequestProperty("Content-Type", "text/xml; charset=utf-8");
      out = httpConn.getOutputStream();
      out.write(msg.getBytes());
      if (httpConn.getResponseCode() == 200) {
        InputStreamReader isr = new InputStreamReader(httpConn.getInputStream());
        in = new BufferedReader(isr);
        String temp = "";
        res = "";
        while ((temp = in.readLine()) != null)
          res = String.valueOf(res) + temp; 
      } else {
        InputStreamReader isr = new InputStreamReader(httpConn.getErrorStream());
        in = new BufferedReader(isr);
        String temp = "";
        res = "";
        while ((temp = in.readLine()) != null)
          res = String.valueOf(res) + temp; 
      } 
    } catch (Exception ex) {
      ex.printStackTrace();
      return "IOEXP";
    } finally {
      try {
        in.close();
        httpConn.disconnect();
      } catch (Exception tx) {
        tx.printStackTrace();
      } 
    } 
    return res;
  }
  
  public static String getResponse3(String url, String msg) {
    String res = "";
    URLConnection connection = null;
    HttpsURLConnection httpConn = null;
    BufferedReader in = null;
    OutputStream out = null;
    try {
      URL url1 = new URL(url);
      connection = url1.openConnection();
      httpConn = (HttpsURLConnection)connection;
      httpConn.setReadTimeout(30000);
      httpConn.setConnectTimeout(30000);
      httpConn.setRequestMethod("POST");
      httpConn.setDoInput(true);
      httpConn.setDoOutput(true);
      httpConn.setRequestProperty("SOAPAction", 
          "http://123.63.20.164:8001/soa-infra/services/Bihar/EsselCCBBHGetBillDetails/EsselCCBGetBillSvc/GetBillDetails");
      httpConn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
      out = httpConn.getOutputStream();
      out.write(msg.getBytes());
      if (httpConn.getResponseCode() == 200) {
        InputStreamReader isr = new InputStreamReader(httpConn.getInputStream());
        in = new BufferedReader(isr);
        String temp = "";
        res = "";
        while ((temp = in.readLine()) != null)
          res = String.valueOf(res) + temp; 
      } else {
        InputStreamReader isr = new InputStreamReader(httpConn.getErrorStream());
        in = new BufferedReader(isr);
        String temp = "";
        res = "";
        while ((temp = in.readLine()) != null)
          res = String.valueOf(res) + temp; 
      } 
    } catch (Exception ex) {
      ex.printStackTrace();
      return "IOEXP";
    } finally {
      try {
        in.close();
        httpConn.disconnect();
      } catch (Exception tx) {
        tx.printStackTrace();
      } 
    } 
    return res;
  }
}
