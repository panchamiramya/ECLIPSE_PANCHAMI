import java.io.File;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Hashtable;

public class CallBackMain {
  public static Hashtable<String, String> ht = new Hashtable<>();
  
  public static void main(String[] args) {
    System.out.println("New IPD Sync Amount version CallBack");
    ThreadPool tp = new ThreadPool(25);
    long starttime = System.currentTimeMillis();
    System.out.println("TP started");
    String dburl = "jdbc:mysql://localhost:3306/dunning_idfc";
    String dbuserid = "root";
    String dbpasswd = "#ikontel@123";
    MyDBPool dp = null;
    Connection conn = null;
    try {
      dp = new MyDBPool(30, 30, dbuserid, dbpasswd, dburl);
    } catch (Exception ex) {
      ex.printStackTrace();
      System.out.println("Exiting the process.. Errr creating DB pool");
      System.exit(-1);
    } 
    String sql = "select id, refer_num, lan, customer_name, product_group, over_dueamt, mobile_number, notice_date, letter_type, language_type, record_id, branch_address, mailling_address, msg, reqid from dunning where process_flag = 0 order by id asc limit 2000";
    System.out.println("SQL=" + sql);
    System.out.println("DB POOL started");
    try {
      conn = dp.getConnection();
    } catch (SQLException e) {
      e.printStackTrace();
    } 
    try {
      Statement st2 = conn.createStatement();
      ResultSet rs2 = st2.executeQuery(sql);
      while (rs2.next())
        ht.put(rs2.getString("id"), rs2.getString("record_id")); 
    } catch (Exception ex) {
      ex.printStackTrace();
      System.out.println("Exiting the system..");
      System.exit(-1);
    } 
    try {
      int cnt = 0;
      int no_of_jobs = 0;
      while (true) {
        conn = dp.getConnection();
        try {
          Statement st = conn.createStatement();
          Statement st1 = conn.createStatement();
          ResultSet rs = st.executeQuery(sql);
          System.out.println("DB Execution completed");
          while (rs.next()) {
            cnt++;
            DunningInfo dnobj = new DunningInfo();
            dnobj.setID(rs.getString("id"));
            dnobj.setCustomerName(rs.getString("customer_name"));
            dnobj.setDueAmt(rs.getString("over_dueamt"));
            dnobj.setDunningType(rs.getString("letter_type"));
            dnobj.setLanguageType(rs.getString("language_type"));
            dnobj.setLanNo(rs.getString("lan"));
            dnobj.setRefNumber(rs.getString("refer_num"));
            dnobj.setMsisdn(rs.getString("mobile_number"));
            dnobj.setNoticeDate(rs.getString("notice_date"));
            dnobj.setProductType(rs.getString("product_group"));
            dnobj.setRecordId(rs.getString("record_id"));
            dnobj.setCustomerAddress(rs.getString("mailling_address"));
            dnobj.setBranchAddress(rs.getString("branch_address"));
            dnobj.setMsg(rs.getString("msg"));
            dnobj.setReqId(rs.getString("reqid"));
            String id = rs.getString("id");
            String record_id = rs.getString("record_id");
            System.out.println(no_of_jobs);
            Job jb = new Job(dnobj, tp, dp, id, record_id);
            tp.run(jb);
          } 
          rs.close();
          st.close();
          st1.close();
          st = null;
          st1 = null;
          rs = null;
          long present = System.currentTimeMillis();
          long interval = present - starttime;
          if (cnt > 1000000 || interval > 86400000L) {
            ThreadPool.stopflag = 1;
            try {
              Thread.sleep(1000L);
            } catch (Exception exception) {}
            tp.notifyall();
            System.out.println("Stop is requested");
            while (ThreadPool.noofstops < 25) {
              try {
                System.out.println("Sleeping for a refresh");
                System.out.println("NOSTOPS=" + ThreadPool.noofstops);
                Thread.sleep(5L);
              } catch (Exception ex) {
                ex.printStackTrace();
              } 
            } 
            System.out.println("Every body synced to stop.. Exiting now");
            System.exit(-1);
          } 
          File f = new File("/tmp/stopcallback");
          if (f.exists()) {
            System.out.println("Stop request received");
            if (tp.getNoTasks() == 0) {
              System.out.println("Stop request received");
              System.exit(-1);
            } else {
              while (true) {
                try {
                  System.out.println("Waiting all process to be completed");
                  System.out.println("wait for 1 sec");
                  Thread.sleep(1000L);
                } catch (Exception exception) {}
                System.out.println("No of tasks remaining-" + tp.getNoTasks());
              }
            } 
          } 
          f = null;
          conn.close();
        } catch (Exception ex) {
          ex.printStackTrace();
          System.exit(-1);
        } 
        try {
          System.out.println("waiting for a while at 2000");
          Thread.sleep(2000L);
        } catch (Exception exception) {}
      } 
    } catch (Exception ex) {
      ex.printStackTrace();
      System.exit(-1);
      return;
    } 
  }
}
