package callback;

import java.sql.*;
import java.util.UUID;

public class CallBackMain {
    public static void main(String[] args) {
        System.out.println("New version CallBack");

        try (
            Connection conn1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/smartivr_cloud", "oditata", "PowTata@987");
            Statement st1 = conn1.createStatement();
            ResultSet rs2 = st1.executeQuery("SELECT id, incoming_number, group_name, start_call_date, status FROM smartivr_cloud.incoming_call_log WHERE update_flag=0 and start_call_date < now() - interval 30 SECOND and account_id=108 limit 100");
        ) {
            while (rs2.next()) {
                String incoming_number = rs2.getString("incoming_number");
                String group_name = rs2.getString("group_name");
                String start_call_date = rs2.getString("start_call_date");
                String id = rs2.getString("id");
                String call_status = rs2.getString("status");

                if ("NA".equals(call_status)) {
                    System.out.println("Processed " + incoming_number);

                    String record_id = UUID.randomUUID().toString();
                    String sql4 = "SELECT count(1) as cnt, record_status FROM campaign_tpcodlop.account_outbound WHERE msisdn=? AND account_id=108 AND record_status = 'active'";

                    try (
                        Connection conn2 = DriverManager.getConnection("jdbc:mysql://localhost:3306/campaign_tpcodlop", "root", "");
                        PreparedStatement pst4 = conn2.prepareStatement(sql4);
                    ) {
                        pst4.setString(1, incoming_number);
                        ResultSet rs4 = pst4.executeQuery();
                        int cnt2 = 0;
                        String ggg = "no";

                        if (rs4.next()) {
                            cnt2 = rs4.getInt("cnt");
                            if (cnt2 < 1) {
                                System.out.println("Count is < 1");
                                ggg = "yes";
                            } else {
                                String status = rs4.getString("record_status");
                                if ("finished".equals(status)) {
                                    System.out.println("Count is > 1 and finished");
                                    ggg = "yes";
                                } else {
                                    System.out.println("Count is > 1 and not finished");
                                }
                            }
                        }

                        if ("yes".equals(ggg)) {
                            System.out.println("Now DB POOL started sql4-------");
                            String sql1 = "INSERT INTO campaign_tpcodlop.callback_tab(account_id, msisdn, callback_date_time, record_status, record_id, campaign, created_on, created_by, agent_group) VALUES (108, ?, ?, 'active', ?, 'callback', NOW(), 'system', ?)";
                            String sql2 = "INSERT INTO campaign_tpcodlop.account_outbound(account_id, msisdn, record_status, record_id, campaign_name, request_date, agent_group) VALUES (108, ?, 'active', ?, 'callback', NOW(), ?)";

                            try (
                                PreparedStatement pst1 = conn2.prepareStatement(sql1);
                                PreparedStatement pst2 = conn2.prepareStatement(sql2);
                                PreparedStatement pst3 = conn1.prepareStatement("UPDATE smartivr_cloud.incoming_call_log SET update_flag = 5 WHERE id = ?");
                            ) {
                                pst1.setString(1, incoming_number);
                                pst1.setString(2, start_call_date);
                                pst1.setString(3, record_id);
                                pst1.setString(4, group_name);
                                pst1.executeUpdate();

                                pst2.setString(1, incoming_number);
                                pst2.setString(2, record_id);
                                pst2.setString(3, group_name);
                                pst2.executeUpdate();

                                pst3.setString(1, id);
                                pst3.executeUpdate();
                            }
                        } else {
                            try (PreparedStatement pst3 = conn1.prepareStatement("UPDATE smartivr_cloud.incoming_call_log SET update_flag = 1 WHERE id = ?")) {
                                pst3.setString(1, id);
                                pst3.executeUpdate();
                            }
                        }
                    }
                } else {
                    try (
                        Connection conn2 = DriverManager.getConnection("jdbc:mysql://localhost:3306/campaign_tpcodlop", "root", "");
                        Statement st3 = conn2.createStatement();
                    ) {
                        st3.executeUpdate("UPDATE smartivr_cloud.incoming_call_log SET update_flag = 1 WHERE id = " + id);
                        st3.executeUpdate("UPDATE campaign_tpcodlop.account_outbound SET record_status='inactive' WHERE msisdn='" + incoming_number + "' AND record_status='active'");
                    }
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Exiting the system..");
        }
    }
}
