package callback;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import java.util.Hashtable;
import java.util.UUID;

public class Test
{
  public static void main(String[] args)
  {
 System.out.println("New version For TPSODL Not Answered Call");
    ThreadPool tp = new ThreadPool(25);
   
    System.out.println("TP started");
 
    Connection conn = null;
    Connection conn1 = null;
    String sql ="";
    try
    {
    Class.forName("com.mysql.jdbc.Driver");  
   //conn=DriverManager.getConnection(  dburl,dbuserid,dbpasswd);  
   conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/smartivr_cloud","tpsodl_na","tpsodl_na");
   conn1=DriverManager.getConnection("jdbc:mysql://localhost:3306/campaign_tpsodl","tpsodl_na","tpsodl_na");
    sql="select incoming_number as msisdn,start_call_date as created_on,id,agent_group from smartivr_cloud.incoming_call_log where account_id=2 and status='NA' "
    		+ "and update_flag=0 and start_call_date < now() - interval 15 minute ";
    Statement st= conn.createStatement();
    System.out.println("NEW SQL="+sql+new Date().toString());
    ResultSet rs=st.executeQuery(sql);
    String msisdn="";
    String mydate="";
    String id="";
    String agent_group="";
    while( rs.next())
    {
    msisdn=rs.getString("msisdn");
    mydate=rs.getString("created_on");
    id=rs.getString("id");
    agent_group = rs.getString("agent_group");
    Statement st1=conn1.createStatement();
    String record_id=UUID.randomUUID().toString();
    String sql2="select count(1) as cnt from campaign_tpsodl.not_answered_tab where msisdn='"+msisdn+"' and created_on >  now() - interval 15 minute  and account_id=2";
    ResultSet rs2=st1.executeQuery(sql2);
    int cnt2=0;
    if ( rs2.next())
    {
    cnt2=rs2.getInt("cnt");
    if ( cnt2  < 1)
    {
    System.out.println("Processed "+msisdn);
    String sql1="insert into campaign_tpsodl.not_answered_tab(account_id, msisdn, missedcall_date_time, record_status , record_id, campaign_name, created_on, inserted_by) values(2,'"+msisdn+"','"+mydate+"','active','"+record_id+"','"+"not_answered',now(),'system')";
    st1.executeUpdate(sql1);
    sql1="insert into campaign_tpsodl.account_outbound(account_id, msisdn, record_status, record_id, campaign_name, request_date) values(2,'"+msisdn+"','active','"+record_id+"','"+"not_answered',now())";

    st1.executeUpdate(sql1);
   
    String sql3 = "update smartivr_cloud.incoming_call_log set update_flag=1 where id='"+id+"'";
    st.executeUpdate(sql3);
   
   
    }
   
    }
   
     
    }

   System.out.println("Now DB POOL started");
   System.exit(-1);
    }
    catch ( Exception ex)
    {
    ex.printStackTrace();
    System.out.println("Exiting the system..");
    System.exit(-1);
   
    }
    finally
    {
    if ( conn !=null)
    {
    try
    {
    conn.close();
    }
    catch ( Exception ex)
    {
   
    }
    }
    }  
  }
}