package pdfGenIDFC_WP;

import java.io.File;

class PdfTask implements Runnable {
  private String fileName;
  
  private String outputPath;
  
  public PdfTask(String fileName, String outputPath) {
    this.fileName = fileName;
    this.outputPath = outputPath;
  }
  
  public void run() {
    try {
      String password = this.fileName.split("-")[1].substring(0, 6);
      String fileNamePdf = String.valueOf(this.fileName.split("-")[0]) + ".pdf";
      System.out.println("Processing file: " + this.fileName);
      Process wait = Runtime.getRuntime().exec("/usr/local/bin/wkhtmltopdf /data/idfc/" + this.fileName + " " + this.outputPath + fileNamePdf);
      wait.waitFor();
      System.out.println("Generated PDF: " + fileNamePdf);
      Process waitencrypt = Runtime.getRuntime().exec("/home/softwares/jdk1.8.0_411/bin/java -jar /data/idfc/pdfbox-app-2.0.23.jar " + " " + this.outputPath + fileNamePdf);
      waitencrypt.waitFor();
      File myObj = new File("/data/idfc/" + this.fileName);
      if (myObj.delete()) {
        System.out.println("Deleted the file: " + myObj.getName());
      } else {
        System.out.println("Failed to delete the file: " + myObj.getName());
      } 
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
}

