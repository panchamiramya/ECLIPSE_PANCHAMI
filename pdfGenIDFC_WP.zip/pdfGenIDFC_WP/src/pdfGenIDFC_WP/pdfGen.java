package pdfGenIDFC_WP;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class pdfGen {
    public static void main(String[] args) throws InterruptedException, IOException {
        if (args.length <= 0) {
            System.out.println("Usage: java -jar PDFGEN.jar <pdfpath>");
            System.exit(0);
        }

        String outputPath = args[0];
        File outputDir = new File(outputPath);
        if (!outputDir.exists() || !outputDir.isDirectory()) {
            System.out.println("Invalid output path: " + outputPath);
            System.exit(1);
        }

        int numThreads = 10;
        ExecutorService executor = Executors.newFixedThreadPool(numThreads);

        while (true) {
            File directoryPath = new File("/data/idfc/");
            if (!directoryPath.exists() || !directoryPath.isDirectory()) {
                System.out.println("Directory not found: /data/idfc/");
                Thread.sleep(5000L);
                continue;
            }

            FilenameFilter textFilefilter = (dir, name) -> name.toLowerCase().endsWith(".html");
            String[] filesList = directoryPath.list(textFilefilter);

            if (filesList == null || filesList.length == 0) {
                System.out.println("No HTML files found in the specified directory.");
                Thread.sleep(5000L);
                continue;
            }

            System.out.println("List of HTML files in the directory:");
            for (String fileName : filesList) {
                System.out.println("Processing: " + fileName);
                executor.submit(new PdfTask(fileName, outputPath));
            }

            Thread.sleep(5000L);
        }
    }
}
