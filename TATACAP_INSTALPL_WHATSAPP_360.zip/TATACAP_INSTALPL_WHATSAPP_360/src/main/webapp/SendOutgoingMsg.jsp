<%@page import="java.util.Random"%>
<%@page import="java.util.Calendar"%>
<%@page import="java.util.UUID"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.text.DateFormat"%>
<%@page import="java.lang.Math.*"%>
<%@page import="java.io.OutputStream"%>
<%@page import="java.io.FileOutputStream"%>
<%@page import="java.io.File"%>
<%@page import="java.io.InputStream"%>
<%@page import="javax.naming.InitialContext"%>
<%@page import="javax.naming.Context"%>
<%@ page import = "java.util.Map" %>
<%@ page import = "java.util.Enumeration" %>
<%@ page import = "org.json.JSONObject" %>
<%@ page import = "org.json.JSONArray" %>
<%@ page import = "java.net.HttpURLConnection" %>
<%@ page import = "java.net.URL" %>
<%@ page import = "java.net.URLConnection" %>
<%@ page import = "java.net.URLDecoder" %>
<%@ page import = "java.net.URLEncoder" %>
<%@ page import = "javax.net.ssl.HttpsURLConnection" %>
<%@page import="helper.WhatsAppMessage"%>

<%@page contentType="text/html" pageEncoding="UTF-8"%> <%@page import="javax.sql.DataSource"%><%@page import="java.io.*"%>  <%@page import="java.sql.*" %><%@page import="org.json.*" %>

<%!
public String sendMessage(String session_id,String msisdn, String msg,String whatsapp_token,Connection conn)
{
	 
		  String contact_id=msisdn;
	
		  
      String json="{\n"
      		+ "  \"recipient_type\": \"individual\",\n"
      		+ "   \"type\": \"text\",\n"
      		+ "  \"to\": \""+contact_id+"\",\n"
      		+ "\"text\": {\n"
      		+ "    \"body\": \""+msg+"\"\n"
      		+ "  }\n"
      		+ "  \n"
      		+ "  \n"
      		+ "  \n"
      		+ " \n"
      		+ "  \n"
      		+ "}";
    
      return sendWhatsappMsg(session_id, json,msisdn,whatsapp_token,conn);
  }

public  String getResponseWhatsapp(String session_id,String json,String whatsapp_key)
{
    String xml=json;
    String res="";
     BufferedReader in=null;
/*    */       OutputStream out=null;
/*    */       Writer wout=null;
String url="https://waba.360dialog.io/v1/messages";
//   OutputStream out=null;
    try {
           URL url1 = new URL(url);
           System.out.println("url="+url+json);
/* 50 */       URLConnection connection = url1.openConnection();
/* 51 */       HttpsURLConnection httpConn = ((HttpsURLConnection)connection);
/* 52 */       httpConn.setReadTimeout(20000);
/* 53 */       httpConn.setConnectTimeout(20000);
/* 55 */       httpConn.setRequestProperty("d360-api-key", whatsapp_key);
/* 55 */       httpConn.setRequestProperty("cache-control", "no-cache");
            httpConn.setRequestProperty("content-type", "application/json");



/* 56 */       httpConn.setRequestMethod("POST");
           httpConn.setDoInput(true);
/* 57 */       httpConn.setDoOutput(true);

out = httpConn.getOutputStream();
out.write(xml.getBytes());
           //httpConn.connect();
/* 58 */      


/*    */
/* 60 */      // out = httpConn.getOutputStream();
/* 61 */      // wout = new OutputStreamWriter(out);
/* 62 */      // wout.flush();
//out = httpConn.getOutputStream();
//out.write(xml.getBytes());
           System.out.println("code="+httpConn.getResponseCode());
          
/* 64 */       InputStreamReader isr = new InputStreamReader(httpConn.getInputStream());
/*    */
/* 66 */       in = new BufferedReader(isr);
/* 67 */       String temp = "";
/* 68 */       res = "";
/* 69 */       while ((temp = in.readLine()) != null)
/* 70 */         res += temp;
           System.out.println("res_ok="+res);
           return res;
         
           
            

/*    */     }
/*    */     catch (Exception ex) {
	          
/* 73 */       ex.printStackTrace();
return "IOEXP";
/* 74 */
/*    */     }
/*    */     finally
/*    */     {
/*    */       try {
/* 79 */         in.close();
/* 80 */         wout.close();
/* 81 */         out.close();
/*    */       }
/*    */       catch (Exception tx)
/*    */       {
/*    */       }
/*    */     }
/*    */
/*    */



}


public String  sendWhatsappMsg(String session_id, String json,String msisdn,String whatsapp_token,Connection conn)
{
	try
	{
		
		String id="";
	
	String resp= getResponseWhatsapp(session_id, json,whatsapp_token);
	 JSONObject jb = new JSONObject(resp);
	    
	    JSONArray ids= jb.getJSONArray("messages");
		  if ( ids ==null || ids.length()==0)
		  {
			 
				String sql ="insert into whatsapp.outgoing_message(session_id,msg,to_msisdn) values(?,?,?)";
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setString(1, session_id);
				ps.setString(2, json);
				ps.setString(3, msisdn);

				ps.executeUpdate();
			  return "error";
		  }
		  else
		  {
			  JSONObject jb1 = ids.getJSONObject(0);
			 
				   id= jb1.getString("id");
				 
					String sql ="insert into whatsapp.outgoing_message(session_id,msg,msg_id,to_msisdn) values(?,?,?,?)";
					PreparedStatement ps = conn.prepareStatement(sql);
					ps.setString(1, session_id);
					ps.setString(2, json);
					ps.setString(3, id);
					ps.setString(4, msisdn);


					ps.executeUpdate();
				   return resp;
			  
			
		  }
	}
	catch( Exception ex)
	{
		ex.printStackTrace();
		return "error";
	}
	
}

%>
<%
response.setContentType("text/html");
response.addHeader("Freeflow","FC");
java.util.Date mydt = new java.util.Date();
response.setDateHeader("Date", mydt.getTime());
Connection conn=null;
Context ctx = new InitialContext();

 if (ctx == null)
 {
    throw new Exception("Boom - No Context");
 }
 Context envCtx = (Context) ctx.lookup("java:comp/env");

 DataSource ds =(DataSource)envCtx.lookup("jdbc/whatsapp");
 
  
    if (ds != null) {
        try{
        conn = ds.getConnection();
            }catch(Exception ex)
                         {
                           
                       }

 }

%><% 

String user_name="";
JSONObject jout= new JSONObject();
JSONObject jres=new JSONObject();
JSONObject jstat= new JSONObject();


try {
	
String reg_id="";
String msisdn="";
String email_id="";
String report_date="";
String account_id="";


//st= "select wavfilename from upload_wavfile_log"

msisdn=request.getParameter("msisdn");
String amount =request.getParameter("amount");
String lan=request.getParameter("lan");

WhatsAppMessage wa = new WhatsAppMessage();

String resp=wa.sendWhatsappTemplateMsg("", amount,lan,msisdn,"5XylMcfyYsfqGn13NOicwqrQAK",conn);

if ( !resp.equals("error"))
{


org.json.JSONObject jbsession= wa.getSessionInfo(msisdn, conn);
if ( jbsession ==null)
{
	 jbsession =new org.json.JSONObject();
	 jbsession.put("mystate","welcome");	 
	 jbsession.put("session_id",resp);

	 
	 
	 jbsession=wa.updateSessionInfo(msisdn, conn, jbsession);
	 
	 
}
jstat.put("statusCode", "0");

jres.put("status", jstat);
jout.put("result", jres);
out.println( jout.toString());
return;


}

jstat.put("statusCode", "1");
jstat.put("errCode","101");
jstat.put("errMessage","Message Failed");


jres.put("status", jstat);
jout.put("result", jres);
out.println( jout.toString());

return;












              
                
                               
                                
                                  
                                   
           
                
               
} catch (Exception e) {

e.printStackTrace();


jstat.put("statusCode", "1");
           jstat.put("errorCode","101");
           jstat.put("errorMessage","UNKNOWN_ERROR");
           jres.put("status", jstat);
           jout.put("result", jres);
          out.println( jout.toString());

/* 18 */
/*    */     }finally{
                        try{
                        	conn.close();
                        }catch(Exception exx)
                                                               {
                            
                        }
                    }



%>

