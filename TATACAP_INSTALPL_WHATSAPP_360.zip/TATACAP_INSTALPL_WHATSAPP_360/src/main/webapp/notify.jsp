<%@page import="org.json.JSONObject"%>
<%@page import="helper.MyMenu"%>
<%@page import="java.util.Random"%>
<%@page import="java.util.Calendar"%>
<%@page import="helper.WhatsAppMessage"%>


<%@page import="java.util.UUID"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.text.DateFormat"%>
<%@page import="java.lang.Math.*"%>
<%@page import="java.io.OutputStream"%>
<%@page import="java.io.FileOutputStream"%>
<%@page import="java.io.File"%>
<%@page import="java.io.InputStream"%>
<%@page import="javax.naming.InitialContext"%>
<%@page import="javax.naming.Context"%>
<%@ page import="java.util.Map"%>
<%@ page import="java.util.Date"%>


<%@ page import="java.util.Enumeration"%>
<%@ page import="java.util.ArrayList"%>

<%@ page import="org.json.simple.JSONArray"%>




<%@ page import="org.json.simple.parser.JSONParser"%>

<%@ page import=" java.text.NumberFormat"%>
<%@ page import=" java.text.DecimalFormat"%>



<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="javax.sql.DataSource"%><%@page import="java.io.*"%>
<%@page import="java.sql.*"%>
<%
	response.setContentType("text/html");
	response.addHeader("Freeflow", "FC");
	java.util.Date mydt = new java.util.Date();
	response.setDateHeader("Date", mydt.getTime());
	Connection conn = null;
	Context ctx = new InitialContext();
	
	if (ctx == null) {
		throw new Exception("Boom - No Context");
	}
	Context envCtx = (Context) ctx.lookup("java:comp/env");
	
	DataSource ds = (DataSource) envCtx.lookup("jdbc/whatsapp");

	if (ds != null) {
		try {
			conn = ds.getConnection();
		} catch (Exception ex) {
	
		}
	
	}
%>
<%
	String user_name = "";

	final String ACCOUNT_SID = "AC01f0c97858ce79906d4855d840ef32cc";
	final String AUTH_TOKEN = "59bfedb7bd610fc04cf9ea98f01ca22a";
	final String INSTAPL_WELCOME = "Hi there! 👋 Welcome to Tata Capital - Count on us" + "\n\n"
		+ "Before we start, please choose your preferred language" + "\n" + "from the options below:" + "\n" + "\n" +

		"शुरू करने से पहले, नीचे दिए गए विकल्पों में से कृपया अपनी पसंदीदा भाषा चुनें|" + "\n\n" +

		"1️⃣ *English*" + "\n" + "2️⃣ *हिंदी*" + "\n";
	//final String ISTAPL_WELCOME="Hi there 👏Welcome to Tata Capital - Count on us Before we start, please choose your preferred language from the option below:1️⃣ English2️⃣ हिंदी";

	try 
	{
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
	
		Map<String, String[]> parameters = request.getParameterMap();
		String challenge = "";
		String token = "";
		/*
		hub.mode:subscribe
		hub.challenge:6461399
		hub.verify_token:Ikontel$987@123
		*/
		String method = "";
		for (String parameter : parameters.keySet()) 
		{
			{
				String[] values = parameters.get(parameter);
				//System.out.println(parameter + ":" + values[0]);
				if (parameter.equals("hub.mode") && values[0].equals("subscribe")) 
				{
					method = "subscribe";
				}
				if (parameter.equals("hub.verify_token")) 
				{
					token = values[0];
				}
				if (parameter.equals("hub.challenge")) 
				{
					challenge = values[0];
				}
			}
		}
	
		if (method.equals("subscribe") && token.equals("Ikontel$987@123")) 
		{
			out.print(challenge);
			return;
		}
	
		Enumeration<String> headerNames = request.getHeaderNames();
	
		while (headerNames.hasMoreElements()) 
		{
	
			String headerName = headerNames.nextElement();
			//System.out.print(headerName + " = ");
			String headerValue = request.getHeader(headerName);
			//System.out.println(headerValue);
		}
	
		String uid = UUID.randomUUID().toString();
	
		String reg_id = "";
		String msisdn = "";
		String email_id = "";
		String report_date = "";
		final String account_id = "instalpl";
	
		//st= "select wavfilename from upload_wavfile_log"
	
		InputStream is = request.getInputStream();
		String cldfilename = "";
	
		JSONParser jsonParser = new JSONParser();
		org.json.simple.JSONObject jsonObject = (org.json.simple.JSONObject) jsonParser
		.parse(new InputStreamReader(is, "UTF-8"));
	
		//{"statuses":[{"id":"gBEGkZdBQRCHAglCL08Zx7t5hss","conversation":{"id":"bee2d03aee293c9614298433b48ea479"},"pricing":{"pricing_model":"NBP","billable":true},"recipient_id":"919741411087","status":"delivered","timestamp":"1627904134"}]}
		//System.out.println(jsonObject.toString());
		org.json.simple.JSONArray jarr = null;
		try
		{
			org.json.JSONObject jbsession = new org.json.JSONObject();
			jbsession = new org.json.JSONObject();
			org.json.simple.JSONArray jenrty = (org.json.simple.JSONArray) jsonObject.get("entry");
			org.json.simple.JSONObject jb1 = (org.json.simple.JSONObject) jenrty.get(0);
			org.json.simple.JSONArray jarr_chgs = (org.json.simple.JSONArray) jb1.get("changes");
			org.json.simple.JSONObject jb2 = (org.json.simple.JSONObject) jarr_chgs.get(0);
			org.json.simple.JSONObject values = (org.json.simple.JSONObject) jb2.get("value");
	
			//	jarr=(org.json.simple.JSONArray)jsonObject.get("statuses");
	
			jarr = (org.json.simple.JSONArray) values.get("statuses");
			//jarr=(org.json.simple.JSONArray)jb2.get("statuses");
	
			if (jarr == null) 
			{
				/*
				{
				"entry":[
				{
				 "changes":[],
				 "id":"100938666067856"
				}
				],
				"object":"whatsapp_business_account"
				}
				*/
				jenrty = (org.json.simple.JSONArray) jsonObject.get("entry");
				jb1 = (org.json.simple.JSONObject) jenrty.get(0);
				jarr_chgs = (org.json.simple.JSONArray) jb1.get("changes");
			
				//System.out.println("jarr_chgs" + jarr_chgs.toString());
			
				jb2 = (org.json.simple.JSONObject) jarr_chgs.get(0);
				//System.out.println("JSONObject" + jb2.toString());
			
				//	((org.json.simple.JSONObject)jarr_chgs.get(0)).get("messages")
			
				values = (org.json.simple.JSONObject) jb2.get("value");
				
				org.json.simple.JSONObject mdata=  (org.json.simple.JSONObject) values.get("metadata");
				
				String phone_number_id=(String)mdata.get("phone_number_id");
				if ( !phone_number_id.equals("104110786108055"))
				{
					return;
				}
		
				org.json.simple.JSONArray jarr_msgs = (org.json.simple.JSONArray) values.get("messages");
			
				org.json.simple.JSONObject jb = (org.json.simple.JSONObject) jarr_msgs.get(0);
			
				String from1 = (String) jb.get("from");
				String from = from1;
				String id = (String) jb.get("id");
			
				String conversation_id = "";
				try 
				{
					conversation_id = (String) ((org.json.simple.JSONObject) jb.get("conversation")).get("id");
				}
				catch (Exception ex) 
				{
				}
			
				if (from1.equals("919110853949")) 
				{
					from1 = "919110853949";
				}
			
				msisdn = from1.substring(2);
			
				String body = jb.toJSONString();
				String type = "";
				String status = "";
				if (jb.get("status") == null) 
				{
					type = "incoming";
					status = "";
				}
				else
				{
					type = "outgoing";
					status = (String) jb.get("status");
					WhatsAppMessage wa = new WhatsAppMessage();
			
					org.json.JSONObject js = new org.json.JSONObject();
					if (!conversation_id.equals("")) 
					{
						js.put("session_id", conversation_id);
						wa.updateSessionInfo(from, conn, js, account_id);
					}
			
				}
			
				String pssql = "insert into incoming_message_axis(from_msisdn,message,msg_id,call_type,msg_status,session_id,account_id) values(?,?,?,?,?,?,?)";
				PreparedStatement ps = conn.prepareStatement(pssql);
				ps.setString(1, from);
				ps.setString(2, body);
				ps.setString(3, id);
				ps.setString(4, type);
				ps.setString(5, status);
				ps.setString(6, conversation_id);
			
				ps.setString(7, "instapl");
			
				ps.executeUpdate();
			
				if (type.equals("incoming")) 
				{
					WhatsAppMessage wa = new WhatsAppMessage();
					String resp = wa.getIntent(body, from, conn, account_id);
			
					jbsession = wa.getSessionInfo(from, conn, account_id);
			
					//System.out.println("RESP=" + resp);
					if (resp.startsWith("menu")) 
					{
						String menu = resp.split("\\:")[1];
			
						System.out.println("MENU Selected:" + menu);
						if (menu.equals("invalid"))
						{
							wa.sendMessage360("121212122", from, "You have entered an invalid value",
									"5XylMcfyYsfqGn13NOicwqrQAK", conn);
						}
			
						else if (menu.equals("stop"))
						{
							String msg = wa.removeFromWhatsapp(msisdn);
							if (msg.contains("consent_value")) 
							{
								wa.sendMessage360("121212122", from, "You are successfully unsubscribed from the services.",
										"5XylMcfyYsfqGn13NOicwqrQAK", conn);
							} 
							else {
								wa.sendMessage360("121212122", from, "We are facing some issue. Please try again",
										"5XylMcfyYsfqGn13NOicwqrQAK", conn);
							}
			
						}
			
						else if (menu.equals("AMTCHOOSEN")) 
						{
							jbsession = wa.getSessionInfo(from, conn, account_id);
							ArrayList arr = new ArrayList();
			
							jbsession = wa.getSessionInfo(from, conn, account_id);
							org.json.JSONArray proddetail = jbsession.getJSONArray("proddetail");
			
							MyMenu mm = new MyMenu();
							int index = Integer.parseInt(jbsession.getString("selectindex"));
							System.out.println("SELECTED INDEX=" + index);
			
							jbsession.put("selectindex", index + "");
							wa.updateSessionInfo(msisdn, conn, jbsession, account_id);
			
							String gcid = proddetail.getJSONObject(index).getString("gcid");
			
							String contract_id = proddetail.getJSONObject(index).getString("contract_no");
							String COMPANY_NAME = proddetail.getJSONObject(index).getString("COMPANY_NAME");
			
							String cust_name = proddetail.getJSONObject(index).getString("cust_name");
							String email = proddetail.getJSONObject(index).getString("email");
			
							String PROD_CODE = proddetail.getJSONObject(index).getString("PRODUCT_CODE");
							String product = proddetail.getJSONObject(index).getString("product");
							String contract_id1 = proddetail.getJSONObject(index).getString("contract_id");
							JSONObject pgdetail = jbsession.getJSONObject("pgdetail");
							String mycontractid = pgdetail.getString("contract_id");
							String outstandingamt = pgdetail.getString("outstandingamt");
							String odcharges = pgdetail.getString("odcharges");
			
							System.out.println("CONTRACT_CHOOSEN=" + contract_id);
			
							String choosen_amt = jbsession.getString("choosen_amount");
			
							System.out.println("AMTCHOOSEN=" + "Please click the below link to pay");
							wa.sendMessage360("121212122", from, "*Please click the below link to pay*",
									"5XylMcfyYsfqGn13NOicwqrQAK", conn);
			
							new Thread(new Runnable() 
							{
								public void run() 
								{
									WhatsAppMessage wa = new WhatsAppMessage();
									wa.doHeavy(from, outstandingamt, outstandingamt, contract_id, odcharges, cust_name,
											email, product, COMPANY_NAME, PROD_CODE, outstandingamt, choosen_amt);
			
									/*	 makePaymentLink(String contract_id,String amount,String cust_name,String email_id,String msisdn,
													String prod_name,String company,String product_code,String source_system,
													String od_charges,String total_amount, String paid_total, 
													String trans_type, String channel,String unique_trans_id,String return_url)*/
			
									/*	wa.doHeavy(from,due_amt,outstandingamt,contract_id,od_charges,cust_name,email,
												from,product,COMPANY_NAME,PROD_CODE,total_amount,total_paid_total);*/
			
								}
							}).start();
			
							return;
			
						}
						
						else if (menu.toLowerCase().startsWith("welcome")) 
						{
							//arr.add("Detail");
							jbsession = new org.json.JSONObject();
							jbsession.put("session_id", UUID.randomUUID().toString());
							jbsession.put("menu_choosen", "welcome");
			
							jbsession = wa.updateSessionInfo(from, conn, jbsession, account_id);
			
							String json1 = wa.sendMessage360("121222", from, INSTAPL_WELCOME, wa.whatsapp_key, conn);
			
						}
						
						else if (menu.toLowerCase().equals("bye")) 
						{
							jbsession.put("menu_choosen", "");
			
							wa.updateSessionInfo(from, conn, jbsession, account_id);
							wa.sendMessage360("121222", from, "Thanks. Bye.", "5XylMcfyYsfqGn13NOicwqrQAK", conn);
						}
						
						else if (menu.toLowerCase().equals("englishmain")) 
						{
							jbsession.put("menu_choosen", "englishmain");
							wa.updateSessionInfo(from, conn, jbsession, account_id);
			
							String mainmenumsg = "Hi, I am *TIA*, Virtual Assistant "
									+ "on WhatsApp, here to assist you in your Consumer Loans Application"
									+ "process and assist you in downloading your statements and certificates."
									+ "Please choose from below services" + "\n\n" +
			
									"Choose from below options to begin with\n" + "*1️⃣ Self-Service*" + "\n"
									+ "*2️⃣ Apply for a Loan*" + "\n" + "*3️⃣ Quick Pay*" + "\n"
									+ "*4️⃣ Pre-Approved Personal Loan*" + "\n" + "*5️⃣ Locate Us*" + "\n" +
			
									"Type 1️⃣, 2️⃣, 3️⃣,4️⃣ or 5️⃣ to continue" + "\n"
									+ "You can type *_Home_* at any stage to return to the main menu" + "\n\n" ;
			
							//	wa.sendMessage360Welcome("121222", from, mainmenumsg,wa.whatsapp_key, conn);
							wa.sendMessage360("121222", from, mainmenumsg, wa.whatsapp_key, conn);
						}
						
						else if (menu.toLowerCase().equals("hindimain")) 
						{
								jbsession.put("menu_choosen", "englishmain");
								wa.updateSessionInfo(from, conn, jbsession, account_id);
			
								String mainmenumsg = "Hi, I am *TIA*, Virtual Assistant "
										+ "on WhatsApp, here to assist you in your Consumer Loans Application"
										+ "process and assist you in downloading your statements and certificates."
										+ "Please choose from below services" + "\n\n" +
			
										"Choose from below options to begin with\n" + "*1️⃣ Self-Service*" + "\n"
										+ "*2️⃣ Apply for a Loan*" + "\n" + "*3️⃣ Quick Pay*" + "\n"
										+ "*4️⃣ Pre-Approved Personal Loan*" + "\n" + "*5️⃣ Locate Us*" + "\n" +
			
										"Type 1️⃣, 2️⃣, 3️⃣,4️⃣ or 5️⃣ to continue" + "\n"
										+ "You can type *_Home_* at any stage to return to the main menu" + "\n\n" ;
			
			
								//	wa.sendMessage360Welcome("121222", from, mainmenumsg,wa.whatsapp_key, conn);
								wa.sendMessage360("121222", from, mainmenumsg, wa.whatsapp_key, conn);
						}
						
						else if (menu.toLowerCase().equals("engsendotp")) 
						{
							final Connection conn1 = ds.getConnection();
							final String msisdn1=msisdn;
			
							new Thread(new Runnable() 
							{
								public void run() 
								{
									try
									{
										JSONObject jbsession = null;
			
										jbsession=wa.getSessionInfo(from, conn1, account_id);
										JSONObject jboffer = wa.getOfferDetailWithNumber(msisdn1);
			
										JSONObject jstatus = jboffer.getJSONObject("status");
										
			
										if (!jstatus.getString("statusMessage").equals("SUCCESS")) 
										{
											wa.sendMessage360("121222", from, "Sorry no offer is configured for this number",
													wa.whatsapp_key, conn1);
											return;
										}
			
										String offer_amount ="";
										String offer_tenure="";
										
										try
										{
											String access_token = jboffer.getString("accessToken");
											String app_id = jboffer.getJSONObject("personalInfo").getString("appId");
											if ( from.equals("919110853949"))
											{
											 JSONObject jOfferDetail = new JSONObject();
											 jOfferDetail.put("offerAmount",1000000);
											 jOfferDetail.put("offerTenureInMonths",24);
											 jboffer.put("offerDetails",jOfferDetail);
											}
				
											
											 offer_amount = jboffer.getJSONObject("offerDetails").getString("offerAmount");
											 offer_tenure = jboffer.getJSONObject("offerDetails").getString("offerTenureInMonths");
											jbsession.put("max_tenure", offer_tenure);
											jbsession.put("offer_tenure", offer_tenure);
				
											jbsession.put("offer_amount", offer_amount);
											jbsession.put("access_token", access_token);
											jbsession.put("app_id", app_id);
										}
										catch ( Exception ex)
										{
											ex.printStackTrace();
											wa.sendMessage360("121222", from, "Sorry no offer is configured for this number",
													wa.whatsapp_key, conn1);
													return;
										}
			
										jbsession.put("menu_choosen", "engsendotp");
			
										wa.updateSessionInfo(from, conn1, jbsession, account_id);
										jbsession = wa.getSessionInfo(from, conn1, account_id);
										/* String offer_msg="Here is an offer curated just for you \n"+
												"you can apply for loan for upto Rs "+ offer_amount+"\n"+
												"at a maximum of "+offer_tenure+" months's tenure\n"+
												
			                                    "Type 1️⃣"+ " if you wish to modify the offer \n"+
			                                    "Type 2️⃣"+ " if you wish to continue with\n"+ 
			                                    "above loan amount"; */
												
										String wel_msg ="Congratulations!!! You already have \n"+
														"Pre- Approved Personal loan from TATA Capital.\n"+
														"Type 1️⃣"+ " to apply";	
												
														
										wa.sendMessage360("121222", from, wel_msg,
														wa.whatsapp_key, conn1);
			
										
										 
										String msg="";
									
									}
									catch (Exception ex) 
									{
									}
									finally
									{
										try
										{
											conn1.close();
										}
										catch (Exception ex) 
										{
										}
									}
			
								}
							}).start();
			
						} 
						
						else if (menu.toLowerCase().equals("engsendotp1")) 
						{
			
							final Connection conn1 = ds.getConnection();
							final String msisdn1=msisdn;
			
							new Thread(new Runnable() 
							{
								public void run() 
								{
									try 
									{
										JSONObject jbsession = null;
										jbsession=wa.getSessionInfo(from, conn1, account_id);
			
										String ref_id = wa.sendOTP(from.substring(2));
										if (ref_id.equals("fail")) 
										{
											wa.sendMessage360("121222", from,
													"Sorry we are facing technical issue. Please try after sometime.",
													wa.whatsapp_key, conn1);
			
										}
										else
										{
											wa.sendMessage360("121222", from,
													"Please enter the OTP sent on your \r\nRegistered mobile number to process.\r\nType 2️⃣ to resend the OTP.",
													wa.whatsapp_key, conn1);
			
										}
										jbsession.put("ref_id", ref_id);
										wa.updateSessionInfo(from, conn1, jbsession, account_id);
									}
									catch (Exception ex) 
									{
									}
									finally
									{
										try
										{
											conn1.close();
										} 
										catch (Exception ex) 
										{
										}
									}
			
								}
							}).start();
			
						} 
						
						else if (menu.toLowerCase().equals("engvalidateotp")) 
						{
			
							final Connection conn1 = ds.getConnection();
							final String msisdn1=msisdn;
			
							new Thread(new Runnable() 
							{
								public void run() 
								{
									try 
									{
										JSONObject jbsession = null;
										jbsession=wa.getSessionInfo(from, conn1, account_id);
										String ref_id = jbsession.getString("ref_id");
										String myotp = resp.split("\\:")[2];
			
										JSONObject jres = wa.verifyOTP(msisdn1, ref_id, myotp);
			
										String access_token = jbsession.getString("access_token");
			
										String apiresult = jres.getString("result");
			
										//JSONObject jpersonal_info = jres.getJSONObject("personalinfo");
									   String app_id = jbsession.getString("app_id");
									   
										wa.generateWebOTP(msisdn1, app_id, access_token);
										
										if (apiresult.equals("fail")) 
										{
											wa.sendMessage360("121222", from,
													"The OTP you have entered is invalid or has expired.\n"
															+ "Please enter a valid OTP to continue.\n"
															+ "Type 2️⃣ to Resend OTP to your phone number.",
													wa.whatsapp_key, conn1);
			
											jbsession.put("menu_choosen", "engsendotp");
											wa.updateSessionInfo(from, conn1, jbsession, account_id);
										}
										else
										{
											jbsession.put("menu_choosen", "enterpan");
											jbsession.put("access_token", access_token);
											jbsession.put("app_id", app_id);
			
											wa.updateSessionInfo(from, conn1, jbsession, account_id);
			
											wa.sendMessage360("121222", from,
													"Thanks! Please type your *PAN* number\r\nto get your details\r\n", wa.whatsapp_key,
													conn1);
											return;
			
										}
										
									}
									catch (Exception ex) 
									{
									}
									finally
									{
										try
										{
											conn1.close();
										}
										catch (Exception ex) 
										{
										}
			
									}
								}
							}).start();
						} 
						else if (menu.toLowerCase().equals("enterofferamount")) 
						{
							String max_amount = jbsession.getString("offer_amount");
							String min_amount = "50000";
			
							jbsession.put("min_amount", min_amount);
							jbsession.put("max_amount", max_amount);
			
							jbsession.put("menu_choosen", "enterofferamount");
							//  jbsession.put("offeramount",resp.split("\\:")[2]);
							wa.updateSessionInfo(from, conn, jbsession, account_id);
							wa.sendMessage360("121222", from,
									"What is the loan amount you wish to apply ?Please choose between *" + "Rs."+min_amount
											+ "* to *" + "Rs."+max_amount + "*?",
									wa.whatsapp_key, conn);
							return;
						}
			
						else if (menu.toLowerCase().equals("checkamount")) 
						{
							String offeramount = resp.split("\\:")[2];
			
							String max_amount = jbsession.getString("max_amount");
							String min_amount = jbsession.getString("min_amount");
							if (!(Float.parseFloat(offeramount) >= Float.parseFloat(min_amount)
									&& Float.parseFloat(offeramount) <= Float.parseFloat(max_amount))) 
							{
								wa.sendMessage360("121222", from, "Please enter a valid amount. Please choose between *"
										+ min_amount + "* to *" + max_amount + "*?", wa.whatsapp_key, conn);
								return;
			
							}
							jbsession.put("choosenamount", offeramount);
							jbsession.put("menu_choosen", "checkamount");
			
							wa.updateSessionInfo(from, conn, jbsession, account_id);
							wa.sendMessage360("121222", from, "Please enter tenure 12, 24, 36 or 48 ", wa.whatsapp_key,
									conn);
			                return;
							//  wa.sendMessage360("121222", from,"Sure. Can I have your company name? \r\n*TIP!* Please enter full name for e.g TATA\r\nCapital instead of just TATA.?",wa.whatsapp_key, conn);
			
						}
						
						else if (menu.toLowerCase().equals("checkamount1")) 
						{
							String offeramount = resp.split("\\:")[2];
							String max_amount = jbsession.getString("max_amount");
							String min_amount = jbsession.getString("min_amount");
							if (!(Float.parseFloat(offeramount) >= Float.parseFloat(min_amount)
									&& Float.parseFloat(offeramount) <= Float.parseFloat(max_amount))) 
							{
								wa.sendMessage360("121222", from, "Please enter a valid amount. Please choose between *"
										+ "Rs."+min_amount + "* to *" + "Rs."+max_amount + "*?", wa.whatsapp_key, conn);
								return;
			
							}
							jbsession.put("choosenamount", offeramount);
							jbsession.put("menu_choosen", "checkamount1");
			
							wa.updateSessionInfo(from, conn, jbsession, account_id);
							wa.sendMessage360("121222", from, "Please enter tenure 12, 24, 36 or 48 ", wa.whatsapp_key,
									conn);
			                return;
							//  wa.sendMessage360("121222", from,"Sure. Can I have your company name? \r\n*TIP!* Please enter full name for e.g TATA\r\nCapital instead of just TATA.?",wa.whatsapp_key, conn);
			
						}
			
						else if (menu.equals("enterpan")) 
						{
							String tenure = resp.split("\\:")[2];
							jbsession.put("tenure", tenure);
							wa.sendMessage360("121222", from, "Please enter your PAN number", wa.whatsapp_key, conn);
							jbsession.put("menu_choosen", "enterpan");
			
							wa.updateSessionInfo(from, conn, jbsession, account_id);
							return;
			
						} 
			
						/* else if (menu.toLowerCase().equals("validatepan")) 
						{
							String mypan = resp.split("\\:")[2];
							String access_token = jbsession.getString("access_token");
							String app_id = jbsession.getString("app_id");
							jbsession.put("mypan", mypan);
			
							String res = wa.verifyPAN(from.substring(2), app_id, access_token, mypan);
							if (res.equals("success")) 
							{
								wa.sendMessage360("121222", from, "Are you \n"+ 
										"1️⃣ salaried \n"+
										"2️⃣ self-employed ",
										wa.whatsapp_key, conn);
			
								//String mypan=resp.split("\\:")[2];
			
								jbsession.put("menu_choosen", "validatepan");
								wa.updateSessionInfo(from, conn, jbsession, account_id);
							}
							else 
							{
								wa.sendMessage360("121222", from, "INVALID PAN", wa.whatsapp_key, conn);
			
								jbsession.put("menu_choosen", "enterpan");
								wa.updateSessionInfo(from, conn, jbsession, account_id);
							}
							return;
			
						} */
						

						else if (menu.toLowerCase().equals("validatepan")) {
						    String mypan = resp.split("\\:")[2];
						    //System.out.println(mypan+"_ABCD_"+resp);
						    String access_token = jbsession.getString("access_token");
						    String app_id = jbsession.getString("app_id");
						    jbsession.put("mypan", mypan);
						
						    String res = wa.verifyPAN(from.substring(2), app_id, access_token, mypan);
						    //System.out.println("EFGH_"+res);
						    if (res.equals("success")) 
						    {
						        final Connection conn1 = ds.getConnection();
						        final String msisdn1 = msisdn;
						
						        new Thread(new Runnable() {
						            public void run() {
						                try {
						                    JSONObject jbsession = null;
						
						                    jbsession = wa.getSessionInfo(from, conn1, account_id);
						                    JSONObject jboffer = wa.getOfferDetailWithNumber(msisdn1);
						
						                    JSONObject jstatus = jboffer.getJSONObject("status");
						
						                    if (!jstatus.getString("statusMessage").equals("SUCCESS")) {
						                        wa.sendMessage360("121222", from, "Sorry no offer is configured for this number",
						                                wa.whatsapp_key, conn1);
						                        return;
						                    }
						
						                    String offer_amount = "";
						                    String offer_tenure = "";
						
						                    try {
						                        String access_token = jboffer.getString("accessToken");
						                        String app_id = jboffer.getJSONObject("personalInfo").getString("appId");
						                        if (from.equals("919110853949")) {
						                            JSONObject jOfferDetail = new JSONObject();
						                            jOfferDetail.put("offerAmount", 1000000);
						                            jOfferDetail.put("offerTenureInMonths", 24);
						                            jboffer.put("offerDetails", jOfferDetail);
						                        }
						
						                        offer_amount = jboffer.getJSONObject("offerDetails").getString("offerAmount");
						                        offer_tenure = jboffer.getJSONObject("offerDetails").getString("offerTenureInMonths");
						                        jbsession.put("max_tenure", offer_tenure);
						                        jbsession.put("offer_tenure", offer_tenure);
						
												/*NumberFormat formatter = new DecimalFormat("##,##,###");
						                        double offerAmountValue = Double.parseDouble(offer_amount);
						                        String formattedOfferAmount = formatter.format(offerAmountValue);
						                        jbsession.put("offer_amount", formattedOfferAmount);*/
						
						                        jbsession.put("offer_amount", offer_amount);
						                        jbsession.put("access_token", access_token);
						                        jbsession.put("app_id", app_id);
						                    } catch (Exception ex) {
						                        ex.printStackTrace();
						                        wa.sendMessage360("121222", from, "Sorry no offer is configured for this number",
						                                wa.whatsapp_key, conn1);
						                        return;
						                    }
						
						                    //jbsession.put("menu_choosen", "modifyoffer");
											jbsession.put("menu_choosen", "validatepan");
						                    wa.updateSessionInfo(from, conn1, jbsession, account_id);
						                    jbsession = wa.getSessionInfo(from, conn1, account_id);
						                    String offer_msg = "Here is an offer curated just for you \n" + "you can apply for loan for upto Rs "
						                            + jbsession.getString("offer_amount") +  " at a maximum of " + jbsession.getString("offer_tenure") + " months's tenure\n"
						                            + "Type 1️⃣" + " if you wish to modify the offer \n" + "Type 2️⃣"
						                            + " if you wish to continue with\n" + "above loan amount";
						
						                    String msg = "";
						                    
						                    
						                    
								    		wa.sendMessage360("121222", from, offer_msg, wa.whatsapp_key, conn1);
								    		
								    		/* String userResponse = resp.split("\\:")[1]; 
								    		System.out.println("_IJKL_"+userResponse);
						                    if (userResponse.equals("1")) {
						                        jbsession.put("menu_choosen", "editoffer");
						                        wa.sendMessage360("121222", from, "Please enter the amount between " +
						                                "pre-approved amount (" + jbsession.getString("min_amount") + 
						                                " - " + jbsession.getString("max_amount") + ")", wa.whatsapp_key, conn1);
						                    } else if (userResponse.equals("2")) {
						                        jbsession.put("menu_choosen", "entertenure");
						                        wa.sendMessage360("121222", from, "Please enter the tenure between 12 and 48 months", wa.whatsapp_key, conn1);
						                    } */
						
						                } catch (Exception ex) {
						                    ex.printStackTrace();
						                } finally {
						                    try {
						                        conn1.close();
						                    } catch (Exception ex) {
						                        ex.printStackTrace();
						                    }
						                }
						            }
						        }).start();
								
						        wa.updateSessionInfo(from, conn, jbsession, account_id);
						    }
						
						    else
						    {
								String errorMessage = "Sorry!! Entered PAN Number Is not Match with the database, please re-enter";
							    wa.sendMessage360("121222", from, errorMessage, wa.whatsapp_key, conn);
								jbsession.put("menu_choosen", "enterpan");
							    wa.updateSessionInfo(from, conn, jbsession, account_id);
						    }
						}

						/* else if (menu.toLowerCase().equals("editoffer")) {
						    String userChoice = resp.split("\\:")[2];
						    if (userChoice.equals("2")) {
						       
						    } else if (userChoice.equals("1")) {
						        
						        String access_token = jbsession.getString("access_token");
						        String app_id = jbsession.getString("app_id");
						        String issalaried = jbsession.getString("issalaried");
						        String offeramount = jbsession.getString("choosenamount");
						        String tenure = jbsession.getString("tenure");
						        String company_name = jbsession.getString("company_name");
						        String companycode = jbsession.getString("companycode");
						        String max_amount = jbsession.getString("offer_amount");
								String min_amount = "50000";
						        
						        if (issalaried.toLowerCase().equals("1")) {
						            issalaried = "true";
						        } else {
						            issalaried = "false";
						        }
						        
						        JSONObject offerdetail = wa.getPAOfferDetail(offeramount, companycode, issalaried, tenure, app_id, from.substring(2), access_token);
						        
						        if (offerdetail.getString("status").equals("none")) {
						            wa.sendMessage360("121222", from, "No offer is configured for this number", wa.whatsapp_key, conn);
						        } else {
						            String loan_amount = offerdetail.getString("loanAmount").split("\\.")[0];
						            String roi = offerdetail.getString("roi");
						            String pf = offerdetail.getString("pf");
						            String emi = offerdetail.getString("emi").split("\\.")[0];
						            
						            access_token = jbsession.getString("access_token");
						            app_id = jbsession.getString("app_id");
						            
						            JSONObject jbpersonal = new JSONObject();
						            jbpersonal.put("companyName", company_name);
						            jbpersonal.put("companyCode", companycode);
						            jbpersonal.put("officialEmail", "");
						            jbpersonal.put("mobileNumber", from.substring(2));
						            jbpersonal.put("minLoanAmount", Float.parseFloat(min_amount));
						            jbpersonal.put("maxLoanAmount", Float.parseFloat(max_amount));
						            jbpersonal.put("minTenure", "12");
						            jbpersonal.put("loanAmount", loan_amount);
						            jbpersonal.put("emi", emi);
						            jbpersonal.put("roi", roi);
						            jbpersonal.put("pf", pf);
						            jbpersonal.put("tenure", tenure);
						            jbpersonal.put("new", true);
						            jbpersonal.put("applSource", "PA");
						            jbpersonal.put("appId", app_id);
						            jbpersonal.put("deviceType", "Whatsapp");
						            jbpersonal.put("deviceSubType", "Whatsapp");
						            jbpersonal.put("channel", "Whatsapp");
						            jbpersonal.put("employment", 1);
						            
						            JSONObject jbres = wa.savePersonalOffer(jbpersonal, access_token);
						            
						            String msg = "Great 👍 Here is your revised offer \n\n"
						                    + "*Loan Amount*: " + loan_amount + "\n"
						                    + "*Rate of Interest* :" + roi + "\n"
						                    + "*Processing Fees* :" + pf + "\n"
						                    + "*EMI* :" + emi + "\n"
						                    + "*Tenure* :" + tenure + "\n\n"
						                    + "Type 1️⃣ to continue and 2️⃣ to edit your offer";
						            
						            jbsession.put("menu_choosen", "editoffer");
						            wa.updateSessionInfo(from, conn, jbsession, account_id);
						            JSONObject jbres1 = wa.editOffer(msisdn, app_id);
						            System.out.println(jbres1.toString());
						            wa.sendMessage360("121222", from, msg, wa.whatsapp_key, conn);
						        }
						    } else {
						        wa.sendMessage360("121222", from, "Invalid choice. Please choose 1️⃣ to continue or 2️⃣ to edit your offer.", wa.whatsapp_key, conn);
						    }
						    						    return;
						} */

						
						else if (menu.toLowerCase().equals("issalaried")) {
							String issalaried = resp.split("\\:")[2];
			
							jbsession.put("menu_choosen", "issalaried");
							jbsession.put("issalaried", issalaried);
			
							wa.updateSessionInfo(from, conn, jbsession, account_id);
			
							String max_amount = jbsession.getString("offer_amount");
							String min_amount = "50000";
							jbsession.put("min_amount", min_amount);
							jbsession.put("max_amount", max_amount);
			
							jbsession.put("menu_choosen", "enterofferamount");
							//  jbsession.put("offeramount",resp.split("\\:")[2]);
							wa.updateSessionInfo(from, conn, jbsession, account_id);
							wa.sendMessage360("121222", from,
									"What is the loan amount you wish to apply ?Please choose between *" + min_amount
											+ "* to *" + max_amount + "*?",
									wa.whatsapp_key, conn);
			
							// wa.sendMessage360("121222", from,"Please enter tenure 6 ,12, 24 ,36 or 48 ",wa.whatsapp_key, conn);
			
							// wa.sendMessage360("121222", from,"Sure. Can I have your company name? \r\n*TIP!* Please enter full name for e.g TATA\r\nCapital instead of just TATA.?",wa.whatsapp_key, conn);
							return;
						}
			
						else if (menu.toLowerCase().equals("entertenure")) 
						{
							String tenure = "";
							String sameoffer="1";
							try
							{
								sameoffer=jbsession.getString("sameoffer");
							}
							catch ( Exception ex)
							{
							}
							if ( sameoffer.equals("2"))
							{
								String issalaried = resp.split("\\:")[2];
			
								jbsession.put("menu_choosen", "issalaried");
								jbsession.put("issalaried",issalaried);
								wa.updateSessionInfo(from, conn, jbsession, account_id);
			
								
								tenure=jbsession.getString("offer_tenure");
								jbsession.put("choosenamount",jbsession.getString("offer_amount"));
								jbsession.put("maxLoanAmount",jbsession.getString("offer_amount"));
								jbsession.put("min_amount", "50000");
								jbsession.put("max_amount", jbsession.getString("offer_amount"));
							}
							else
							{
								tenure=resp.split("\\:")[2];
							}
							
							jbsession.put("menu_choosen", "entertenure");
			
							jbsession.put("tenure", tenure);
							if ( !tenure.equals("12") && !tenure.equals("24") && !tenure.equals("36") &&  !tenure.equals("48"))
							{
								wa.sendMessage360("121222", from,
										"Invalid tenure. Please enter tenure 12, 24, 36 or 48 ",
										wa.whatsapp_key, conn);
												return;
			
							}
			
							wa.updateSessionInfo(from, conn, jbsession, account_id);
			
							/*wa.sendMessage360("121222", from,
									"Sure. Can I have your company name? \r\n*TIP!* Please enter full name for e.g TATA\r\nCapital instead of just TATA.?",
									wa.whatsapp_key, conn); */
											
							wa.sendMessage360("121222", from, "Are you \n"+ 
											"1️⃣ salaried \n"+
											"2️⃣ self-employed ",
											wa.whatsapp_key, conn);
			
											
							
							// wa.sendMessage360("121222", from,"Sure. Can I have your company name? \r\n*TIP!* Please enter full name for e.g TATA\r\nCapital instead of just TATA.?",wa.whatsapp_key, conn);
			
							return;
			
						}
			
						else if (menu.toLowerCase().equals("entertenure1")) 
						{
							final Connection conn1 = ds.getConnection();
							String tenure = resp.split("\\:")[2];
			
						
			
							jbsession.put("tenure", tenure);
							if ( !tenure.equals("12") && !tenure.equals("24") && !tenure.equals("36") &&  !tenure.equals("48"))
							{
								wa.sendMessage360("121222", from,
										"Invalid tenure. Please enter tenure 12, 24, 36 or 48 ",
										wa.whatsapp_key, conn);
												return;
			
							}
							
							String access_token = jbsession.getString("access_token");
							String app_id = jbsession.getString("app_id");
							String issalaried = jbsession.getString("issalaried");
							String offeramount = jbsession.getString("choosenamount");
			
							//   wa.updateSessionInfo(from, conn1, jbsession,account_id);
							String company_name = jbsession.getString("company_name");
			
							String companycode = jbsession.getString("companycode");
							
							String min_amount = jbsession.getString("min_amount");
							String max_amount = jbsession.getString("max_amount");
			
			
			
							if (issalaried.toLowerCase().equals("1")) 
							{
								issalaried = "true";
							}
							else
							{
								issalaried = "false";
							}
			
							JSONObject offerdetail = wa.getPAOfferDetail(offeramount, companycode, issalaried, tenure,
									app_id, from.substring(2), access_token);
			
							if (offerdetail.getString("status").equals("none")) 
							{
			
								wa.sendMessage360("121222", from, "no offer is configured for this number", wa.whatsapp_key, conn);
			
							}
							else
							{
								String loan_amount = offerdetail.getString("loanAmount").split("\\.")[0];
								String roi = offerdetail.getString("roi");
								String pf = offerdetail.getString("pf");
								String emi = offerdetail.getString("emi").split("\\.")[0];
			
								access_token = jbsession.getString("access_token");
								app_id = jbsession.getString("app_id");
								issalaried = jbsession.getString("issalaried");
								offeramount = jbsession.getString("choosenamount");
								tenure = jbsession.getString("tenure");
			
								JSONObject jbpersonal = new JSONObject();
								jbpersonal.put("companyName", company_name);
								jbpersonal.put("companyCode", companycode);
								jbpersonal.put("officialEmail", "");
								jbpersonal.put("mobileNumber", from.substring(2));
								jbpersonal.put("minLoanAmount", Float.parseFloat(min_amount));
								jbpersonal.put("maxLoanAmount", Float.parseFloat(max_amount));
								jbpersonal.put("minTenure", "12");
								jbpersonal.put("loanAmount", loan_amount);
								jbpersonal.put("emi", emi);
								jbpersonal.put("roi", roi);
								jbpersonal.put("pf", pf);
								jbpersonal.put("tenure", tenure);
								jbpersonal.put("new", true);
								jbpersonal.put("applSource", "PA");
								jbpersonal.put("appId", app_id);
								jbpersonal.put("deviceType", "Whatsapp");
								jbpersonal.put("deviceSubType", "Whatsapp");
								jbpersonal.put("channel", "Whatsapp");
								jbpersonal.put("employment", 1);
			
								JSONObject jbres = wa.savePersonalOffer(jbpersonal, access_token);
			
								// wa.sendMessage360("121222", from,"OFFERDETAIL="+offerdetail,wa.whatsapp_key, conn);
								// wa.sendMessage360("121222", from,"OFFERDETAIL="+offerdetail,wa.whatsapp_key, conn);
								String msg ="Great 👍 Here is your revised offer \n\n" + "*Loan Amount*: " + loan_amount
										+ "\n" + "*Rate of Interest* :" + roi + "\n" + "*Processing Fees* :" + pf + "\n"
										+ "*EMI* :" + emi + "\n" + "*Tenure* :" + tenure + "\n\n"
										+ "Type 1️⃣ to continue and 2️⃣ to edit your offer";
			
								jbsession.put("menu_choosen", "presentoffer");
								
								wa.updateSessionInfo(from, conn, jbsession, account_id);
		          				JSONObject jbres1=	wa.editOffer(msisdn, app_id);
								System.out.println(jbres1.toString());
								wa.sendMessage360("121222", from, msg, wa.whatsapp_key, conn);
			
							}
			
							return;
			
							// wa.sendMessage360("121222", from,"Sure. Can I have your company name? \r\n*TIP!* Please enter full name for e.g TATA\r\nCapital instead of just TATA.?",wa.whatsapp_key, conn);
						}
			
						else if (menu.toLowerCase().equals("entercompany"))
						{
							jbsession.put("menu_choosen", "entercompany");
							wa.updateSessionInfo(from, conn, jbsession, account_id);
							wa.sendMessage360("121222", from,"Sure. Can I have your company name? \r\n*TIP!* Please enter full name for e.g TATA\r\nCapital instead of just TATA.?",wa.whatsapp_key, conn);
							return;
						}				
						
						else if (menu.toLowerCase().equals("selectcompany")) 
						{
							final Connection conn1 = ds.getConnection();
			
							new Thread(new Runnable() 
							{
								public void run() 
								{
									//  wa.sendMessage360("121222", from,"Sure. Can I have your company name? \r\n*TIP!* Please enter full name for e.g TATA\r\nCapital instead of just TATA.?",wa.whatsapp_key, conn);
									String msgheader = "Which company to be specific? Choose\nfrom below and enter  the respective number.\n";
			
									String company_name_search = resp.split("\\:")[2];
									final JSONObject jbsession = wa.getSessionInfo(from, conn1, account_id);
									String access_token = jbsession.getString("access_token");
									String app_id = jbsession.getString("app_id");
			
									org.json.JSONArray cnames = wa.getCompanyNameS(from.substring(2), company_name_search,
											access_token, app_id);
									if (cnames.length() != 0) 
									{
										jbsession.put("menu_choosen", "selectcompany");
										jbsession.put("cnames", cnames);
			
										String companynames = wa.formatCompanyName(cnames);
			
										wa.updateSessionInfo(from, conn1, jbsession, account_id);
										wa.sendMessage360("121222", from, msgheader + companynames, wa.whatsapp_key, conn1);
			
									}
									else
									{
										//jbsession.put("menu_choosen","issalaried");
										//wa.updateSessionInfo(from, conn1, jbsession,account_id);
										wa.sendMessage360("121222", from, "No company found", wa.whatsapp_key, conn1);
			
									}
								}
							}).start();
							return;
						} 
						
						else if (menu.toLowerCase().equals("choosecompany")) 
						{
							//   wa.sendMessage360("121222", from,"Which company to be specific? Choose\r\nfrom below and enter  the respective \r\nnumber\r\n1.HDFC BANK CSE AND COEXACCOUNTS\r\n2.HDFC BANK LTD.",wa.whatsapp_key, conn);
							final Connection conn1 = ds.getConnection();
							String company_index = resp.split("\\:")[2];
							org.json.JSONArray cnames = jbsession.getJSONArray("cnames");
							String company_name = cnames.getJSONObject(Integer.parseInt(company_index) - 1)
									.getString("value");
							String companycode = cnames.getJSONObject(Integer.parseInt(company_index) - 1).getString("key");
			
							System.out.println("COMPANY_NAME=" + company_name);
							String access_token = jbsession.getString("access_token");
							String app_id = jbsession.getString("app_id");
							String issalaried = jbsession.getString("issalaried");
							String offeramount = jbsession.getString("choosenamount");
							String tenure = jbsession.getString("tenure");
							
							String sameoffer="1";
							try
							{
								sameoffer=jbsession.getString("sameoffer");
							}
							catch ( Exception ex)
							{
							}
							
							if ( sameoffer.equals("2"))
							{
								offeramount=jbsession.getString("maxLoanAmount");
								tenure= jbsession.getString("offer_tenure");
							}
			
							jbsession.put("company_name", company_name);
							jbsession.put("companycode", companycode);
			
							wa.updateSessionInfo(from, conn1, jbsession, account_id);
			
							if (issalaried.toLowerCase().equals("1")) 
							{
								issalaried = "true";
							} 
							else 
							{
								issalaried = "false";
							}
			
							JSONObject offerdetail = wa.getPAOfferDetail(offeramount, companycode, issalaried, tenure,
									app_id, from.substring(2), access_token);
							String msgstatus="";
							msgstatus=offerdetail.getJSONObject("status").getString("statusMessage");
			
							if (!msgstatus.equals("SUCCESS")) 
							{
			
								wa.sendMessage360("121222", from, "Sorry no offer is configured for this number", wa.whatsapp_key, conn);
			
							} 
							else
							{
								String loan_amount = offerdetail.getString("loanAmount");
								String roi = offerdetail.getString("roi");
								String pf = offerdetail.getString("pf");
								String emi = offerdetail.getString("emi").split("\\.")[0];
								
								access_token = jbsession.getString("access_token");
								app_id = jbsession.getString("app_id");
								issalaried = jbsession.getString("issalaried");
								offeramount = jbsession.getString("choosenamount");
								tenure = jbsession.getString("tenure");
								company_name = jbsession.getString("company_name");
			
								companycode = jbsession.getString("companycode");
								loan_amount=loan_amount.split("\\.")[0];
								
								jbsession.put("loan_amount",loan_amount);
								jbsession.put("roi",roi);
								jbsession.put("pf",pf);
								jbsession.put("emi",emi);
								
								wa.updateSessionInfo(from, conn, jbsession, account_id);
			
			
								/*   { "companyName": "HDFC BANK", "companyCode": "217244", "officialEmail": 
								 	  "panchami.c@ikontel.com", "employment": 1, "mobileNumber": "7019891938", 
								 	  "minLoanAmount": "75000", "maxLoanAmount": "800000", 
								 	  "minTenure": "12", "loanAmount": "800000", "emi": "21561",
								 	  "roi": "13.25", "pf": "14160", "tenure": "48", "new": true, "applSource": "PA", "appId": "27135", "deviceType": "Whatsapp", 
								 	  "deviceSubType": "Whatsapp", "channel": "Whatsapp"})*/
			
								
								String min_amount = jbsession.getString("min_amount");
								String max_amount = jbsession.getString("max_amount");
			
								JSONObject jbpersonal = new JSONObject();
								jbpersonal.put("companyName", company_name);
								jbpersonal.put("companyCode", companycode);
								jbpersonal.put("officialEmail", "");
								jbpersonal.put("mobileNumber", from.substring(2));
								jbpersonal.put("minLoanAmount", min_amount);
								jbpersonal.put("maxLoanAmount", max_amount);
								jbpersonal.put("minTenure", "12");
								jbpersonal.put("loanAmount", loan_amount);
								jbpersonal.put("emi",emi.split("\\.")[0]);
								jbpersonal.put("roi", roi);
								jbpersonal.put("pf", pf);
								jbpersonal.put("tenure", tenure);
								jbpersonal.put("new", true);
								jbpersonal.put("applSource", "PA");
								jbpersonal.put("appId", app_id);
								jbpersonal.put("deviceType", "Whatsapp");
								jbpersonal.put("deviceSubType", "Whatsapp");
								jbpersonal.put("channel", "Whatsapp");
								jbpersonal.put("employment", 1);
			
			
							   JSONObject jbres = wa.savePersonalOffer(jbpersonal, access_token);
			
								// wa.sendMessage360("121222", from,"OFFERDETAIL="+offerdetail,wa.whatsapp_key, conn);
								// wa.sendMessage360("121222", from,"OFFERDETAIL="+offerdetail,wa.whatsapp_key, conn);
								String msg = "Great 👍 Here is your offer \n\n" + "*Loan Amount*: " + loan_amount + "\n"
										+ "*Rate of Interest* :" + roi + "\n" + "*Processing Fees* :" + pf + "\n"
										+ "*EMI* :" + emi + "\n" + "*Tenure* :" + tenure + "\n\n"
										+ "Type 1️⃣ to continue and 2️⃣ to edit your offer";
			
								jbsession.put("menu_choosen", "presentoffer");
			
								wa.updateSessionInfo(from, conn, jbsession, account_id);
			
								wa.sendMessage360("121222", from, msg, wa.whatsapp_key, conn);
			
							}
			
							return;
			
						}
						
						else if (menu.toLowerCase().equals("saveoffer"))
						{
			
							String access_token = jbsession.getString("access_token");
							String app_id = jbsession.getString("app_id");
							
							String company_name = "";
							String company_code = "";
							String official_emailid = "panchami.c@ikontel.com";
							String employment = "1";
							String mobilenumber = "1";
							String maxloan = "1";
							String minloan = "1";
							String mintenure = "1";
							String loanamt = "1";
							String emi = "1";
							String roi = "1";
							String pf = "1";
							String tenure = "1";
							String newloan = "1";
							String applSource = "PA";
							String appid = jbsession.getString("app_id");
							String deviceType = "Whatsapp";
							String deviceSubType = "Whatsapp";
							String channel = "Whatsapp";
							
							String issalaried = jbsession.getString("issalaried");
							tenure = jbsession.getString("tenure");
							company_name = jbsession.getString("company_name");
			
							company_code = jbsession.getString("companycode");
							roi = jbsession.getString("roi");
							pf = jbsession.getString("pf");
							emi = jbsession.getString("emi").split("\\.")[0];
							company_code = jbsession.getString("companycode");
							loanamt=jbsession.getString("loan_amount").split("\\.")[0];
							
							String min_amount = jbsession.getString("min_amount");
							String max_amount = jbsession.getString("max_amount");
			
							
							JSONObject jbpersonal = new JSONObject();
							jbpersonal.put("companyName", company_name);
							jbpersonal.put("companyCode", company_code);
							jbpersonal.put("officialEmail", official_emailid);
							jbpersonal.put("mobileNumber", from.substring(2));
							jbpersonal.put("minLoanAmount", min_amount);
							jbpersonal.put("maxLoanAmount", max_amount);
							jbpersonal.put("minTenure", "12");
							jbpersonal.put("loanAmount", loanamt);
							jbpersonal.put("emi", emi);
							jbpersonal.put("roi", roi);
							jbpersonal.put("pf", pf);
							jbpersonal.put("tenure", tenure);
							jbpersonal.put("new", "true");
							jbpersonal.put("employment", 1);
			
							jbpersonal.put("applSource", applSource);
							jbpersonal.put("appId", appid);
							jbpersonal.put("deviceType", "Whatsapp");
							jbpersonal.put("deviceSubType", "Whatsapp");
							jbpersonal.put("channel", "Whatsapp");
			
							JSONObject jbres = null;
							try
							{
							//jbres=wa.savePersonalOffer(jbpersonal, access_token);
							}
							catch ( Exception ex)
							{
								wa.sendMessage360("121222", from, "Facing internal Error. Please try again later", wa.whatsapp_key, conn);
								return;
								
							}
							
						/*	if ( !jbres.getJSONObject("status").getString("statusMessage").toLowerCase().equals("succes"))
							{
								wa.sendMessage360("121222", from, "Facing internal Error. Please try again later", wa.whatsapp_key, conn);
										return;
								
							}*/
							jbsession.put("menu_choosen", "saveoffer");
							wa.updateSessionInfo(from, conn, jbsession, account_id);
			
							jbsession.put("jbpersonal", jbpersonal);
							String firstname = "";
							String middelname = "";
							String lastname = "";
							String dob = "";
							String gender = "";
							String married_status = "";
							String pan = "";
							String address = "";
			
							/*
							String personal_msg="Here are the your details:\n"+
							"First Name:"+firstname+"\n"+
							"Middle Name: "+middelname+"\n"+
							"Last Name: "+lastname+"\n"+
							"DOB :"+dob+"\n"+
							"Gender :"+gender+"\n"+
							"Marital Status:"+married_status+"\n"+
							"PAN Number :"+pan+"\n"+
							"Address :"+address+"\n"+
							"Continue :"+"\n"+
							"Change Address "+"\n\n"+
							
							"You can enter 10 to change your email address";
							
							 wa.sendMessage360("121222", from,personal_msg,wa.whatsapp_key, conn);*/
							 
							 
			/*				 {"status":{"statusCode":"200","statusMessage":"SUCCESS"},"personalInfo":{"appId":"31988","mobileNumber":"9110853949"},"loanAmount":900000.0,"tenure":48,"emi":21561.0,"firstName":"RAMAVATAR","middleName":"","lastName":"GIRDHARILAL","dob":"01-05-1990","gender":"Male","maritalStatus":"Married","panNumber":"AXJPR0674D","address":" ,110071","isKycRequired":false}*/
							 
			
							 JSONObject jpersondetail=wa.getPersonalDetail(company_name, msisdn, access_token, appid);
			              //   if ( !jpersondetail.getJSONObject("status").getString("statusMessage").equals("SUCCESS"))
			               //  {
			                		//wa.sendMessage360("121222", from, "Facing internal Error. Please try again later", wa.whatsapp_key, conn);
			    					//return;
			                	 
			               //  }
			                 
			                 
			               String middlename="";
			               firstname="";
			               lastname="";
			               dob="";
			               gender="";
			               String pannumber=jbsession.getString("mypan");
			               String maritalStatus="";
			               address="";
			               String personalEmailId="";
			                				
			               
			                				
			             try
			             {
			              
			                 firstname=jpersondetail.getString("firstName");
			                 lastname=jpersondetail.getString("lastName");
			                 middlename=jpersondetail.getString("middleName");
			                 dob= jpersondetail.getString("dob");
			                 pannumber=jpersondetail.getString("panNumber");
			                 gender=jpersondetail.getString("gender");
			                 maritalStatus=jpersondetail.getString("maritalStatus");
			                 address=jpersondetail.getString("address");
			             }
			             catch ( Exception ex)
			             {
			             }
			                				
		                 JSONObject jbpdetail= new JSONObject();
		                 jbpdetail.put("loanAmount",loanamt);
		                 jbpdetail.put("tenure",tenure);
		                 jbpdetail.put("roi",roi);
		                 jbpdetail.put("emi",emi);
		                 jbpdetail.put("pf",pf);
		                 jbpdetail.put("gender",gender);
		                 jbpdetail.put("maritalStatus",maritalStatus);
				         jbpdetail.put("panNumber",pannumber);
		                 jbpdetail.put("address",address);
		                 jbpdetail.put("personalEmailId","");
		                 jbpdetail.put("mobileNumber",msisdn);
		                 jbpdetail.put("firstName",firstname);
		                 jbpdetail.put("middleName",middelname);
		                 jbpdetail.put("lastName",lastname);
		                 jbpdetail.put("applSource","PA");
		                 jbpdetail.put("appId",appid);
		                 jbpdetail.put("isCustomerDeclaredForAddr",false);
		                 jbpdetail.put("isAddressChanged",false);
		                 jbpdetail.put("deviceType","Whatsapp");
		                 jbpdetail.put("deviceSubType","Whatsapp");
		                 jbpdetail.put("channel","Whatsapp");
			               
		                 JSONObject jbres1=  wa.savePersonalDetail(jbpdetail, access_token);
		                 if ( !jpersondetail.getJSONObject("status").getString("statusMessage").equals("SUCCESS"))
		                 {
		                		wa.sendMessage360("121222", from, "Facing internal Error. Please try again later", wa.whatsapp_key, conn);
		    					return;
			                	 
		                 }
			                 
			                 /*
			                 {"loanAmount": "900000","tenure": "48","roi": "13.25","emi": 
			                	 "21561","pf": 
			                		 "14160","dob": "01-05-1990",
			                		 "gender": "Male","maritalStatus": "Married",
			                		 "panNumber": "AXJPR0674D",
			                		 "address": " ,110071",
			                		 "personalEmailId": "panchami.c@ikontel.com",
			                		 "mobileNumber": "9110853949",
			                		 "firstName": "RAMAVATAR",
			                		 "middleName": "",
			                		 "lastName": "GIRDHARILAL",
			                		 "applSource": "PA",
			                		 "appId": "31988",
			                		 "isCustomerDeclaredForAddr": false,
			                		 "isAddressChanged": false,
			                		 "deviceType": "Whatsapp","deviceSubType": "Whatsapp","channel": "Whatsapp"}
			                 */
			                 
			               /*  JSONObject jbpdetail= new JSONObject();
			                 jbpdetail.put("loanAmount",loanamt);
			                 jbpdetail.put("tenure",tenure);
			                 jbpdetail.put("roi",roi);
			                 jbpdetail.put("emi",emi);
			                 jbpdetail.put("pf",pf);
			                 jbpdetail.put("gender",gender);
			                 jbpdetail.put("maritalStatus",maritalStatus);
					         jbpdetail.put("panNumber",pannumber);
			                 jbpdetail.put("address",address);
			                 jbpdetail.put("personalEmailId","");
			                 jbpdetail.put("mobileNumber",from.substring(2));
			                 jbpdetail.put("firstName",firstname);
			                 jbpdetail.put("middleName",middelname);
			                 jbpdetail.put("lastName",lastname);
			                 jbpdetail.put("applSource","PA");
			                 jbpdetail.put("appId",appid);
			                 jbpdetail.put("isCustomerDeclaredForAddr",false);
			                 jbpdetail.put("isAddressChanged",false);
			                 
			                 
			                 jbpdetail.put("deviceType","Whatsapp");
			                 jbpdetail.put("deviceSubType","Whatsapp");
			                 jbpdetail.put("channel","Whatsapp");*/
			
							JSONObject jbresp = wa.generateWebLink(msisdn, access_token, appid);
			
							String link = jbresp.getString("url");
			
							String msg = "Great ! Please provide us \n" + "*one-time-mandate by clicking on below\n" +
			
									"link 👇" + "\n\n" + link;
							
			
							wa.sendMessage360("121222", from, msg, wa.whatsapp_key, conn);
			
			
						}
			
						else if (menu.toLowerCase().equals("modifyoffer1")) 
						{
							//   wa.sendMessage360("121222", from,"Which company to be specific? Choose\r\nfrom below and enter  the respective \r\nnumber\r\n1.HDFC BANK CSE AND COEXACCOUNTS\r\n2.HDFC BANK LTD.",wa.whatsapp_key, conn);
			
							String option = resp.split("\\:")[1];
							if (option.equals("1")) 
							{
								String access_token = jbsession.getString("access_token");
								String app_id = jbsession.getString("app_id");
								JSONObject jbresp = wa.generateWebLink(msisdn, access_token, app_id);
			
								String link = "";
			
								String msg = "Great ! Please provide us \n" + "*one-time-mandate by clicking on below\n" +
			
										"link 👇" + "\n\n" + link;
								wa.sendMessage360("121222", from, msg, wa.whatsapp_key, conn);
								jbsession.put("menu_choosen", "");
			
							}
							else if (option.equals("2")) 
							{
			
								wa.sendMessage360("121222", from, "Please enter the tenure.", wa.whatsapp_key, conn);
			
								jbsession.put("menu_choosen", "modifyoffer");
								wa.updateSessionInfo(from, conn, jbsession, account_id);
							}
			
						}
			
						else if (menu.toLowerCase().equals("enterofferamount1")) 
						{
							//   wa.sendMessage360("121222", from,"Which company to be specific? Choose\r\nfrom below and enter  the respective \r\nnumber\r\n1.HDFC BANK CSE AND COEXACCOUNTS\r\n2.HDFC BANK LTD.",wa.whatsapp_key, conn);
			
							String min_amount = jbsession.getString("min_amount");
							String max_amount = jbsession.getString("max_amount");
							wa.sendMessage360("121222", from,
									"Sure, let's modify the as per your requirement\n\n What is the loan amount you wish to apply ? Please choose between Rs."+min_amount+" and Rs."+max_amount+" .",
											
									wa.whatsapp_key, conn);
			
							jbsession.put("menu_choosen", "enterofferamount1");
							
							wa.updateSessionInfo(from, conn, jbsession, account_id);
			
						}
			
					}
			
				}
				//org.json.simple.JSONArray jarr1=(org.json.simple.JSONArray)jsonObject.get("contacts");
			}
			
			else
			{
				//"statuses":[{"id":"gBEGkZdBQRCHAgnKpPfNAmsHdUA","type":"message","conversation":{"id":"8891a5c7dc85633757b9281e9f83119a"},"pricing":{"pricing_model":"NBP","billable":false},"recipient_id":"919741411087","status":"delivered","timestamp":"1636536278"}]}
				org.json.simple.JSONObject jb = (org.json.simple.JSONObject) jarr.get(0);
				String msg_id = (String) jb.get("id");
				String body = jb.toJSONString();
				String to_num = (String) jb.get("recipient_id");
				String status = (String) jb.get("status");
			
				String conversation_id = (String) ((org.json.simple.JSONObject) jb.get("conversation")).get("id");
			
				if (body.contains("user_initiated") || body.contains("business_initiated")) 
				{
			
					WhatsAppMessage wa = new WhatsAppMessage();
					org.json.JSONObject js = wa.getSessionInfo(to_num, conn, account_id);
					if (js == null)
					{
			
						js = new org.json.JSONObject();
						js.put("session_id", conversation_id);
						wa.updateSessionInfo(to_num, conn, js, account_id);
					}
				}
			
				String pssql = "insert into outgoing_message_axis_log(to_msisdn,message,msg_id,call_type,msg_status,conversation_id,account_id) values(?,?,?,?,?,?,?)";
				PreparedStatement ps = conn.prepareStatement(pssql);
				ps.setString(1, to_num);
				ps.setString(2, body);
				ps.setString(3, msg_id);
				ps.setString(4, "outgoing");
				ps.setString(5, status);
				ps.setString(6, conversation_id);
				ps.setString(7, "instapl");
			
				ps.executeUpdate();
			
				String sql = "update outgoing_message_axis set msg_status='" + status + "' where msg_id='" + msg_id + "'";
				Statement stupd = conn.createStatement();
				stupd.executeUpdate(sql);
	
		}
	}
	catch (Exception ex) 
	{
		ex.printStackTrace();

	}

} 
catch (Exception e) 
{

	e.printStackTrace();
	JSONObject jstat = new JSONObject();
	JSONObject jres = new JSONObject();
	JSONObject jout = new JSONObject();

	jstat.put("statusCode", "1");
	jstat.put("errorCode", "101");
	jstat.put("errorMessage", "UNKNOWN_ERROR");
	jres.put("status", jstat);
	jout.put("result", jres);
	out.println(jout.toString());

	/* 18 */
	/*    */
}
finally
{
	try {
		conn.close();
	} catch (Exception exx) {

	}
}
%>
