package helper;



import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HttpsURLConnection;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.parser.*;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;



public class WhatsAppMessage {
	
	 public static final String ACCOUNT_SID ="AC01f0c97858ce79906d4855d840ef32cc";
	  public static final String AUTH_TOKEN = "59bfedb7bd610fc04cf9ea98f01ca22a";
	  
	  public static final String PHONE_ID="104110786108055";
	  public static final String UAT_URL="https://loanuat.tatacapital.com:8080/";
	 
	  public static String whatsapp_key="EAAKGhZC3Q6FABO0Rxb6C5GblwVZAvZBdll3nYBdzdybYSOqGPeIgrKi6soSMLZAk9Keb8JIRLfN5wj2adHETDrsnBLVJxKkAdmtZBfuiDDuEKWJWVatHRucK5NEZAmIgQNpOQNxZBZBMI79Yy5ZAkrZC7h7IuZCTLTdZBBBJVGcjjNgPW5OY9mBePw3xMZCiSPjsnl77KZCrtcmaMswKtLyFHbOxzZB9LBRtTHF7mcSo4bpmGgZD";

	
	
	public String sendMenu(String msisdn, String msg, String whatsapp_token, Connection conn)
	{
		return null;
	}
	
	public void sendMsg(String msisdn,String msg)
	{
		System.out.println("MSISDNTWILIO="+msisdn+":"+msg);
		try
		{
		 String smsurl="https://msg2all.com/TRANSAPI/sendsms.jsp?login=gogas&passwd=gogas@321&version=v1.0&msisdn="+
		       	 msisdn+"&msg_type=text&msg="+URLEncoder.encode(msg,"utf8")+"&sender_id="+"GOGASz";
		 System.out.println("MSISDNTWILIO="+smsurl);
		       	 String resp=HTTPRequest.getResponse(smsurl);
		}
		catch ( Exception ex)
		{
			ex.printStackTrace();
		}
		
		
		
	}
	
	public JSONObject getOfferDetailWithNumber( String mobilenumber)
	{
		JSONObject jres= new JSONObject();
		JSONObject status=new JSONObject();
	
		status.put("statusMessage","FAIL");
		jres.put("status",status);
		try
		{
			
		OkHttpClient client = new OkHttpClient().newBuilder()
				.connectTimeout(180, TimeUnit.SECONDS)
				 .readTimeout(180, TimeUnit.SECONDS)
				 .build();			    
				MediaType mediaType = MediaType.parse("application/json");
				String jsonrequest="{\"mobileNumber\": \""+mobilenumber+"\",\"applSource\": \"PA\",\"deviceType\": \"Whatsapp\",\"deviceSubType\": \"Whatsapp\",\"channel\": \"Whatsapp\" ,\"employment\":\"1\"}";
			  
				RequestBody body = RequestBody.create(mediaType, jsonrequest);
				Request request = new Request.Builder()
				  .url(UAT_URL+"DLPDelegator/authentication/mobile/v0.1/FetchOfferDetailsWithNumber")
				  .method("POST", body)
				
				  .addHeader("Content-Type", "application/json")
				 // .addHeader("Cookie", "JSESSIONID=BD96BD9B5FB040ABD6378E8F652CE9B6")
				  .build();
				Response response = client.newCall(request).execute();
				String text=response.body().string();
				System.out.println("OFFER DETAIL="+text);
				JSONObject jb = new JSONObject(text);
				return jb;
				
		}
		catch ( Exception ex)
		{
			ex.printStackTrace();
			return jres;
		}
		
	}
	
	public JSONObject generateWebOTP( String mobilenumber,String appid,String access_token)
	{
		JSONObject jres= new JSONObject();
		try
		{
		OkHttpClient client = new OkHttpClient().newBuilder()
				  .build();
				MediaType mediaType = MediaType.parse("application/json");
				String jsonrequest="{\"mobileNumber\": \""+mobilenumber+"\",\"applSource\": \"PA\",\"appId\": \""+appid+"\"}";
				System.out.println("WEBTOKEN_REQ="+jsonrequest+"::"+access_token);

				RequestBody body = RequestBody.create(mediaType, jsonrequest);
				Request request = new Request.Builder()
		//		  .url(UAT_URL+"DLPDelegator/authentication/mobile/v0.1/FetchOfferDetailsWithNumber")
				   .url(UAT_URL+"/DLPDelegator/webtop/services/v0.1/createWebtopForPA")
				  .method("POST", body)
				  .addHeader("Authorization", access_token)
				  .addHeader("Content-Type", "application/json")
				  .addHeader("Cookie", "JSESSIONID=BD96BD9B5FB040ABD6378E8F652CE9B6")
				  .build();
				Response response = client.newCall(request).execute();
				String text=response.body().string();
				System.out.println("generateWEBOTP="+text);
				JSONObject jb = new JSONObject(text);
				return jb;
				
		}
		catch ( Exception ex)
		{
			ex.printStackTrace();
			return jres;
		}
		
	}
	
	public JSONObject generateWebLink( String mobilenumber,String access_token,String appid)
	{
		JSONObject jres= new JSONObject();
		try
		{
		OkHttpClient client = new OkHttpClient().newBuilder()
				.connectTimeout(90, TimeUnit.SECONDS)
				 .readTimeout(90, TimeUnit.SECONDS)
		
				  .build();
				MediaType mediaType = MediaType.parse("application/json");
				String jsonrequest="{\"applSource\": \"PA\",\"deviceType\": \"Whatsapp\",\"deviceSubType\": \"Whatsapp\",\"channel\":\"Whatsapp\",\"appId\": \""+appid+"\",\"mobileNumber\": \""+mobilenumber+"\",\"isOkycRequired\": false}";

				RequestBody body = RequestBody.create(mediaType, jsonrequest);
				Request request = new Request.Builder()
				  .url(UAT_URL+"/DLPDelegator/offerbanking/services/v0.1/getPABankingDetailsWebURL")
				  .method("POST", body)
				  .addHeader("Authorization", access_token)
				  .addHeader("Content-Type", "application/json")
				  .addHeader("Cookie", "JSESSIONID=BD96BD9B5FB040ABD6378E8F652CE9B6")
				  .build();
				Response response = client.newCall(request).execute();
				String text=response.body().string();
				System.out.println("generateWEBOTP="+text);
				JSONObject jb = new JSONObject(text);
				return jb;
				
		}
		catch ( Exception ex)
		{
			ex.printStackTrace();
			return jres;
		}
		
	}
	
	
	
	//https://loanuat.tatacapital.com:8080/DLPDelegator/webtop/services/v0.1/createWebtopForPA
	
	public JSONObject getPAOfferDetail(String loanamt, String companycode,String issalaried,String tenure, String appid, String mobilenumber,String access_token)
	{
		JSONObject jres= new JSONObject();
		try
		{
		OkHttpClient client = new OkHttpClient().newBuilder()
				.connectTimeout(90, TimeUnit.SECONDS)
				 .readTimeout(90, TimeUnit.SECONDS)
				 .build();
				 
		String jsonreq="{\"loanAmount\": \""+loanamt+"\",\"companyCode\": \""+companycode+"\",\"isSalaried\": "+issalaried+",\"tenure\": \""+tenure+"\",\"mobileNumber\": \""+mobilenumber+"\",\"applSource\": \"PA\",\"appId\": \""+appid+"\",\"deviceType\": \"Whatsapp\",\"deviceSubType\": \"Whatsapp\",\"channel\": \"Whatsapp\"}";
		System.out.println("GETPAOfferDetail="+jsonreq);		
		
		MediaType mediaType = MediaType.parse("application/json");
				RequestBody body = RequestBody.create(mediaType, jsonreq);
				Request request = new Request.Builder()
				  .url(UAT_URL+"DLPDelegator/offerparate/services/v0.1/getOfferPARate")
				  .method("POST", body)
				  .addHeader("Authorization", access_token)
				  .addHeader("Content-Type", "application/json")
				  .addHeader("Cookie", "JSESSIONID=BD96BD9B5FB040ABD6378E8F652CE9B6")
				  .build();
				Response response = client.newCall(request).execute();
				String text=response.body().string();
				System.out.println("OFFERDETAIL="+text);
				JSONObject jb = new JSONObject(text);
				return jb;
				
		}
		catch ( Exception ex)
		{
			ex.printStackTrace();
			return jres;
		}
		
	}
	
	public String getOfferDetail(String company_name, String msisdn, String access_token, String app_id)
	{
		try
		{
		OkHttpClient client = new OkHttpClient().newBuilder()
				.connectTimeout(90, TimeUnit.SECONDS)
				 .readTimeout(90, TimeUnit.SECONDS)
				 .build();
				  
				MediaType mediaType = MediaType.parse("application/json");
				RequestBody body = RequestBody.create(mediaType, "{\"companyName\": \""+company_name+"\",\"mobileNumber\": \""+msisdn+"\",\"applSource\": \"PA\",\"appId\": \""+app_id+"\",\"deviceType\":\"Whatsapp\",\"deviceSubType\": \"Whatsapp\",\"channel\": \"Whatsapp\"}");
				Request request = new Request.Builder()
				  .url(UAT_URL+"/DLPDelegator/offerloan/services/v0.1/getOfferLoanDetails")
				  .method("POST", body)
				  .addHeader("Authorization", "Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI1MDEzODExIiwic2NvcGVzIjpbeyJhdXRob3JpdHkiOiJST0xFX0FETUlOIn1dLCJpc3MiOiJodHRwOi8vdGNsLmNvbSIsImlhdCI6MTY1NDY1MTM0MSwiZXhwIjoxNjU1MjUxMzQxfQ.ktGwpt0_KjjUh-lUxS-pTRdUgvIe93pfLa5r1QruyCw")
				  .addHeader("Content-Type", "application/json")
				  .build();
				Response response = client.newCall(request).execute();
				String text=response.body().string();
				JSONObject jb = new JSONObject(text);
				System.out.println(text);
		}
		catch ( Exception ex)
		{
			ex.printStackTrace();
		}
		return "none";
				
	}
	
	
	public JSONObject getPersonalDetail(String company_name, String msisdn, String access_token, String app_id)
	{
		/*
		 * {"appId": "27135","mobileNumber": "7019891938","applSource": "PA","deviceType": "Whatsapp","deviceSubType": "Whatsapp","channel": "Whatsapp"}
		 */
				
		try
		{
		OkHttpClient client = new OkHttpClient().newBuilder()
				 .connectTimeout(90, TimeUnit.SECONDS)
				 .readTimeout(90, TimeUnit.SECONDS)
				 .build();
				MediaType mediaType = MediaType.parse("application/json");
				RequestBody body = RequestBody.create(mediaType, "{\"companyName\": \""+company_name+"\",\"mobileNumber\": \""+msisdn+"\",\"applSource\": \"PA\",\"appId\": \""+app_id+"\",\"deviceType\":\"Whatsapp\",\"deviceSubType\": \"Whatsapp\",\"channel\": \"Whatsapp\"}");
				Request request = new Request.Builder()
						
				  .url(UAT_URL+"DLPDelegator/offerpersonaldtls/services/v0.1/getPAPersonalDetails")
				  .method("POST", body)
				  .addHeader("Authorization",access_token)
				  
				  .build();
				Response response = client.newCall(request).execute();
				String text=response.body().string();
				JSONObject jb = new JSONObject(text);
				System.out.println("PERSONALDETAIL="+text);

				return jb;
		}
		catch ( Exception ex)
		{
			ex.printStackTrace();
		}
		return null;
				
	}
	
	
	
	
	public JSONObject  savePersonalOffer(JSONObject jbperson,String access_token)
	{
		/*
		 * 
		 * {
    "companyName": "HDFC BANK",
    "companyCode": "217244",
    "officialEmail": "panchami.c@ikontel.com",
    "employment": 1,
    "mobileNumber": "7019891938",
    "minLoanAmount": "75000",
    "maxLoanAmount": "800000",
    "minTenure": "12",
    "loanAmount": "800000",
    "emi": "21561",
    "roi": "13.25",
    "pf": "14160",
    "tenure": "48",
    "new": true,
    "applSource": "PA",
    "appId": "27135",
    "deviceType": "Whatsapp",
    "deviceSubType": "Whatsapp",
    "channel": "Whatsapp"
}

		 */
		System.out.println("OFFERDETAIL2="+jbperson.toString()+"::"+access_token);
		JSONObject jbsaveoffer = new JSONObject();
		try
		{
		OkHttpClient client = new OkHttpClient().newBuilder()
				.connectTimeout(90, TimeUnit.SECONDS)
				 .readTimeout(90, TimeUnit.SECONDS)
				 .build();
				MediaType mediaType = MediaType.parse("application/json");
				RequestBody body = RequestBody.create(mediaType,jbperson.toString());
				Request request = new Request.Builder()
				  .url(UAT_URL+"/DLPDelegator/offerloan/services/v0.1/saveOfferLoanDetails")
				  .method("POST", body)
				  .addHeader("Authorization", access_token)
				  .addHeader("Content-Type", "application/json")
				  .build();
				Response response = client.newCall(request).execute();
				String text=response.body().string();
				jbsaveoffer = new JSONObject(text);
				System.out.println("SAVEOFFERDETAIL="+text);
		}
		catch ( Exception ex)
		{
			ex.printStackTrace();
		}
		return jbsaveoffer;
				
	}
	
	
	
	public JSONObject  savePersonalDetail(JSONObject jbpersond,String access_token)
	{
		
		System.out.println("OFFERDETAIL2="+jbpersond.toString());
		JSONObject jbsaveoffer = new JSONObject();
		try
		{
		OkHttpClient client = new OkHttpClient().newBuilder()
				.connectTimeout(90, TimeUnit.SECONDS)
				 .readTimeout(90, TimeUnit.SECONDS)
				  .build();
				MediaType mediaType = MediaType.parse("application/json");
				RequestBody body = RequestBody.create(mediaType,jbpersond.toString());
				Request request = new Request.Builder()
				  .url(UAT_URL+"DLPDelegator/offerpersonaldtls/services/v0.1/savePAPersonalDetails")
				  .method("POST", body)
				  .addHeader("Authorization", access_token)
				  .addHeader("Content-Type", "application/json")
				  .build();
				Response response = client.newCall(request).execute();
				String text=response.body().string();
				jbsaveoffer = new JSONObject(text);
				System.out.println("SAVEOFFERDETAIL="+text);
		}
		catch ( Exception ex)
		{
			ex.printStackTrace();
		}
		return jbsaveoffer;
				
	}
	
	public JSONObject getSessionInfo(String from_msisdn,Connection conn,String account_id)
	{
		 JSONObject jsinfo=null;
		try
		{
		 String sql="select session_var from session_info where from_msisdn='"+from_msisdn+"' and account_id='"+account_id+"'";
         Statement st= conn.createStatement();
         ResultSet rs=st.executeQuery(sql);
         String session_json=null;
         String offset="0";
          jsinfo = new JSONObject();
         if (rs.next())
         {
        	 session_json=rs.getString("session_var");
        	 try
        	 {
        		 JSONObject jb = new JSONObject(session_json);
        		 return jb;
        		 
        		 
        	 }
        	 catch ( Exception ex)
        	 {
        		 return null;

        	 }
        	 
         }
         else
         {
        	 return null;

         }
		}
		catch ( Exception ex)
		{
			ex.printStackTrace();
			
		}
		return null;
		
	}
	
	public JSONObject updateSessionInfo(String from_msisdn,Connection conn,JSONObject jb2,String account_id)
	{
		 JSONObject jsinfo= null;
		// System.out.println("SESSION="+jb2.toString());
		try
		{
		String sql="select session_var from session_info where from_msisdn='"+from_msisdn+"'";
         Statement st= conn.createStatement();
         ResultSet rs=st.executeQuery(sql);
         String session_json=null;
         String offset="0";
          jsinfo = new JSONObject();
         if (rs.next())
         {
        	
			
			 sql="update session_info set session_var=? where from_msisdn='"+from_msisdn+"'";
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1,jb2.toString());
			ps.executeUpdate();
			return jb2;
        	 
         }
         else
         {
        	 sql="insert  session_info (session_var,from_msisdn,account_id) values(?,?,?)";
 			PreparedStatement ps=conn.prepareStatement(sql);
 			ps.setString(1,jb2.toString());
 			ps.setString(2,from_msisdn);
 			ps.setString(3,account_id);

 			ps.executeUpdate();
 			return jb2;

         }
		}
		catch ( Exception ex)
		{
			ex.printStackTrace();
			
		}
		return null;
		
	}
	public String getIntent(String resp,String msisdn,Connection conn,String account_id)
	{
		try
		{
//	{"messages":[{"button":{"text":"Pay Now"},"context":{"from":"917777892222","id":"gBEGkZdBQRCHAgnooWiepw2TJFo"},"from":"919741411087","id":"ABEGkZdBQRCHAhDajiTTG8EizKgtoeUPhh4S","type":"button","timestamp":"1650592034"}],"contacts":[{"profile":{"name":"Sanjit Pradhan"},"wa_id":"919741411087"}]}
		//	{"from":"918073131344","id":"wamid.HBgMOTE4MDczMTMxMzQ0FQIAEhggNjRGQzFEQ0QwREYxNURCNTBFOEVEQzJERkY1MTQxRkEA","text":{"body":"Hi"},"type":"text","timestamp":"1660205970"}

			JSONObject js= getSessionInfo(msisdn, conn,account_id);
			String menuchoosen="";
			String text="";
			System.out.println("INTENTRESP="+resp);
			try
			{
				text=new JSONObject(resp).getJSONObject("text").getString("body");
				
			
				
				menuchoosen=js.getString("menu_choosen");
				
				
				
			}
			catch ( Exception ex)
			{
				ex.printStackTrace();
				System.out.println("RESP1="+resp);
			}
			
			if ( menuchoosen==null || text.toLowerCase().equals("home")||text.toLowerCase().equals("hi"))
			{
				return "menu:welcome";
			}
			else if ( menuchoosen.equals("welcome"))
			{
				if ( text.equals("1"))
				{
					return "menu:englishmain";
				}
				else if ( text.equals("2"))
				{
					return "menu:hindimain";

				}
				else
				{
					return "menu:repeatwelcome";
				}
			}
			
			else if ( menuchoosen.equals("englishmain"))
			{
				if ( text.equals("4"))
				{
					return "menu:engsendotp";
				}
			}
			else if ( menuchoosen.equals("hindimain"))
			{
				if ( text.equals("4"))
				{
					return "menu:hindisendotp";
				}
				else
				{
					return "menu:invalidoption"+":"+text;
				}
				
			}
			else if (menuchoosen.equals("engsendotp") )
			{
				String otp = text;
				if ( otp.equals("2"))
				{
				  js.put("sameoffer","2");
				  updateSessionInfo(msisdn, conn, js, account_id);
				}
				
				
				if ( otp.equals("2") || otp.equals("1"))
				{
					return "menu:engsendotp1";
				}
				
				else
				{ 
					int otpint=0;
					try
					{
						otpint=Integer.parseInt(otp);
						if ( otp.length()==6)
						{
							return "menu:engvalidateotp:"+text;
						}
						else
						{
							return "menu:invalidoption"+":"+text;
						}
					}
					catch ( Exception ex)
					{
				
					return "menu:invalidoption"+":"+text;
					}
				}
						
			}
			
			else if (menuchoosen.equals("engsendotp1") )
			{
				String otp = text;
				if ( otp.equals("2"))
				{
					return "menu:engsendotp";
				}
				
				else
				{ 
					int otpint=0;
					try
					{
						otpint=Integer.parseInt(otp);
						if ( otp.length()==6)
						{
							return "menu:engvalidateotp:"+text;
						}
						else
						{
							return "menu:invalidoption"+":"+text;
						}
					}
					catch ( Exception ex)
					{
				
					return "menu:invalidoption"+":"+text;
					}
				}
						
			}
			
		
			else if (menuchoosen.equals("enterpan"))
			{
				return "menu:validatepan:"+text;
				
			}
			else if (menuchoosen.equals("validatepan"))
			{
				String sameoffer="1";
				try
				{
				sameoffer=js.getString("sameoffer");
				}
				catch ( Exception ex)
				{
					
				}
				if ( sameoffer.equals("2"))
				{
					return "menu:entertenure:"+text;
				}
				return "menu:issalaried:"+text;
				
			}
			else if (menuchoosen.equals("issalaried"))
			{
				
				
				return "menu:"+"enterofferamount"+":"+text;
				
			}
			else if (menuchoosen.equals("enterofferamount"))
			{
				
				return "menu:"+"checkamount"+":"+text;
				
			}
			else if (menuchoosen.equals("checkamount"))
			{
				return "menu:"+"entertenure"+":"+text;
				
			}
			else if (menuchoosen.equals("entertenure"))
			{
				return "menu:"+"entercompany"+":"+text;
				
			}
			else if (menuchoosen.equals("entercompany"))
			{
				return "menu:"+"selectcompany"+":"+text;
				
			}
			else if (menuchoosen.equals("selectcompany"))
			{
				return "menu:choosecompany:"+text;
				
			}
			else if (menuchoosen.equals("choosecompany"))
			{
				if ( text.equals("2"))
				{
				return "menu:enterofferamount"+":"+text;
				}
				else if ( text.equals("1"))
				{
					return "menu:saveoffer"+":"+text;
				}
				else
				{
					return "menu:invalidoption"+":"+text;
					
				}
				
			}
			
			else if (menuchoosen.equals("presentoffer") )
			{
				if ( text.equals("2"))
				{
				return "menu:enterofferamount1"+":"+text;
				}
				else if ( text.equals("1"))
				{
					return "menu:saveoffer"+":"+text;
				}
				else
				{
					return "menu:invalidopt"+":"+text;
				}
				
				
			}
			
			else if (menuchoosen.equals("enterofferamount1"))
			{
				
				return "menu:checkamount1"+":"+text;
				
				
			}
			else if (menuchoosen.equals("checkamount1") )
			{
				return "menu:entertenure1"+":"+text;
				
				
			}
			else if (menuchoosen.equals("enterofferamount"))
			{
				
				return "menu:entertenure"+":"+text;
				
				
			}
			else if (menuchoosen.equals("entertenure"))
			{
				
				return "menu:enterpan"+":"+text;
				
				
			}
			
			
			
		}
			
		catch ( Exception ex)
		{
			ex.printStackTrace();
			return "error";
		}
		return "error";
	}
	
	public String formPrompt(String msisdn,String body,ArrayList jarrmenu,String button)
	{
		
		String body_text=body;
		JSONObject jb = new JSONObject();
		jb.put("recipient_type", "individual");
		jb.put("to", msisdn);
		jb.put("type", "interactive");
		JSONObject jbinteractive=new JSONObject();
		jbinteractive.put("type", "list");
		JSONObject jbheader=new JSONObject();
		jbheader.put("type","text");
		jbheader.put("text","");
		
		JSONObject jbbody=new JSONObject();
		
		jbbody.put("text",body_text);
        JSONObject jbfoot=new JSONObject();
		
		jbfoot.put("text","");
		
		JSONObject jbaction=new JSONObject();
		jbaction.put("button", button);
		JSONArray jbsections=new JSONArray();
		JSONObject jbsection= new JSONObject();
		
		JSONArray rows = new JSONArray();
		
		for ( int i=0 ;i< jarrmenu.size();i++)
		{
			
			String  menu=(String)jarrmenu.get(i);
			JSONObject row= new JSONObject();

			
			row.put("id",i+"");
			row.put("title", (i+1)+"");
			row.put("description",menu);
			rows.put(row);
			if ( i >8)
			{
				break;
			}
			


			
		}
		
		jbsection.put("title", " ");
		jbsection.put("rows", rows);
		jbsections.put(jbsection);
		
		 rows = new JSONArray();

		/*for ( int i=10 ;i< jarr.length();i++)
		{
			
			JSONObject ca=jarr.getJSONObject(i);
			JSONObject row= new JSONObject();

			
			row.put("id",i+ca.getString("complaint_type"));
			row.put("title", (i+1)+"");
			row.put("description", ca.getString("complaint_type"));
			rows.put(row);
			

			
		}
		
       jbsection= new JSONObject();
        jbsection.put("title", "PART-2");
		jbsection.put("rows", rows);
		jbsections.put(jbsection);*/

		
		
		
		
		
		
		jbaction.put("sections", jbsections);
		jbinteractive.put("action", jbaction);
		jbinteractive.put("header", jbheader);
		jbinteractive.put("body", jbbody);
		jbinteractive.put("footer", jbfoot);
		jb.put("interactive", jbinteractive);
		System.out.println(jb.toString());
	    return jb.toString();
		//HTTPRequest.getResponseWhatsapp(getMycallid(),jb.toString());
	    
		
	}
	
	public String formPrompt(String msisdn,String body,ArrayList jarrmenu,String button,String menu_note)
	{
		
		String body_text=body;
		JSONObject jb = new JSONObject();
		jb.put("recipient_type", "individual");
		jb.put("to", msisdn);
		jb.put("type", "interactive");
		JSONObject jbinteractive=new JSONObject();
		jbinteractive.put("type", "list");
		JSONObject jbheader=new JSONObject();
		jbheader.put("type","text");
		jbheader.put("text","");
		
		JSONObject jbbody=new JSONObject();
		
		jbbody.put("text",body_text);
        JSONObject jbfoot=new JSONObject();
		
		jbfoot.put("text","");
		
		JSONObject jbaction=new JSONObject();
		jbaction.put("button", button);
		JSONArray jbsections=new JSONArray();
		JSONObject jbsection= new JSONObject();
		
		JSONArray rows = new JSONArray();
		
		for ( int i=0 ;i< jarrmenu.size();i++)
		{
			
			String  menu=(String)jarrmenu.get(i);
			JSONObject row= new JSONObject();

			
			row.put("id",i+menu_note);
			row.put("title", (i+1)+"");
			row.put("description",menu);
			rows.put(row);
			if ( i >8)
			{
				break;
			}
			


			
		}
		
		jbsection.put("title", " ");
		jbsection.put("rows", rows);
		jbsections.put(jbsection);
		
		 rows = new JSONArray();

		/*for ( int i=10 ;i< jarr.length();i++)
		{
			
			JSONObject ca=jarr.getJSONObject(i);
			JSONObject row= new JSONObject();

			
			row.put("id",i+ca.getString("complaint_type"));
			row.put("title", (i+1)+"");
			row.put("description", ca.getString("complaint_type"));
			rows.put(row);
			

			
		}
		
       jbsection= new JSONObject();
        jbsection.put("title", "PART-2");
		jbsection.put("rows", rows);
		jbsections.put(jbsection);*/

		
		
		
		
		
		
		jbaction.put("sections", jbsections);
		jbinteractive.put("action", jbaction);
		jbinteractive.put("header", jbheader);
		jbinteractive.put("body", jbbody);
		jbinteractive.put("footer", jbfoot);
		jb.put("interactive", jbinteractive);
		System.out.println(jb.toString());
	    return jb.toString();
		//HTTPRequest.getResponseWhatsapp(getMycallid(),jb.toString());
	    
		
	}
	
	public String formPromptId(String msisdn,String body,ArrayList jarrmenu,String button,String id)
	{
		
		String body_text=body;
		JSONObject jb = new JSONObject();
		jb.put("recipient_type", "individual");
		jb.put("to", msisdn);
		jb.put("type", "interactive");
		JSONObject jbinteractive=new JSONObject();
		jbinteractive.put("type", "list");
		JSONObject jbheader=new JSONObject();
		jbheader.put("type","text");
		jbheader.put("text","");
		
		JSONObject jbbody=new JSONObject();
		
		jbbody.put("text",body_text);
        JSONObject jbfoot=new JSONObject();
		
		jbfoot.put("text","");
		
		JSONObject jbaction=new JSONObject();
		jbaction.put("button", button);
		JSONArray jbsections=new JSONArray();
		JSONObject jbsection= new JSONObject();
		
		JSONArray rows = new JSONArray();
		
		for ( int i=0 ;i< jarrmenu.size();i++)
		{
			
			String  menu=(String)jarrmenu.get(i);
			JSONObject row= new JSONObject();

			
			row.put("id",i+"X"+id.toLowerCase());
			row.put("title", (i+1)+"");
			row.put("description",menu);
			rows.put(row);
			if ( i >8)
			{
				break;
			}
			


			
		}
		
		jbsection.put("title", " ");
		jbsection.put("rows", rows);
		jbsections.put(jbsection);
		
		 rows = new JSONArray();

		/*for ( int i=10 ;i< jarr.length();i++)
		{
			
			JSONObject ca=jarr.getJSONObject(i);
			JSONObject row= new JSONObject();

			
			row.put("id",i+ca.getString("complaint_type"));
			row.put("title", (i+1)+"");
			row.put("description", ca.getString("complaint_type"));
			rows.put(row);
			

			
		}
		
       jbsection= new JSONObject();
        jbsection.put("title", "PART-2");
		jbsection.put("rows", rows);
		jbsections.put(jbsection);*/

		
		
		
		
		
		
		jbaction.put("sections", jbsections);
		jbinteractive.put("action", jbaction);
		jbinteractive.put("header", jbheader);
		jbinteractive.put("body", jbbody);
		jbinteractive.put("footer", jbfoot);
		jb.put("interactive", jbinteractive);
		System.out.println(jb.toString());
	    return jb.toString();
		//HTTPRequest.getResponseWhatsapp(getMycallid(),jb.toString());
	    
		
	}
	
	
	public String sendQuickPaymsg(String msisdn, String last_4_digit,String amount)
	{
		try
		{
		OkHttpClient client = new OkHttpClient();

		MediaType mediaType = MediaType.parse("application/json");
		RequestBody body = RequestBody.create(mediaType, "{\n\t\"to\": \""+msisdn+"\",\n\t\"type\": "
				+ "\"template\",\n\t\"template\": {\n\t\t\"namespace\":\"a216669b_75e4_463e_b253_311a018e333e\",\n   "
				+ " \t\"name\": \"reminder_template3\",\n      "
				+ "  \"language\": {\n    \t\t\"policy\": \"deterministic\",\n    \t\t\"code\": \"EN\"\n        },\n     "
				+ "   \"components\": [{\n            \"type\": \"body\",\n            \"parameters\": [\n            "
				+ "    {\n                    \"type\": \"text\",\n                    \"text\": \""+amount+"\"\n         "
				+ "       },\n                 {\n                    \"type\": \"text\",\n                 "
				+ "   \"text\": \""+last_4_digit+"\"\n                }\n                 \n            ]\n        }]\n\t}\n}");
		Request request = new Request.Builder()
		  .url("https://waba.360dialog.io/v1/messages")
		  .post(body)
		  .addHeader("content-type", "application/json")
		  .addHeader("d360-api-key", "5XylMcfyYsfqGn13NOicwqrQAK")
		  .addHeader("cache-control", "no-cache")
		  .addHeader("postman-token", "96a5f840-b337-ee2f-24d5-86bc6572a6f5")
		  .build();

		Response response = client.newCall(request).execute();
		String text= response.body().string();
		return text;
		}
		catch ( Exception ex)
		{
			return "error";
		}
		
	}
	
	
	public String formMsisdnList(String msisdn,String body,ArrayList jarrmenu,String button,String id)
	{
		
		String body_text=body;
		JSONObject jb = new JSONObject();
		jb.put("recipient_type", "individual");
		jb.put("to", msisdn);
		jb.put("type", "interactive");
		JSONObject jbinteractive=new JSONObject();
		jbinteractive.put("type", "list");
		JSONObject jbheader=new JSONObject();
		jbheader.put("type","text");
		jbheader.put("text","");
		
		JSONObject jbbody=new JSONObject();
		
		jbbody.put("text",body_text);
        JSONObject jbfoot=new JSONObject();
		
		jbfoot.put("text","");
		
		JSONObject jbaction=new JSONObject();
		jbaction.put("button", button);
		JSONArray jbsections=new JSONArray();
		JSONObject jbsection= new JSONObject();
		
		JSONArray rows = new JSONArray();
		
		for ( int i=0 ;i< jarrmenu.size();i++)
		{
			
			MyMenu mm =(MyMenu)jarrmenu.get(i);
			JSONObject row= new JSONObject();

			
			row.put("id",mm.id+"MOB"+mm.msisdn);
			row.put("title", (mm.id)+"");
			row.put("description",org.json.simple.JSONObject.escape(mm.description));
			rows.put(row);
			
			
			


			
		}
		String uuid=UUID.randomUUID().toString();
		JSONObject row= new JSONObject();
		row.put("id","MORE"+uuid);
		row.put("title", "More");
		row.put("description","");
		rows.put(row);
		
		jbsection.put("title", " ");
		jbsection.put("rows", rows);
		jbsections.put(jbsection);
		
		 rows = new JSONArray();

		/*for ( int i=10 ;i< jarr.length();i++)
		{
			
			JSONObject ca=jarr.getJSONObject(i);
			JSONObject row= new JSONObject();

			
			row.put("id",i+ca.getString("complaint_type"));
			row.put("title", (i+1)+"");
			row.put("description", ca.getString("complaint_type"));
			rows.put(row);
			

			
		}
		
       jbsection= new JSONObject();
        jbsection.put("title", "PART-2");
		jbsection.put("rows", rows);
		jbsections.put(jbsection);*/

		
		
		
		
		
		
		jbaction.put("sections", jbsections);
		jbinteractive.put("action", jbaction);
		jbinteractive.put("header", jbheader);
		jbinteractive.put("body", jbbody);
		jbinteractive.put("footer", jbfoot);
		jb.put("interactive", jbinteractive);
		System.out.println(jb.toString());
	    return jb.toString();
		//HTTPRequest.getResponseWhatsapp(getMycallid(),jb.toString());
	    
		
	}
	
	
	
	
	
	
	public String formList(String msisdn,String body,ArrayList jarrmenu,String button,String id)
	{
		
		String body_text=body;
		JSONObject jb = new JSONObject();
		jb.put("recipient_type", "individual");
		jb.put("to", msisdn);
		jb.put("type", "interactive");
		JSONObject jbinteractive=new JSONObject();
		jbinteractive.put("type", "list");
		JSONObject jbheader=new JSONObject();
		jbheader.put("type","text");
		jbheader.put("text","");
		
		JSONObject jbbody=new JSONObject();
		
		jbbody.put("text",body_text);
        JSONObject jbfoot=new JSONObject();
		
		jbfoot.put("text","");
		
		JSONObject jbaction=new JSONObject();
		jbaction.put("button", button);
		JSONArray jbsections=new JSONArray();
		JSONObject jbsection= new JSONObject();
		
		JSONArray rows = new JSONArray();
		
		for ( int i=0 ;i< jarrmenu.size();i++)
		{
			
			MyMenu mm =(MyMenu)jarrmenu.get(i);
			JSONObject row= new JSONObject();

			
			row.put("id",mm.id+id);
			row.put("title", (Integer.parseInt(mm.id)+1)+"");
			if ( mm.contract_id !=null)
			{
			row.put("description",mm.product+"-"+mm.contract_id);
			}
			else
			{
				row.put("description",mm.product);

			}
			rows.put(row);
			
			
			


			
		}
		
		

		/*for ( int i=10 ;i< jarr.length();i++)
		{
			
			JSONObject ca=jarr.getJSONObject(i);
			JSONObject row= new JSONObject();

			
			row.put("id",i+ca.getString("complaint_type"));
			row.put("title", (i+1)+"");
			row.put("description", ca.getString("complaint_type"));
			rows.put(row);
			

			
		}*/
		
       jbsection= new JSONObject();
		jbsection.put("rows", rows);
		jbsections.put(jbsection);

		
		
		
		
		
		
		jbaction.put("sections", jbsections);
		jbinteractive.put("action", jbaction);
		jbinteractive.put("header", jbheader);
		jbinteractive.put("body", jbbody);
		jbinteractive.put("footer", jbfoot);
		jb.put("interactive", jbinteractive);
		System.out.println(jb.toString());
	    return jb.toString();
		//HTTPRequest.getResponseWhatsapp(getMycallid(),jb.toString());
	    
		
	}
	
	
	public String formMsisdnTypeList(String msisdn,String body,ArrayList jarrmenu,String button,String id)
	{
		
		String body_text=body;
		JSONObject jb = new JSONObject();
		jb.put("recipient_type", "individual");
		jb.put("to", msisdn);
		jb.put("type", "interactive");
		JSONObject jbinteractive=new JSONObject();
		jbinteractive.put("type", "list");
		JSONObject jbheader=new JSONObject();
		jbheader.put("type","text");
		jbheader.put("text","");
		
		JSONObject jbbody=new JSONObject();
		
		jbbody.put("text",body_text);
        JSONObject jbfoot=new JSONObject();
		
		jbfoot.put("text","");
		
		JSONObject jbaction=new JSONObject();
		jbaction.put("button", button);
		JSONArray jbsections=new JSONArray();
		JSONObject jbsection= new JSONObject();
		
		JSONArray rows = new JSONArray();
		
		for ( int i=0 ;i< jarrmenu.size();i++)
		{
			
			MyMenu mm =(MyMenu)jarrmenu.get(i);
			JSONObject row= new JSONObject();

			
			row.put("id",mm.id+"TYPE"+mm.msisdn);
			row.put("title", mm.id);
			row.put("description",mm.description);
			rows.put(row);
			
			
			


			
		}
		String uuid=UUID.randomUUID().toString();
		JSONObject row= new JSONObject();
		row.put("id","MORE"+uuid);
		row.put("title", "More");
		row.put("description","");
		rows.put(row);
		
		jbsection.put("title", " ");
		jbsection.put("rows", rows);
		jbsections.put(jbsection);
		
		 rows = new JSONArray();

		/*for ( int i=10 ;i< jarr.length();i++)
		{
			
			JSONObject ca=jarr.getJSONObject(i);
			JSONObject row= new JSONObject();

			
			row.put("id",i+ca.getString("complaint_type"));
			row.put("title", (i+1)+"");
			row.put("description", ca.getString("complaint_type"));
			rows.put(row);
			

			
		}
		
       jbsection= new JSONObject();
        jbsection.put("title", "PART-2");
		jbsection.put("rows", rows);
		jbsections.put(jbsection);*/

		
		
		
		
		
		
		jbaction.put("sections", jbsections);
		jbinteractive.put("action", jbaction);
		jbinteractive.put("header", jbheader);
		jbinteractive.put("body", jbbody);
		jbinteractive.put("footer", jbfoot);
		jb.put("interactive", jbinteractive);
		System.out.println(jb.toString());
	    return jb.toString();
		//HTTPRequest.getResponseWhatsapp(getMycallid(),jb.toString());
	    
		
	}
	public String sendMessage(String session_id,String msisdn, String msg,String whatsapp_token,Connection conn)
	{
		 
			  String contact_id=msisdn;
		
			  
	    String json="";
	    JSONObject jb = new JSONObject();
	    org.json.simple.JSONArray jarr = new org.json.simple.JSONArray();
	    JSONObject jb1 = new JSONObject();
	    jb1.put("channel","whatsapp");
	    jb1.put("to",contact_id);
	    jb1.put("content",msg);
	    jarr.add(jb1);
	    jb.put("message",jarr);
	    
	    

	    
	      json="{\"messages\": [{ \"channel\": \"whatsapp\", \"to\": \""+contact_id+"\", \"content\": \""+msg+"\" }]}";
	  //  json=jb.toString();
	    System.out.println("JSON="+json);
	      return sendWhatsappMsg(session_id, json,msisdn,whatsapp_token,conn);
	  }
	
	public String sendMessage360(String session_id,String msisdn, String msg,String whatsapp_token,Connection conn)
	{
		 
			  String contact_id=msisdn;
		
	      String json="{\n"
	      		+ "  \"recipient_type\": \"individual\",\n"
	      		+ "   \"type\": \"text\",\n"
	      		+ "  \"to\": \""+contact_id+"\",\n"
	      		+ "\"text\": {\n"
	      		+ "    \"body\": \""+org.json.simple.JSONObject.escape(msg)+"\"\n"
	      		+ "  }\n"
	      		+ "  \n"
	      		+ "  \n"
	      		+ "  \n"
	      		+ " \n"
	      		+ "  \n"
	      		+ "}";
	    
	      return sendWhatsappMsg(session_id, json,msisdn,whatsapp_token,conn);
	  }
	
	public String sendMessage360Welcome(String session_id,String msisdn, String msg,String whatsapp_token,Connection conn)
	{
		 
			  String contact_id=msisdn;
			
			  String json="{ \"messaging_product\": \"whatsapp\", \"to\": \""+msisdn+"\", \"type\": \"template\", \"template\": { \"name\": \"main_menu\", \"language\": { \"code\": \"en\" } } }";

	/*	String json="{\n"
				+ "	\"to\": \""+msisdn+"\",\n"
				+ "	\"type\": \"template\",\n"
				+ "	\"template\": {\n"
				+ "		\"namespace\":\"86d727eb_dedf_4ec3_a067_c4bf997d9d11\",\n"
				+ "    	\"name\": \"main_menu\",\n"
				+ "        \"language\": {\n"
				+ "    		\"policy\": \"deterministic\",\n"
				+ "    		\"code\": \"EN\"\n"
				+ "        },\n"
				+ "        \"components\": [{\n"
				+ "            \"type\": \"body\"\n"
				+ "           \n"
				+ "        }]\n"
				+ "	}\n"
				+ "}";*/
	    
	      return sendWhatsappMsg(session_id, json,msisdn,whatsapp_token,conn);
	  }
	
	
	
	
	public String markRead(String whatsapp_key,String msg_id,Connection conn)
	{
		String url="https://waba.360dialog.io/v1/messages";
		//   OutputStream out=null;
		    try {
		           URL url1 = new URL(url);
		          
		/* 50 */       URLConnection connection = url1.openConnection();
		/* 51 */       HttpsURLConnection httpConn = ((HttpsURLConnection)connection);
		/* 52 */       httpConn.setReadTimeout(20000);
		/* 53 */       httpConn.setConnectTimeout(20000);
		/* 55 */       httpConn.setRequestProperty("d360-api-key", whatsapp_key);
		/* 55 */       httpConn.setRequestProperty("cache-control", "no-cache");
		httpConn.setRequestMethod("PUT");
		Statement st=conn.createStatement();
		String sql="update whatsapp.incoming_message set msg_status='read' where msg_id='"+msg_id+"'";
		st.executeUpdate(sql);
		
		// InputStreamReader isr = new InputStreamReader(httpConn.getInputStream());
		 
		    }
		    catch ( Exception ex)
		    {
		    	ex.printStackTrace();
		    }
		    return "";
		            
		
	}
	
	
	
	
	public String call(String a_number, String b_number)
	{
		   String res="";
		     BufferedReader in=null;
		/*    */       OutputStream out=null;
		/*    */       Writer wout=null;
		try
		{
		//String url="https://obdmumbai.anymsg.in:8443/CALLPATCHAPI/patchcall.jsp?"+
			String url="http://dial.123ivr.in:5555/CALLPATCHAPI/patchcall.jsp?"+
				"USERID=ikontelprod&PASSWD="+URLEncoder.encode("Ikontel@456","utf8")+"&A_PARTY="+a_number+"&B_PARTY="+b_number+"&NO_OF_RETRIES=1&RETRY_INTERVAL=10&SCHEDULE_TIME=2021-06-04%2010:10:00&EXPIRED_TIME=2022-06-04%2010:30:00&DETAIL_EVENT=Y&PRIORITY=1&CALLBACK_URL="+URLEncoder.encode("https://ha1.msg2all.com:8443/ikontel_whatsapp_360/callback.jsp","utf8");
		// url="https://waba.360dialog.io/v1/messages";
		System.out.println(url);
		//   OutputStream out=null;
		 
		           URL url1 = new URL(url);
		          
		/* 50 */       URLConnection connection = url1.openConnection();
		/* 51 */       HttpURLConnection httpConn = ((HttpURLConnection)connection);
		/* 52 */       httpConn.setReadTimeout(20000);
		/* 53 */       httpConn.setConnectTimeout(20000);
		/* 55 */      
		
		  httpConn.setRequestMethod("POST");
          httpConn.setDoInput(true);
/* 57 */       httpConn.setDoOutput(true);


          //httpConn.connect();
/* 58 */      


/*    */
/* 60 */      // out = httpConn.getOutputStream();
/* 61 */      // wout = new OutputStreamWriter(out);
/* 62 */      // wout.flush();
//out = httpConn.getOutputStream();
//out.write(xml.getBytes());
          System.out.println("code="+httpConn.getResponseCode());
         
/* 64 */       InputStreamReader isr = new InputStreamReader(httpConn.getInputStream());
/*    */
/* 66 */       in = new BufferedReader(isr);
/* 67 */       String temp = "";
/* 68 */       res = "";
/* 69 */       while ((temp = in.readLine()) != null)
/* 70 */         res += temp;
          System.out.println("res_ok="+res);
          return res;
        
		
		
		// InputStreamReader isr = new InputStreamReader(httpConn.getInputStream());
		 
		    }
		    catch ( Exception ex)
		    {
		    	ex.printStackTrace();
		    }
		    return "";
		            	
	
	}
	
	
	public String updateDisposition(String req_id, String disposition, String mode)
	{
		   String res="";
		     BufferedReader in=null;
		/*    */       OutputStream out=null;
		/*    */       Writer wout=null;
		try
		{
		//String url="https://obdmumbai.anymsg.in:8443/CALLPATCHAPI/patchcall.jsp?"+
			String url="http://dial.123ivr.in:5555/CALLPATCHAPI/updateDispo.jsp?mode="+URLEncoder.encode(mode,"utf8")+"&disposition="+URLEncoder.encode(disposition,"utf8")+"&req_id="+req_id;
		// url="https://waba.360dialog.io/v1/messages";
		System.out.println(url);
		//   OutputStream out=null;
		 
		           URL url1 = new URL(url);
		          
		/* 50 */       URLConnection connection = url1.openConnection();
		/* 51 */       HttpURLConnection httpConn = ((HttpURLConnection)connection);
		/* 52 */       httpConn.setReadTimeout(20000);
		/* 53 */       httpConn.setConnectTimeout(20000);
		/* 55 */      
		
		  httpConn.setRequestMethod("POST");
          httpConn.setDoInput(true);
/* 57 */       httpConn.setDoOutput(true);


          //httpConn.connect();
/* 58 */      


/*    */
/* 60 */      // out = httpConn.getOutputStream();
/* 61 */      // wout = new OutputStreamWriter(out);
/* 62 */      // wout.flush();
//out = httpConn.getOutputStream();
//out.write(xml.getBytes());
          System.out.println("code="+httpConn.getResponseCode());
         
/* 64 */       InputStreamReader isr = new InputStreamReader(httpConn.getInputStream());
/*    */
/* 66 */       in = new BufferedReader(isr);
/* 67 */       String temp = "";
/* 68 */       res = "";
/* 69 */       while ((temp = in.readLine()) != null)
/* 70 */         res += temp;
          System.out.println("res_ok="+res);
          return res;
        
		
		
		// InputStreamReader isr = new InputStreamReader(httpConn.getInputStream());
		 
		    }
		    catch ( Exception ex)
		    {
		    	ex.printStackTrace();
		    }
		    return "";
		            	
	
	}
	
	
	public JSONArray getBankDetail(String msisdn,String session_id)
	{
		try
		{
		JSONObject jbauth= new JSONObject();
		jbauth.put("authToken","MTI4OjoxMDAwMDo6YzQ2NTk3ZDk2OGFhYTllMjJmMTdkMzQ3YTBlYmM4Mjk6OjZhM2RkZWQzNmZiZTFiODBhNjE0ZjQwYTcwNmQ5MzA2Ojp0RlBITGczVFQyN254QWxNWm8yUy8wY3FKZFZIVE5XaWxFRUhLUFkweTQwL1BCTmo3Vy9SMzZsK2oyY3VRNVdI");
		
		JSONObject jmob = new JSONObject();
		//jmob.put("mobileNo",msisdn.substring(2));
		jmob.put("mobileNo","8978751133");

		
		JSONObject jb1  = new JSONObject();
		jb1.put("header",jbauth);
		jb1.put("body",jmob);
		
		//GET USER DETAIAIL -SHAFT API
		
		String resp=HTTPRequest.getBankApiResponse(msisdn, "https://retail1.tatacapital.com/shaft/partner/api/services/db/get-user-token", jb1.toString());

		JSONObject jb= new JSONObject(resp);
		
		String userid=jb.getJSONObject("body").getString("userToken");
		
		
		jbauth= new JSONObject();
		jbauth.put("authToken","MTI4OjoxMDAwMDo6M2E3YjA4ZjAyZGIxNjRlYjM4ODkzOTE5NjA3ZTNkMzY6OmNhMjc3NDgxMmUwOTBhYjUyYzYwMDljZTYwN2U4Yzk2OjpLVDFLRCtDRzJtWUxOMFkxWVhDNkpkY05ld0pHdEE2NytLa3FkU0VMQnJLV3VNOGI4M2pHWVBJdkQ5cHQ2aWhy");
		
		jbauth.put("type","gcid");
		
		jmob = new JSONObject();
		jmob.put("username",userid);
		
		jb1  = new JSONObject();
		jb1.put("header",jbauth);
		jb1.put("body",jmob);
		
		String url="https://retail1.tatacapital.com/shaft/partner/api/services/db/get-user-data-v2";
		
		 resp=HTTPRequest.getBankApiResponse(msisdn, url, jb1.toString());

		 jb= new JSONObject(resp);
		 /*
		  * {"header":{"status":"SUCCESS","requestId":"REQ-1650605299031"},"body":{"PRIMARY_GCID":"7291283",
		  * "GCID":"7291283","USER_ID":"136","FIRST_NAME":"Ritu","LAST_NAME":"Singh",
		  * "COMPANY_NAME":"TCHFL","FIRST_LOGIN":"N","MOBILE_FIRST_LOGIN":"N","LAST_LOGGED_IN":"2022-04-21 07:07:57",
		  * "EMAIL_SENT":"N","SMS_SENT":"N","ELOCKER_TNC":"Y","RESET_PASSWORD":"N","DEFAULT_SYSTEM_ID":"1",
		  * "PORTAL_CREATED_DATE":"2019-11-05 06:44:55","PORTAL_LAST_MODIFIED":"2022-04-21 07:07:57",
		  * "CURRENT_LOGGED_IN":"04-22-2022 10:58:19","IS_FEEDBACK_SUBMITTED":"N","ucics":"1000723343",
		  * "pans":"AGLPM8311R","dobs":"07/14/2021 00:00:00","mobiles":"","emails":"NA","CREDIT_SCORE":""
		  * ,"PROFILE_PIC_SIZE":2,
		  * "contracts":[{"ID":"1105202","PRIMARY_GCID":"7291283","PORTAL_CREATED_DATE":"2019-11-05 06:44:55","PORTAL_LAST_MODIFIED":
		  * "2022-01-18 06:41:28","TITLE":"Mrs","FIRSTNAME":"Ritu","LASTNAME":"Singh","DOB":"07/14/2021 00:00:00","CITY":"Udaipur (Rajasthan)",
		  * "EMAIL":"NA","COUNTRY":"IN","MOBILENO":"","GCID":"7291283",
		  * "BUSINESSCATEGORY":"CFAB","PAN_NBR":"AGLPM8311R","CONTRACT_NUMBER":"9414435","USER_CREATED_IN_OPEN_DS":"Y","SOURCE_SYSTEM":"BANCS",
		  * "ADDRESS_LINE1":"\"HOUSE NO 412\"","ADDRESS_LINE3":"","ADDRESS_LINE2":"\"ROAD D-1 BHUPALPURA\"","CREATED_DATE":"2015.04.01",
		  * "PINCODE":"313001","STATE":"RAJASTHAN","DISBURSAL_DATE":"2015.04.30","COMPANY":"TCHFL","TELEPHONE_NO":""
		  * ,"PRODUCT":"\"HOME LOAN\"","SUB_PRODUCT":"\"HOME LOAN\"","CUSTOMER_CATEGORY":"01","PRODUCT_CODE":"9001","UCIC":"1000723343","NEW_USER":"N","CUSTOMER_COUNT_ID":"AGLPM8311R","WEBTOP_NO":"284080002226","SUB_PRODUCT_CODE":"1102","CUSTOMER_COUNT_ID_TYPE":"PAN","productInfo":{"PRODUCT_CODE":"9001","SUB_PRODUCT_CODE":"1102","PRODUCT_NAME":"9001","SUB_PRODUCT_NAME":"HOME LOAN-FIXED","PRODUCT":"HOME LOAN","SUB_PRODUCT":"HOME LOAN","SOURCE_SYSTEM":"BANCS","BUSINESS_SEGMENT":"","DISPLAY_NAME":"Home Loan","PRODUCT_FAMILY":"TCHFL","FORECLOSURE_CHARGES":"NA"}}],"otherSystemDetails":[],"primarySystem":{"USER_ID":"136","GCID":"7291283","SYSTEM_ID":"1","SYSTEM_NAME":"Retail"},
		  * "creditScoreDetails":{},"otherSystem":[]},"errorBody":{}}
		  */
		 String gcid=jb.getJSONObject("body").getString("GCID");
		 
		
		 String COMPANY_NAME=jb.getJSONObject("body").getString("COMPANY_NAME");
		 
		 
		 JSONArray jarr = new JSONArray();
		 JSONArray jbcontracts=jb.getJSONObject("body").getJSONArray("contracts");
		 
		 for ( int i=0;i<jbcontracts.length();i++)
		 {
			 JSONObject jbc= jbcontracts.getJSONObject(i);
			 JSONObject jbprod= new JSONObject();
			 jbprod.put("gcid",gcid);
			 jbprod.put("contract_no",jbc.getString("CONTRACT_NUMBER"));
			 jbprod.put("product",jbc.getString("PRODUCT"));
			 jbprod.put("PRODUCT_CODE",jbc.getString("PRODUCT_CODE"));
			 jbprod.put("COMPANY_NAME",COMPANY_NAME);
			 String cust_name=jbc.getString("FIRSTNAME") +" "+jbc.getString("LASTNAME");


			 jbprod.put("cust_name",cust_name);
			 jbprod.put("email",jbc.getString("EMAIL"));

			 
			 jarr.put(jbprod);


			 
		 }
		 
				
		 System.out.println("PROD_DETAIL="+jarr.toString());
		 
		 
		 
		 return jarr;
		 
		 
		
		
		
	    
		
		
		
		}
		catch ( Exception ex)
		{
			ex.printStackTrace();
			return null;
		}
		
		
	

		

		
	}
	
	
	public JSONArray getBankOutStandingDetail(String CONTRACT_NO,String gcid,String session_id)
	{
		try
		{
	
		 String url1="https://apicast-uat-whatsappfrontendadapter.tclnprdservice.tatacapital.com/rest/whatsApp/v1.0/pgs/getPGSContracts";
		 		
		 
		 JSONObject jb2= new JSONObject();
		 jb2.put("contractNo",CONTRACT_NO);
		 jb2.put("gcid",gcid);
		 System.out.println("output="+jb2.toString());
		 
		 OkHttpClient client = new OkHttpClient();

		 MediaType mediaType = MediaType.parse("application/json");
		 RequestBody body = RequestBody.create(mediaType, jb2.toString());
		 Request request = new Request.Builder()
		   .url("https://apicast-uat-whatsappfrontendadapter.tclnprdservice.tatacapital.com/rest/whatsApp/v1.0/cdi/getLoanPositionDetails")
		   .post(body)
		   .addHeader("accept-encoding", "gzip,deflate")
		   .addHeader("authorization", "Basic MTA3ZTU1OWU6d2hhdHNhcHB1YXQ=")
		   .addHeader("conversationid", session_id)
		   .addHeader("sourcename", "whatsapp")
		   .addHeader("content-type", "application/json")
		   .addHeader("cache-control", "no-cache")
		   .addHeader("postman-token", "2167ab53-4f28-ab8a-8a36-97d404fd1824")
		   .build();

		 Response response = client.newCall(request).execute();
		 
		 
		 String myresp=response.body().string();
		 System.out.println("BANKRESP1="+myresp);
		 
		 JSONObject jresp= new JSONObject(myresp);
		 
		 JSONArray jarr= jresp.getJSONArray("Response");
		 
		 JSONArray jarr1= new JSONArray();
		 
		 for ( int i=0;i<jarr.length();i++)
		 {
			 JSONObject jbs= jarr.getJSONObject(i);
			 String outstanding_amt=jbs.getString("outstandingAmount");
			 String product=jbs.getString("product");
			 String dueAmount=jbs.getString("dueAmount");
			 String overdueAmount=jbs.getString("overdueAmount");

			 
			 JSONObject jprod= new JSONObject();
			 
			 jprod.put("product",product);
			 jprod.put("od",outstanding_amt);
			 jprod.put("due_amt",dueAmount);
			 jprod.put("overdueAmount",overdueAmount);


			 
			 jarr1.put(jprod);
			 

			 
			 
			 
		 }
		 System.out.println("LOAN_DETAIL="+jarr1.toString());
		 
		 
		 
		 return jarr1;
		 
		 
		
		
		
	    
		
		
		
		}
		catch ( Exception ex)
		{
			ex.printStackTrace();
			return null;
		}
		
		
	

		

		
	}
	
	
	public JSONArray getBankOutStandingDetailFromPG(String CONTRACT_NO,String company,String session_id)
	{
		try
		{
	
		 String url1="https://apicast-uat-whatsappfrontendadapter.tclnprdservice.tatacapital.com/rest/whatsApp/v1.0/pgs/getPGSContracts";
		 		
		 
		 JSONObject jb2= new JSONObject();
		 jb2.put("contractNo",CONTRACT_NO);
		 jb2.put("company",company);
		 System.out.println("output="+jb2.toString());
		 
		 OkHttpClient client = new OkHttpClient();

		 MediaType mediaType = MediaType.parse("application/json");
		 RequestBody body = RequestBody.create(mediaType, jb2.toString());
		 Request request = new Request.Builder()
		   .url("https://apicast-uat-whatsappfrontendadapter.tclnprdservice.tatacapital.com/rest/whatsApp/v1.0/pgs/getPGSContracts")
		   .post(body)
		   .addHeader("accept-encoding", "gzip,deflate")
		   .addHeader("authorization", "Basic MTA3ZTU1OWU6d2hhdHNhcHB1YXQ=")
		   .addHeader("conversationid", session_id)
		   .addHeader("sourcename", "whatsapp")
		   .addHeader("content-type", "application/json")
		   .addHeader("cache-control", "no-cache")
		   .addHeader("postman-token", "2167ab53-4f28-ab8a-8a36-97d404fd1824")
		   .build();

		 Response response = client.newCall(request).execute();
		 
		 
		 String myresp=response.body().string();
		 
		 
		 System.out.println("BANKRESP1="+myresp);
		 
		 JSONObject jresp= new JSONObject(myresp);
		 
		 JSONArray jarr= jresp.getJSONArray("Response");
		 
		 JSONArray jarr1= new JSONArray();
		 
		 for ( int i=0;i<jarr.length();i++)
		 {
			 JSONObject jbs= jarr.getJSONObject(i);
			
			
			 String product=jbs.getString("productCode");
			 String dueAmount=jbs.getString("odAmount");
			 String odCharges=jbs.getString("odCharges");
			 String contract_no=jbs.getString("contractNo");
			 
			 Float outstanding_amt=Float.parseFloat(dueAmount) + Float.parseFloat(odCharges);
			 String outstanding_amt1=Float.toString(outstanding_amt);


			 
			 JSONObject jprod= new JSONObject();
			 
			 jprod.put("product",product);
			 jprod.put("od",outstanding_amt);
			 jprod.put("due_amt",dueAmount);
			 jprod.put("overdueAmount",outstanding_amt1);
			 jprod.put("odcharges",odCharges);
			 jprod.put("contract_no",contract_no);


			 
			 jarr1.put(jprod);
			 

			 
			 
			 
		 }
		 System.out.println("LOAN_DETAIL="+jarr1.toString());
		 
		 
		 
		 return jarr1;
		 
		 
		
		
		
	    
		
		
		
		}
		catch ( Exception ex)
		{
			ex.printStackTrace();
			return null;
		}
		
		
	

		

		
	}
	
	public String removeFromWhatsapp(String msisdn)
	{
		try
		{
		String client_id="7lestlo59yyy8a4xwb3rvhcl";
		String client_secret="29vT9qeZJR3O4LzlWYOI7Cmo";
		OkHttpClient client = new OkHttpClient();

		MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
		RequestBody body = RequestBody.create(mediaType, "client_id="+client_id+"&client_secret="+
		client_secret+"&grant_type=client_credentials");
		Request request = new Request.Builder()
		  .url("https://mczqk2ykblyg79tkynlmnzn9qz04.auth.marketingcloudapis.com/v2/token")
		  .post(body)
		  .addHeader("content-type", "application/x-www-form-urlencoded")
		  .addHeader("cache-control", "no-cache")
		  .build();

		Response response = client.newCall(request).execute();
		String jsonstring=response.body().string();
		JSONObject jb = new JSONObject(jsonstring);
		String accesstoken=jb.getString("access_token");
		System.out.println("ACCESSTOKEN="+accesstoken);
		
		 client = new OkHttpClient();

		 mediaType = MediaType.parse("application/json");
		 JSONObject jbval = new JSONObject();
		 JSONArray jarr= new JSONArray();
		 JSONObject jb1= new JSONObject();
		 jb1.put("Mobile_number",msisdn);
		 
		 jbval.put("keys",jb1);
		 
		 JSONObject jb2= new JSONObject();
		 jb2.put("Consent_value",false);
		 
		 jbval.put("values",jb2);
		 
		 jarr.put(jbval);
		 
		 
		 body = RequestBody.create(mediaType,jarr.toString());
		 request = new Request.Builder()
				
		  .url("https://mczqk2ykblyg79tkynlmnzn9qz04.rest.marketingcloudapis.com/hub/v1/dataevents/key:D464FF86-E069-4099-A6A6-BC51FE259459/rowset")
		  .post(body)
		  .addHeader("content-type", "application/json")
		  .addHeader("authorization", "Bearer "+accesstoken)
		  .addHeader("cache-control", "no-cache")
		  .build();

		 response = client.newCall(request).execute();
		 String consent_resp=response.body().string();
			System.out.println("CONTENT_RESP="+consent_resp);

		/* jb= new JSONObject(consent_resp);
		 
		 if ( jb.getInt("errorcode") ==10001)
		 {
			 
			 return "success";
		 }
		 else
		 {
			 return "failure";
			 
		 }*/
			return consent_resp;
		 
		
		}
		catch ( Exception ex)
		{
			return "failure";
		}
		
		
		
	}
	
	public void SelectAmout(String from, String due_amt,String outstandingamt,String contract_id, String od_charges, 
			String cust_name, String email,String product, String COMPANY_NAME, String PROD_CODE, String total_amount, String total_paid_total)
	{
		Connection conn=null;
		try
		{
		  
			Class.forName("com.mysql.jdbc.Driver");  
			 conn=DriverManager.getConnection(  
			"jdbc:mysql://localhost:3306/whatsapp","whatsapp","whatsapp123");  
   		  MyMenu mm= new MyMenu();
   		  ArrayList arr = new ArrayList();

			 
			 mm.id="0";
			   mm.product=org.json.simple.JSONObject.escape("Total OverDue Amount Rs."+outstandingamt);
			   arr.add(mm);
			   
			   mm= new MyMenu();
			   
			   mm.id="1";
			   
			   mm.product=org.json.simple.JSONObject.escape("Pay Other Amount");
			   arr.add(mm);
			   
			   WhatsAppMessage wa= new WhatsAppMessage();
			   String jsonw=wa.formList(from, "Select Amount", arr, "Select Amount","PROD");
		    	//String json1=wa.sendMessage360("121222", from, "Hi, Welcome  to GoGas Scheme Enrollment.", "5XylMcfyYsfqGn13NOicwqrQAK", conn);
			    wa.sendWhatsappMsg("121212", jsonw, from, "5XylMcfyYsfqGn13NOicwqrQAK", conn);
		
	
		}
		catch ( Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			try
			{
			conn.close();
			}
			catch ( Exception ex)
			{
				
			}
		}
	}
	
	
	public void doHeavy(String from, String due_amt,String outstandingamt,String contract_id, String od_charges, 
			String cust_name, String email,
	 String product, String COMPANY_NAME, String PROD_CODE, String total_amount, String total_paid_total)
	{
		Connection conn=null;
		try
		{
		  
			Class.forName("com.mysql.jdbc.Driver");  
			 conn=DriverManager.getConnection(  
			"jdbc:mysql://localhost:3306/whatsapp","whatsapp","whatsapp123");  
		
	
	/*	String msg="➡️ *Registered Mobile Number* "+from+"\n"+"➡️ *Total Overdraft Amount Rs*."+
		due_amt+"\n"+"➡️ *Outstanding Balance Rs*."+outstandingamt;
	
	   sendMessage360("121212", from, msg, "5XylMcfyYsfqGn13NOicwqrQAK", conn);
	   String msg1="*You can make the payment*\n *towards the outstanding balance*\n *by visiting the link below.* 👇🏻";
	   sendMessage360("121212", from, msg1, "5XylMcfyYsfqGn13NOicwqrQAK", conn);*/
	   
	   UUID uuid= UUID.randomUUID();
	   String link=makePaymentLink(contract_id, due_amt, cust_name, email, from, product, 
					   COMPANY_NAME, PROD_CODE, "FINONE", od_charges, 
					   total_amount, total_paid_total, "Overdue EMI and LatePayment Charges", "whatsapp", uuid.toString(), "www.xyz.com");
	   
	   String linkmsg= "*Please click on the link below to make payment :*\n\n"+link;
			   sendMessage360("121212", from, linkmsg,"5XylMcfyYsfqGn13NOicwqrQAK", conn);
			   
	  String helpmsg="*Can I help you with anything else? 😊*";
	  
	  sendMessage360("121212", from, helpmsg,"5XylMcfyYsfqGn13NOicwqrQAK", conn);
		}
		catch ( Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			try
			{
			conn.close();
			}
			catch ( Exception ex)
			{
				
			}
		}
	}
	


	public String makePaymentLink(String contract_id,String amount,String cust_name,String email_id,String msisdn,
			String prod_name,String company,String product_code,String source_system,
			String od_charges,String total_amount, String paid_total, 
			String trans_type, String channel,String unique_trans_id,String return_url)
	{
		try
		{
		
		 String msg="{  \n"
		    		+ "   \"customerName\":\"abc\",\n"
		    		+ "   \"contractNo\":\"TCHHL0269000100007162\",\n"
		    		+ "   \"emailId\":\"abc@GMAIL.COM\",\n"
		    		+ "   \"mobileNo\":\"9876543210\",\n"
		    		+ "   \"productName\":\"CD_Product\",\n"
		    		+ "   \"company\":\"TCFSL\",\n"
		    		+ "   \"productCode\":\"CD\",\n"
		    		+ "   \"sourceSystem\":\"FINONE\",\n"
		    		+ "   \"odAmount\":\"0.00\",\n"
		    		+ "   \"odCharges\":\"3.00\",\n"
		    		+ "   \"totalAmount\":\"3.00\",\n"
		    		+ "   \"paidTotal\":3.00,\n"
		    		+ "   \"transactionType\":\"Overdue EMI and LatePayment Charges\",\n"
		    		+ "   \"channel\":\"whatsapp\",\n"
		    		+ "           \"uniqueTransactionId\":\"21221212\",\n"
		    		+ "   \"returnURL\":\"www.abc.com\",\n"
		    		+ "   \"timestamp\":\"28-04-2020 17:37:25\",\n"
		    		+ "   \"altMobileNo\": \"9999090900\", \n"
		    		+ "   \"altEmailId\":\"xyz@abc.com\"\n"
		    		+ "\n"
		    		+ "}";
		 
		 
		AES aes= new AES();
		JSONObject jb = new JSONObject();
		jb.put("customerName",cust_name);
		jb.put("contractNo",contract_id);
		jb.put("emailId",email_id);
		jb.put("mobileNo",msisdn);
		jb.put("productName",prod_name);
		jb.put("company",company);
		jb.put("productCode",product_code);
		jb.put("sourceSystem",source_system);
		jb.put("odAmount",amount);
		jb.put("odCharges",od_charges);
		jb.put("totalAmount",total_amount);
		jb.put("paidTotal",paid_total);
		jb.put("transactionType",trans_type);
		jb.put("channel",channel);
		jb.put("uniqueTransactionId",unique_trans_id);
		jb.put("returnURL",return_url);
		DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
		String strDate = dateFormat.format(new Date());

		jb.put("timestamp",strDate);
		jb.put("altMobileNo",msisdn);
		jb.put("altEmailId",email_id);





		









		String encmsg=aes.encrypt(jb.toString(), "ajqzplsmlqfaofqmtzjpq-pgs-WH");
		
		String myurl="https://online1.tatacapital.com:8085/#/payment-gateway?channel=whatsapp&pgsmsg="+encmsg;
		
		
		
		  // String myurl="https://capitalfirst.com/customer-moratorium-calculator/RojhRbxwy636QRv654db1A==";
			 
			  // String myurl="https://capitalfirst.com/customer-moratorium-calculator/RojhRbxwy636QRv654db1A==";


			String url="https://api.anymsg.in/ALLLINKS/createQuick.jsp?myurl="+URLEncoder.encode(myurl,"utf8");
			String resp=HTTPRequest.getResponseShort(url);
			System.out.println("RESP="+resp);
			JSONObject jb3 = new JSONObject(resp);
			//{"result":{"req_id":"b773a35e-2201-4259-8a19-8152e390acf0","tinyurl":"h","status":{"statusCode":"0"}}}
			String tinyurl="";
			String req_id="";
			if ( jb3.getJSONObject("result").getJSONObject("status").getString("statusCode").equals("0"))
			{
				tinyurl=jb3.getJSONObject("result").getString("tinyurl");
				req_id=jb3.getJSONObject("result").getString("req_id");
			}
			
			
			if ( tinyurl.length() !=0)
			{
			tinyurl="https://q.ikns.biz/"+tinyurl;
			}
			
		return tinyurl;
		}
		catch ( Exception ex)
		{
			ex.printStackTrace();
		}
		return null;
		
	}

	public String formatCompanyName(JSONArray arr)
	{
		String formated_string="";
		for (int i=0;i<arr.length();i++)
		{
			formated_string=formated_string+(i+1)+"."+arr.getJSONObject(i).getString("value")+"\n";
			
		}
		
		return formated_string;
	}
	
 public JSONArray getCompanyNameS(String msisdn ,String company_name, String access_token,String app_id)
	 
	 {
	 
		 try
		 {
		 OkHttpClient client = new OkHttpClient().newBuilder()
				  .build();
				MediaType mediaType = MediaType.parse("application/json");
				RequestBody body = RequestBody.create(mediaType, "{\"companyName\": \""+company_name+"\",\"mobileNumber\": \""+msisdn+"\",\"applSource\": \"PA\",\"appId\": \""+app_id+"\",\"deviceType\":\"Whatsapp\",\"deviceSubType\": \"Whatsapp\",\"channel\": \"Whatsapp\"}");
				Request request = new Request.Builder()
				  .url(UAT_URL+"/DLPDelegator/professional/services/v0.1/getCompanyNames")
				  .method("POST", body)
				  .addHeader("Authorization", access_token)
				  .addHeader("Content-Type", "application/json")
				  .build();
				Response response = client.newCall(request).execute();
				String text=response.body().string();
				System.out.println("TEXT="+text);
				
				
				JSONObject jb = new JSONObject(text);
				String statusMessage=jb.getJSONObject("status").getString("statusMessage");
				if ( statusMessage.equals("SUCCESS"))
				{
					return jb.getJSONArray("companyNames");
				}
				/*
				 * 
    "status": {
        "statusCode": "200",
        "statusMessage": "SUCCESS"
    },
    "personalInfo": {
        "appId": "5013811"
    },
    "companyNames": [
        {
            "key": "79569",
            "value": "HDFC BANK CSE AND COEX ACCOUNTS",
            "category": "CATB"
        },
        {
            "key": "80919",
            "value": "HDFC BANK LTD.",
            "category": "SUPERCATA"
        },
        {
            "key": "81409",
            "value": "HOUSING DEVELOPMENT FINANCE CORPORATION Limited",
            "category": "SUPERCATA"
        },
        {
            "key": "116802",
            "value": "PT BANK MAYBANK INDONESIA TBK",
            "category": "SUPERCATA"
        },
        {
            "key": "89774",
            "value": "H D F C INVESTMENTS LTD.",
            "category": "CATC"
        },
        {
            "key": "116439",
            "value": "RELIGARE HOUSING DEVELOPMENT FINANCE CORPORATION LIMITED",
            "category": "CATB"
        },
        {
            "key": "118923",
            "value": "RELIGARE HOUSING DEVELOPMENT FINANCE CORPrivate Limited",
            "category": "CATB"
        },
        {
            "key": "106730",
            "value": "RELIGARE HOUSING DEVELOPMENT FINANCE CORPVT LTD",
            "category": "CATB"
        },
        {
            "key": "98904",
            "value": "SHUBHAM HOUSING DEVELOPMENT FINANCE COMPANY LIMITED",
            "category": "CATA"
        },
        {
            "key": "82387",
            "value": "HDFC SALES PRIVATE LIMITED",
            "category": "CATB"
        }
    ]
}
				 */
		 }
		 catch ( Exception ex)
		 {
			 
		 }
		 return null;
	 }
 
 
 public JSONObject editOffer(String msisdn,String app_id)
 {

	 JSONObject jbres=new JSONObject();
	 try
	 {
		 
	 OkHttpClient client = new OkHttpClient().newBuilder()
			 .connectTimeout(90, TimeUnit.SECONDS)
			 .readTimeout(90, TimeUnit.SECONDS)
			  .build();
			MediaType mediaType = MediaType.parse("application/json");
			RequestBody body = RequestBody.create(mediaType, "{\"mobileNumber\": \""+msisdn+"\",\"appId\": \""+app_id+"\", \"applSource\": \"PA\"}");
			Request request = new Request.Builder()
			  .url(UAT_URL+"DLPDelegator/authentication/mobile/v0.1/verifyOtp")
			  .method("POST", body)
			  .addHeader("Content-Type", "application/json")
			  .build();

			Response response = client.newCall(request).execute();
			String text=response.body().string();
			System.out.println("TEXT="+text);
	   
			JSONObject jb = new JSONObject(text);
			String statusMessage=jb.getJSONObject("status").getString("statusMessage");
			if ( statusMessage.equals("SUCCESS"))
			{
			//	return jb.getString("accessToken")+":"+jb.getJSONObject("personalInfo").getString("appId");
				jbres.put("result","success");
				jbres.put("accesstoken",jb.getString("accessToken"));
				jbres.put("personalinfo",jb.getJSONObject("personalInfo"));
				

				
				return jbres;
			}
			
			jbres.put("result","fail");
			return jbres;
	 }
	 catch ( Exception ex)
	 {
			jbres.put("result","fail");
			return jbres;
	 }
	 
	 
 }

 public JSONObject verifyOTP(String msisdn,String ref_id,String otp)
 {
	 JSONObject jbres=new JSONObject();
	 try
	 {
		 System.out.println(ref_id+":"+otp+":"+msisdn);
	 OkHttpClient client = new OkHttpClient().newBuilder()
			 .connectTimeout(90, TimeUnit.SECONDS)
			 .readTimeout(90, TimeUnit.SECONDS)
			  .build();
			MediaType mediaType = MediaType.parse("application/json");
			RequestBody body = RequestBody.create(mediaType, "{\"mobileNumber\": \""+msisdn+"\",\"refId\":\""+ref_id+"\",\"otp\": \""+otp+"\",\"applSource\": \"PL\",\"deviceOS\":\"Whatsapp\",\"deviceType\": \"Whatsapp\",\"deviceSubType\":\"Whatsapp\"}");
			Request request = new Request.Builder()
			  .url(UAT_URL+"DLPDelegator/authentication/mobile/v0.1/verifyOtp")
			  .method("POST", body)
			  .addHeader("Content-Type", "application/json")
			  
			  .build();

			Response response = client.newCall(request).execute();
			String text=response.body().string();
			System.out.println("TEXT="+text);
	   
			JSONObject jb = new JSONObject(text);
			String statusMessage=jb.getJSONObject("status").getString("statusMessage");
			if ( statusMessage.equals("SUCCESS"))
			{
			//	return jb.getString("accessToken")+":"+jb.getJSONObject("personalInfo").getString("appId");
				jbres.put("result","success");
				jbres.put("accesstoken",jb.getString("accessToken"));
				jbres.put("personalinfo",jb.getJSONObject("personalInfo"));
				

				
				return jbres;
			}
			
			jbres.put("result","fail");
			return jbres;
	 }
	 catch ( Exception ex)
	 {
			jbres.put("result","fail");
			return jbres;
	 }
	 
 }
 
 public String verifyPAN(String msisdn, String app_id, String access_token,String pan)
 {
	 try
	 {
	 OkHttpClient client = new OkHttpClient().newBuilder()
			 .connectTimeout(90, TimeUnit.SECONDS)
			 .readTimeout(90, TimeUnit.SECONDS)
			  .build();
			MediaType mediaType = MediaType.parse("application/json");
			RequestBody body = RequestBody.create(mediaType, "{\"mobileNumber\": \""+msisdn+"\",\""+pan+"\": \"\",\"applSource\":\"PA\",\"appId\":\""+app_id+"\",\"deviceOS\": \"Whatsapp\",\"deviceType\": \"Whatsapp\",\"deviceSubType\": \"Whatsapp\"}");
			Request request = new Request.Builder()
			  .url(UAT_URL+"DLPDelegator/offerpan/services/v0.1/validatePan")
			  .method("POST", body)
			  .addHeader("Authorization", access_token)
			  .addHeader("Content-Type", "application/json")
			  .build();
			Response response = client.newCall(request).execute();
			String text=response.body().string();

			System.out.println(text);
			
			return "success";
	 }
	 catch ( Exception ex)
	 {
		 return "fail";
	 }
 }
  public String sendOTP(String msisdn)
  {
	  try
	  {
	  OkHttpClient client = new OkHttpClient().newBuilder()
			  .connectTimeout(90, TimeUnit.SECONDS)
				 .readTimeout(90, TimeUnit.SECONDS)
			  .build();
			MediaType mediaType = MediaType.parse("application/json");
			RequestBody body = RequestBody.create(mediaType, "{\"mobileNumber\":\""+msisdn+"\",\"deviceOS\":\"Whatsapp\",\"applSource\":\"PA\",\"deviceType\":\"Whatsapp\",\"deviceSubType\":\"Whatsapp\"}");
			Request request = new Request.Builder()
			  .url(UAT_URL+"/DLPDelegator/authentication/mobile/v0.1/generateOtp")
			  .method("POST", body)
			  .addHeader("Content-Type", "application/json")
			  .build();
			
			Response response = client.newCall(request).execute();
			String text=response.body().string();
		
			JSONObject jb = new JSONObject(text);
			System.out.println("SMSTXTJSONXXXXXXXXXXXXXXXXXXXXXXXXXXXX="+jb.toString());
			String statusMessage=jb.getJSONObject("status").getString("statusMessage");
			if ( statusMessage.equals("SUCCESS"))
			{
				return jb.getString("refId");
			}
			return "fail";
			
	  }
	  catch ( Exception x)
	  {
		  return "fail";
		  
	  }
	  
  }

	public  String getResponseWhatsapp(String session_id,String json,String whatsapp_key)
	{
		
		System.out.println("SENDING .."+json);
		JSONObject jb=null;
		try
		{
		 jb = new JSONObject(json);
		 jb.put("messaging_product","whatsapp");
		}
		catch ( Exception ex)
		{
			ex.printStackTrace();
		}
		
		OkHttpClient client = new OkHttpClient();

		MediaType mediaType = MediaType.parse("application/json");
		RequestBody body = RequestBody.create(mediaType,jb.toString());
		Request request = new Request.Builder()
		 // .url("https://waba.360dialog.io/v1/messages")
        .url("https://graph.facebook.com/v13.0/"+PHONE_ID+"/messages")

		  .post(body)
		  .addHeader("content-type", "application/json")
		//  .addHeader("d360-api-key", whatsapp_key)
		  .addHeader("cache-control", "no-cache")
		//  .addHeader("Authorization","Bearer EAAdprOSjVZAcBAHhnGXpriIj0x8GJMZAAzlw4LsXOF8Dd7dYb4rIZCAIVatmpiN0VTIwVikimcF7r8XDGOvR9vLvDpcXA44UflJiSxrlCnN2HF0nctCfcfnT91ClAXfFfU1RMBPic1Miv4SxESXUWxP8VFGPS1dKYCgFleLFU6BDIHR9xrhaPah9b24anZBZB19ne7AFH3WDuLCfZBiAEW")
		  .addHeader("Authorization","Bearer "+whatsapp_key)

		  .build();
		try
		{

		Response response = client.newCall(request).execute();
		String resp=response.body().string();
		System.out.println("RESP="+resp);
		return resp;
		}
		catch ( Exception ex)
		{
			ex.printStackTrace();
			return "error";
		}
		
		
	  



	}


	public String  sendWhatsappMsg(String session_id, String json,String msisdn,String whatsapp_token,Connection conn)
	{
		try
		{
			
			String id="";
		
		String resp= getResponseWhatsapp(session_id, json,whatsapp_token);
		 JSONObject jb = new JSONObject(resp);
		    
		 return "success";
		  /*  JSONArray ids= jb.getJSONArray("messages");
			  if ( ids ==null || ids.length()==0)
			  {
				 
					String sql ="insert into whatsapp.outgoing_message_axis_log(session_id,msg,to_msisdn) values(?,?,?)";
					PreparedStatement ps = conn.prepareStatement(sql);
					ps.setString(1, session_id);
					ps.setString(2, json);
					ps.setString(3, msisdn);

					ps.executeUpdate();
				  return "error";
			  }
			  else
			  {
				  JSONObject jb1 = ids.getJSONObject(0);
				 
					   id= jb1.getString("id");
					 
						String sql ="insert into whatsapp.outgoing_message(session_id,msg,msg_id,to_msisdn) values(?,?,?,?)";
						PreparedStatement ps = conn.prepareStatement(sql);
						ps.setString(1, session_id);
						ps.setString(2, json);
						ps.setString(3, id);
						ps.setString(4, msisdn);


						ps.executeUpdate();
					   return resp;
				  
				
			  }*/
		}
		catch( Exception ex)
		{
			ex.printStackTrace();
			return "error";
		}
		
	}
	
	
	public String  sendWhatsappTemplateMsg(String session_id, String amount,String lan,String msisdn,String whatsapp_token,Connection conn)
	{
		try
		{
			
			String id="";
			String json="{"
					+ "	\"to\": \""+msisdn+"\",\n"
					+ "	\"type\": \"template\",\n"
					+ "	\"template\": {\n"
					+ "		\"namespace\":\"a216669b_75e4_463e_b253_311a018e333e\",\n"
					+ "    	\"name\": \"reminder_template2\",\n"
					+ "        \"language\": {\n"
					+ "    		\"policy\": \"deterministic\",\n"
					+ "    		\"code\": \"EN\"\n"
					+ "        },\n"
					+ "        \"components\": [{\n"
					+ "            \"type\": \"body\",\n"
					+ "            \"parameters\": [\n"
					+ "                {\n"
					+ "                    \"type\": \"text\",\n"
					+ "                    \"text\": \""+amount+"\"\n"
					+ "                },\n"
					+ "                 {\n"
					+ "                    \"type\": \"text\",\n"
					+ "                    \"text\": \""+lan+"\"\n"
					+ "                }\n"
					+ "                 \n"
					+ "            ]\n"
					+ "        }]\n"
					+ "	}\n"
					+ "}";
			
		
		String resp= getResponseWhatsapp(session_id, json,whatsapp_token);
		 JSONObject jb = new JSONObject(resp);
		/* {
			    "contacts": [
			        {
			            "input": "919741411087",
			            "wa_id": "919741411087"
			        }
			    ],
			    "messages": [
			        {
			            "id": "gBEGkZdBQRCHAgnooWiepw2TJFo"
			        }
			    ],
			    "meta": {
			        "api_status": "stable",
			        "version": "2.39.2"
			    }
			}*/
		 String msgid=jb.getJSONArray("messages").getJSONObject(0).getString("id");
		    
		 return msgid;
		  
		}
		catch( Exception ex)
		{
			ex.printStackTrace();
			return "error";
		}
		
	}

}
