import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.json.JSONObject;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class IncomingCallLog {
    public static void main(String[] args) {
       
        String apiUrl = "https://telephony-in21.leadsquared.com/1/api/Telephony/LogCallComplete/ORG75560/249dcaa6b3b201d2c94b960bffe1f33a7d/c9d6c260-dd21-437c-8690-801d1fab81e4";
        Connection conn1 = null;
        Connection conn2 = null;

        try {
            //Class.forName("com.mysql.jdbc.Driver");
            
            conn1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/smartivr_cloud", "oditata", "PowTata@987");
            
            conn2 = DriverManager.getConnection("jdbc:mysql://172.31.43.6:3306/smartivr_cloud", "reportnha", "India@456");
            
            String query = "SELECT id, incoming_number as SourceNumber, agent_id as DestinationNumber,  queue_no as DisplayNumber, IFNULL(start_call_date, NOW()) as StartTime, end_call_date as EndTime, IFNULL(duration, '0') as CallDuration,  IF(status = 'answered', 'Answered', IF(status = 'NA', 'fail', status)) AS Status, call_id as CallSessionId, record_file_name, start_call_date FROM incoming_call_log where account_id='191' and retry_missedcall_count = 0 and end_call_date != '2010-10-10 00:00:00' order by id desc limit 100";
                
            																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																									
                try (PreparedStatement preparedStatement = conn2.prepareStatement(query);
                    ResultSet resultSet = preparedStatement.executeQuery()) {
                	//System.out.println("TEST1"+query);
                    while (resultSet.next()) {
                    	//System.out.println("TEST");
                    	String fileName = resultSet.getString("record_file_name");
                    	String reqDateTime = resultSet.getString("start_call_date");
                    	SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    	Date date = inputFormat.parse(reqDateTime);
                    	SimpleDateFormat outputFormat = new SimpleDateFormat("yyyyMMdd");
                    	String dateFolder = outputFormat.format(date);
                    	String newFileName = "";
                    	if (fileName != null && !fileName.trim().isEmpty()) {
                    	    newFileName = fileName.replace(".wav", ".mp3");
                    	} else {
                    	    //System.out.println("Warning: Null or empty recording_file_name for ID: " + resultSet.getInt("id"));
                    		newFileName = "NA";
                    	}
                    	String baseUrl = "https://ikontel.123ivr.in/TPCLOUD/outgoing_direct_download.php?file=";
                    	String relativePath = "../smartreceiverv1/RECORDING/191/" + dateFolder + "/" + newFileName;
                    	String resourceUrl = baseUrl + relativePath;
                        JSONObject requestBody = new JSONObject();
                        requestBody.put("SourceNumber", resultSet.getString("SourceNumber"));
                        requestBody.put("DestinationNumber", resultSet.getString("DestinationNumber"));
                        requestBody.put("DisplayNumber", resultSet.getString("DisplayNumber"));
                        requestBody.put("CallDuration", resultSet.getString("CallDuration"));
                        requestBody.put("StartTime", resultSet.getString("StartTime"));
                        requestBody.put("EndTime", resultSet.getString("EndTime"));
                        requestBody.put("Status", resultSet.getString("Status"));
                        requestBody.put("CallNotes", "");
                        requestBody.put("ResourceURL", resourceUrl);
                        requestBody.put("Direction","Inbound");
                        requestBody.put("CallSessionId", resultSet.getString("CallSessionId"));
                        
                        String jsonInputString = requestBody.toString();
                        System.out.println("Input:" + jsonInputString);
                        int id = resultSet.getInt("id");
                        
                        OkHttpClient client = new OkHttpClient();
                        MediaType mediaType = MediaType.parse("application/json");
                        RequestBody body = RequestBody.create(mediaType, jsonInputString);
                        Request request = new Request.Builder()
                                .url(apiUrl)
                                .method("POST", body)
                                .addHeader("Content-Type", "application/json")
                                .build();

                        Response response = client.newCall(request).execute();
                        String responseBody = response.body().string();
                        System.out.println("Response:" + responseBody);

                        int code = response.code();
                        if (code == 200) {
                            JSONObject jsonResponse = new JSONObject(responseBody);
                            String status = jsonResponse.optString("Status", "");
                            String messageText = jsonResponse.optString("Message", "");

                            System.out.println("Status: " + status);
                            System.out.println("Message: " + messageText);

                            if ("Success".equalsIgnoreCase(status) && messageText.contains("Successfully")) {
                                System.out.println("✅ Success: setting retry_missedcall_count = 1 for ID " + id);
                                updateFlagTo1(conn1, id, 1, responseBody);
                            } else if (responseBody.contains("foreign key constraint fails") && responseBody.contains("RelatedProspectId")) {
                                System.out.println("⚠️ LeadId issue: setting retry_missedcall_count = 30 for ID " + id);
                                updateFlagTo1(conn1, id, 30, responseBody);
                            } else {
                                System.out.println("❌ Failure: setting retry_missedcall_count = 10 for ID " + id);
                                updateFlagTo1(conn1, id, 10, responseBody);
                            }
                        } else {
                            System.out.println("Error Response Code: " + code);
                            updateFlagTo1(conn1, id, 20, responseBody);
                            System.out.println("Error Response: " + responseBody);
                        }
                    }
                }
            
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (conn1 != null) {
                    conn1.close();
           }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try {
                if (conn2 != null) {
                    conn2.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    private static void updateFlagTo1(Connection connection, int id, int flag, String message) throws Exception {
        String updateQuery = "UPDATE incoming_call_log SET retry_missedcall_count = '"+flag+"' WHERE id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(updateQuery)) {
            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();
        }
    }
    
}