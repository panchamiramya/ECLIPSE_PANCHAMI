public class NumberToWordsConverter {

    private static final String[] ONES = {
        "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine",
        "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen",
        "Seventeen", "Eighteen", "Nineteen"
    };

    private static final String[] TENS = {
        "", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"
    };

    private static final String[] THOUSANDS = {
        "", "Thousand", "Million", "Billion"
    };

    public static String convert(int number) {
        if (number == 0) {
            return "Zero";
        }

        String word = "";
        int index = 0;

        while (number > 0) {
            if (number % 1000 != 0) {
                word = convertLessThanThousand(number % 1000) + THOUSANDS[index] + " " + word;
            }
            number /= 1000;
            index++;
        }

        return word.trim();
    }

    private static String convertLessThanThousand(int number) {
        String word;

        if (number % 100 < 20) {
            word = ONES[number % 100];
            number /= 100;
        } else {
            word = ONES[number % 10];
            number /= 10;

            word = TENS[number % 10] + " " + word;
            number /= 10;
        }
        if (number == 0) {
            return word;
        }
        return ONES[number] + " Hundred " + word;
    }

    public static void main(String[] args) {
        int number = 123456789;
        System.out.println(number + " in words: " + convert(number));
    }
}
