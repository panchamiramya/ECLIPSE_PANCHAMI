package smartcoin;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.http.HttpServlet;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.mysql.jdbc.exceptions.MySQLIntegrityConstraintViolationException;


import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Date;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LeadData extends HttpServlet {

	private static final long serialVersionUID = 1L;
	String currentDateTime = getCurrentTimeStamp();
	SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd HH:mm:SS");
	public static String getCurrentTimeStamp() {
		Date dateTime = new Date();
		String strDateFormat = "ddMMyyHHmmss";
		DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
		return dateFormat.format(dateTime);
	}

	public String getRecordId() {

		return currentDateTime + "-" + UUID.randomUUID().toString().toUpperCase();
	}
	public static String getCurrentDateTime() {
		Date dateTime = new Date();
		String strDateFormat = "yyyy-MM-dd HH:mm:ss";
		DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
		return dateFormat.format(dateTime);
	}

	public static String getCurrentDateFromString(String datetimeString) {
		String datetime = datetimeString;
		String[] datetimeArray = datetime.split("T");
		String date = datetimeArray[0];
		System.out.println(date);
		return date.toUpperCase();
	}

	public static String getCurrentDateTimeFromString(String datetimeString) {
		String datetime = datetimeString;
		String[] datetimeArray = datetime.split("T");
		String date = datetimeArray[0];
		String[] timeArray = datetimeArray[1].split(":");
		String time = timeArray[0] + ":" + timeArray[1] + ":" + timeArray[2].substring(0, 2);
		System.out.println(date + " " + time);
		return date + " " + time;
	}

	public static boolean checkPattern(String dateTimeString) {
		try {
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:SS");
			format.parse(dateTimeString);
			return true;
		} catch (ParseException e) {
			return false;
		}
	}

	public static boolean checkDatePattern(String dateTimeString) {
		try {
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			format.parse(dateTimeString);
			return true;
		} catch (ParseException e) {
			return false;
		}
	}
	
	public boolean isValidDateFormat(String dateString) {
        if(dateString==null) {
            return true;
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        try {
            LocalDate.parse(dateString, formatter);
            return true; 
        } catch (DateTimeParseException e) {
            return false; 
        }
    }
	
	public boolean validateJsonPattern(String jsonString) {
        Pattern pattern = Pattern.compile("[<>#^*]");
        Matcher matcher = pattern.matcher(jsonString);
        return !matcher.find();
    }
	
	public String processData(String authtoken, String campaignName, String isagentwise, String leadData, Connection conn) {

		try {
			if (leadData == null || leadData.trim().isEmpty()) {
				log(conn,"Empty JSON data.");
				return "{\"result\": {\"status\": {\"statusCode\": 100, \"status\": \"error\", \"message\": \"Empty JSON data.\"}}}";
			}

			JSONParser parser = new JSONParser();
			JSONObject jsonData = (JSONObject) parser.parse(leadData);
			System.out.println("Parsed JSON Data: " + jsonData.toString());

			String authTokenFromRequest = (String) jsonData.get("authtoken");
			String campaignNameFromRequest = (String) jsonData.get("campaign_name");
			JSONArray leadsArray = (JSONArray) jsonData.get("leads");
			
			
			
			if (!authtoken.equals(authTokenFromRequest) || !campaignName.equals(campaignNameFromRequest)) {
				log(conn,"Invalid authtoken or campaign_name.");
				return "{\"result\": {\"status\": {\"statusCode\": 101, \"status\": \"error\", \"message\": \"Invalid authtoken or campaign_name.\"}}}";
			}
			checkForTableOrCreate(conn,campaignName);

			for (Object leadObject : leadsArray) {
				JSONObject lead = (JSONObject) leadObject;

				String recordId=getRecordId();
				String msisdn = (lead.containsKey("msisdn")) ? (String) lead.get("msisdn") : null;
				String disbursed_date = (lead.containsKey("disbursed_date")) ? (String) lead.get("disbursed_date") : null;
				String crn = (lead.containsKey("crn")) ? (String) lead.get("crn") : null;
				String last_payment_date = (lead.containsKey("last_payment_date")) ? (String) lead.get("last_payment_date") : null;
				
				
				if(!validateJsonPattern(lead.toString())){
					log(conn,lead,"Invalid character JSON data.");
					System.err.println("{\"result\": {\"status\": {\"statusCode\": 102, \"status\": \"error\", \"message\": \"Invalid character JSON data.\"}}}");
					continue;
				}
				
				if (msisdn == null || msisdn.trim().isEmpty() || !msisdn.matches("\\d{10}")) {
					log(conn,lead,"Invalid msisdn field");
					System.err.println("{\"result\": {\"status\": {\"statusCode\": 106, \"status\": \"error\", \"message\": \"Invalid msisdn field.\"}}}");
					continue;
				}
				
				if (crn == null || crn.trim().isEmpty()) {
					log(conn,lead,"Invalid crn field");
					System.err.println("{\"result\": {\"status\": {\"statusCode\": 106, \"status\": \"error\", \"message\": \"Invalid crn field.\"}}}");
					continue;
				}
				if (!(isValidDateFormat(disbursed_date)&&isValidDateFormat(last_payment_date))) {
					
					log(conn,lead,"Invalid date format field");
					System.err.println("{\"result\": {\"status\": {\"statusCode\": 106, \"status\": \"error\", \"message\": \"Invalid date format field.\"}}}");
					continue;
				}
				if(isagentwise.equals("yes") && ((!lead.containsKey("agent_id")) || ((String) lead.get("agent_id")).equals(null) || ((String) lead.get("agent_id")).equals(""))) {
					System.out.println("Empty agent id for msisdn"+(String) lead.get("msisdn"));
					log(conn,lead,"Agent Id is missing.");
					System.err.println("{\"result\": {\"status\": {\"statusCode\": 107, \"status\": \"error\", \"message\": \"Agent Id is missing.\"}}}");
					continue;
				}else {
					insertLeadIntoDatabase(lead, conn, recordId, campaignName);
					insertLeadIntoAccountOutboundTable(lead, conn, recordId, campaignName);
				}
			}
			return "{\"result\": {\"status\": {\"statusCode\": 0, \"status\": \"success\", \"message\": \"Leads inserted successfully.\"}}}";
		} catch (Exception e) {
			e.printStackTrace();
			log(conn,"Invalid JSON data.");
			return "{\"result\": {\"status\": {\"statusCode\": 102, \"status\": \"error\", \"message\": \"Invalid JSON data.\"}}}";
		}
	}
	
	//log function overloading
	private void log(Connection conn, JSONObject lead, String msg) {
		try {
			PreparedStatement ps_log = conn.prepareStatement("INSERT INTO api_log (list_id, crn, uid, msisdn, created_on, message) VALUES (?, ?, ?, ?, ?, ?)");
			ps_log.setString(1, (lead.containsKey("list_id")) ? (String) lead.get("list_id") : null);
			ps_log.setString(2, (lead.containsKey("crn")) ? (String) lead.get("crn") : null);
			ps_log.setString(3, (lead.containsKey("uid")) ? (String) lead.get("uid") : null);
			ps_log.setString(4, (lead.containsKey("msisdn")) ? (String) lead.get("msisdn") : null);
			ps_log.setString(5, getCurrentDateAndTime());
			ps_log.setString(6, msg);
			ps_log.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	private void log(Connection conn, String msg) {
		try {
			PreparedStatement ps_log = conn.prepareStatement("INSERT INTO api_log (list_id, crn, uid, msisdn, created_on, message) VALUES (?, ?, ?, ?, ?, ?)");
			ps_log.setString(1,  null);
			ps_log.setString(2,  null);
			ps_log.setString(3,  null);
			ps_log.setString(4,  null);
			ps_log.setString(5, getCurrentDateAndTime());
			ps_log.setString(6, msg);
			ps_log.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	private void checkForTableOrCreate(Connection conn, String campaignName) {
        try {
            String tableName = campaignName + "_tab";
            String checkTableQuery = "SELECT COUNT(*) AS tableCount FROM information_schema.tables WHERE table_schema = ? AND table_name = ?";
            try (PreparedStatement checkTableStatement = conn.prepareStatement(checkTableQuery)) {
                checkTableStatement.setString(1, conn.getCatalog()); // Get current database name
                checkTableStatement.setString(2, tableName);
                try (ResultSet resultSet = checkTableStatement.executeQuery()) {
                    if (resultSet.next()) {
                        int tableCount = resultSet.getInt("tableCount");
                        if (tableCount == 0) {
                            createTable(conn, campaignName);
                        }
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

	private String getCurrentDate() {
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		return now.format(formatter);
	}

	private String getCurrentDateAndTime() {
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		return now.format(formatter);
	}

	private void createTable(Connection conn, String campaignName) {
		String insertQuery = "INSERT INTO campaign_status (account_id, campaign_name, start_date, end_date, " +
				"status, created_on, modified_on, call_type, url_type, campaign_call_max_limit, group_name, " +
				"isagentwise, is_predictive) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		try (PreparedStatement preparedStatement = conn.prepareStatement(insertQuery)) {
			preparedStatement.setString(1, "116");
			preparedStatement.setString(2, campaignName);
			preparedStatement.setString(3, getCurrentDate());
			preparedStatement.setString(4, getCurrentDate());
			preparedStatement.setString(5, "running");
			preparedStatement.setString(6, getCurrentDateAndTime());
			preparedStatement.setString(7, getCurrentDateAndTime());
			preparedStatement.setString(8, "outbound");
			preparedStatement.setString(9, "external");
			preparedStatement.setString(10, "100");
			preparedStatement.setString(11, "incoming");
			preparedStatement.setString(12, "yes");
			preparedStatement.setString(13, "no");

			preparedStatement.executeUpdate();
			System.out.println("Data inserted successfully!");
		}

		catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			String createTableQuery = "CREATE TABLE " + campaignName + "_tab ("
					+ "id int(11) NOT NULL AUTO_INCREMENT,"
					+ "customer_name varchar(255) COLLATE utf8_unicode_ci NOT NULL,"
					+ "msisdn varchar(255) COLLATE utf8_unicode_ci NOT NULL,"
					+ "mailingphone2 varchar(255) COLLATE utf8_unicode_ci DEFAULT '0',"
					+ "list_id varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,"
					+ "crn varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,"
					+ "uid varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,"
					+ "state varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,"
					+ "address varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,"
					+ "language varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,"
					+ "title varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,"
					+ "loan_details varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,"
					+ "bounce_charge varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,"
					+ "payment_details varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,"
					+ "payment_deadline varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,"
					+ "extension_deadline varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,"
					+ "pos_value varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,"
					+ "disbursed_date varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,"
					+ "lender_name varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,"
					+ "last_payment_date varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,"
					+ "last_call_log varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,"
					+ "admin_link varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,"
					+ "agent_id varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,"
					+ "recording_file_name varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,"
					+ "duration varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,"
					+ "next_call varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,"
					+ "record_status varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,"
					+ "phase varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,"
					+ "record_id varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,"
					+ "file_name varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,"
					+ "modified_by varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,"
					+ "modified_on timestamp NULL DEFAULT NULL,"
					+ "campaign_name varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,"
					+ "created_on timestamp NOT NULL DEFAULT current_timestamp(),"
					+ "inserted_by varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,"
					+ "disposition varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,"
					+ "system_disposition varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,"
					+ "remarks text COLLATE utf8_unicode_ci DEFAULT NULL,"
					+ "PRIMARY KEY (id),"
					+ "KEY idx_msisdn (msisdn),"
					+ "KEY idx_reordid (record_id),"
					+ "KEY idx_modified_on (modified_on)"
					+ ") ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci";

			try (PreparedStatement createTableStatement = conn.prepareStatement(createTableQuery)) {
				createTableStatement.executeUpdate();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}


	private void insertLeadIntoDatabase(JSONObject lead, Connection conn, String recordId, String campaignName) {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			PreparedStatement ps = conn.prepareStatement("INSERT INTO "+campaignName+"_tab (customer_name, msisdn, mailingphone2, list_id, crn, uid, state, address, language, title, loan_details, bounce_charge, payment_details, payment_deadline, extension_deadline, pos_value, disbursed_date, lender_name, last_payment_date, last_call_log, admin_link, agent_id, record_status, record_id, campaign_name, created_on) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, now())");

			System.out.println(ps);
			ps.setString(1, (lead.containsKey("customer_name")) ? (String) lead.get("customer_name") : null);
			ps.setString(2, (lead.containsKey("msisdn")) ? (String) lead.get("msisdn") : null);
			ps.setString(3, (lead.containsKey("mailingphone2")) ? (String) lead.get("mailingphone2") : null);
			ps.setString(4, (lead.containsKey("list_id")) ? (String) lead.get("list_id") : null);
			ps.setString(5, (lead.containsKey("crn")) ? (String) lead.get("crn") : null);
			ps.setString(6, (lead.containsKey("uid")) ? (String) lead.get("uid") : null);
			ps.setString(7, (lead.containsKey("state")) ? (String) lead.get("state") : null);
			ps.setString(8, (lead.containsKey("address")) ? (String) lead.get("address") : null);
			ps.setString(9, (lead.containsKey("language")) ? (String) lead.get("language") : null);
			ps.setString(10, (lead.containsKey("title")) ? (String) lead.get("title") : null);
			ps.setString(11, (lead.containsKey("loan_details")) ? (String) lead.get("loan_details") : null);
			ps.setString(12, (lead.containsKey("bounce_charge")) ? (String) lead.get("bounce_charge") : null);
			ps.setString(13, (lead.containsKey("payment_details")) ? (String) lead.get("payment_details") : null);
			ps.setString(14, (lead.containsKey("payment_deadline")) ? (String) lead.get("payment_deadline") : null);
			ps.setString(15, (lead.containsKey("extension_deadline")) ? (String) lead.get("extension_deadline") : null);
			ps.setString(16, (lead.containsKey("pos_value")) ? (String) lead.get("pos_value") : null);
			ps.setString(17, (lead.containsKey("disbursed_date")) ? (String) lead.get("disbursed_date") : null);
			ps.setString(18, (lead.containsKey("lender_name")) ? (String) lead.get("lender_name") : null);
			ps.setString(19, (lead.containsKey("last_payment_date")) ? (String) lead.get("last_payment_date") : null);
			ps.setString(20, (lead.containsKey("last_call_log")) ? (String) lead.get("last_call_log") : null);
			ps.setString(21, (lead.containsKey("admin_link")) ? (String) lead.get("admin_link") : null);
			ps.setString(22, (lead.containsKey("agent_id")) ? (String) lead.get("agent_id") : null);
			ps.setString(23, "active");
			ps.setString(24, recordId);
			ps.setString(25, campaignName);
			//ps.setString(26, created_on);

			ps.executeUpdate();
		} catch (MySQLIntegrityConstraintViolationException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void insertLeadIntoAccountOutboundTable(JSONObject lead, Connection conn, String recordId, String campaignName) {
	    try {
	        String insertQuery = "INSERT INTO account_outbound (msisdn, record_id, record_status, campaign_name, account_id, server_id) VALUES (?, ?, ?, ?, '116', 'bng_pred')";
	        try (PreparedStatement ps = conn.prepareStatement(insertQuery)) {
	            ps.setString(1, (lead.containsKey("msisdn")) ? (String) lead.get("msisdn") : null);
	            ps.setString(2, recordId);
	            ps.setString(3, "active");
	            ps.setString(4, campaignName);
	            int rowsAffected = ps.executeUpdate();
	            if (rowsAffected > 0) {
	                System.out.println("Lead inserted into account_outbound table successfully.");
	            } else {
	                System.out.println("Lead insertion into account_outbound table failed.");
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

}
