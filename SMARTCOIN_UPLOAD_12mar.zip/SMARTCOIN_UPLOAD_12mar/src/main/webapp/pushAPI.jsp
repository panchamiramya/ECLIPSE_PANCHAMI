<%@ page import="java.io.OutputStream" %>
<%@ page import="java.io.OutputStreamWriter" %>
<%@ page import="java.io.BufferedReader" %>
<%@ page import="java.io.InputStreamReader" %>
<%@ page import="java.net.HttpURLConnection" %>
<%@ page import="java.net.URL" %>
<%@ page import="java.nio.charset.StandardCharsets" %>
<%@ page import="java.sql.Connection" %>
<%@ page import="java.sql.DriverManager" %>
<%@ page import="java.sql.PreparedStatement" %>
<%@ page import="java.sql.ResultSet" %>
<%@ page import="org.json.JSONObject" %>

<%
    String accessToken = "f702b6c6-9a20-419b-b89b-7c799ee9094d";
    String agencyName = "ikontel";
    String apiUrl = "https://qa115-admin.rebase.in/bot_api/pushcalldata";

    String dbUrl = "jdbc:mysql://localhost:3306/smartcoin";
    String dbUser = "root";
    String dbPassword = "";

    try {
        Class.forName("com.mysql.jdbc.Driver");
        Connection dbConnection = DriverManager.getConnection(dbUrl, dbUser, dbPassword);

        String crn = "";  

        String query = "SELECT crn, customer_msisdn as phone, disposition, remarks as remark, recording_file_name as call_recording_mapping, created_on as callDate, agent_id as agent FROM customer_info_call_history WHERE crn=?";
        System.out.println(query);
        try (PreparedStatement preparedStatement = dbConnection.prepareStatement(query)) {
            preparedStatement.setString(1, crn);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                JSONObject requestBody = new JSONObject();

                if (resultSet.next()) {
                    requestBody.put("crn", resultSet.getString("crn"));
                    requestBody.put("phone", resultSet.getString("phone"));
                    requestBody.put("disposition", resultSet.getString("disposition"));
                    requestBody.put("remark", resultSet.getString("remark"));
                    requestBody.put("ptpdate", resultSet.getString("ptpdate"));
                    requestBody.put("call_recording_mapping", resultSet.getString("call_recording_mapping"));
                    requestBody.put("callDate", resultSet.getString("callDate"));
                    requestBody.put("agent", resultSet.getString("agent"));
                }

                String jsonInputString = requestBody.toString();

                URL url = new URL(apiUrl);

                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();

                httpURLConnection.setRequestMethod("POST");

                httpURLConnection.setRequestProperty("Authorization", "Bearer " + accessToken);
                httpURLConnection.setRequestProperty("agency_name", agencyName);
                httpURLConnection.setRequestProperty("Content-Type", "application/json");

                httpURLConnection.setDoOutput(true);

                try (OutputStream os = httpURLConnection.getOutputStream();
                     OutputStreamWriter osw = new OutputStreamWriter(os, StandardCharsets.UTF_8)) {
                    osw.write(jsonInputString);
                    osw.flush();
                }

                int responseCode = httpURLConnection.getResponseCode();

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    try (BufferedReader br = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()))) {
                        StringBuilder responseContent = new StringBuilder();
                        String line;
                        while ((line = br.readLine()) != null) {
                            responseContent.append(line);
                        }

                        JSONObject jsonResponse = new JSONObject(responseContent.toString());

                        String message = jsonResponse.getString("message");
                        boolean isTokenValid = jsonResponse.getBoolean("is_token_valid");
                        int validityInSecs = jsonResponse.getInt("validity_in_secs");

                        out.println("Message: " + message);
                        out.println("Is Token Valid: " + isTokenValid);
                        out.println("Validity in Seconds: " + validityInSecs);
                    }
                } else {
                    try (BufferedReader br = new BufferedReader(new InputStreamReader(httpURLConnection.getErrorStream()))) {
                        StringBuilder errorContent = new StringBuilder();
                        String line;
                        while ((line = br.readLine()) != null) {
                            errorContent.append(line);
                        }

                        out.println("Error Response: " + errorContent.toString());
                    }
                }

                httpURLConnection.disconnect();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
%>
