import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;

public class HTTPRequest {
  public static String getResponse(String url) {
    String res = "";
    BufferedReader in = null;
    OutputStream out = null;
    Writer wout = null;
    try {
      URL url1 = new URL(url);
      System.out.println("url=" + url);
      URLConnection connection = url1.openConnection();
      HttpURLConnection httpConn = (HttpURLConnection)connection;
      httpConn.setReadTimeout(50000);
      httpConn.setConnectTimeout(50000);
      httpConn.setRequestProperty("Accept", "text/html");
      httpConn.setRequestProperty("Content-Type", "text/html");
      httpConn.setRequestMethod("POST");
      httpConn.setDoInput(true);
      httpConn.setDoOutput(true);
      OutputStream out1 = httpConn.getOutputStream();
      out1.write("".getBytes());
      System.out.println("code=" + httpConn.getResponseCode());
      if (httpConn.getResponseCode() == 200) {
        InputStreamReader isr = new InputStreamReader(httpConn.getInputStream());
        in = new BufferedReader(isr);
        String temp = "";
        res = "";
        while ((temp = in.readLine()) != null)
          res = String.valueOf(res) + temp; 
        System.out.println("res_ok=" + res);
      } else {
        InputStreamReader isr = new InputStreamReader(httpConn.getErrorStream());
        in = new BufferedReader(isr);
        String temp = "";
        res = "";
        while ((temp = in.readLine()) != null)
          res = String.valueOf(res) + temp; 
        System.out.println("res_err=" + res);
      } 
    } catch (Exception ex) {
      ex.printStackTrace();
      return "servererror";
    } finally {
      try {
        in.close();
        wout.close();
        out.close();
      } catch (Exception exception) {}
    } 
    String decoderes = "";
    try {
      decoderes = URLDecoder.decode(res, "utf8");
      System.out.println("decoderes" + decoderes);
    } catch (Exception ex) {
      ex.printStackTrace();
    } 
    return decoderes;
  }
}
