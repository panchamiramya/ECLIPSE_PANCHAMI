import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;

public class MainMIS {
  public static void main(String[] args) {
    String sql = "";
    Connection conn = null;
    try {
      Class.forName("com.mysql.jdbc.Driver").newInstance();
      conn = DriverManager.getConnection("jdbc:mysql://localhost/farmer_registration_fdd_sumitomo", "root", "");
      Statement st = conn.createStatement();
      Statement st1 = conn.createStatement();
      sql = "select staff_msisdn,staff_name from staff_detail where staff_name is not null";
      ResultSet rs = st.executeQuery(sql);
      ResultSet rs1 = null;
      String msisdn = "";
      String sql1 = "";
      String resp = "";
      String sms_msg = "";
      String staff_name = "";
      int achieved = 0;
      int achieved_month = 0;
      System.out.println("Daily MIS for staff");
      while (rs.next()) {
        msisdn = rs.getString("staff_msisdn");
        staff_name = rs.getString("staff_name");
        sql1 = "select count(distinct(farmer_msisdn)) as achieved  from miscall_unique where staff_msisdn='" + msisdn + "' and date( miscall_time)= date(now() )";
        rs1 = st1.executeQuery(sql1);
        if (rs1.next())
          achieved = rs1.getInt("achieved"); 
        sql1 = "select count(distinct(farmer_msisdn)) as achieved  from miscall_unique where staff_msisdn='" + msisdn + "' and month( miscall_time)= month(now() )";
        rs1 = st1.executeQuery(sql1);
        if (rs1.next())
          achieved_month = rs1.getInt("achieved"); 
        sql1 = "SELECT DATE_FORMAT(now(), '%d-%m-%Y %h:%i:%s') as mydate";
        String mydate = "";
        rs1 = st1.executeQuery(sql1);
        if (rs1.next())
          mydate = rs1.getString("mydate"); 
        //Dear Sir, You have registered {#var#} farmers today and {#var#} for the month till today. Thank You! IPL Biologicals Limited
        sms_msg = "Yours farmer miscalls count is " + achieved_month + " , total miscalls count for today " + achieved + ".Sumitomo";
        String url = "http://msg2all.com/TRANSAPI/sendsms.jsp?login=sumitomofdd&passwd=sumitomo%40321&version=v1.0&msg_type=text&msisdn=" + msisdn + "&sender_id=SUMIHO" + "&msg=" + URLEncoder.encode(sms_msg, "utf8");
        Date dt = new Date();
        System.out.println(dt.toString());
        System.out.println(url);
        if (args[1].equals("yesy"))
          resp = HTTPRequest.getResponse(url); 
        System.out.println("RESP=" + resp);
      } 
    } catch (Exception ex) {
      ex.printStackTrace();
    } 
  }
}
