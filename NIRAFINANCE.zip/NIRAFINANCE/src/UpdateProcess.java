import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.StringWriter;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

//import org.apache.commons.codec.binary.Base64;


public class UpdateProcess {
	
	
	
	
	public static void main(String[] args) throws Exception
	  {
		String lan = "";  
		String id="";
		try
		{

			 Class.forName("com.mysql.jdbc.Driver");
			 Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/campaign_cloud","root","");
			 Statement st = conn.createStatement();
			
			 String sql = "select * from paid_dump where account_id = '130' and flag = 0 limit 100";	
			 
			 System.out.println("SQL="+sql);
			 ResultSet rs=st.executeQuery(sql);
				
			 try
			 {
				 Statement st2 = conn.createStatement();Statement st3 = conn.createStatement();
				 while(rs.next())
				 {	
					 lan = rs.getString("lan");
					 id=rs.getString("id");
			  
					 String sql_updte = "UPDATE account_outbound SET record_status = 'finished', disposition = 'dnc', system_disposition = 'system' WHERE record_status='active' and lan='"+lan+"'";
					 st3.executeUpdate(sql_updte);
					 st2.executeUpdate("update paid_dump set flag=2 where id='"+id+"'");
					 
	         	}

		 	}
		 catch ( Exception ex)
		 {
			 ex.printStackTrace();
			 System.exit(-1);
		 }
			
		 System.exit(-1);
				 
				
	}
	catch ( Exception ex)
	{
		ex.printStackTrace();
	}
 }
				
}
