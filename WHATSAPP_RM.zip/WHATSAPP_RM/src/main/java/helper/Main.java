package helper;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WhatsAppMessage wa = new WhatsAppMessage();
		wa.sendMessage("12122", "919741411087", "this is\n"
				+ "sanjit", "GadP7ihb8nqVSQRrs2gXXulBAK", null);

	}

}
