package helper;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Writer;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.UUID;

import javax.net.ssl.HttpsURLConnection;

import org.json.JSONArray;
import org.json.JSONObject;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class WhatsAppMessage {
	
	public boolean isEmoji(String message){
	    return message.matches("(?:[\uD83C\uDF00-\uD83D\uDDFF]|[\uD83E\uDD00-\uD83E\uDDFF]|" +
	            "[\uD83D\uDE00-\uD83D\uDE4F]|[\uD83D\uDE80-\uD83D\uDEFF]|" +
	            "[\u2600-\u26FF]\uFE0F?|[\u2700-\u27BF]\uFE0F?|\u24C2\uFE0F?|" +
	            "[\uD83C\uDDE6-\uD83C\uDDFF]{1,2}|" +
	            "[\uD83C\uDD70\uD83C\uDD71\uD83C\uDD7E\uD83C\uDD7F\uD83C\uDD8E\uD83C\uDD91-\uD83C\uDD9A]\uFE0F?|" +
	            "[\u0023\u002A\u0030-\u0039]\uFE0F?\u20E3|[\u2194-\u2199\u21A9-\u21AA]\uFE0F?|[\u2B05-\u2B07\u2B1B\u2B1C\u2B50\u2B55]\uFE0F?|" +
	            "[\u2934\u2935]\uFE0F?|[\u3030\u303D]\uFE0F?|[\u3297\u3299]\uFE0F?|" +
	            "[\uD83C\uDE01\uD83C\uDE02\uD83C\uDE1A\uD83C\uDE2F\uD83C\uDE32-\uD83C\uDE3A\uD83C\uDE50\uD83C\uDE51]\uFE0F?|" +
	            "[\u203C\u2049]\uFE0F?|[\u25AA\u25AB\u25B6\u25C0\u25FB-\u25FE]\uFE0F?|" +
	            "[\u00A9\u00AE]\uFE0F?|[\u2122\u2139]\uFE0F?|\uD83C\uDC04\uFE0F?|\uD83C\uDCCF\uFE0F?|" +
	            "[\u231A\u231B\u2328\u23CF\u23E9-\u23F3\u23F8-\u23FA]\uFE0F?)+");
	}
	
	
	public int detectEmojis(String message){
		    int len = message.length(), NumEmoji = 0;
		    // if the the given String is only emojis.
		    if(isEmoji(message)){
		        for (int i = 0; i < len; i++) {
		            // if the charAt(i) is an emoji by it self -> ++NumEmoji
		            if (isEmoji(message.charAt(i)+"")) {
		                NumEmoji++;
		            } else {
		                // maybe the emoji is of size 2 - so lets check.
		                if (i < (len - 1)) { // some Emojis are two characters long in java, e.g. a rocket emoji is "\uD83D\uDE80";
		                    if (Character.isSurrogatePair(message.charAt(i), message.charAt(i + 1))) {
		                        i += 1; //also skip the second character of the emoji
		                        NumEmoji++;
		                    }
		                }
		            }
		        }
		        return NumEmoji;
		    }
		    return 0;
		}
	 
	 
	
	public String sendMessage(String session_id,String msisdn, String msg,String whatsapp_token,String account_id,Connection conn)
	{
		 
			  String contact_id=msisdn;
			  String msg1=org.json.simple.JSONValue.escape(msg);

			  
	      String json="{\n"
	      		+ "  \"recipient_type\": \"individual\",\n"
	      		+ "   \"type\": \"text\",\n"
	      		+ "  \"to\": \""+contact_id+"\",\n"
	      		+ "\"text\": {\n"
	      		+ "    \"body\": \""+msg1+"\"\n"
	      		+ "  }\n"
	      		+ "  \n"
	      		+ "  \n"
	      		+ "  \n"
	      		+ " \n"
	      		+ "  \n"
	      		+ "}";
	    
	      return sendWhatsappMsg(session_id, json,msisdn,whatsapp_token,account_id,conn);
	  }
	
	
	public String markRead(String whatsapp_key,String msg_id,Connection conn)
	{
		String url="https://waba.360dialog.io/v1/messages";
		//   OutputStream out=null;
		    try {
		           URL url1 = new URL(url);
		          
		/* 50 */       URLConnection connection = url1.openConnection();
		/* 51 */       HttpsURLConnection httpConn = ((HttpsURLConnection)connection);
		/* 52 */       httpConn.setReadTimeout(20000);
		/* 53 */       httpConn.setConnectTimeout(20000);
		/* 55 */       httpConn.setRequestProperty("d360-api-key", whatsapp_key);
		/* 55 */       httpConn.setRequestProperty("cache-control", "no-cache");
		httpConn.setRequestMethod("PUT");
		Statement st=conn.createStatement();
		String sql="update whatsapp.incoming_message set msg_status='read' where msg_id='"+msg_id+"'";
		st.executeUpdate(sql);
		
		// InputStreamReader isr = new InputStreamReader(httpConn.getInputStream());
		 
		    }
		    catch ( Exception ex)
		    {
		    	ex.printStackTrace();
		    }
		    return "";
		            
		
	}

	public  String getResponseWhatsapp(String session_id,String json,String whatsapp_key,String account_id,Connection conn)
	{
	    
		System.out.println("SENDING .."+json);
		JSONObject jb=null;
		try
		{
		 jb = new JSONObject(json);
		 jb.put("messaging_product","whatsapp");
		}
		catch ( Exception ex)
		{
			ex.printStackTrace();
		}
		
		String whatsapp_token="";
		String phoneid="";

		String sql="select whatsapp_key,phoneid from account_info where account_id='"+account_id+"'";
		try
		{
		Statement st =conn.createStatement();
		ResultSet rs=st.executeQuery(sql);
		if ( rs.next())
		{
			whatsapp_token=rs.getString("whatsapp_key");
			phoneid=rs.getString("phoneid");

		}
		}
		catch ( Exception e)
		{
			
		}
		
		OkHttpClient client = new OkHttpClient();

		MediaType mediaType = MediaType.parse("application/json");
		RequestBody body = RequestBody.create(mediaType,jb.toString());
		Request request = new Request.Builder()
		 // .url("https://waba.360dialog.io/v1/messages")
        .url("https://graph.facebook.com/v13.0/"+phoneid+"/messages")

		  .post(body)
		  .addHeader("content-type", "application/json")
		//  .addHeader("d360-api-key", whatsapp_key)
		  .addHeader("cache-control", "no-cache")
		//  .addHeader("Authorization","Bearer EAAdprOSjVZAcBAHhnGXpriIj0x8GJMZAAzlw4LsXOF8Dd7dYb4rIZCAIVatmpiN0VTIwVikimcF7r8XDGOvR9vLvDpcXA44UflJiSxrlCnN2HF0nctCfcfnT91ClAXfFfU1RMBPic1Miv4SxESXUWxP8VFGPS1dKYCgFleLFU6BDIHR9xrhaPah9b24anZBZB19ne7AFH3WDuLCfZBiAEW")
		  .addHeader("Authorization","Bearer "+whatsapp_key)

		  .build();
		try
		{

		Response response = client.newCall(request).execute();
		String resp=response.body().string();
		System.out.println("RESP="+resp);
		return resp;
		}
		catch ( Exception ex)
		{
			ex.printStackTrace();
			return "error";
		}
		


	}


	public String  sendWhatsappMsg(String session_id, String json,String msisdn,String whatsapp_token,String account_id,Connection conn)
	{
		try
		{
			
			String id="";
		
		String resp= getResponseWhatsapp(session_id, json,whatsapp_token,account_id,conn);
		 JSONObject jb = new JSONObject(resp);
		    
		    JSONArray ids= jb.getJSONArray("messages");
			  if ( ids ==null || ids.length()==0)
			  {
				 
					String sql ="insert into whatsapp.outgoing_message(session_id,msg,to_msisdn) values(?,?,?)";
					PreparedStatement ps = conn.prepareStatement(sql);
					ps.setString(1, session_id);
					ps.setString(2, json);
					ps.setString(3, msisdn);

					ps.executeUpdate();
				  return "error";
			  }
			  else
			  {
				  JSONObject jb1 = ids.getJSONObject(0);
				 
					   id= jb1.getString("id");
					 
						String sql ="insert into whatsapp.outgoing_message(session_id,msg,msg_id,to_msisdn) values(?,?,?,?)";
						PreparedStatement ps = conn.prepareStatement(sql);
						ps.setString(1, session_id);
						ps.setString(2, json);
						ps.setString(3, id);
						ps.setString(4, msisdn);


						ps.executeUpdate();
					   return resp;
				  
				
			  }
		}
		catch( Exception ex)
		{
			ex.printStackTrace();
			return "error";
		}
		
	}

	public void updateCallBackURL(String msg_id,String status,String msisdn, String remark)
    {
    	try
    	{
    	String url="https://connect.123ivr.in/whatsapp_upload/saveStatus.php?msg_id="+URLEncoder.encode(msg_id,"utf8")+"&msisdn="+msisdn+"&status="+status+"&remark="+URLEncoder.encode(remark,"utf8");
    	 String resp=HTTPRequest.getResponse(url);
    	}
    	catch ( Exception ex)
    	{
    		ex.printStackTrace();
    	}
    }
	
	public String  sendWhatsappJSONMsg(String msisdn,String json,String account_id,Connection conn,String session_id)
	{

		System.out.println("msisdn ="+ msisdn+"json ="+json+"account_id="+account_id+"session_id ="+session_id);
		try
		{

			String uuid=UUID.randomUUID().toString();
			String sqlinsert="insert into outgoing_whatsapp_log(to_msisdn,message,account_id,session_id,uuid,wp_type) values(?,?,?,?,?,?)";
			PreparedStatement ps=conn.prepareStatement(sqlinsert);
			ps.setString(1,msisdn);
			ps.setString(2,json);

			ps.setString(3,account_id);

			ps.setString(4,session_id);
			ps.setString(5,uuid);
			ps.setString(6,"whatsapp");

			ps.executeUpdate();

			String whatsapp_token="";
			String sql="select whatsapp_key,phoneid from account_info where account_id='"+account_id+"'";
			Statement st =conn.createStatement();
			ResultSet rs=st.executeQuery(sql);
			String phoneid="";
			if ( rs.next())
			{
				whatsapp_token=rs.getString("whatsapp_key");
				phoneid=rs.getString("phoneid");

			}



			String resp= getResponseWhatsapp(session_id, json,whatsapp_token,account_id,conn);
			JSONObject jb = new JSONObject(resp);

			String msgid=jb.getJSONArray("messages").getJSONObject(0).getString("id");
			sql="update outgoing_whatsapp_log set msg_id='"+msgid+"' where uuid='"+uuid+"'";
			st.executeUpdate(sql);

			sql="update account_daily_info set no_of_sent= no_of_sent where account_id='"+account_id+"' and sent_date=date(now())";
			int cnt=st.executeUpdate(sql);
			if ( cnt==0)
			{
				sql="insert into account_daily_info(account_id,sent_date,no_of_sent) values(account_id,date(now()),1)";
				st.executeUpdate(sql);
			}
			return msgid;

		}
		catch( Exception ex)
		{
			ex.printStackTrace();
			return "error";
		}

	}
	
	public String getIntent(String resp,String msisdn,Connection conn,String account_id)
	{
		try
		{
//	{"messages":[{"button":{"text":"Pay Now"},"context":{"from":"917777892222","id":"gBEGkZdBQRCHAgnooWiepw2TJFo"},"from":"919741411087","id":"ABEGkZdBQRCHAhDajiTTG8EizKgtoeUPhh4S","type":"button","timestamp":"1650592034"}],"contacts":[{"profile":{"name":"Sanjit Pradhan"},"wa_id":"919741411087"}]}
		//	{"from":"918073131344","id":"wamid.HBgMOTE4MDczMTMxMzQ0FQIAEhggNjRGQzFEQ0QwREYxNURCNTBFOEVEQzJERkY1MTQxRkEA","text":{"body":"Hi"},"type":"text","timestamp":"1660205970"}

			JSONObject js= getSessionInfo(msisdn, conn,account_id);
			String menuchoosen="";
			String text="";
			System.out.println("INTENTRESP="+resp);
			try
			{
				text=new JSONObject(resp).getJSONObject("button").getString("text");
				
			
				
			//	menuchoosen=js.getString("menu_choosen");
				
				
				
			}
			catch ( Exception ex)
			{
				ex.printStackTrace();
				System.out.println("RESP1="+resp);
			}
			
			if (text.toLowerCase().equals("continue"))
			{
				return "menu:continue";
			}
			else if ( text.equals("NO"))
			{
				
					return "menu:no";
				
			}
			
			else if ( text.equals("STOP"))
			{
				
					return "menu:stop";
				
			}
			else if ( text.equals("Subscribe"))
			{
				
					return "menu:subscribe";
				
			}
			else if ( menuchoosen.equals("hindimain"))
			{
				if ( text.equals("4"))
				{
					return "menu:hindisendotp";
				}
			}
			else if (menuchoosen.equals("engsendotp") )
			{
				String otp = text;
				if ( otp.equals("2"))
				{
					return "menu:engsendotp";
				}
				else
				{
					return "menu:engvalidateotp:"+text;
					
				}
						
			}
			
		
			else if (menuchoosen.equals("enterpan"))
			{
				return "menu:validatepan:"+text;
				
			}
			else if (menuchoosen.equals("validatepan"))
			{
				return "menu:issalaried:"+text;
				
			}
			else if (menuchoosen.equals("issalaried"))
			{
				return "menu:"+"selectcompany"+":"+text;
				
			}
			else if (menuchoosen.equals("selectcompany"))
			{
				return "menu:choosecompany:"+text;
				
			}
			else if (menuchoosen.equals("choosecompany"))
			{
				return "menu:enterpan"+":"+text;
				
			}
			
			else if (menuchoosen.equals("presentoffer"))
			{
				if ( text.equals("2"))
				{
				return "menu:enterofferamount"+":"+text;
				}
				
			}
			else if (menuchoosen.equals("enterofferamount"))
			{
				if ( text.equals("2"))
				{
				return "menu:presentoffer"+":"+text;
				}
				
			}
			
			
			
		}
			
		catch ( Exception ex)
		{
			ex.printStackTrace();
			return "error";
		}
		return "error";
	}
	
	public JSONObject getSessionInfo(String from_msisdn,Connection conn,String account_id)
	{
		 JSONObject jsinfo=null;
		try
		{
		 String sql="select session_var from session_info where from_msisdn='"+from_msisdn+"' and account_id='"+account_id+"'";
         Statement st= conn.createStatement();
         ResultSet rs=st.executeQuery(sql);
         String session_json=null;
         String offset="0";
          jsinfo = new JSONObject();
         if (rs.next())
         {
        	 session_json=rs.getString("session_var");
        	 try
        	 {
        		 JSONObject jb = new JSONObject(session_json);
        		 return jb;
        		 
        		 
        	 }
        	 catch ( Exception ex)
        	 {
        		 return null;

        	 }
        	 
         }
         else
         {
        	 return null;

         }
		}
		catch ( Exception ex)
		{
			ex.printStackTrace();
			
		}
		return null;
		
	}
	

}
