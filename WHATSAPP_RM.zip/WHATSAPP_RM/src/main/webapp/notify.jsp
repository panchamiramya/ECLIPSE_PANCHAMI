<%@page import="helper.EmojiUtils"%>
<%@page import="helper.WhatsAppMessage"%>
<%@page import="java.util.Random"%>
<%@page import="java.util.Calendar"%>
<%@page import="java.util.UUID"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.text.DateFormat"%>
<%@page import="java.lang.Math.*"%>
<%@page import="java.io.OutputStream"%>
<%@page import="java.io.FileOutputStream"%>
<%@page import="java.io.File"%>
<%@page import="java.io.InputStream"%>
<%@page import="javax.naming.InitialContext"%>
<%@page import="javax.naming.Context"%>
<%@ page import = "java.util.Map" %>
<%@ page import = "java.util.Enumeration" %>
<%@ page import = "org.json.simple.JSONObject" %>
<%@ page import = "org.json.simple.JSONArray" %>

<%@ page import = "org.json.simple.parser.JSONParser" %>







<%@page contentType="text/html" pageEncoding="UTF-8"%> <%@page import="javax.sql.DataSource"%><%@page import="java.io.*"%>  <%@page import="java.sql.*" %><%@page import="org.json.*" %>
<%
response.setContentType("text/html");
response.addHeader("Freeflow","FC");
java.util.Date mydt = new java.util.Date();
response.setDateHeader("Date", mydt.getTime());
Connection conn=null;
Context ctx = new InitialContext();

 if (ctx == null)
 {
    throw new Exception("Boom - No Context");
 }
 Context envCtx = (Context) ctx.lookup("java:comp/env");

 DataSource ds =(DataSource)envCtx.lookup("jdbc/whatsapp_rm");
 
  
    if (ds != null) {
        try{
        conn = ds.getConnection();
            }catch(Exception ex)
                         {
                           
                       }

 }

%><% 

String user_name="";
try {
DateFormat df=new SimpleDateFormat("yyyy-MM-dd");


Map<String, String[]> parameters = request.getParameterMap();
String challenge = "";
String token = "";
final String account_id="306";
/*
hub.mode:subscribe
hub.challenge:6461399
hub.verify_token:Ikontel$987@123
*/
String method = "";
for (String parameter : parameters.keySet()) {
	{
String[] values = parameters.get(parameter);
System.out.println(parameter + ":" + values[0]);
if (parameter.equals("hub.mode") && values[0].equals("subscribe")) {
	method = "subscribe";
}
if (parameter.equals("hub.verify_token")) {
	token = values[0];
	System.out.println("The Token Is :"+token);
}
if (parameter.equals("hub.challenge")) {
	challenge = values[0];
}

//your code here
	}
}


if (method.equals("subscribe") && token.equals("Ikontel$987@1233")) {
	out.print(challenge);
	return;
}

//https://ha1.msg2all.com:8443/TATACAP_QUICKPAY_WHATSAPP_360_CLOUD_UAT/notify.jsp
Enumeration<String> headerNames = request.getHeaderNames();

while (headerNames.hasMoreElements()) {

	String headerName = headerNames.nextElement();
	//System.out.print(headerName + " = ");
	String headerValue = request.getHeader(headerName);
	//System.out.println(headerValue);
}

String uid = UUID.randomUUID().toString();

String reg_id = "";
String msisdn = "";
String email_id = "";
String report_date = "";

//st= "select wavfilename from upload_wavfile_log"

InputStream is = request.getInputStream();
String cldfilename = "";

JSONParser jsonParser = new JSONParser();
org.json.simple.JSONObject jsonObject = (org.json.simple.JSONObject) jsonParser
.parse(new InputStreamReader(is, "UTF-8"));

//{"statuses":[{"id":"gBEGkZdBQRCHAglCL08Zx7t5hss","conversation":{"id":"bee2d03aee293c9614298433b48ea479"},"pricing":{"pricing_model":"NBP","billable":true},"recipient_id":"919741411087","status":"delivered","timestamp":"1627904134"}]}
System.out.println("RMPHOP______________________________________"+jsonObject.toString());
org.json.simple.JSONArray jarr = null;
try {
	org.json.JSONObject jbsession = new org.json.JSONObject();
	jbsession = new org.json.JSONObject();
	org.json.simple.JSONArray jenrty = (org.json.simple.JSONArray) jsonObject.get("entry");
	org.json.simple.JSONObject jb1 = (org.json.simple.JSONObject) jenrty.get(0);
	org.json.simple.JSONArray jarr_chgs = (org.json.simple.JSONArray) jb1.get("changes");
	org.json.simple.JSONObject jb2 = (org.json.simple.JSONObject) jarr_chgs.get(0);
	org.json.simple.JSONObject values = (org.json.simple.JSONObject) jb2.get("value");
	

	//	jarr=(org.json.simple.JSONArray)jsonObject.get("statuses");

	jarr = (org.json.simple.JSONArray) values.get("statuses");
	//jarr=(org.json.simple.JSONArray)jb2.get("statuses");

	if (jarr == null) {
/*
{
"entry":[
{
 "changes":[],
 "id":"100938666067856"
}
],
"object":"whatsapp_business_account"
}
*/
jenrty = (org.json.simple.JSONArray) jsonObject.get("entry");
jb1 = (org.json.simple.JSONObject) jenrty.get(0);
jarr_chgs = (org.json.simple.JSONArray) jb1.get("changes");

//System.out.println("jarr_chgs" + jarr_chgs.toString());

jb2 = (org.json.simple.JSONObject) jarr_chgs.get(0);
//System.out.println("JSONObject" + jb2.toString());

//	((org.json.simple.JSONObject)jarr_chgs.get(0)).get("messages")

values = (org.json.simple.JSONObject) jb2.get("value");

org.json.simple.JSONObject mdata=  (org.json.simple.JSONObject) values.get("metadata");

String phone_number_id=(String)mdata.get("phone_number_id");
if ( !phone_number_id.equals("122094783104010987"))
{
	return;
}




org.json.simple.JSONArray jarr_msgs = (org.json.simple.JSONArray) values.get("messages");

org.json.simple.JSONObject jb = (org.json.simple.JSONObject) jarr_msgs.get(0);


//System.out.println("ACTUALLLLLLLLLLLLLLLLLLLLLLLLLLLL_________________" + actual_id);
String from1 = (String) jb.get("from");
String from = from1;
String id = (String) jb.get("id");


String textbody="";
org.json.simple.JSONObject jbtext1=null;

try
{
jbtext1=(org.json.simple.JSONObject  )jb.get("text");
textbody=(String)jbtext1.get("body");
}
catch ( Exception ex)
{
}

String conversation_id = "";
try {
	conversation_id = (String) ((org.json.simple.JSONObject) jb.get("conversation")).get("id");
} catch (Exception ex) {
}

if (from1.equals("919741411087")) {
	from1 = "919741411087";
}

msisdn = from1.substring(2);

String body = jb.toJSONString();
String type = "";
String status = "";
if (jb.get("status") == null) {
	type = "incoming";
	status = "";
} else {
	type = "outgoing";
	status = (String) jb.get("status");
}




		WhatsAppMessage wa = new WhatsAppMessage();
		if ( textbody.length() !=0)
				{
		if ( EmojiUtils.containsEmoji(textbody))
		{
			System.out.println("EMOJI DETECTED");
			org.json.simple.JSONArray jarr1=null;
			jarr1=(org.json.simple.JSONArray)jsonObject.get("messages");
			org.json.simple.JSONObject jbl=(org.json.simple.JSONObject)jarr.get(0);
			jbl.put("type","emoji");
			JSONObject jbtext=(JSONObject)jbl.get("text");
			jbtext.put("body","emoji");
			body=jbl.toJSONString();
			
			System.out.println("EMOJI BODY="+body);
		}
				}
		
		if ( body.contains("sticker"))
		{
			System.out.println("EMOJI DETECTED");
			org.json.simple.JSONArray jarr1=null;
			jarr1=(org.json.simple.JSONArray)jsonObject.get("messages");
			org.json.simple.JSONObject jbl=(org.json.simple.JSONObject)jarr.get(0);
			jbl.put("type","emoji");
			
			//jbtext.put("body","emoji");
			body=EmojiUtils.removeEmoji(jbl.toJSONString());
			
		}

		String pssql="insert into incoming_message(from_msisdn,message,msg_id,call_type,msg_status,account_id) values(?,?,?,?,?,?)";
		PreparedStatement ps=conn.prepareStatement(pssql);
		ps.setString(1,from);
		ps.setString(2,body);
		ps.setString(3,id);
		ps.setString(4,type);
		ps.setString(5,status);
		ps.setString(6,account_id);

		ps.executeUpdate();
		
		if( type.equals("incoming"))
		{
			
			//testttttt
				
			 String resp=wa.getIntent(body,from,conn,account_id);
			 
			 jbsession= wa.getSessionInfo(from, conn,account_id);
			 
			 System.out.println("RESP="+resp);
			 if ( resp.contains("menu"))
			 {
				 String menu=resp.split("\\:")[1];

				 System.out.println("MENU Selected:"+menu);
				 if ( menu.toLowerCase().equals("continue"))
				 {
					 org.json.simple.JSONObject context = (org.json.simple.JSONObject) jb.get("context");
					 String actual_id = (String) context.get("id");
					 String sql="update outgoing_whatsapp_log set user_resp='CONTINUE',user_resp_date=now() where msg_id='"+actual_id+"'";
					 Statement st=conn.createStatement();
					 wa.updateCallBackURL(actual_id, "read", from.substring(2), "CONTINUE");
					 
					 System.out.println("SQL="+sql);
					 st.executeUpdate(sql);
			    		//wa.sendMessage360("121212122", from,"Thanks for choosing Techsquadteam, We will call you back soon", "5XylMcfyYsfqGn13NOicwqrQAK", conn);
                      //return;
				 }
				
				 else if ( menu.equals("stop"))
				 {
					//String msg= wa.removeFromWhatsapp(msisdn);
					org.json.simple.JSONObject context = (org.json.simple.JSONObject) jb.get("context");
					String actual_id = (String) context.get("id");
					 String sql="update outgoing_whatsapp_log set user_resp='STOP',user_resp_date=now() where msg_id='"+actual_id+"'";
					 System.out.println("SQL="+sql);
					 wa.updateCallBackURL(actual_id, "read", from.substring(2), "STOP");
					 Statement st=conn.createStatement();
					 st.executeUpdate(sql);
					 System.out.println("SQL="+sql);

					 sql="update cust_status set cust_status='"+"STOP"+"' where msisdn='"+msisdn+"' and account_id='"+account_id+"'";
					 int cnt=st.executeUpdate(sql);
					 if ( cnt ==0)
					 {
					 	sql="insert into cust_status(msisdn,status,account_id) values('"+msisdn+"','"+"STOP"+"','"+account_id+"')";
					 }
					 st.executeUpdate(sql);
					 
					
					    String json="";
					    
					    JSONObject jb3 = new JSONObject();
						jb3.put("messaging_product","whatsapp");
						jb3.put("to","91"+from.substring(2));
						jb3.put("type","template");
						JSONObject jtemp= new JSONObject();
						jtemp.put("name","template_subscribeagain");
						JSONObject jlang= new JSONObject();
						jlang.put("code","en");
						
					   jtemp.put("language",jlang);
						
						
						
							
					     jb3.put("template",jtemp);
					     
					     System.out.println("JSON="+jb3.toString());
					     
					     json=jb3.toString();
					     
					
					   //  wa.sendWhatsappJSONMsgNoUUID(msisdn, json, account_id, conn, "");
					

					 
				 }		
					 
			 } 
			//testtttt
			System.out.println("Inside incoming type");
			//String checkSql = "select * from ";
			
		    	String flag = "0";
		    	
			String sql="select session_id,agent_id from chat_session where msisdn='"+from+"' and last_message_received_at > now() - interval 10 minute  and flag !=99 ";
		    Statement st = conn.createStatement();
		    ResultSet rs=st.executeQuery(sql);
		    String session_id="";
		    String agent_id="";
		    if ( rs.next())
		    {System.out.println("Inside incoming type 2");
		    	session_id=rs.getString("session_id");
		    	agent_id=rs.getString("agent_id");
		    	//if(fla)
		    	String sqlupd="update incoming_message set session_id='"+session_id+"',agent_id='"+agent_id+"' where msg_id='"+id+"'";
		    	Statement stupd=conn.createStatement();
		    	stupd.executeUpdate(sqlupd);
		    	sqlupd="update chat_session set last_message_received_at=now(), last_msg_id= now() where session_id='"+session_id+"'";
		    	stupd.executeUpdate(sqlupd);
		    }
		    else
		    {
		    	//create a new session.
		    	System.out.println("Inside incoming type 3");
		    	String mysql="select max(id) as maxid from chat_session where msisdn='"+from+"'";
		    	Statement stsql= conn.createStatement();
		    	ResultSet rsset=stsql.executeQuery(mysql);
		    	String prev_id="";
		    	if ( rsset.next())
		    	{
		    		prev_id=rsset.getString("maxid");
		    	}
		    	mysql="update chat_session set status='hangup' ,session_end_time=now() where id="+prev_id+" and (status !='hangup' and status !='queuehangupmaxtime')";
		    	stsql.executeUpdate(mysql);
		    	if ( body.toLowerCase().contains("thank") || body.toLowerCase().contains("bye"))
		    	{
		    		return;
		    	}
		    	session_id=UUID.randomUUID().toString();
		    	
		    	String sqlinsert="insert into chat_session(session_id,last_message_received_at,last_msg_id,msisdn,created_on,flag) values('"+session_id+"',now(),'"+id+"','"+from+"',now(),'"+flag+"')";
		    	Statement stinsert=conn.createStatement();
		    	stinsert.executeUpdate(sqlinsert);
		    	String sqlu="update chat_session set account_id='"+account_id+"', campaign_name='whatsapp_campaign',group_name='whatsapp_group',queue_name='whatsapp_queue',queue_id=54 where session_id ='"+session_id+"'";
		    	
		    	stinsert.executeUpdate(sqlu);
		    	if(flag.equals("25"))
		    	{}else{
		    	String sqlupd="update incoming_message set session_id='"+session_id+"',flag=5 where msg_id='"+id+"'";
		    	Statement stupd=conn.createStatement();
		    	stupd.executeUpdate(sqlupd);
		    	}

		    	
		    }
		    
		}else{
			System.out.println("Inside incoming type 4");
			String sql10="update outgoing_whatsapp_log set conversation_id='"+conversation_id+"', msg_status='"+status+"' where msg_id='"+id+"'";
		    
			Statement stupd=conn.createStatement();
			stupd.executeUpdate(sql10);
		}

		
		
		//org.json.simple.JSONArray jarr1=(org.json.simple.JSONArray)jsonObject.get("contacts");
		
	}
	else
	{
		//"statuses":[{"id":"gBEGkZdBQRCHAgnKpPfNAmsHdUA","type":"message","conversation":{"id":"8891a5c7dc85633757b9281e9f83119a"},"pricing":{"pricing_model":"NBP","billable":false},"recipient_id":"919741411087","status":"delivered","timestamp":"1636536278"}]}
		org.json.simple.JSONObject jb=(org.json.simple.JSONObject)jarr.get(0);
		String msg_id=(String)jb.get("id");
		String body=jb.toJSONString();
		String to_num=(String)jb.get("recipient_id");
		String status=(String)jb.get("status");
		System.out.println("Inside incoming type 5");
		String pssql="insert into outgoing_message_log(to_msisdn,message,msg_id,call_type,msg_status) values(?,?,?,?,?)";
		PreparedStatement ps=conn.prepareStatement(pssql);
		ps.setString(1,to_num);
		ps.setString(2,body);
		ps.setString(3,msg_id);
		ps.setString(4,"outgoing");
		ps.setString(5,status);
		ps.executeUpdate();
		
		WhatsAppMessage wa = new WhatsAppMessage();
		wa.updateCallBackURL(msg_id,status, to_num.substring(2), "NA");
		String sql="update outgoing_message set msg_status='"+status+"' where msg_id='"+msg_id+"'";
		Statement stupd=conn.createStatement();
		stupd.executeUpdate(sql);
		
		
		
		
		
		
		
	}
	System.out.println("Inside incoming type6");
}
catch ( Exception ex)
{
	System.out.println("Inside incoming type7");
	ex.printStackTrace();
	
}



              
                
                               
                                
                                  
                                   
           
                
               
} catch (Exception e) {

e.printStackTrace();
JSONObject jstat =new JSONObject();
JSONObject jres = new JSONObject();
JSONObject jout = new JSONObject();


jstat.put("statusCode", "1");
           jstat.put("errorCode","101");
           jstat.put("errorMessage","UNKNOWN_ERROR");
           jres.put("status", jstat);
           jout.put("result", jres);
          out.println( jout.toString());

/* 18 */
/*    */     }finally{
                        try{
                        	conn.close();
                        }catch(Exception exx)
                                                               {
                            
                        }
                    }



%>
