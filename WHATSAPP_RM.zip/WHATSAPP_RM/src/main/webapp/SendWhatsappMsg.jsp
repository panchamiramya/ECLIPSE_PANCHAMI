<%@page import="java.util.Random"%>
<%@page import="java.util.Calendar"%>
<%@page import="java.util.UUID"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.text.DateFormat"%>
<%@page import="java.lang.Math.*"%>
<%@page import="java.io.OutputStream"%>
<%@page import="java.io.FileOutputStream"%>
<%@page import="java.io.File"%>
<%@page import="java.io.InputStream"%>
<%@page import="javax.naming.InitialContext"%>
<%@page import="javax.naming.Context"%>
<%@ page import = "java.util.Map" %>
<%@ page import = "java.util.Enumeration" %>
<%@ page import = "org.json.JSONObject" %>
<%@ page import = "org.json.JSONArray" %>
<%@ page import = "java.net.HttpURLConnection" %>
<%@ page import = "java.net.URL" %>
<%@ page import = "java.net.URLConnection" %>
<%@ page import = "java.net.URLDecoder" %>
<%@ page import = "java.net.URLEncoder" %>
<%@ page import = "java.sql.ResultSet" %>

<%@ page import = "javax.net.ssl.HttpsURLConnection" %>
<%@page import="helper.WhatsAppMessage"%>

<%@page contentType="text/html" pageEncoding="UTF-8"%> <%@page import="javax.sql.DataSource"%><%@page import="java.io.*"%>  
<%@page import="java.sql.*" %><%@page import="org.json.*" %>

<%!
public String sendMessage(String session_id,String msisdn, String msg,String whatsapp_token,Connection conn)
{
	 
		  String contact_id=msisdn;
	
		  
      String json="{\n"
      		+ "  \"recipient_type\": \"individual\",\n"
      		+ "   \"type\": \"text\",\n"
      		+ "  \"to\": \""+contact_id+"\",\n"
      		+ "\"text\": {\n"
      		+ "    \"body\": \""+msg+"\"\n"
      		+ "  }\n"
      		+ "  \n"
      		+ "  \n"
      		+ "  \n"
      		+ " \n"
      		+ "  \n"
      		+ "}";
    
      return sendWhatsappMsg(session_id, json,msisdn,whatsapp_token,conn);
  }

public  String getResponseWhatsapp(String session_id,String json,String whatsapp_key)
{
    String xml=json;
    String res="";
     BufferedReader in=null;
/*    */       OutputStream out=null;
/*    */       Writer wout=null;
String url="https://waba.360dialog.io/v1/messages";
//   OutputStream out=null;
    try {
           URL url1 = new URL(url);
           System.out.println("url="+url+json);
/* 50 */       URLConnection connection = url1.openConnection();
/* 51 */       HttpsURLConnection httpConn = ((HttpsURLConnection)connection);
/* 52 */       httpConn.setReadTimeout(20000);
/* 53 */       httpConn.setConnectTimeout(20000);
/* 55 */       httpConn.setRequestProperty("d360-api-key", whatsapp_key);
/* 55 */       httpConn.setRequestProperty("cache-control", "no-cache");
            httpConn.setRequestProperty("content-type", "application/json");



/* 56 */       httpConn.setRequestMethod("POST");
           httpConn.setDoInput(true);
/* 57 */       httpConn.setDoOutput(true);

out = httpConn.getOutputStream();
out.write(xml.getBytes());
           //httpConn.connect();
/* 58 */      


/*    */
/* 60 */      // out = httpConn.getOutputStream();
/* 61 */      // wout = new OutputStreamWriter(out);
/* 62 */      // wout.flush();
//out = httpConn.getOutputStream();
//out.write(xml.getBytes());
           System.out.println("code="+httpConn.getResponseCode());
          
/* 64 */       InputStreamReader isr = new InputStreamReader(httpConn.getInputStream());
/*    */
/* 66 */       in = new BufferedReader(isr);
/* 67 */       String temp = "";
/* 68 */       res = "";
/* 69 */       while ((temp = in.readLine()) != null)
/* 70 */         res += temp;
           System.out.println("res_ok="+res);
           return res;
         
           
            

/*    */     }
/*    */     catch (Exception ex) {
	          
/* 73 */       ex.printStackTrace();
return "IOEXP";
/* 74 */
/*    */     }
/*    */     finally
/*    */     {
/*    */       try {
/* 79 */         in.close();
/* 80 */         wout.close();
/* 81 */         out.close();
/*    */       }
/*    */       catch (Exception tx)
/*    */       {
/*    */       }
/*    */     }
/*    */
/*    */



}


public String  sendWhatsappMsg(String session_id, String json,String msisdn,String whatsapp_token,Connection conn)
{
	try
	{
		
		String id="";
	
	String resp= getResponseWhatsapp(session_id, json,whatsapp_token);
	 JSONObject jb = new JSONObject(resp);
	    
	    JSONArray ids= jb.getJSONArray("messages");
		  if ( ids ==null || ids.length()==0)
		  {
			 
				String sql ="insert into whatsapp.outgoing_message(session_id,msg,to_msisdn) values(?,?,?)";
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setString(1, session_id);
				ps.setString(2, json);
				ps.setString(3, msisdn);

				ps.executeUpdate();
			  return "error";
		  }
		  else
		  {
			  JSONObject jb1 = ids.getJSONObject(0);
			 
				   id= jb1.getString("id");
				 
					String sql ="insert into whatsapp.outgoing_message(session_id,msg,msg_id,to_msisdn) values(?,?,?,?)";
					PreparedStatement ps = conn.prepareStatement(sql);
					ps.setString(1, session_id);
					ps.setString(2, json);
					ps.setString(3, id);
					ps.setString(4, msisdn);


					ps.executeUpdate();
				   return resp;
			  
			
		  }
	}
	catch( Exception ex)
	{
		ex.printStackTrace();
		return "error";
	}
	
}

%>
<%
response.setContentType("text/html");
response.addHeader("Freeflow","FC");
java.util.Date mydt = new java.util.Date();
response.setDateHeader("Date", mydt.getTime());
Connection conn=null;
Context ctx = new InitialContext();

 if (ctx == null)
 {
    throw new Exception("Boom - No Context");
 }
 Context envCtx = (Context) ctx.lookup("java:comp/env");

 DataSource ds =(DataSource)envCtx.lookup("jdbc/whatsapp_rm");
 
  
    if (ds != null) {
        try{
        conn = ds.getConnection();
            }catch(Exception ex)
                         {
                           
                       }

 }

%><% 

String user_name="";
JSONObject jout= new JSONObject();
JSONObject jres=new JSONObject();
JSONObject jstat= new JSONObject();


try {
	
String reg_id="";
String msisdn="";
String email_id="";
String report_date="";
String account_id="";


//st= "select wavfilename from upload_wavfile_log"

msisdn=request.getParameter("msisdn");
account_id=request.getParameter("account_id");
String template_name= request.getParameter("template_name");
String image_file_name= request.getParameter("image_file");



String json="";
String sql="select user_authtoken ,daily_limit from account_info where account_id='"+account_id+"'";

String authtoken=request.getParameter("authtoken");


String authtoken_from_db="";
int daily_limit=0;
int sent_today=0;
Statement st = conn.createStatement();
ResultSet rs= st.executeQuery(sql);
if ( rs.next())
{
	authtoken_from_db=rs.getString("user_authtoken");
	daily_limit=rs.getInt("daily_limit");
	
}



if ( !authtoken_from_db.equals(authtoken))
{
	jstat.put("statusCode", "1");
	jstat.put("errCode","101");
	jstat.put("errMessage","Message Failed auth token");


	jres.put("status", jstat);
	jout.put("result", jres);
	out.println( jout.toString());
	return;

}

sql= "select no_of_sent from account_daily_info where account_id="+account_id+" and sent_date=date(now())";
rs=st.executeQuery(sql);
if ( rs.next())
{
	sent_today=rs.getInt("no_of_sent");
}

if	( sent_today > daily_limit)
{
	jstat.put("statusCode", "1");
	jstat.put("errCode","109");
	jstat.put("errMessage","Daily limit of "+daily_limit +" Exceeded");


	jres.put("status", jstat);
	jout.put("result", jres);
	out.println( jout.toString());
	return;
}
//customer_status

sql="select status from cust_status where msisdn='"+"91"+msisdn+"'";
Statement st2= conn.createStatement();
String status="";
ResultSet rs2=st2.executeQuery(sql);
if ( rs2.next())
{
	status=rs2.getString("status");
	
}

if ( status.toLowerCase().equals("STOP"))
{
	jstat.put("statusCode", "1");
	jstat.put("errCode","110");
	jstat.put("errMessage","Subscriotion "+daily_limit +" Stopped");


	jres.put("status", jstat);
	jout.put("result", jres);
	out.println( jout.toString());
	return;
}



if ( template_name.equals("techsquad_serviceomplete"))
{
	String cust_name=request.getParameter("cust_name");
	String percent=request.getParameter("percent");

	JSONObject jb = new JSONObject();
	jb.put("messaging_product","whatsapp");
	jb.put("to","91"+msisdn);
	jb.put("type","template");
	JSONObject jtemp= new JSONObject();
	jtemp.put("name","techsquad_serviceomplete");
	JSONObject jlang= new JSONObject();
	jlang.put("code","en");
	
   jtemp.put("language",jlang);
	
	JSONObject jbcmp=new JSONObject();
	
	jbcmp.put("type","body");
	 JSONObject jparam= new JSONObject();
	 jparam.put("type","text");
	 jparam.put("text",cust_name);
	 
	 JSONArray jbparamarray= new JSONArray();
	 jbparamarray.put(jparam);
	 jparam= new JSONObject();
	 jparam.put("type","text");
	 jparam.put("text",percent);
	 jbparamarray.put(jparam);
	 jbcmp.put("type","body");
	 jbcmp.put("parameters",jbparamarray);
	 
	 JSONArray jbcmparray=new JSONArray();
     jbcmparray.put(jbcmp);
		
     jtemp.put("components",jbcmparray);
		
     jb.put("template",jtemp);
     
     System.out.println("JSON="+jb.toString());
     
     json=jb.toString();
     
     
		/*
		
	 
	 

	 
	 


	
	{
		"messaging_product": "whatsapp",
		"to": "919741411087",
		"type": "template",
		"template": {
			"name": "techsquad_serviececomplete",
			"language": {
				"code": "en"
			},
			"components": [

				{
					"type": "body",
					"parameters":[ {
						"type": "text",
						"text": "sanjit pradhan"
					}
	                ]
				}
			]
		}
	}*/
	
}
else if ( template_name.equals("techsquad_marketing_offer_today"))
{
	
	String cust_name=request.getParameter("cust_name");
	String percent=request.getParameter("percent");

	JSONObject jb = new JSONObject();
	jb.put("messaging_product","whatsapp");
	jb.put("to","91"+msisdn);
	jb.put("type","template");
	JSONObject jtemp= new JSONObject();
	jtemp.put("name","techsquad_marketing_offer_today");
	JSONObject jlang= new JSONObject();
	jlang.put("code","en");
	
   jtemp.put("language",jlang);
	
	JSONObject jbcmp=new JSONObject();
	
	jbcmp.put("type","body");
	 JSONObject jparam= new JSONObject();
	 jparam.put("type","text");
	 jparam.put("text",cust_name);
	 
	 JSONArray jbparamarray= new JSONArray();
	 jbparamarray.put(jparam);
	 jparam= new JSONObject();
	 jparam.put("type","text");
	 jparam.put("text",percent);
	 jbparamarray.put(jparam);
	 jbcmp.put("type","body");
	 jbcmp.put("parameters",jbparamarray);
	 
	 JSONArray jbcmparray=new JSONArray();
     jbcmparray.put(jbcmp);
		
     jtemp.put("components",jbcmparray);
		
     jb.put("template",jtemp);
     
     System.out.println("JSON="+jb.toString());
     
     json=jb.toString();
     
}
else if (template_name.equals("temp_1_image"))
{
	JSONObject jb = new JSONObject();
        jb.put("messaging_product","whatsapp");
        jb.put("to","91"+msisdn);
        jb.put("type","template");
        JSONObject jtemp= new JSONObject();
        jtemp.put("name",template_name);
        JSONObject jlang= new JSONObject();
	 jlang.put("code","hi");
	jtemp.put("language",jlang);

        JSONObject jbcmp=new JSONObject();

        jbcmp.put("type","header");
         JSONObject jparam= new JSONObject();
        // jparam.put("type","text");
        // jparam.put("text",cust_name);

         JSONArray jbparamarray= new JSONArray();
        // jbparamarray.put(jparam);
        // jparam= new JSONObject();
         jparam.put("type","image");

         JSONObject jparamimg= new JSONObject();
         jparamimg.put("link","https://msg2all.com/"+image_file_name);
         jparam.put("image",jparamimg);
         jbparamarray.put(jparam);
         jbcmp.put("type","header");
         jbcmp.put("parameters",jbparamarray);

         JSONArray jbcmparray=new JSONArray();
     jbcmparray.put(jbcmp);

     jtemp.put("components",jbcmparray);

     jb.put("template",jtemp);

     System.out.println("JSON="+jb.toString());

     json=jb.toString();
}
else if ( template_name.equals("location"))
{
	
	   
	JSONObject jb = new JSONObject();
	JSONObject jbtxt= new JSONObject();
	jbtxt.put("preview_url",true);

	jbtxt.put("body","https://maps.app.goo.gl/JLHebVwQPPTRB5Y96");
	jb.put("text",jbtxt);
	jb.put("to","91"+msisdn);
	jb.put("preview_url",true);
	json=jb.toString();
	
	

}







else if ( template_name.equals("generic_text"))
{
	
	String cust_name=request.getParameter("cust_name");
	String percent=request.getParameter("percent");

	JSONObject jb = new JSONObject();
	jb.put("messaging_product","whatsapp");
	jb.put("to","91"+msisdn);
	jb.put("recipient_type","individual");

	jb.put("preview_url",true);

	jb.put("type","template");
	JSONObject jtemp= new JSONObject();
	jtemp.put("name","generic_text");
	JSONObject jlang= new JSONObject();
	jlang.put("code","en");
	
   jtemp.put("language",jlang);
	
	JSONObject jbcmp=new JSONObject();
	
	jbcmp.put("type","body");
	 JSONObject jparam= new JSONObject();
	 jparam.put("type","text");
	 jparam.put("text",cust_name);
	 
	 JSONArray jbparamarray= new JSONArray();
	 jbparamarray.put(jparam);
	 jparam= new JSONObject();
	 jparam.put("type","text");
	 jparam.put("text",percent);
	 jbparamarray.put(jparam);
	 jbcmp.put("type","body");
	 //jbcmp.put("parameters",jbparamarray);
	 
	 JSONArray jbcmparray=new JSONArray();
     jbcmparray.put(jbcmp);
		
     jtemp.put("components",jbcmparray);
		
     jb.put("template",jtemp);
     
     System.out.println("JSON="+jb.toString());
     
     json=jb.toString();
     
}

else if ( template_name.startsWith("jkagri_imgtemp"))
{
	String cust_name=request.getParameter("cust_name");
	String percent=request.getParameter("percent");

	JSONObject jb = new JSONObject();
	jb.put("messaging_product","whatsapp");
	jb.put("to","91"+msisdn);
	jb.put("type","template");
	JSONObject jtemp= new JSONObject();
	jtemp.put("name",template_name);
	JSONObject jlang= new JSONObject();
	jlang.put("code","hi");
	
   jtemp.put("language",jlang);
	
	JSONObject jbcmp=new JSONObject();
	
	jbcmp.put("type","header");
	 JSONObject jparam= new JSONObject();
	// jparam.put("type","text");
	// jparam.put("text",cust_name);
	 
	 JSONArray jbparamarray= new JSONArray();
	// jbparamarray.put(jparam);
	// jparam= new JSONObject();
	 jparam.put("type","image");
	 
	 JSONObject jparamimg= new JSONObject();
	 jparamimg.put("link","https://msg2all.com/"+image_file_name);
	 jparam.put("image",jparamimg);
	 jbparamarray.put(jparam);
	 jbcmp.put("type","header");
	 jbcmp.put("parameters",jbparamarray);
	 
	 JSONArray jbcmparray=new JSONArray();
     jbcmparray.put(jbcmp);
		
     jtemp.put("components",jbcmparray);
		
     jb.put("template",jtemp);
     
     System.out.println("JSON="+jb.toString());
     
     json=jb.toString();
	
	
}

else if ( template_name.startsWith("jkagri_temp3"))
{
	String cust_name=request.getParameter("cust_name");
	String percent=request.getParameter("percent");

	JSONObject jb = new JSONObject();
	jb.put("messaging_product","whatsapp");
	jb.put("to","91"+msisdn);
	jb.put("type","template");
	JSONObject jtemp= new JSONObject();
	jtemp.put("name",template_name);
	JSONObject jlang= new JSONObject();
	jlang.put("code","hi");
	
   jtemp.put("language",jlang);
	JSONArray jbcmparray= new JSONArray();

	/*
	JSONObject jbcmp=new JSONObject();
	
	jbcmp.put("type","header");
	 JSONObject jparam= new JSONObject();
	
	 JSONArray jbparamarray= new JSONArray();
	
	 jparam.put("type","image");
	 
	 JSONObject jparamimg= new JSONObject();
	 jparamimg.put("link","https://msg2all.com/"+image_file_name);
	 jparam.put("image",jparamimg);
	 jbparamarray.put(jparam);
	 jbcmp.put("type","header");
	 jbcmp.put("parameters",jbparamarray);
	 
	 JSONArray jbcmparray=new JSONArray();
     jbcmparray.put(jbcmp);*/
		
     jtemp.put("components",jbcmparray);
		
     jb.put("template",jtemp);
     
     System.out.println("JSON="+jb.toString());
     
     json=jb.toString();
	
	
}

else if ( template_name.equals("jkagri_temp1"))
{
	/*String cust_name=request.getParameter("cust_name");
	String percent=request.getParameter("percent");

	JSONObject jb = new JSONObject();
	jb.put("messaging_product","whatsapp");
	jb.put("to",msisdn);
	jb.put("type","template");
	JSONObject jtemp= new JSONObject();
	jtemp.put("name","jkagri_temp1");
	JSONObject jlang= new JSONObject();
	jlang.put("code","hi");
	
   jtemp.put("language",jlang);
	
		
     jb.put("template",jtemp);
     
     System.out.println("JSON="+jb.toString());
     
     json=jb.toString();*/
     
	String cust_name=request.getParameter("cust_name");
	String percent=request.getParameter("percent");

	JSONObject jb = new JSONObject();
	jb.put("messaging_product","whatsapp");
	jb.put("to","91"+msisdn);
	jb.put("type","template");
	JSONObject jtemp= new JSONObject();
	jtemp.put("name","jkagri_temp1");
	JSONObject jlang= new JSONObject();
	jlang.put("code","hi");
	
   jtemp.put("language",jlang);
	
	JSONObject jbcmp=new JSONObject();
	
	jbcmp.put("type","header");
	 JSONObject jparam= new JSONObject();
	// jparam.put("type","text");
	// jparam.put("text",cust_name);
	 
	 JSONArray jbparamarray= new JSONArray();
	// jbparamarray.put(jparam);
	// jparam= new JSONObject();
	 jparam.put("type","image");
	 
	 JSONObject jparamimg= new JSONObject();
	 jparamimg.put("link","https://msg2all.com/"+image_file_name);
	 jparam.put("image",jparamimg);
	 jbparamarray.put(jparam);
	 jbcmp.put("type","header");
	 jbcmp.put("parameters",jbparamarray);
	 
	 JSONArray jbcmparray=new JSONArray();
     jbcmparray.put(jbcmp);
		
     jtemp.put("components",jbcmparray);
		
     jb.put("template",jtemp);
     
     System.out.println("JSON="+jb.toString());
     
     json=jb.toString();
	
}




else if ( template_name.equals("jkagri_temp2"))
{
	/*String cust_name=request.getParameter("cust_name");
	String percent=request.getParameter("percent");

	JSONObject jb = new JSONObject();
	jb.put("messaging_product","whatsapp");
	jb.put("to",msisdn);
	jb.put("type","template");
	JSONObject jtemp= new JSONObject();
	jtemp.put("name","jkagri_temp2");
	JSONObject jlang= new JSONObject();
	jlang.put("code","hi");
	
   jtemp.put("language",jlang);
	

		
     jb.put("template",jtemp);
     
     System.out.println("JSON="+jb.toString());
     
     json=jb.toString();*/
     
    
	String cust_name=request.getParameter("cust_name");
	String percent=request.getParameter("percent");

	JSONObject jb = new JSONObject();
	jb.put("messaging_product","whatsapp");
	jb.put("to","91"+msisdn);
	jb.put("type","template");
	JSONObject jtemp= new JSONObject();
	jtemp.put("name","jkagri_temp2");
	JSONObject jlang= new JSONObject();
	jlang.put("code","hi");
	
  jtemp.put("language",jlang);
	
	JSONObject jbcmp=new JSONObject();
	
	jbcmp.put("type","header");
	 JSONObject jparam= new JSONObject();
	// jparam.put("type","text");
	// jparam.put("text",cust_name);
	 
	 JSONArray jbparamarray= new JSONArray();
	// jbparamarray.put(jparam);
	// jparam= new JSONObject();
	 jparam.put("type","image");
	 
	 JSONObject jparamimg= new JSONObject();
	 jparamimg.put("link","https://msg2all.com/"+image_file_name);
	 jparam.put("image",jparamimg);
	 jbparamarray.put(jparam);
	 jbcmp.put("type","header");
	 jbcmp.put("parameters",jbparamarray);
	 
	 JSONArray jbcmparray=new JSONArray();
    jbcmparray.put(jbcmp);
		
    jtemp.put("components",jbcmparray);
		
    jb.put("template",jtemp);
    
    System.out.println("JSON="+jb.toString());
    
    json=jb.toString();
     
	
}

else if ( template_name.equals("techsquad_miscall"))
{
	String cust_name=request.getParameter("cust_name");
	String percent=request.getParameter("percent");

	JSONObject jb = new JSONObject();
	jb.put("messaging_product","whatsapp");
	jb.put("to","91"+msisdn);
	jb.put("type","template");
	JSONObject jtemp= new JSONObject();
	jtemp.put("name","techsquad_miscall");
	JSONObject jlang= new JSONObject();
	jlang.put("code","en");
	
   jtemp.put("language",jlang);
	
	/*JSONObject jbcmp=new JSONObject();
	
	jbcmp.put("type","body");
	 JSONObject jparam= new JSONObject();
	 jparam.put("type","text");
	 jparam.put("text",cust_name);
	 
	 JSONArray jbparamarray= new JSONArray();
	 jbparamarray.put(jparam);
	 jparam= new JSONObject();
	 jparam.put("type","text");
	 jparam.put("text",percent);
	 jbparamarray.put(jparam);
	 jbcmp.put("type","body");
	 jbcmp.put("parameters",jbparamarray);
	 
	 JSONArray jbcmparray=new JSONArray();
     jbcmparray.put(jbcmp);
		
     jtemp.put("components",jbcmparray);*/
		
     jb.put("template",jtemp);
     
     System.out.println("JSON="+jb.toString());
     
     json=jb.toString();
}
else if ( template_name.equals("techsquad_service_complete"))
{
	String cust_name=request.getParameter("cust_name");
	String percent=request.getParameter("percent");

	JSONObject jb = new JSONObject();
	jb.put("messaging_product","whatsapp");
	jb.put("to","91"+msisdn);
	jb.put("type","template");
	JSONObject jtemp= new JSONObject();
	jtemp.put("name","techsquad_service_complete");
	JSONObject jlang= new JSONObject();
	jlang.put("code","en");
	
   jtemp.put("language",jlang);
	
	JSONObject jbcmp=new JSONObject();
	
	jbcmp.put("type","body");
	 JSONObject jparam= new JSONObject();
	 jparam.put("type","text");
	 jparam.put("text",cust_name);
	 
	 JSONArray jbparamarray= new JSONArray();
	 jbparamarray.put(jparam);
	 jparam= new JSONObject();
	 jparam.put("type","text");
	 jparam.put("text",percent);
	 jbparamarray.put(jparam);
	 jbcmp.put("type","body");
	 jbcmp.put("parameters",jbparamarray);
	 
	 JSONArray jbcmparray=new JSONArray();
     jbcmparray.put(jbcmp);
		
     jtemp.put("components",jbcmparray);
		
     jb.put("template",jtemp);
     
     System.out.println("JSON="+jb.toString());
     
     json=jb.toString();
}
else if ( template_name.equals("techsquad_dewaili_marketing"))
{
	
	String cust_name=request.getParameter("cust_name");
	String percent=request.getParameter("percent");

	JSONObject jb = new JSONObject();
	jb.put("messaging_product","whatsapp");
	jb.put("to","91"+msisdn);
	jb.put("type","template");
	JSONObject jtemp= new JSONObject();
	jtemp.put("name","techsquad_dewaili_marketing");
	JSONObject jlang= new JSONObject();
	jlang.put("code","en");
	
   jtemp.put("language",jlang);
	
	JSONObject jbcmp=new JSONObject();
	
	jbcmp.put("type","header");
	 JSONObject jparam= new JSONObject();
	// jparam.put("type","text");
	// jparam.put("text",cust_name);
	 
	 JSONArray jbparamarray= new JSONArray();
	// jbparamarray.put(jparam);
	// jparam= new JSONObject();
	 jparam.put("type","image");
	 
	 JSONObject jparamimg= new JSONObject();
	 jparamimg.put("link","https://msg2all.com/techsquad_dewali.jpeg");
	 jparam.put("image",jparamimg);
	 jbparamarray.put(jparam);
	 jbcmp.put("type","header");
	 jbcmp.put("parameters",jbparamarray);
	 
	 JSONArray jbcmparray=new JSONArray();
     jbcmparray.put(jbcmp);
		
     jtemp.put("components",jbcmparray);
		
     jb.put("template",jtemp);
     
     System.out.println("JSON="+jb.toString());
     
     json=jb.toString();
	
}


else if ( template_name.equals("agri_market_video") || template_name.equals("agri_market_video_generic"))
{
	
	String cust_name=request.getParameter("cust_name");
	String percent=request.getParameter("percent");

	JSONObject jb = new JSONObject();
	jb.put("messaging_product","whatsapp");
	jb.put("to","91"+msisdn);
	jb.put("type","template");
	JSONObject jtemp= new JSONObject();
	jtemp.put("name",template_name.trim());
	JSONObject jlang= new JSONObject();
	if ( template_name.equals("agri_market_video"))
	{
		
	jlang.put("code","hi");
	}
	else
	{
		jlang.put("code","en");

	}
	
   jtemp.put("language",jlang);
	
	JSONObject jbcmp=new JSONObject();
	
	jbcmp.put("type","header");
	 JSONObject jparam= new JSONObject();
	// jparam.put("type","text");
	// jparam.put("text",cust_name);
	 
	 JSONArray jbparamarray= new JSONArray();
	// jbparamarray.put(jparam);
	// jparam= new JSONObject();
	 jparam.put("type","video");
	 
	 JSONObject jparamimg= new JSONObject();
	 jparamimg.put("link","https://msg2all.com/"+image_file_name);
	 jparam.put("video",jparamimg);
	 jbparamarray.put(jparam);
	 jbcmp.put("type","header");
	 jbcmp.put("parameters",jbparamarray);
	 
	 JSONArray jbcmparray=new JSONArray();
     jbcmparray.put(jbcmp);
		
     jtemp.put("components",jbcmparray);
		
     jb.put("template",jtemp);
     
     System.out.println("JSON="+jb.toString());
     
     json=jb.toString();
	
}

else if ( template_name.equals("agri_market_link"))
{
	
	

	JSONObject jb = new JSONObject();
	jb.put("messaging_product","whatsapp");
	jb.put("to","91"+msisdn);
	jb.put("type","template");
	JSONObject jtemp= new JSONObject();
	jtemp.put("name","agri_market_text");
	JSONObject jlang= new JSONObject();
	jlang.put("code","hi");
	
   jtemp.put("language",jlang);
	
	JSONObject jbcmp=new JSONObject();
	
	jbcmp.put("type","header");
	 JSONObject jparam= new JSONObject();
	// jparam.put("type","text");
	// jparam.put("text",cust_name);
	 
	 JSONArray jbparamarray= new JSONArray();
	// jbparamarray.put(jparam);
	// jparam= new JSONObject();
	 jparam.put("type","video");
	 
	 JSONObject jparamimg= new JSONObject();
	 jparamimg.put("link","https://msg2all.com/"+image_file_name);
	 jparam.put("video",jparamimg);
	 jbparamarray.put(jparam);
	 jbcmp.put("type","header");
	 jbcmp.put("parameters",jbparamarray);
	 
	 JSONArray jbcmparray=new JSONArray();
   //  jbcmparray.put(jbcmp);
		
     jtemp.put("components",jbcmparray);
		
     jb.put("template",jtemp);
     
     System.out.println("JSON="+jb.toString());
     
     json=jb.toString();
	
}


else if ( template_name.equals("contact_welcome"))
{
	String agent_id=request.getParameter("agent_id");
	sql = "insert into chat_session(msisdn,agent_id,account_id,status) values('"+msisdn+"','"+agent_id+"','"+account_id+"','"+"connected"+"')";
	st = conn.createStatement();
	st.executeUpdate(sql);
	
	String cust_name=request.getParameter("cust_name");
	String percent=request.getParameter("percent");

	JSONObject jb = new JSONObject();
	jb.put("messaging_product","whatsapp");
	jb.put("to","91"+msisdn);
	jb.put("type","template");
	JSONObject jtemp= new JSONObject();
	jtemp.put("name","contact_welcome");
	JSONObject jlang= new JSONObject();
	jlang.put("code","en");
	
   jtemp.put("language",jlang);
	
	JSONObject jbcmp=new JSONObject();
	
	jbcmp.put("type","body");
	 JSONObject jparam= new JSONObject();
	 jparam.put("type","text");
	 jparam.put("text",cust_name);
	 
	 JSONArray jbparamarray= new JSONArray();
	 jbparamarray.put(jparam);
	 jparam= new JSONObject();
	 jparam.put("type","text");
	 jparam.put("text",percent);
	 jbparamarray.put(jparam);
	 jbcmp.put("type","body");
	 jbcmp.put("parameters",jbparamarray);
	 
	 JSONArray jbcmparray=new JSONArray();
     jbcmparray.put(jbcmp);
		
     jtemp.put("components",jbcmparray);
		
     jb.put("template",jtemp);
     
     System.out.println("JSON="+jb.toString());
     
     json=jb.toString();
	
}



else if ( template_name.equals("sendmsg_template"))
		{
	String msg=request.getParameter("msg");


     json="{\n"
    		+ "  \"recipient_type\": \"individual\",\n"
    		+ "   \"type\": \"text\",\n"
    		+ "  \"to\": \""+msisdn+"\",\n"
    		+ "\"text\": {\n"
    		+ "    \"body\": \""+org.json.simple.JSONObject.escape(msg)+"\"\n"
    		+ "  }\n"
    		+ "  \n"
    		+ "  \n"
    		+ "  \n"
    		+ " \n"
    		+ "  \n"
    		+ "}";
  
//     return getResponseWhatsapp(session_id, json,msisdn,whatsapp_token,conn);
    
		}
		



else if (template_name.equals("promalin_1"))
{
	String cust_name=request.getParameter("cust_name");
	String percent=request.getParameter("percent");

	JSONObject jb = new JSONObject();
	jb.put("messaging_product","whatsapp");
	jb.put("to","91"+msisdn);
	jb.put("type","template");
	JSONObject jtemp= new JSONObject();
	jtemp.put("name","promalin_1");
	JSONObject jlang= new JSONObject();
	jlang.put("code","en");
	
   jtemp.put("language",jlang);
	
	JSONObject jbcmp=new JSONObject();
	
	jbcmp.put("type","header");
	 JSONObject jparam= new JSONObject();
	// jparam.put("type","text");
	// jparam.put("text",cust_name);
	 
	 JSONArray jbparamarray= new JSONArray();
	// jbparamarray.put(jparam);
	// jparam= new JSONObject();
	 jparam.put("type","image");
	 
	 JSONObject jparamimg= new JSONObject();
	 jparamimg.put("link","https://msg2all.com/"+image_file_name);
	 jparam.put("image",jparamimg);
	 jbparamarray.put(jparam);
	 jbcmp.put("type","header");
	 jbcmp.put("parameters",jbparamarray);
	 
	 JSONArray jbcmparray=new JSONArray();
     jbcmparray.put(jbcmp);
		
     jtemp.put("components",jbcmparray);
		
     jb.put("template",jtemp);
     
     System.out.println("JSON="+jb.toString());
     
     json=jb.toString();
	
}
else if ( template_name.equals("agri_market1"))
{
	
	String cust_name=request.getParameter("cust_name");
	String percent=request.getParameter("percent");

	JSONObject jb = new JSONObject();
	jb.put("messaging_product","whatsapp");
	jb.put("to","91"+msisdn);
	jb.put("type","template");
	JSONObject jtemp= new JSONObject();
	jtemp.put("name","agri_market1");
	JSONObject jlang= new JSONObject();
	jlang.put("code","en");
	
   jtemp.put("language",jlang);
	
	JSONObject jbcmp=new JSONObject();
	
	jbcmp.put("type","header");
	 JSONObject jparam= new JSONObject();
	// jparam.put("type","text");
	// jparam.put("text",cust_name);
	 
	 JSONArray jbparamarray= new JSONArray();
	// jbparamarray.put(jparam);
	// jparam= new JSONObject();
	 jparam.put("type","image");
	 
	 JSONObject jparamimg= new JSONObject();
	 jparamimg.put("link","https://msg2all.com/"+image_file_name);
	 jparam.put("image",jparamimg);
	 jbparamarray.put(jparam);
	 jbcmp.put("type","header");
	 jbcmp.put("parameters",jbparamarray);
	 
	 JSONArray jbcmparray=new JSONArray();
     jbcmparray.put(jbcmp);
		
     jtemp.put("components",jbcmparray);
		
     jb.put("template",jtemp);
     
     System.out.println("JSON="+jb.toString());
     
     json=jb.toString();
	
}
else if ( template_name.equals("agri_market5"))
{
	
	String cust_name=request.getParameter("cust_name");
	String percent=request.getParameter("percent");

	JSONObject jb = new JSONObject();
	jb.put("messaging_product","whatsapp");
	jb.put("to","91"+msisdn);
	jb.put("type","template");
	JSONObject jtemp= new JSONObject();
	jtemp.put("name","agri_market5");
	JSONObject jlang= new JSONObject();
	jlang.put("code","en");
	
   jtemp.put("language",jlang);
	
	JSONObject jbcmp=new JSONObject();
	
	jbcmp.put("type","header");
	 JSONObject jparam= new JSONObject();
	// jparam.put("type","text");
	// jparam.put("text",cust_name);
	 
	 JSONArray jbparamarray= new JSONArray();
	// jbparamarray.put(jparam);
	// jparam= new JSONObject();
	 jparam.put("type","image");
	 
	 JSONObject jparamimg= new JSONObject();
	 jparamimg.put("link","https://msg2all.com/"+image_file_name);
	 jparam.put("image",jparamimg);
	 jbparamarray.put(jparam);
	 jbcmp.put("type","header");
	 jbcmp.put("parameters",jbparamarray);
	 
	 JSONArray jbcmparray=new JSONArray();
     jbcmparray.put(jbcmp);
		
     jtemp.put("components",jbcmparray);
		
     jb.put("template",jtemp);
     
     System.out.println("JSON="+jb.toString());
     
     json=jb.toString();
	
}


else if ( template_name.equals("agri_market3"))
{
	
	String cust_name=request.getParameter("cust_name");
	String percent=request.getParameter("percent");
	String shortlink=request.getParameter("shortlink");


	JSONObject jb = new JSONObject();
	jb.put("messaging_product","whatsapp");
	jb.put("to","91"+msisdn);
	jb.put("type","template");
	JSONObject jtemp= new JSONObject();
	jtemp.put("name", template_name);
	JSONObject jlang= new JSONObject();
	jlang.put("code","en");
	
   jtemp.put("language",jlang);
	
	JSONObject jbcmp=new JSONObject();
	
	jbcmp.put("type","header");
	 JSONObject jparam= new JSONObject();
	// jparam.put("type","text");
	// jparam.put("text",cust_name);
	 
	 JSONArray jbparamarray= new JSONArray();
	// jbparamarray.put(jparam);
	// jparam= new JSONObject();
	 jparam.put("type","image");
	 
	 JSONObject jparamimg= new JSONObject();
	 jparamimg.put("link","https://msg2all.com/"+image_file_name);
	 jparam.put("image",jparamimg);
	 jbparamarray.put(jparam);
	 jbcmp.put("type","header");
	 jbcmp.put("parameters",jbparamarray);
	 
	 JSONArray jbcmparray=new JSONArray();
     jbcmparray.put(jbcmp);
     
     
     
     JSONObject jparam3= new JSONObject();
	 jparam3.put("type","text");
	/* JSONObject jtext= new JSONObject();
	 jtext.put("body",shortlink);
	 jtext.put("preview_url",true);*/
	 
	 JSONArray jbparamarray1= new JSONArray();
		JSONObject jbcmp1=new JSONObject();

		jbcmp1.put("type","body");
	 	//jbcmp1.put("preview_url",true);
	 
	 jparam3.put("text",shortlink);
	 jbparamarray1.put(jparam3);
	 
 	 jbcmp1.put("type","body");
 	 jbcmp1.put("parameters",jbparamarray1);
 	 
     jbcmparray.put(jbcmp1);
     
     
     
		
     jtemp.put("components",jbcmparray);
		
     jb.put("template",jtemp);
     
     System.out.println("JSON="+jb.toString());
     
     json=jb.toString();
	
}
else if ( template_name.equals("orix_testtemplate"))
{
	String amount=request.getParameter("amount");
	String account_no=request.getParameter("account_no");
	String shortlink=request.getParameter("shortlink");
	

	JSONObject jb = new JSONObject();
	jb.put("messaging_product","whatsapp");
	jb.put("preview_url",true);
	jb.put("to","91"+msisdn);
	jb.put("type","template");
	JSONObject jtemp= new JSONObject();
	jtemp.put("name",template_name);
	JSONObject jlang= new JSONObject();
	jlang.put("code","en");
	
   jtemp.put("language",jlang);
   JSONObject jbcmp=new JSONObject();
   JSONObject jparam= new JSONObject();
	 
	 JSONArray jbparamarray= new JSONArray();
	 
	 
	 jparam= new JSONObject();
	 
	 
	 JSONObject jparamimg= new JSONObject();
	 
	 jparamimg.put("link","https://api.anymsg.in/MYPDF/"+image_file_name);
	 jparamimg.put("filename",image_file_name);
	 jparam.put("document",jparamimg);
	 jparam.put("type","document");
	 
	 jbparamarray.put(jparam);
	 
	 
	 jbcmp.put("type","header");
	 jbcmp.put("parameters",jbparamarray);
	 
	 JSONArray jbcmparray=new JSONArray();
     jbcmparray.put(jbcmp);
     
     
     
     
     JSONObject jbcmp1=new JSONObject();
 	
 	jbcmp1.put("type","body");
 	jbcmp1.put("preview_url",true);

 	 JSONObject jparam1= new JSONObject();
 	 jparam1.put("type","text");
 	 jparam1.put("text",amount);
 	 
 	 JSONArray jbparamarray1= new JSONArray();
 	 jbparamarray1.put(jparam1);
 	 JSONObject jparam2= new JSONObject();
 	 jparam2.put("type","text");
 	 jparam2.put("text",account_no);
 	 jbparamarray1.put(jparam2);
 	 
 	JSONObject jparam3= new JSONObject();
	 jparam3.put("type","text");
	/* JSONObject jtext= new JSONObject();
	 jtext.put("body",shortlink);
	 jtext.put("preview_url",true);*/
	 
	 jparam3.put("text",shortlink);
	 jbparamarray1.put(jparam3);
	 
 	 jbcmp1.put("type","body");
 	 jbcmp1.put("parameters",jbparamarray1);
     jbcmparray.put(jbcmp1);

 	 
 	
    
 	 
 
	 
	 jtemp.put("components",jbcmparray);
		
     jb.put("template",jtemp);
     
     System.out.println("JSON="+jb.toString());
     
     json=jb.toString();
	
}
else if ( template_name.equals("temp2"))
{

        JSONObject jb = new JSONObject();
        jb.put("messaging_product","whatsapp");
        jb.put("to","91"+msisdn);
        jb.put("type","template");
        JSONObject jtemp= new JSONObject();
        jtemp.put("name",template_name);
        JSONObject jlang= new JSONObject();
        if(template_name.equals("temp2"))
        {
                jlang.put("code","hi");
        }

   jtemp.put("language",jlang);

        JSONObject jbcmp=new JSONObject();

        jbcmp.put("type","body");
      //   jbcmp.put("parameters",jbparamarray);

         JSONArray jbcmparray=new JSONArray();
     jbcmparray.put(jbcmp);

     jtemp.put("components",jbcmparray);

     jb.put("template",jtemp);

     System.out.println("JSON="+jb.toString());

     json=jb.toString();
}

else if ( template_name.startsWith("orx") ||  template_name.startsWith("orix"))
{

	
	String amount=request.getParameter("amount");
	String account_no=request.getParameter("account_no");
	String shortlink=request.getParameter("shortlink");

	JSONObject jb = new JSONObject();
	jb.put("messaging_product","whatsapp");
	jb.put("preview_url",true);

	jb.put("to","91"+msisdn);
	jb.put("type","template");
	JSONObject jtemp= new JSONObject();
	jtemp.put("name",template_name);
	JSONObject jlang= new JSONObject();
	jlang.put("code","en");
	
   jtemp.put("language",jlang);
   JSONObject jbcmp=new JSONObject();
   JSONObject jparam= new JSONObject();
	 
	 JSONArray jbparamarray= new JSONArray();
	 
	 
	 jparam= new JSONObject();
	 
	 
	 JSONObject jparamimg= new JSONObject();
	 
	 jparamimg.put("link","https://api.anymsg.in/MYPDF/"+image_file_name);
	 jparamimg.put("filename",image_file_name);
	 jparam.put("document",jparamimg);
	 jparam.put("type","document");
	 
	 jbparamarray.put(jparam);
	 
	 
	 jbcmp.put("type","header");
	 jbcmp.put("parameters",jbparamarray);
	 
	 JSONArray jbcmparray=new JSONArray();
     jbcmparray.put(jbcmp);
     
     
     
     
     JSONObject jbcmp1=new JSONObject();
 	
 	jbcmp1.put("type","body");
 	 JSONObject jparam1= new JSONObject();
 	 jparam1.put("type","text");
 	 jparam1.put("text",amount);
 	 
 	 JSONArray jbparamarray1= new JSONArray();
 	 jbparamarray1.put(jparam1);
 	 JSONObject jparam2= new JSONObject();
 	 jparam2.put("type","text");
 	 jparam2.put("text",account_no);
 	 jbparamarray1.put(jparam2);
 	 
 	JSONObject jparam3= new JSONObject();
	 jparam3.put("type","text");
	 jparam3.put("text",shortlink);
	 jbparamarray1.put(jparam3);
	 
 	 jbcmp1.put("type","body");
 	 jbcmp1.put("parameters",jbparamarray1);
     jbcmparray.put(jbcmp1);

 	 
 	
    
 	 
 
	 
	 jtemp.put("components",jbcmparray);
		
     jb.put("template",jtemp);
     
     System.out.println("JSON="+jb.toString());
     
     json=jb.toString();
	
}





WhatsAppMessage wa = new WhatsAppMessage();




String resp=wa.sendWhatsappJSONMsg(msisdn, json, account_id, conn, "");

//out.println(resp);
if ( !resp.equals("error"))
{

jstat.put("statusCode", "0");

jres.put("status", jstat);
jout.put("result", jres);
jout.put("msg_id", resp);

out.println( jout.toString());
return;


}

jstat.put("statusCode", "1");
jstat.put("errCode","101");
jstat.put("errMessage","Message Failed resp");


jres.put("status", jstat);
jout.put("result", jres);
out.println( jout.toString());

return;












              
                
                               
                                
                                  
                                   
           
                
               
} catch (Exception e) {

e.printStackTrace();


jstat.put("statusCode", "1");
           jstat.put("errorCode","101");
           jstat.put("errorMessage","UNKNOWN_ERROR");
           jres.put("status", jstat);
           jout.put("result", jres);
          out.println( jout.toString());

/* 18 */
/*    */     }finally{
                        try{
                        	conn.close();
                        }catch(Exception exx)
                                                               {
                            
                        }
                    }



%>
