package callback;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.*;
import java.util.Date;
import java.util.Hashtable;
import java.util.UUID;

public class CallBackMain {
    public static void main(String[] args) {
        System.out.println("New version CallBack");

        try (
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/smartivr_cloud", "oditata", "PowTata@987");
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT id, channel_id FROM smartivr_cloud.dtmf_channel WHERE account_id = 108 AND digit = 2 AND pflag = 0");
        ) {
            while (rs.next()) {
                String channel_id = rs.getString("channel_id");
                String id = rs.getString("id");

                try (
                    Connection conn1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/campaign_tpcodlop", "root", "");
                    Statement st1 = conn1.createStatement();
                    ResultSet rs2 = st1.executeQuery("SELECT incoming_number, group_name, start_call_date FROM smartivr_cloud.incoming_call_log WHERE call_id = '" + channel_id + "' and start_call_date < now() - interval 30 SECOND");
                ) {
                    if (rs2.next()) {
                        String incoming_number = rs2.getString("incoming_number");
                        String group_name = rs2.getString("group_name");
                        String start_call_date = rs2.getString("start_call_date");

                        System.out.println("Processed " + incoming_number);

                        String record_id = UUID.randomUUID().toString();

                        String sql1 = "INSERT INTO campaign_tpcodlop.callback_tab(account_id, msisdn, callback_date_time, record_status, record_id, campaign, created_on, created_by, agent_group) VALUES (108, ?, ?, 'active', ?, 'callback', NOW(), 'system', ?)";
                        try (PreparedStatement pst1 = conn1.prepareStatement(sql1)) {
                            pst1.setString(1, incoming_number);
                            pst1.setString(2, start_call_date);
                            pst1.setString(3, record_id);
                            pst1.setString(4, group_name);
                            pst1.executeUpdate();
                        }

                        String sql2 = "INSERT INTO campaign_tpcodlop.account_outbound(account_id, msisdn, record_status, record_id, campaign_name, request_date, agent_group) VALUES (108, ?, 'active', ?, 'callback', NOW(), ?)";
                        try (PreparedStatement pst2 = conn1.prepareStatement(sql2)) {
                            pst2.setString(1, incoming_number);
                            pst2.setString(2, record_id);
                            pst2.setString(3, group_name);
                            pst2.executeUpdate();
                        }

                        String sql3 = "UPDATE smartivr_cloud.dtmf_channel SET pflag = 1 WHERE id = ?";
                        try (PreparedStatement pst3 = conn.prepareStatement(sql3)) {
                            pst3.setString(1, id);
                            pst3.executeUpdate();
                        }
                    }
                }
            }

            System.out.println("Now DB POOL started");
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Exiting the system..");
        }
    }
}