package callback;

public class CallInformation
{
  String msisdn = "";
 
  String id = "";
  String account_id="";
  String calltime="";
  String type="";
  String callref="";
  
  
  
  
  
  
}