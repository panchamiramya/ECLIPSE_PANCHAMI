package callback;

import java.io.PrintStream;
import com.twilio.rest.api.v2010.account.Message;

import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.UUID;

import org.json.JSONObject;


public class Job
  implements Runnable
{
  CallInformation ci;
  MyDBPool dbPool;
  String dbuserid="";
  String dbpasswd="";

  public Job(CallInformation ci, MyDBPool dbPool,String dbuserid, String dbpasswd)
  {
    this.ci = ci;
    this.dbPool = dbPool;
    this.dbuserid=dbuserid;
    this.dbpasswd=dbpasswd;
  }

  public void run()
  {
    inserttoDataBase(this.ci);
  }
  
 

  public void inserttoDataBase(CallInformation ci)
  {
	  Connection conn = null;
    try
    {
    

       conn = null;
     
    	
    	 String res="";
    	 String url="";
     	conn = this.dbPool.getConnection();


     	String sql="";
     	String msisdn=ci.msisdn;
     	String account_id=ci.account_id;
     	String callref=ci.callref;
     	String type=ci.type;
     	String calltime=ci.calltime;
     	
     	
     	
     //	String url="";
     	String resp=HTTPRequest.getResponse(url);
     	//this.logger.info(resp);
     	Statement st1=conn.createStatement();
        st1.executeUpdate("update queue_detail set sflag=2 where id="+ci.id);

     	
     	
     	
     			
     	
     	
        
     	
                 
     			

     	
    	  
      }
      catch (Exception ex)
      {
        ex.printStackTrace();
        try
        {
          if (conn == null)
            return;
          
        }
        catch (Exception localException1)
        {
        }
      }
      finally
      {
        try
        {
          if (conn != null)
          {
            conn.close();
          }
        }
        catch (Exception localException2)
        {
        }
      }
     

    
   
  }
}