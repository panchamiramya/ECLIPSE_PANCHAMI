package callback;

import java.io.PrintStream;

class ThreadTask extends Thread
{
  private ThreadPool pool;

  public ThreadTask(ThreadPool thePool)
  {
    this.pool = thePool;
  }

  public void run()
  {
    while (true) {
      Runnable job = this.pool.getNext();
      try {
        job.run();
      }
      catch (Exception e) {
        System.err.println("Job exception: " + e);
      }
    }
  }
}