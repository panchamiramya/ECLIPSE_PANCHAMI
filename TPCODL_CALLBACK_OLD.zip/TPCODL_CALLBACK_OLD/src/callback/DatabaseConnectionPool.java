package callback;


import java.io.PrintStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.Iterator;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.logging.Logger;

public class DatabaseConnectionPool implements Runnable
{
  ConcurrentLinkedQueue<Connection> connectionQueue;
  String dburl = "";
  String dbuser = "";
  String dbpasswd = "";
  boolean isFaulty = false;

  public static boolean checkConnection(Connection connect) {
    try {
      Statement st = connect.createStatement();
      st.execute("show databases");
    }
    catch (Exception e) {
      return false;
    }
    return true;
  }
  private int no_of_conns=0;
  private int total_conns=0;
  private Logger logger=null;
  
  
  
  public void run()
  {
	  while ( true)
	  {
	  Iterator<Connection> itr = connectionQueue.iterator();
	  
      // hasNext() returns true if the queue has more elements
	  Connection conn =null;
      while (itr.hasNext())
      {
          // next() returns the next element in the iteration
           conn=itr.next();
          String sql = "select 1 ";
          try
          {
          Statement st = conn.createStatement();
          st.executeQuery(sql);
          st.close();
          }
          catch ( SQLException ex)
          {
        	  break;
          }
      }
      if ( conn !=null)
      {
    	  connectionQueue.remove(conn);
    	  logger.severe("One connection got bad");
    	  total_conns=total_conns-1;
    	  no_of_conns=no_of_conns-1;
    	  
      }
      try
      {
      Thread.sleep(30000L);
      }
      catch( Exception ex)
      {
    	  
      }
	  }
  }
  
  public void printConnnections()
  {
	 logger.info("CREATED CONNS="+total_conns+":"+"Left in pool="+no_of_conns);
  }
  
  
  
  
  public Connection getConnection()
  {
    if (this.connectionQueue != null)
    {
      Connection con = (Connection)this.connectionQueue.poll();
     
      
      try {
    	  Statement st=con.createStatement();
       st.execute("show databases");
       st.close();
      //  con.close();
      } catch (Exception e) {
        con = null;
        
      }
      if ( con !=null)
      {
    	  no_of_conns=no_of_conns-1;
    	  return con;
      }
      int i=0;
      while ((con == null)) {
    	  if ( i > 10)
    	  {
    		  return con;
    	  }
    	  else
    	  {
    		  try
    		  {
    		  Thread.sleep(1000L);
    		  }
    		  catch ( Exception ex)
    		  {
    			  
    		  }
    	  }
        try {
          con = createConnection();
          logger.warning("New connection created, - No more connections in pool");
          total_conns=total_conns+1;
          
          //this.connectionQueue.offer(con);
          
          Statement st=con.createStatement();
          st.execute("show databases");
          st.close();
          //con.close();
          
        } catch (Exception ex) {
         // sleepThread(5000);
          //count++;
         // System.out.println("Unable to create connection "+new Date()+"::"+this.connectionQueue.size());
          con = null;
        }
        if ( con !=null)
        {
      	  return con;
        }
      }

      return con;
    }

    return null;
  }

  private void sleepThread(int interval) {
    try {
      Thread.sleep(interval); } catch (Exception localException) {
    }
  }

  public void putConnection(Connection conn) {
    this.connectionQueue.offer(conn);
    try
    {
    conn.setAutoCommit(true);
    }
    catch ( Exception ex)
    {
    	
    }

    this.no_of_conns=this.no_of_conns+1;
  }

  private Connection createConnection() throws Exception {
    Class.forName("com.mysql.jdbc.Driver").newInstance();

    return DriverManager.getConnection(this.dburl, 
      this.dbuser, this.dbpasswd);
  }
  public DatabaseConnectionPool(String dburl, String dbuserid, String dbpasswd,int no_of_conns,Logger logger) {
    this.connectionQueue = new ConcurrentLinkedQueue();
    this.dburl = dburl;
    this.dbuser = dbuserid;
    this.dbpasswd = dbpasswd;
    this.no_of_conns=no_of_conns;
    this.total_conns=no_of_conns;
    this.logger=logger;
    for (int i = 0; i < no_of_conns; i++)
    {
      try
      {
        Connection conn = createConnection();
        conn.setAutoCommit(true);
        this.connectionQueue.add(conn);
      }
      catch (Exception e)
      {
        logger.severe(e.getMessage());
        logger.severe("Unable to create connection");
        System.exit(-1);
        this.isFaulty = true;
        break;
      }
    }
    new Thread(this).start();
  }
}