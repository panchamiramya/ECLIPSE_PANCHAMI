package callback;

import java.io.PrintStream;
import java.util.LinkedList;

public class ThreadPool
{
  private LinkedList<Runnable> tasks = new LinkedList();
  public static int stopflag=0;
  public static int noofstops=0;
  
  public int getNoTasks()
  {
    int count = 0;
    synchronized (this.tasks)
    {
      count = this.tasks.size();
    }
    return count;
  }
  
  public ThreadPool(int size)
  {
    for (int i = 0; i < size; i++)
    {
      Thread thread = new ThreadTask(this);
      thread.start();
    }
  }
  
  public void run(Runnable task)
  {
    synchronized (this.tasks)
    {
      this.tasks.addLast(task);
      this.tasks.notify();
    }
    
  }
  
  public void notifyme ()
  {
	  this.tasks.notify();
  }
  public void notifyall ()
  {
	  synchronized (this.tasks)
	    {
	  this.tasks.notifyAll();
	    }
  }
  public Runnable getNext()
  {
    Runnable returnVal = null;
    synchronized (this.tasks)
    {
      while (this.tasks.isEmpty()) {
        try
        {
          if ( stopflag == 1)
          {
        	  noofstops = noofstops+1;
        	  System.out.println("Stop processed..Thread is waiting now");
        	  this.tasks.wait();;
        	 
          }
          
          this.tasks.wait();
          
        }
        catch (InterruptedException ex)
        {
          System.err.println("Interrupted");
        }
      }
      returnVal = (Runnable)this.tasks.removeFirst();
    }
    return returnVal;
  }
}
