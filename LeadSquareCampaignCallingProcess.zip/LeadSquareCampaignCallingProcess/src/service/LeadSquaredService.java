package service;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.LocalDateTime;

import util.AppLogger;
import util.ConfigLoader;

public class LeadSquaredService {

    private final ConfigLoader config;

    private final AppLogger logger;

    public LeadSquaredService(
            ConfigLoader config,
            AppLogger logger) {

        this.config = config;
        this.logger = logger;
    }

    public boolean sendPopup(
            String sourceNumber,
            String destinationNumber,
            String displayNumber,
            String agentId,
            String recordId,
            String channelId) {

        HttpURLConnection conn = null;

        try {

            String startTime = LocalDateTime.now().toString();

            String payload =
                    "{"
                    + "\"SourceNumber\":\"" + safe(sourceNumber) + "\","
                    + "\"DestinationNumber\":\"" + safe(destinationNumber) + "\","
                    + "\"DisplayNumber\":\"" + safe(displayNumber) + "\","
                    + "\"Status\":\"Answered\","
                    + "\"Direction\":\"clickToCall\","
                    + "\"CallSessionId\":\"" + safe(channelId) + "\","
                    + "\"StartTime\":\"" + safe(startTime) + "\","
                    + "\"AgentId\":\"" + safe(agentId) + "\","
                    + "\"OpportunityTelephonyMappingId\":\"O$" + safe(recordId) + "\","
                    + "\"CallDuration\":\"0\""
                    + "}";

            logger.log("LSQ REQUEST: " + payload);

            URL url = new URL(config.get("lsq.url"));

            conn = (HttpURLConnection) url.openConnection();

            conn.setRequestMethod("POST");

            conn.setDoOutput(true);

            conn.setConnectTimeout(
                    config.getInt("lsq.connect.timeout.ms", 10000));

            conn.setReadTimeout(
                    config.getInt("lsq.read.timeout.ms", 15000));

            conn.setRequestProperty(
                    "Content-Type",
                    "application/json");

            OutputStream os = conn.getOutputStream();

            os.write(payload.getBytes("UTF-8"));

            os.flush();

            os.close();

            int code = conn.getResponseCode();

            String body;

            if (code >= 200 && code < 300) {

                body = readResponseBody(
                        conn.getInputStream());

            } else {

                body = readResponseBody(
                        conn.getErrorStream());
            }

            logger.log("LSQ RESPONSE CODE: " + code);

            logger.log("LSQ RESPONSE BODY: " + body);

            return (code >= 200 && code < 300);

        } catch (Exception e) {

            logger.log(
                    "LSQ API ERROR: " + e.getMessage());

            e.printStackTrace();

            return false;

        } finally {

            if (conn != null) {

                conn.disconnect();
            }
        }
    }

    private String readResponseBody(InputStream is) {

        if (is == null) {

            return "";
        }

        StringBuilder sb = new StringBuilder();

        BufferedReader br = null;

        try {

            br = new BufferedReader(
                    new InputStreamReader(is));

            String line;

            while ((line = br.readLine()) != null) {

                sb.append(line);
            }

        } catch (Exception e) {

            return "";

        } finally {

            try {

                if (br != null) {

                    br.close();
                }

            } catch (Exception e) {
            }
        }

        return sb.toString();
    }

    private String safe(String s) {

        return (s == null)
                ? ""
                : s.replace("\"", "\\\"");
    }
}