package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import java.util.ArrayList;
import java.util.List;

import model.AccountInfoData;
import model.AgentData;
import model.CampaignStatusData;
import model.OutboundData;

import util.AppLogger;

public class ProcessorService {

    private final AppLogger logger;

    private final LeadSquaredService leadSquaredService;

    public ProcessorService(
            AppLogger logger,
            LeadSquaredService leadSquaredService) {

        this.logger = logger;
        this.leadSquaredService = leadSquaredService;
    }

    public void process(
            Connection leadConn,
            Connection smartConn) throws Exception {

        List<CampaignStatusData> campaigns =
                getRunningCampaigns(leadConn);

        logger.log(
                "Eligible running campaigns found : "
                        + campaigns.size());

        for (CampaignStatusData campaign : campaigns) {

            try {

                processCampaign(
                        campaign,
                        leadConn,
                        smartConn);

            } catch (Exception e) {

                logger.log(
                        "Campaign processing failed : "
                                + campaign.campaignName
                                + " error="
                                + e.getMessage());

                e.printStackTrace();
            }
        }
    }

    private void processCampaign(
            CampaignStatusData campaign,
            Connection leadConn,
            Connection smartConn) throws Exception {

        logger.log(
                "Processing campaign="
                        + campaign.campaignName
                        + " predictive="
                        + campaign.isPredictive);

        AccountInfoData accountInfo =
                getAccountInfo(
                        smartConn,
                        campaign.accountId);

        if (accountInfo == null) {

            logger.log(
                    "No account info found");

            return;
        }

        String serverId =
                getActiveServerId(
                        smartConn,
                        campaign.accountId);

        if (serverId == null
                || serverId.trim().isEmpty()) {

            logger.log(
                    "No active server found");

            return;
        }

        if ("yes".equalsIgnoreCase(
                campaign.isPredictive)) {

            processPredictiveCampaign(
                    campaign,
                    accountInfo,
                    serverId,
                    leadConn,
                    smartConn);

        } else {

            processProgressiveCampaign(
                    campaign,
                    accountInfo,
                    serverId,
                    leadConn,
                    smartConn);
        }
    }

    /*
     * ============================================
     * PROGRESSIVE
     * ============================================
     */

    private void processProgressiveCampaign(
            CampaignStatusData campaign,
            AccountInfoData accountInfo,
            String serverId,
            Connection leadConn,
            Connection smartConn) throws Exception {

        OutboundData outbound =
                pickProgressiveOutbound(
                        leadConn,
                        campaign.accountId,
                        campaign.campaignName);

        if (outbound == null) {

            logger.log(
                    "No READY progressive outbound found");

            return;
        }

        String channelId = "";

        try {

            smartConn.setAutoCommit(false);

            long aocrId =
                    insertAccountOutgoingCallReq(
                            smartConn,
                            campaign.accountId,
                            outbound.msisdn,
                            outbound.agentMsisdn,
                            accountInfo.outgoingQueue,
                            accountInfo.callerId,
                            outbound.agentId,
                            campaign.campaignName,
                            outbound.recordId,
                            serverId,
                            outbound.lan);

            channelId =
                    getChannelIdById(
                            smartConn,
                            aocrId);

            smartConn.commit();

        } catch (Exception e) {

            smartConn.rollback();

            revertOutboundStatusToActive(
                    leadConn,
                    outbound.id);

            throw e;

        } finally {

            smartConn.setAutoCommit(true);
        }

        leadSquaredService.sendPopup(
                outbound.msisdn,
                outbound.agentMsisdn,
                accountInfo.callerId,
                outbound.agentId,
                outbound.recordId,
                channelId);

        logger.log(
                "Progressive call pushed : "
                        + outbound.agentId);
    }

    /*
     * ============================================
     * PREDICTIVE
     * ============================================
     */

    private void processPredictiveCampaign(
            CampaignStatusData campaign,
            AccountInfoData accountInfo,
            String serverId,
            Connection leadConn,
            Connection smartConn) throws Exception {

        AgentData agent =
                getLongestWaitingReadyAgent(
                        smartConn,
                        campaign.accountId,
                        campaign.campaignName);

        if (agent == null) {

            logger.log(
                    "No READY predictive agent");

            return;
        }

        OutboundData outbound =
                pickPredictiveOutbound(
                        leadConn,
                        campaign.accountId,
                        campaign.campaignName);

        if (outbound == null) {

            logger.log(
                    "No predictive outbound found");

            return;
        }

        String channelId = "";

        try {

            smartConn.setAutoCommit(false);

            long aocrId =
                    insertAccountOutgoingCallReq(
                            smartConn,
                            campaign.accountId,
                            outbound.msisdn,
                            agent.agentMsisdn,
                            accountInfo.outgoingQueue,
                            accountInfo.callerId,
                            agent.agentId,
                            campaign.campaignName,
                            outbound.recordId,
                            serverId,
                            outbound.lan);

            channelId =
                    getChannelIdById(
                            smartConn,
                            aocrId);

            smartConn.commit();

        } catch (Exception e) {

            smartConn.rollback();

            revertOutboundStatusToActive(
                    leadConn,
                    outbound.id);

            throw e;

        } finally {

            smartConn.setAutoCommit(true);
        }

        leadSquaredService.sendPopup(
                outbound.msisdn,
                agent.agentMsisdn,
                accountInfo.callerId,
                agent.agentId,
                outbound.recordId,
                channelId);

        logger.log(
                "Predictive call pushed : "
                        + agent.agentId);
    }

    /*
     * ============================================
     * GET RUNNING CAMPAIGNS
     * ============================================
     */

    private List<CampaignStatusData> getRunningCampaigns(
            Connection conn) throws Exception {

        String sql =
                "SELECT * "
                        + "FROM campaign_status "
                        + "WHERE status='running' "
                        + "AND CURDATE() BETWEEN start_date AND end_date "
                        + "AND CURTIME() BETWEEN from_time AND to_time";

        List<CampaignStatusData> list =
                new ArrayList<>();

        PreparedStatement ps = null;
        ResultSet rs = null;

        try {

            ps = conn.prepareStatement(sql);

            rs = ps.executeQuery();

            while (rs.next()) {

                CampaignStatusData c =
                        new CampaignStatusData();

                c.accountId =
                        rs.getString("account_id");

                c.campaignName =
                        rs.getString("campaign_name");

                c.isPredictive =
                        rs.getString("is_predictive");

                list.add(c);
            }

        } finally {

            if (rs != null)
                rs.close();

            if (ps != null)
                ps.close();
        }

        return list;
    }

    /*
     * ============================================
     * ACCOUNT INFO
     * ============================================
     */

    private AccountInfoData getAccountInfo(
            Connection conn,
            String accountId) throws Exception {

        String sql =
                "SELECT outgoing_queue, callerid "
                        + "FROM account_info "
                        + "WHERE account_id=?";

        PreparedStatement ps = null;
        ResultSet rs = null;

        try {

            ps = conn.prepareStatement(sql);

            ps.setString(1, accountId);

            rs = ps.executeQuery();

            if (rs.next()) {

                AccountInfoData a =
                        new AccountInfoData();

                a.outgoingQueue =
                        rs.getString("outgoing_queue");

                a.callerId =
                        rs.getString("callerid");

                return a;
            }

        } finally {

            if (rs != null)
                rs.close();

            if (ps != null)
                ps.close();
        }

        return null;
    }

    /*
     * ============================================
     * SERVER
     * ============================================
     */

    private String getActiveServerId(
            Connection conn,
            String accountId) throws Exception {

        String sql =
                "SELECT server_id "
                        + "FROM outgoing_server "
                        + "WHERE isActive='1' "
                        + "AND account_id=? "
                        + "LIMIT 1";

        PreparedStatement ps = null;
        ResultSet rs = null;

        try {

            ps = conn.prepareStatement(sql);

            ps.setString(1, accountId);

            rs = ps.executeQuery();

            if (rs.next()) {

                return rs.getString("server_id");
            }

        } finally {

            if (rs != null)
                rs.close();

            if (ps != null)
                ps.close();
        }

        return null;
    }

    /*
     * ============================================
     * READY AGENT
     * ============================================
     */

    private AgentData getLongestWaitingReadyAgent(
            Connection conn,
            String accountId,
            String campaignName) throws Exception {

        String sql =
                "SELECT agent_id, agent_msisdn "
                        + "FROM smartivr_cloud.agent_detail "
                        + "WHERE account_id=? "
                        + "AND campaign_name=? "
                        + "AND LOWER(agent_status)='ready' "
                        + "AND LOWER(is_login)='yes' "
                        + "ORDER BY agent_status_date ASC "
                        + "LIMIT 1";

        PreparedStatement ps = null;
        ResultSet rs = null;

        try {

            ps = conn.prepareStatement(sql);

            ps.setString(1, accountId);
            ps.setString(2, campaignName);

            rs = ps.executeQuery();

            if (rs.next()) {

                AgentData a =
                        new AgentData();

                a.agentId =
                        rs.getString("agent_id");

                a.agentMsisdn =
                        rs.getString("agent_msisdn");

                return a;
            }

        } finally {

            if (rs != null)
                rs.close();

            if (ps != null)
                ps.close();
        }

        return null;
    }

    /*
     * ============================================
     * PROGRESSIVE PICK
     * ============================================
     */

    private OutboundData pickProgressiveOutbound(
            Connection conn,
            String accountId,
            String campaignName) throws Exception {

        conn.setAutoCommit(false);

        PreparedStatement ps = null;
        ResultSet rs = null;

        try {

            String sql =
                    "SELECT ao.id, "
                            + "ao.msisdn, "
                            + "ao.agent_id, "
                            + "ao.record_id, "
                            + "ao.lan, "
                            + "ad.agent_msisdn "
                            + "FROM account_outbound ao "
                            + "INNER JOIN smartivr_cloud.agent_detail ad "
                            + "ON ao.agent_id=ad.agent_id "
                            + "AND ao.account_id=ad.account_id "
                            + "AND ao.campaign_name=ad.campaign_name "
                            + "WHERE ao.account_id=? "
                            + "AND ao.campaign_name=? "
                            + "AND ao.record_status='active' "
                            + "AND LOWER(ad.agent_status)='ready' "
                            + "AND LOWER(ad.is_login)='yes' "
                            + "ORDER BY ao.id ASC "
                            + "LIMIT 1 FOR UPDATE";

            ps = conn.prepareStatement(sql);

            ps.setString(1, accountId);
            ps.setString(2, campaignName);

            rs = ps.executeQuery();

            if (!rs.next()) {

                conn.commit();

                return null;
            }

            OutboundData o =
                    new OutboundData();

            o.id =
                    rs.getLong("id");

            o.msisdn =
                    rs.getString("msisdn");

            o.agentId =
                    rs.getString("agent_id");

            o.recordId =
                    rs.getString("record_id");

            o.lan =
                    rs.getString("lan");

            o.agentMsisdn =
                    rs.getString("agent_msisdn");

            PreparedStatement ups =
                    conn.prepareStatement(
                            "UPDATE account_outbound "
                                    + "SET record_status='retrive' "
                                    + "WHERE id=?");

            ups.setLong(1, o.id);

            ups.executeUpdate();

            ups.close();

            conn.commit();

            return o;

        } catch (Exception e) {

            conn.rollback();

            throw e;

        } finally {

            conn.setAutoCommit(true);

            if (rs != null)
                rs.close();

            if (ps != null)
                ps.close();
        }
    }

    /*
     * ============================================
     * PREDICTIVE PICK
     * ============================================
     */

    private OutboundData pickPredictiveOutbound(
            Connection conn,
            String accountId,
            String campaignName) throws Exception {

        conn.setAutoCommit(false);

        try {

            String sql =
                    "SELECT id, msisdn, record_id, lan "
                            + "FROM account_outbound "
                            + "WHERE account_id=? "
                            + "AND campaign_name=? "
                            + "AND record_status='active' "
                            + "ORDER BY id ASC "
                            + "LIMIT 1 FOR UPDATE";

            PreparedStatement ps =
                    conn.prepareStatement(sql);

            ps.setString(1, accountId);
            ps.setString(2, campaignName);

            ResultSet rs =
                    ps.executeQuery();

            if (!rs.next()) {

                conn.commit();

                return null;
            }

            OutboundData o =
                    new OutboundData();

            o.id =
                    rs.getLong("id");

            o.msisdn =
                    rs.getString("msisdn");

            o.recordId =
                    rs.getString("record_id");

            o.lan =
                    rs.getString("lan");

            rs.close();
            ps.close();

            PreparedStatement ups =
                    conn.prepareStatement(
                            "UPDATE account_outbound "
                                    + "SET record_status='retrive' "
                                    + "WHERE id=?");

            ups.setLong(1, o.id);

            ups.executeUpdate();

            ups.close();

            conn.commit();

            return o;

        } catch (Exception e) {

            conn.rollback();

            throw e;

        } finally {

            conn.setAutoCommit(true);
        }
    }

    /*
     * ============================================
     * REVERT
     * ============================================
     */

    private void revertOutboundStatusToActive(
            Connection conn,
            long id) throws Exception {

        PreparedStatement ps = null;

        try {

            ps = conn.prepareStatement(
                    "UPDATE account_outbound "
                            + "SET record_status='active' "
                            + "WHERE id=?");

            ps.setLong(1, id);

            ps.executeUpdate();

        } finally {

            if (ps != null)
                ps.close();
        }
    }

    /*
     * ============================================
     * INSERT CALL
     * ============================================
     */

    private long insertAccountOutgoingCallReq(
            Connection conn,
            String accountId,
            String outgoingNo,
            String agentMsisdn,
            String queueNo,
            String callerId,
            String agentId,
            String campaignName,
            String recordId,
            String serverId,
            String crn) throws Exception {

        String sql =
                "INSERT INTO account_outgoing_call_req "
                        + "(account_id,outgoing_no,agent_msisdn,"
                        + "req_date,queue_no,callerid,retry_cnt,"
                        + "retry_interval,treatment,agent_id,src,"
                        + "record_id,campaign_name,server_id,crn,call_ref1) "
                        + "VALUES "
                        + "(?,?,?,NOW(),?,?,2,30,"
                        + "'AGENTONLYCALLBACK',?,?,?,?,?,?,'fromjar')";

        PreparedStatement ps = null;

        try {

            ps = conn.prepareStatement(
                    sql,
                    Statement.RETURN_GENERATED_KEYS);

            ps.setString(1, accountId);
            ps.setString(2, outgoingNo);
            ps.setString(3, agentMsisdn);
            ps.setString(4, queueNo);
            ps.setString(5, callerId);
            ps.setString(6, agentId);
            ps.setString(7, campaignName);
            ps.setString(8, recordId);
            ps.setString(9, campaignName);
            ps.setString(10, serverId);
            ps.setString(11, crn);

            ps.executeUpdate();

            ResultSet rs =
                    ps.getGeneratedKeys();

            if (rs.next()) {

                return rs.getLong(1);
            }

            rs.close();

        } finally {

            if (ps != null)
                ps.close();
        }

        throw new RuntimeException(
                "Insert failed");
    }

    /*
     * ============================================
     * CHANNEL ID
     * ============================================
     */

    private String getChannelIdById(
            Connection conn,
            long id) throws Exception {

        String sql =
                "SELECT channel_id "
                        + "FROM account_outgoing_call_req "
                        + "WHERE id=?";

        PreparedStatement ps = null;
        ResultSet rs = null;

        try {

            ps = conn.prepareStatement(sql);

            ps.setLong(1, id);

            rs = ps.executeQuery();

            if (rs.next()) {

                return rs.getString("channel_id");
            }

        } finally {

            if (rs != null)
                rs.close();

            if (ps != null)
                ps.close();
        }

        return "";
    }
}