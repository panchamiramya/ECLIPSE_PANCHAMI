package main;

import db.DBConnection;
import java.time.LocalTime;
import service.LeadSquaredService;
import service.ProcessorService;
import util.AppLogger;
import util.ConfigLoader;

public class LeadSquareCampaignProcessorMain {
  public static void main(String[] args) {
    String configPath = "config/config.properties";
    if (args != null && args.length > 0 && args[0] != null && !args[0].trim().isEmpty())
      configPath = args[0]; 
    try {
      ConfigLoader config = new ConfigLoader(configPath);
      AppLogger logger = new AppLogger(config.get("log.file"));
      DBConnection db = new DBConnection(config);
      LeadSquaredService leadSquaredService = new LeadSquaredService(config, logger);
      ProcessorService processorService = new ProcessorService(logger, leadSquaredService);
      LocalTime allowedStart = config.getTime("process.window.start");
      LocalTime allowedEnd = config.getTime("process.window.end");
      logger.log("Processor started. Window: " + allowedStart + " to " + allowedEnd);
      while (true) {
        try {
          LocalTime now = LocalTime.now();
          if (!now.isBefore(allowedStart) && !now.isAfter(allowedEnd)) {

        	    logger.log("Current time inside process window. Starting cycle.");

        	    java.sql.Connection leadConn = null;
        	    java.sql.Connection smartConn = null;

        	    try {

        	        leadConn = db.getCampaignConnection();

        	        smartConn = db.getSmartConnection();

        	        processorService.process(leadConn, smartConn);

        	    } finally {

        	        if (leadConn != null) {
        	            leadConn.close();
        	        }

        	        if (smartConn != null) {
        	            smartConn.close();
        	        }
        	    }

        	} else {

        	    logger.log("Current time outside process window. Skipping cycle.");
        	}
        } catch (Exception e) {
          logger.log("Cycle error: " + e.getMessage());
          e.printStackTrace();
        } 
        try {
          Thread.sleep(60000L);
        } catch (InterruptedException e) {
          Thread.currentThread().interrupt();
          logger.log("Processor interrupted. Exiting.");
          break;
        } 
      } 
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
}
