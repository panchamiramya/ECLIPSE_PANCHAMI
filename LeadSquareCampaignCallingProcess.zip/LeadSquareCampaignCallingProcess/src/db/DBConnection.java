package db;

import java.sql.Connection;
import java.sql.DriverManager;

import util.ConfigLoader;

public class DBConnection {

    private final ConfigLoader config;

    public DBConnection(ConfigLoader config) {
        this.config = config;
    }

    static {

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public Connection getConnection(String dbName) throws Exception {

        String urlPrefix = this.config.get("db.host");

        String user = this.config.get("db.user");

        String password = this.config.get("db.password");

        return DriverManager.getConnection(
                urlPrefix + dbName + "?useSSL=false&serverTimezone=UTC",
                user,
                password);
    }

    public Connection getCampaignConnection() throws Exception {

        String dbName = config.get("campaign.db");

        return getConnection(dbName);
    }

    public Connection getSmartConnection() throws Exception {

        String dbName = config.get("smartivr.db");

        return getConnection(dbName);
    }
}