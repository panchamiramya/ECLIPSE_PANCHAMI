package util;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.sql.Timestamp;
import java.time.LocalDateTime;

public class AppLogger {

    private final String logFile;

    public AppLogger(String logFile) {

        this.logFile = logFile;
    }

    public synchronized void log(String message) {

        String line =
                "[" + Timestamp.valueOf(LocalDateTime.now()) + "] "
                        + message;

        System.out.println(line);

        try {

            File file = new File(logFile);

            File parent = file.getParentFile();

            if (parent != null && !parent.exists()) {
                parent.mkdirs();
            }

            FileWriter fw = new FileWriter(file, true);

            PrintWriter pw = new PrintWriter(fw);

            pw.println(line);

            pw.flush();

            pw.close();

            fw.close();

        } catch (Exception e) {

            e.printStackTrace();
        }
    }
}