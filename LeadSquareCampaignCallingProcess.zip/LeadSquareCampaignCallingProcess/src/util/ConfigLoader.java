package util;

import java.io.FileInputStream;
import java.io.InputStream;
import java.time.LocalTime;
import java.util.Properties;

public class ConfigLoader {

    private final Properties props = new Properties();

    public ConfigLoader(String path) throws Exception {

        try (InputStream input = new FileInputStream(path)) {

            props.load(input);

        } catch (Exception e) {

            throw new Exception("Unable to load config file: " + path, e);
        }
    }

    public String get(String key) {

        return props.getProperty(key);
    }

    public int getInt(String key, int defaultValue) {

        String val = props.getProperty(key);

        if (val == null || val.trim().isEmpty()) {
            return defaultValue;
        }

        return Integer.parseInt(val.trim());
    }

    public LocalTime getTime(String key) {

        String value = props.getProperty(key);

        if (value == null || value.trim().isEmpty()) {
            throw new RuntimeException("Missing property: " + key);
        }

        return LocalTime.parse(value.trim());
    }
}