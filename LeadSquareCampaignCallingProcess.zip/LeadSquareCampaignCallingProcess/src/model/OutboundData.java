package model;

public class OutboundData {
  public long id;
  
  public String accountId;
  
  public String msisdn;
  
  public String agentId;
  
  public String agentMsisdn;
  
  public String campaignName;
  
  public String recordId;
  
  public String lan;
  
  public String campaignType;
}
