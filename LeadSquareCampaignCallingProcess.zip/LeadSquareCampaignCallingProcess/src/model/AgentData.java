package model;

import java.sql.Timestamp;

public class AgentData {
  public String agentId;
  
  public String agentMsisdn;
  
  public Timestamp agentStatusDate;
}
