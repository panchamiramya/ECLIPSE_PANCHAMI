package model;

public class AccountInfoData {
  public String outgoingQueue;
  
  public String queueNo;
  
  public String callerId;
}
