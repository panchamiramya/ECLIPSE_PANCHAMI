package model;

public class CampaignStatusData {
  public long id;
  
  public String accountId;
  
  public String campaignName;
  
  public String isPredictive;
  
  public String isAgentWise;
}
