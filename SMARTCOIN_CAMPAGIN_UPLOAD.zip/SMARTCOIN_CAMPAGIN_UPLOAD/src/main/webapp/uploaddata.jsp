<%@page import="smartcoin.LeadData"%>
<%@page import="java.io.*"%>
<%@page import="javax.servlet.*"%>
<%@page import="javax.servlet.http.*"%>
<%@page import="javax.json.*"%>
<%@page import="javax.naming.InitialContext"%>
<%@page import="javax.naming.Context"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="javax.sql.DataSource"%>
<%@page import="java.sql.*"%>

<%
    response.setContentType("application/json");
    response.addHeader("Freeflow", "FC");
    java.util.Date mydt = new java.util.Date();
    response.setDateHeader("Date", mydt.getTime());
    
    Connection conn = null;
    
    try {
        // Database connection setup
        Context ctx = new InitialContext();
        DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/campaign_smartcoin");
        conn = ds.getConnection();

        // Read JSON data from the request input stream
        StringBuilder requestData = new StringBuilder();
        try (BufferedReader br = request.getReader()) {
            String line;
            while ((line = br.readLine()) != null) {
                requestData.append(line);
            }
        }

        if (requestData.toString().trim().isEmpty()) {
            out.println("{\"status\": \"error\", \"message\": \"Empty or null JSON data.\"}");
            return;
        }

        try (JsonReader jsonReader = Json.createReader(new StringReader(requestData.toString()))) {
            JsonObject jsonData = jsonReader.readObject();
            
            String campaign_name = jsonData.getString("campaign_name");

            LeadData ld = new LeadData();
            String chkmsg = ld.processData("dhdjje888399w9w112ed", campaign_name, requestData.toString(), conn)
                                .replace("\\", "").replace("\n", "");
            out.println(chkmsg);
        }

    } catch (Exception e) {
        e.printStackTrace();
        out.println("{\"status\": \"error\", \"message\": \"Internal server error.\"}");
    } finally {
        try {
            if (conn != null) {
                conn.close();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
%>
