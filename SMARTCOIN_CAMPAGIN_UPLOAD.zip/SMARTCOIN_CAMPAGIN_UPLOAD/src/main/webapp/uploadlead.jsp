<%@ page import="java.io.*, java.util.*, org.json.*" %>
<%@ page contentType="application/json;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="java.util.ArrayList" %>

<%
    response.setContentType("application/json");
    response.setCharacterEncoding("UTF-8");

    try {
        // Reading JSON data from the request body
        StringBuilder buffer = new StringBuilder();
        BufferedReader reader = request.getReader();
        String line;
        while ((line = reader.readLine()) != null) {
            buffer.append(line);
        }

        // Parse JSON data
        JSONObject requestBody = new JSONObject(buffer.toString());

        // Extracting values from the JSON
        String authToken = requestBody.getString("authtoken");
        String campaignName = requestBody.getString("campaign_name");
        String fileName = requestBody.getString("filename");
        String fields = requestBody.getString("fields");
        JSONArray dataArray = requestBody.getJSONArray("data");

        // Process the data array
        List<String> processedData = new ArrayList<>();
        for (Object dataObj : dataArray) {
            if (dataObj instanceof JSONObject) {
                JSONObject data = (JSONObject) dataObj;
                String customerName = data.optString("customer_name", "");
                String msisdn = data.optString("msisdn", "");
                processedData.add("Customer Name: " + customerName + ", MSISDN: " + msisdn);
            }
        }

        // Construct the response JSON
        JSONObject jsonResponse = new JSONObject();
        jsonResponse.put("authToken", authToken);
        jsonResponse.put("campaignName", campaignName);
        jsonResponse.put("fileName", fileName);
        jsonResponse.put("fields", fields);
        jsonResponse.put("processedData", processedData);

        out.println(jsonResponse.toString());
    } catch (Exception e) {
        // Handle exceptions
        e.printStackTrace();

        // Send error response
        JSONObject errorResponse = new JSONObject();
        errorResponse.put("error", "An error occurred while processing the request.");
        out.println(errorResponse.toString());
    }
%>
