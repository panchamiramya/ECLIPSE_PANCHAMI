<%@page import="java.util.UUID"%>
<%@page import="java.text.NumberFormat"%>
<%@page import="javax.naming.InitialContext"%>
<%@page import="javax.naming.Context"%>
<%@page import="java.net.*"%>
<%@page import="java.sql.*"%>
<%@page import="javax.naming.InitialContext"%>
<%@page import="javax.naming.Context"%>
<%@ page import="java.io.InputStream"%>
<%@ page import="java.io.InputStreamReader"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="javax.sql.DataSource"%>
<%@page import="org.json.*"%>

<%
    response.setContentType("text/html");
    response.addHeader("Freeflow", "FC");
    java.util.Date mydt = new java.util.Date();
    response.setDateHeader("Date", mydt.getTime());
    Connection conn = null;
    Context ctx = new InitialContext();

    if (ctx == null) {
        throw new Exception("Boom - No Context");
    }
    Context envCtx = (Context) ctx.lookup("java:comp/env");
    DataSource ds = null;

    // final String AUTH_TOKEN = "59bfedb7bd610fc04cf9ea98f018888a";

    JSONObject jout = new JSONObject();
    JSONObject jres = new JSONObject();
    JSONObject jstat = new JSONObject();

    try {
        PreparedStatement ps1 = null; // For the first table
        PreparedStatement ps2 = null; // For the second table

        ds = (DataSource) envCtx.lookup("jdbc/campaign_smartcoin");

        if (ds != null) {
            try {
                conn = ds.getConnection();
            } catch (Exception ex) {

            }
        }

        String req_id = UUID.randomUUID().toString();
        String uuid = req_id;

        String customer_name = request.getParameter("customer_name");
        String msisdn = request.getParameter("msisdn");
        String mailingphone2 = request.getParameter("mailingphone2");
        String list_id = request.getParameter("list_id");
        String crn = request.getParameter("crn");
        String uid = request.getParameter("uid");

        // Insert into the first table
        String query1 = "insert into test_3rdjan2024_tab(customer_name, msisdn, mailingphone2, list_id, crn, uid) values(?,?,?,?,?,?)";
        if (ps1 == null) {
            ps1 = conn.prepareStatement(query1);
        }
        ps1.setString(1, customer_name);
        ps1.setString(2, msisdn);
        ps1.setString(3, mailingphone2);
        ps1.setString(4, list_id);
        ps1.setString(5, crn);
        ps1.setString(6, uid);
        ps1.addBatch();
        int rs1 = ps1.executeUpdate();

        // Insert into the second table
        String query2 = "insert into account_outbound(msisdn) values(?)"; // Replace with your actual column names
        if (ps2 == null) {
            ps2 = conn.prepareStatement(query2);
        }
        ps2.setString(1, msisdn); // Replace with the actual values
        ps2.addBatch();
        int rs2 = ps2.executeUpdate();

        jstat.put("statusCode", "0");

        jres.put("status", jstat);
        jres.put("req_id", req_id);
        jout.put("result", jres);
        // out.println( jout.toString());
        out.println(jout.toString());
        return;

    } catch (SQLException ex) {
        ex.printStackTrace();
        jstat.put("statusCode", "1");
        jstat.put("errorCode", "110");
        jstat.put("errorMessage", "DB Error");
        jres.put("status", jstat);
        jout.put("result", jres);
        out.println(jout.toString());
    } catch (Exception ex) {
        ex.printStackTrace();
        jstat.put("statusCode", "1");
        jstat.put("errorCode", "105");
        jstat.put("errorMessage", "Unknown Error");
        jres.put("status", jstat);
        jout.put("result", jres);
        out.println(jout.toString());

    } finally {
        try {
            conn.close();
        } catch (Exception ex) {

        }
    }
%>
