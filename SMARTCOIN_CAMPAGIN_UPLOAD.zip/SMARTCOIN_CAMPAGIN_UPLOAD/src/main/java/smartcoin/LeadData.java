package smartcoin;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.mysql.jdbc.exceptions.MySQLIntegrityConstraintViolationException;

public class LeadData extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public String processData(String authtoken, String campaignName, String leadData, Connection conn) {
        try {
            if (leadData == null || leadData.trim().isEmpty()) {
                return "{\"status\": \"error\", \"message\": \"Empty or null JSON data.\"}";
            }

            // Parse JSON data
            JSONParser parser = new JSONParser();
            JSONObject jsonData = (JSONObject) parser.parse(leadData);
            System.out.println("Parsed JSON Data: " + jsonData.toString());

            String authTokenFromRequest = (String) jsonData.get("authtoken");
            String campaignNameFromRequest = (String) jsonData.get("campaign_name");
            JSONArray leadsArray = (JSONArray) jsonData.get("leads");

            if (!authtoken.equals(authTokenFromRequest) || !campaignName.equals(campaignNameFromRequest)) {
                return "{\"status\": \"error\", \"message\": \"Invalid authtoken or campaign_name.\"}";
            }

            for (Object leadObject : leadsArray) {
                JSONObject lead = (JSONObject) leadObject;
                insertLeadIntoDatabase(lead, conn);
                insertLeadIntoAccountOutboundTable(lead, conn);
            }

            return "{\"status\": \"success\", \"message\": \"Leads inserted into the database successfully.\"}";
        } catch (Exception e) {
            e.printStackTrace();
            return "{\"status\": \"error\", \"message\": \"Invalid JSON data.\"}";
        }
    }

    private void insertLeadIntoDatabase(JSONObject lead, Connection conn) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            PreparedStatement ps = conn.prepareStatement("INSERT INTO test_3rdjan2024_tab (id, customer_name, msisdn, mailingphone2) VALUES (?, ?, ?, ?)");

            ps.setString(1, (lead.containsKey("id")) ? (String) lead.get("id") : null);
            ps.setString(2, (lead.containsKey("customer_name")) ? (String) lead.get("customer_name") : null);
            ps.setString(3, (lead.containsKey("msisdn")) ? (String) lead.get("msisdn") : null);
            ps.setString(4, (lead.containsKey("mailingphone2")) ? (String) lead.get("mailingphone2") : null);

            ps.executeUpdate();
        } catch (MySQLIntegrityConstraintViolationException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void insertLeadIntoAccountOutboundTable(JSONObject lead, Connection conn) {
        try {
            Class.forName("com.mysql.jdbc.Driver");

            String insertQuery = "INSERT INTO account_outbound (msisdn) VALUES (?)";

            PreparedStatement ps = conn.prepareStatement(insertQuery);
            ps.setString(1, (lead.containsKey("msisdn")) ? (String) lead.get("msisdn") : null);
            //ps.setString(3, (lead.containsKey("other_column2")) ? (String) lead.get("other_column2") : null);

            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
