import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

public class HTTPRequest
{
	 public static int  get_msg_count(int count,String msg,String lang_type){

		  if ( count==0) return 1;
		       if ( lang_type.equals("1"))
		        {
		          if(count<=160){
		                  return 1;
		          }
		          else if(count>=161 && count <=306){
		                  return 2;
		          }
		          else if(count>=307 && count <=459){
		                  return 3;
		          }
		          else if(count>=460 && count <=612){
		                  return 4;
		          }
		          else if(count>=613 && count <=765){
		                  return 5;
		          }
		          else if(count>=766 && count <=918){
		                  return 6;
		          }
		          else if(count>=919 && count <=1071){
		                  return 7;
		          }
		          else if(count>=1072 && count <=1224){
		                  return 8;
		          }
		          else if(count>=1225 && count <=1377){
		                  return 9;
		          }
		          else if(count>=1377 && count <=1530){
		                  return 10;
		          }
		          else if(count>=1531 && count <=1683){
		                  return 11;
		          }
		          else if(count>=1684 && count <=1836){
		                  return 12;
		          }
		          else if(count>=1837 && count <=1989){
		                  return 13;
		          }
		          if(count >1989) return 20;
		          else return 20;
		         }
		         else
		         {
		            if(count<=70){
		            return 1;
		            }
		            else if(count>=71 && count <=130){
		                    return 2;
		            }
		            else if(count>=131 && count <=198){
		                   return 3;
		            }
		            else if(count>=199 && count <=264){
		                   return 4;
		            }
		            else if(count>=265 && count <=330){
		                  return 5;
		            }
		            else if(count>=331 && count <=396){
		                  return 6;
		            }
		            else if(count>=397 && count <=462){
		                 return 7;
		            }
		            else if(count>=463 && count <=528){
		                  return 8;
		            }
		            else if(count>=529 && count <=594){
		                   return 9;
		            }
		            else if(count>=595 && count <=624){
		                  return 10;
		            }
		            if(count >625)
		            {
		                return 20;
		            }
		            else
		            {
		                return 20;
		            }



		       }
		    }

  public static String getResponse(String url)
  {
    String res = "";
    URLConnection connection = null;
    HttpURLConnection httpConn = null;
    BufferedReader in = null;
    OutputStream out = null;
    Writer wout = null;
    try {
      URL url1 = new URL(url);
      connection = url1.openConnection();
      httpConn = (HttpURLConnection)connection;
      httpConn.setReadTimeout(30000);
      httpConn.setConnectTimeout(30000);

      httpConn.setRequestMethod("GET");

      httpConn.setDoInput(true);

      if (httpConn.getResponseCode() == 200)
      {
        InputStreamReader isr = new InputStreamReader(httpConn.getInputStream());

        in = new BufferedReader(isr);
        String temp = "";
        res = "";
        while ((temp = in.readLine()) != null)
          res = res + temp;
      }
      else
      {
        InputStreamReader isr = new InputStreamReader(httpConn.getErrorStream());

        in = new BufferedReader(isr);
        String temp = "";
        res = "";
        while ((temp = in.readLine()) != null)
          res = res + temp;
      }
    }
    catch (IOException ex)
    {
      ex.printStackTrace();
      return "IOEXP";
    }
    finally
    {
      try
      {
        in.close();
        wout.close();
        out.close();
        httpConn.disconnect();
      }
      catch (Exception localException1)
      {
      }

    }

    return res;
  }
}
