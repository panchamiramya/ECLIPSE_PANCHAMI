<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%-- Outgoing Call Report Template --%>

<%@ page import="java.sql.*"%>
<%@ page import="java.text.SimpleDateFormat"%>
<%@ page import="java.util.Date"%>
<%@ page import="jakarta.servlet.ServletOutputStream"%>
<%
String username = (String) session.getAttribute("username");

if (username == null) {
    response.sendRedirect("login.jsp");
    return;
}

String todayDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());

String fromDate = request.getParameter("fromDate");
String toDate = request.getParameter("toDate");
String pflag = request.getParameter("pflag");
String cflag = request.getParameter("cflag");
String download = request.getParameter("download");

if (fromDate == null || fromDate.trim().isEmpty()) {
    fromDate = todayDate;
}

if (toDate == null || toDate.trim().isEmpty()) {
    toDate = todayDate;
}

/* ======================================================
   EXCEL DOWNLOAD SECTION
====================================================== */
if ("excel".equalsIgnoreCase(download)) {

    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;

    try {

        response.reset();
        response.setContentType("application/vnd.ms-excel");
        response.setHeader(
            "Content-Disposition",
            "attachment; filename=outgoing_call_report.xls"
        );

        Class.forName("com.mysql.cj.jdbc.Driver");

        conn = DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/callpatch_db",
            "webapi",
            "Ikontel@456"
        );

        StringBuilder query = new StringBuilder();

        query.append("SELECT ");
        query.append("id, ");
        query.append("callerid, ");
        query.append("outgoing_no, ");
        query.append("agent_msisdn, ");
        query.append("req_date, ");
        query.append("pflag, ");
        query.append("cflag, ");
        query.append("agent_status, ");
        query.append("cust_status ");
        query.append("FROM account_outgoing_call_req ");
        query.append("WHERE account_id='16' ");
        query.append("AND req_date >= ? ");
        query.append("AND req_date <= ? ");

        if (pflag != null && !pflag.trim().isEmpty()) {
            query.append("AND pflag=? ");
        }

        if (cflag != null && !cflag.trim().isEmpty()) {
            query.append("AND cflag=? ");
        }

        query.append("ORDER BY id DESC");

        ps = conn.prepareStatement(query.toString());

        int index = 1;

        ps.setString(index++, fromDate + " 00:00:00");
        ps.setString(index++, toDate + " 23:59:59");

        if (pflag != null && !pflag.trim().isEmpty()) {
            ps.setString(index++, pflag);
        }

        if (cflag != null && !cflag.trim().isEmpty()) {
            ps.setString(index++, cflag);
        }

        rs = ps.executeQuery();

        ServletOutputStream outputStream = response.getOutputStream();

        String header =
            "ID\tCaller ID\tOutgoing No\tAgent MSISDN\tReq Date\tPFLAG\tCFLAG\tAgent Status\tCust Status\n";

        outputStream.write(header.getBytes());

        while (rs.next()) {

            String row =
                (rs.getString("id") == null ? "" : rs.getString("id")) + "\t" +
                (rs.getString("callerid") == null ? "" : rs.getString("callerid")) + "\t" +
                (rs.getString("outgoing_no") == null ? "" : rs.getString("outgoing_no")) + "\t" +
                (rs.getString("agent_msisdn") == null ? "" : rs.getString("agent_msisdn")) + "\t" +
                (rs.getString("req_date") == null ? "" : rs.getString("req_date")) + "\t" +
                (rs.getString("pflag") == null ? "" : rs.getString("pflag")) + "\t" +
                (rs.getString("cflag") == null ? "" : rs.getString("cflag")) + "\t" +
                (rs.getString("agent_status") == null ? "" : rs.getString("agent_status")) + "\t" +
                (rs.getString("cust_status") == null ? "" : rs.getString("cust_status")) + "\n";

            outputStream.write(row.getBytes());
        }

        outputStream.flush();
        outputStream.close();

        return;

    } catch (Exception e) {

        out.println(e);

    } finally {

        try {
            if (rs != null)
                rs.close();
        } catch (Exception e) {
        }

        try {
            if (ps != null)
                ps.close();
        } catch (Exception e) {
        }

        try {
            if (conn != null)
                conn.close();
        } catch (Exception e) {
        }
    }
}
%>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">

<title>Outgoing Call Report</title>

<link rel="stylesheet"
    href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">

<link rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

<link rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<style>

body{
    background:#eef2f7;
    font-family:Segoe UI;
    padding:20px;
}

.report-card{
    background:#fff;
    padding:20px;
    border-radius:8px;
    box-shadow:0 2px 8px rgba(0,0,0,0.08);
}

.report-title{
    font-size:22px;
    font-weight:600;
    color:#2d3e50;
    margin-bottom:20px;
    border-left:4px solid #0d6efd;
    padding-left:10px;
}

.filter-section{
    display:flex;
    flex-wrap:wrap;
    gap:15px;
    align-items:end;
    margin-bottom:20px;
}

.filter-box{
    display:flex;
    flex-direction:column;
}

.filter-box label{
    font-size:13px;
    font-weight:600;
    margin-bottom:5px;
}

.form-control{
    min-width:180px;
}

.btn-search{
    background:#0d6efd;
    color:#fff;
    border:none;
}

.btn-download{
    background:#198754;
    color:#fff;
    border:none;
}

.table-responsive{
    width:100%;
    overflow-x:auto;
}

#reportTable{
    width:100% !important;
    border-collapse:collapse !important;
}

#reportTable thead{
    background:#0d6efd;
    color:#fff;
}

#reportTable thead th{
    padding:12px;
    font-size:13px;
    border:1px solid #dee2e6;
}

#reportTable tbody td{
    padding:10px;
    font-size:13px;
    border:1px solid #dee2e6;
}

.dataTables_wrapper{
    margin-top:10px;
}

.dataTables_length,
.dataTables_filter{
    margin-bottom:10px;
}

.dataTables_paginate{
    margin-top:10px !important;
}

.paginate_button{
    padding:4px 10px !important;
    border-radius:4px !important;
    margin-left:3px !important;
}

.current{
    background:#0d6efd !important;
    color:#fff !important;
    border:1px solid #0d6efd !important;
}

.top-navbar{
    width:100%;
    background:#0d6efd;
    padding:12px 20px;
    border-radius:8px;
    display:flex;
    justify-content:flex-end;
    align-items:center;
    margin-bottom:20px;
}

.logout-link{
    text-decoration:none;
    font-weight:600;
}

.logout-link:hover{
    color:#dbeafe !important;
}
</style>

</head>

<body>


    <jsp:include page="sidebar.jsp" />

	<div class="main-content">

		<div class="top-navbar">

    <div class="ms-auto">

        <a style="font-size:15px; color:#fff;"
           class="nav-link logout-link"
           href="logout.jsp">

            Logout

            <i class="fa fa-sign-out-alt"></i>

        </a>

    </div>

</div>
<div class="report-card">

    <div class="report-title">
        Outgoing Call Request Report
    </div>

    <form method="get">

        <div class="filter-section">

            <div class="filter-box">

                <label>From Date</label>

                <input type="date"
                    name="fromDate"
                    class="form-control"
                    value="<%=fromDate%>">

            </div>

            <div class="filter-box">

                <label>To Date</label>

                <input type="date"
                    name="toDate"
                    class="form-control"
                    value="<%=toDate%>">

            </div>

            <div class="filter-box">

                <label>PFLAG</label>

                <select name="pflag" class="form-control">

                    <option value="">ALL</option>

                    <option value="0"
                        <%= "0".equals(pflag) ? "selected" : "" %>>
                        0
                    </option>

                    <option value="1"
                        <%= "1".equals(pflag) ? "selected" : "" %>>
                        1
                    </option>

                    <option value="2"
                        <%= "2".equals(pflag) ? "selected" : "" %>>
                        2
                    </option>

                    <option value="3"
                        <%= "3".equals(pflag) ? "selected" : "" %>>
                        3
                    </option>

                    <option value="4"
                        <%= "4".equals(pflag) ? "selected" : "" %>>
                        4
                    </option>

                </select>

            </div>

            <div class="filter-box">

                <label>CFLAG</label>

                <select name="cflag" class="form-control">

                    <option value="">ALL</option>

                    <option value="0"
                        <%= "0".equals(cflag) ? "selected" : "" %>>
                        0
                    </option>

                    <option value="1"
                        <%= "1".equals(cflag) ? "selected" : "" %>>
                        1
                    </option>

                    <option value="2"
                        <%= "2".equals(cflag) ? "selected" : "" %>>
                        2
                    </option>

                    <option value="3"
                        <%= "3".equals(cflag) ? "selected" : "" %>>
                        3
                    </option>

                    <option value="4"
                        <%= "4".equals(cflag) ? "selected" : "" %>>
                        4
                    </option>

                </select>

            </div>

            <div class="filter-box">

                <button type="submit"
                    class="btn btn-search">

                    <i class="fa fa-search"></i> Search

                </button>

            </div>

            <div class="filter-box">

                <button type="submit"
                    name="download"
                    value="excel"
                    class="btn btn-download">

                    <i class="fa fa-download"></i> Download

                </button>

            </div>

        </div>

    </form>

    <div class="table-responsive">

        <table id="reportTable" class="display">

            <thead>

                <tr>

                    <th>ID</th>
                    <th>Caller ID</th>
                    <th>Outgoing No</th>
                    <th>Agent MSISDN</th>
                    <th>Req Date</th>
                    <th>PFLAG</th>
                    <th>CFLAG</th>
                    <th>Agent Status</th>
                    <th>Cust Status</th>

                </tr>

            </thead>

            <tbody>

<%
Connection conn = null;
PreparedStatement ps = null;
ResultSet rs = null;

try {

    Class.forName("com.mysql.cj.jdbc.Driver");

    conn = DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/callpatch_db",
        "webapi",
        "Ikontel@456"
    );

    StringBuilder query = new StringBuilder();

    query.append("SELECT ");
    query.append("id, ");
    query.append("callerid, ");
    query.append("outgoing_no, ");
    query.append("agent_msisdn, ");
    query.append("req_date, ");
    query.append("pflag, ");
    query.append("cflag, ");
    query.append("agent_status, ");
    query.append("cust_status ");
    query.append("FROM account_outgoing_call_req ");
    query.append("WHERE account_id='16' ");
    query.append("AND req_date >= ? ");
    query.append("AND req_date <= ? ");

    if (pflag != null && !pflag.trim().isEmpty()) {
        query.append("AND pflag=? ");
    }

    if (cflag != null && !cflag.trim().isEmpty()) {
        query.append("AND cflag=? ");
    }

    query.append("ORDER BY id DESC");

    ps = conn.prepareStatement(query.toString());

    int index = 1;

    ps.setString(index++, fromDate + " 00:00:00");
    ps.setString(index++, toDate + " 23:59:59");

    if (pflag != null && !pflag.trim().isEmpty()) {
        ps.setString(index++, pflag);
    }

    if (cflag != null && !cflag.trim().isEmpty()) {
        ps.setString(index++, cflag);
    }

    rs = ps.executeQuery();

    while (rs.next()) {
%>

<tr>

    <td><%=rs.getString("id") == null ? "" : rs.getString("id")%></td>

    <td><%=rs.getString("callerid") == null ? "" : rs.getString("callerid")%></td>

    <td><%=rs.getString("outgoing_no") == null ? "" : rs.getString("outgoing_no")%></td>

    <td><%=rs.getString("agent_msisdn") == null ? "" : rs.getString("agent_msisdn")%></td>

    <td><%=rs.getString("req_date") == null ? "" : rs.getString("req_date")%></td>

    <td><%=rs.getString("pflag") == null ? "" : rs.getString("pflag")%></td>

    <td><%=rs.getString("cflag") == null ? "" : rs.getString("cflag")%></td>

    <td><%=rs.getString("agent_status") == null ? "" : rs.getString("agent_status")%></td>

    <td><%=rs.getString("cust_status") == null ? "" : rs.getString("cust_status")%></td>

</tr>

<%
    }

} catch (Exception e) {

    out.println(e);

} finally {

    try {
        if (rs != null)
            rs.close();
    } catch (Exception e) {
    }

    try {
        if (ps != null)
            ps.close();
    } catch (Exception e) {
    }

    try {
        if (conn != null)
            conn.close();
    } catch (Exception e) {
    }
}
%>

            </tbody>

        </table>

    </div>

</div>

<script>

$(document).ready(function() {

    $('#reportTable').DataTable({

        "paging": true,
        "searching": true,
        "ordering": true,
        "info": true,
        "pageLength": 25,
        "lengthMenu": [[10,25,50,100], [10,25,50,100]]

    });

});

</script>


 </div>

</body>
<script>

if (window.performance && window.performance.navigation.type === 1) {
    window.location.href = "viewCallData.jsp";
}

</script>
</html>