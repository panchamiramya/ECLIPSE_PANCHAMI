<%@ page import="java.sql.*, java.io.BufferedReader, java.io.InputStreamReader, java.net.HttpURLConnection, java.net.URL, java.net.URLEncoder" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<%
    // Database connection details
    String dbURL = "jdbc:mysql://localhost:3306/callpatch_db";
    String dbUser = "root";
    String dbPass = "";

    Connection conn = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;
    
    String agentId = "";
    String password = "";
    String AccountId = request.getParameter("AccountId");
    String AParty = request.getParameter("AParty");
    String BParty = request.getParameter("BParty");
    System.out.println(AccountId + " " + AParty + " " + BParty);
    
    try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        conn = DriverManager.getConnection(dbURL, dbUser, dbPass);

        String sql = "SELECT agent_id, passwd FROM agent_detail WHERE account_id = ?";
        stmt = conn.prepareStatement(sql);
        stmt.setString(1, AccountId);
        rs = stmt.executeQuery();

        if (rs.next()) {
            agentId = rs.getString("agent_id");
            password = rs.getString("passwd");
        } else {
            out.println("Error: Invalid Account ID. No agent found for the given details.");
            return;
        }

        if (AParty != null && BParty != null && !agentId.isEmpty() && !password.isEmpty()) {
            final String apiUrl = "https://callpatchapi.anymsg.in/CALLPATCHAPI/patchcall.jsp?"
                + "LAN_NO=12233"
                + "&USERID=" + URLEncoder.encode(agentId, "UTF-8")
                + "&PASSWD=" + URLEncoder.encode(password, "UTF-8")
                + "&A_PARTY=" + URLEncoder.encode(AParty, "UTF-8")
                + "&B_PARTY=" + URLEncoder.encode(BParty, "UTF-8")
                + "&CRE_ID=12345_cre"
                + "&CRE_NAME=sudeshna"
                + "&CLIENT_REFERENCE_NO=1122334455"
                + "&CALLERID=8035480561"
                + "&NO_OF_RETRIES=1"
                + "&RETRY_INTERVAL=10"
                + "&SCHEDULE_TIME=2024-02-25%2010:00:00"
                + "&EXPIRED_TIME=2025-10-23%2014:00:00"
                + "&DETAIL_EVENT=Y"
                + "&PRIORITY=1"
                + "&CALLBACK_URL=https://ikontel.com";

            System.out.println("Initiating async API call to: " + apiUrl);

            java.util.concurrent.CompletableFuture.runAsync(() -> {
                HttpURLConnection connApi = null;
                BufferedReader br = null;
                try {
                    URL url = new URL(apiUrl);
                    connApi = (HttpURLConnection) url.openConnection();
                    connApi.setRequestMethod("GET");
                    connApi.setRequestProperty("Accept", "application/json");
                    connApi.setConnectTimeout(5000); // 5s connection timeout
                    connApi.setReadTimeout(20000);    // 20s read timeout

                    int responseCode = connApi.getResponseCode();
                    if (responseCode == 200) {
                        br = new BufferedReader(new InputStreamReader(connApi.getInputStream()));
                        StringBuilder responseOutput = new StringBuilder();
                        String output;
                        while ((output = br.readLine()) != null) {
                            responseOutput.append(output);
                        }
                        System.out.println("API call successful in background: " + responseOutput.toString());
                    } else {
                        System.err.println("API call failed in background with response code: " + responseCode);
                    }
                } catch (Exception e) {
                    System.err.println("Error in background API call: " + e.getMessage());
                    e.printStackTrace();
                } finally {
                    try {
                        if (br != null) br.close();
                    } catch (Exception ignored) {}
                    if (connApi != null) {
                        connApi.disconnect();
                    }
                }
            });

            out.println("call initiate successfully");

        } else {
            out.println("Error: Invalid data. Please check the provided details.");
        }

    } catch (SQLException e) {
        out.println("Error: " + e.getMessage());
    } catch (Exception e) {
        out.println("Error: " + e.getMessage());
    } finally {
        if (rs != null) rs.close();
        if (stmt != null) stmt.close();
        if (conn != null) conn.close();
    }
%>