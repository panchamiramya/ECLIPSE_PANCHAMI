<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%-- Dialer Log Template --%>
	<% String username=(String) session.getAttribute("username"); if (username==null) {
		response.sendRedirect("login.jsp"); } %>

		<%@ page import="java.sql.*" %>
			<%@ page import="javax.naming.InitialContext" %>
				<%@ page import="javax.naming.Context" %>
					<%@ page import="javax.sql.DataSource" %>
						<!DOCTYPE html>
						<html lang="en">

						<head>
							<meta charset="UTF-8">
							<meta name="viewport" content="width=device-width, initial-scale=1.0">
							<title>CLI PORTAL</title>
							<link rel="stylesheet"
								href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
							<link rel="stylesheet"
								href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
							<link rel="stylesheet" type="text/css"
								href="<%=request.getContextPath()%>/css/dashBoard.css">
							<link rel="icon" type="image/png" href="assets/img/fav-icon.png">

							<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
							<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
							<script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>


						</head>

						<body>

							<style>
								iframe {
									width: 100%;
									height: calc(100vh - 80px);
									border: none;
									border-radius: 10px;
									box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
									transition: opacity 0.5s ease;
								}

								li {
									display: flex;
									align-items: center;
									gap: 5px;
								}
							</style>
							<!-- Sidebar -->
							<!-- Sidebar -->
							<aside class="sidebar position-fixed top-0 left-0 h-100" id="sidebar"
								style="background-color: #252636">
								<div class="sidebar-header d-flex justify-content-center align-items-center p-3">
									<div class="rounded-circle d-flex justify-content-center align-items-center"
										style="width: 65px; height: 65px; background-color: #3f4056; color: #FFC107; flex-shrink: 0;">
										<i class="fa-solid fa-user-tie fa-2x"></i>
									</div>
									<div class="ms-2 text-center">
										<img src="ikontellogot.png" alt="Logo" style="height: 70px;">
										<h5 style="color: #FFC107;" class="mt-3 mb-0">CLI PORTAL</h5>
									</div>
								</div>

								<ul class="categories list-unstyled">
									<li><a href="./dashboard.jsp"> Update CallerId</a></li>
									<li><a href="./dailerLog.jsp"> Dailer Log</a></li>
									<% if ("panchami".equalsIgnoreCase(username)) { %>

										<li>
											<a href="./viewCallData.jsp">
												TATACAP DATA
											</a>
										</li>

										<% } %>
								</ul>


							</aside>
							<!-- Main Section -->
							<section id="wrapper">
								<nav class="navbar navbar-expand-lg navbar-dark">
									<div class="container-fluid">
										<!-- Menu Toggle Button (Left) -->
										<button id="menu-toggle" class="btn btn-outline-light">
											<i class="fas fa-bars"></i>
										</button>

										<!-- Dashboard Title -->
										<a class="navbar-brand text-white ms-2" href="#">Dash<span
												class="main-color">board</span></a>

										<!-- Logout Button (Right) -->
										<div class="ms-auto">
											<a style="font-size: 15px; color: #fff;" class="nav-link" href="logout.jsp">
												Logout <i></i>
											</a>
										</div>
									</div>
								</nav>


								<div class="p-4">
									<div class="welcome">
										<div class="content rounded-3 p-3">
											<h1 class="fs-3">Welcome to Ikontel CLI Portal</h1>
										</div>
									</div>







									<section class="statistics mt-4">
										<div class="container">
											<h4 class="text-white">Dailer Log Details</h4>
											<div class="table-responsive">
												<table id="callRequestsTable" class="table table-striped table-bordered"
													style="width: 100%">
													<thead class="table-dark">
														<tr>

															<th>Server Id</th>
															<th>Account Id</th>
															<th>Account Name</th>
															<th>Old CLI</th>
															<th>New CLI</th>
															<th>Old Status</th>
															<th>New Status</th>
															<th>Change Type</th>
															<th>Change Time</th>
															<th>Change By</th>

														</tr>
													</thead>
													<tbody>
														<%
														Connection conn = null;
														PreparedStatement ps = null;
														ResultSet rs = null;
														try {
															Class.forName("com.mysql.cj.jdbc.Driver");
															conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/callpatch_db", "webapi", "Ikontel@456");
															
															// String query = "select * from dialer_servers where account_id=16 and id=0";
															String query = "SELECT * from dialer_servers_log ORDER BY id DESC";
															
															ps = conn.prepareStatement(query);
															rs = ps.executeQuery();
															while (rs.next()) {
														%>
															<tr>

																<td>
																	<%=rs.getString("server_id")%>
																</td>
																<td>
																	<%=rs.getString("account_id")%>
																</td>
																<td>
																	<%=rs.getString("account_name")%>
																</td>
																<td>
																	<%=rs.getString("old_callerid")%>
																</td>
																<td>
																	<%=rs.getString("new_callerid")%>
																</td>
																<td>
																	<%=rs.getString("old_status")%>
																</td>
																<td>
																	<%=rs.getString("new_status")%>
																</td>
																<td>
																	<%=rs.getString("change_type")%>
																</td>
																<td>
																	<%=rs.getString("change_time")%>
																</td>
																<td>
																	<%=rs.getString("changed_by")%>
																</td>

															</tr>
															<% } } catch (Exception e) { e.printStackTrace(); } finally
																{ if (rs !=null) rs.close(); if (ps !=null) ps.close();
																if (conn !=null) conn.close(); } %>
													</tbody>
												</table>
											</div>
										</div>
									</section>

									<script>
										$(document).ready(function () {
											// Initialize DataTable
											$('#callRequestsTable').DataTable();
										});
									</script>

									<!-- Include Bootstrap, jQuery & DataTables JS -->
									<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
									<script
										src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
									<script
										src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
									<script
										src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>


									<!-- Include DataTables CSS -->
									<link rel="stylesheet"
										href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">


								</div>
							</section>

							<script>
								document.addEventListener("DOMContentLoaded", function () {
									const menuToggle = document.getElementById("menu-toggle");
									const sidebar = document.getElementById("sidebar");

									menuToggle.addEventListener("click", function (event) {
										event.stopPropagation(); // Prevents event from bubbling up
										sidebar.classList.toggle("show");
									});

									// Close sidebar when clicking outside on mobile
									document.addEventListener("click", function (event) {
										if (window.innerWidth <= 768) {
											if (!sidebar.contains(event.target)
												&& event.target !== menuToggle) {
												sidebar.classList.remove("show");
											}
										}
									});
								});
							</script>

							<style>
								/* General Sidebar Styling */
								.sidebar {
									width: 250px;
									background: #343a40;
									color: white;
									position: fixed;
									height: 100%;
									transition: all 0.3s;
									left: -250px;
									/* Initially hidden */
									overflow-y: auto;
									padding-top: 20px;
								}

								/* Show sidebar when toggled */
								.sidebar.show {
									left: 0;
								}

								/* Sidebar Header */
								/* .sidebar-header {
    text-align: center;
} */

								/* Logo Image */
								/* .sidebar-header img {
    max-width: 100px;
} */

								/* Sidebar Links */
								.categories {
									padding: 0;
									list-style: none;
								}

								.categories li {
									padding: 12px 20px;
									font-size: 16px;
								}

								.categories li a {
									color: white;
									text-decoration: none;
									display: block;
								}

								.categories li:hover {
									background: #495057;
								}

								/* Navbar styles */
								.navbar {
									padding: 10px;
								}

								/* Toggle Button */
								#menu-toggle {
									border: none;
									background: none;
									color: white;
									font-size: 20px;
									cursor: pointer;
								}

								/* Logout Button */
								.navbar .btn-warning {
									font-size: 15px;
								}

								/* Ensure Logout is properly aligned in small screens */
								@media (max-width : 768px) {
									.navbar .ms-auto {
										text-align: right;
									}
								}

								/* Responsive Fixes */
								@media (max-width : 768px) {

									/* Sidebar is hidden initially on mobile */
									.sidebar {
										left: -250px;
									}

									/* Sidebar is shown when toggled */
									.sidebar.show {
										left: 0;
									}
								}

								/* Hide toggle button on desktop screens */
								@media (min-width : 769px) {
									#menu-toggle {
										display: none;
									}

									/* Show sidebar by default */
									.sidebar {
										left: 0 !important;
									}
								}
							</style>

						</body>

						</html>