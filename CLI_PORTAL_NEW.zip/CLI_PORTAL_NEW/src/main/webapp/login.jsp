<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" type="image/png" href="assets/img/fav-icon.png">

<title>CLI PORTAL</title>
<link rel="stylesheet"
	href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<style>
/* Existing CSS remains unchanged */
body {
	margin: 0;
	padding: 0;
	background: #221F2E;
	display: flex;
	justify-content: center;
	align-items: center;
	height: 100vh;
	font-family: Arial, sans-serif;
}
.bg {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
}
.dotWrapper {
    position: absolute;
}
.dot {
    width: 4px;
    height: 4px;
    background: #FEA039;
    border-radius: 50%;
}
@keyframes rotating {
    0% { opacity: 0; transform: rotate(0deg); }
    25%, 75% { opacity: 1; }
    50% { opacity: 0; }
    100% { opacity: 0; transform: rotate(360deg); }
}
@keyframes flying {
    0%, 100% { transform: translate(0, 0); }
    10% { transform: translate(20px, 50px); }
    20% { transform: translate(-30px, 10px); }
    30% { transform: translate(10px, 60px); }
    40% { transform: translate(50px, 0px); }
    50% { transform: translate(-10px, -40px); }
    60% { transform: translate(-40px, 20px); }
    70% { transform: translate(30px, -30px); }
    80% { transform: translate(0px, -60px); }
    90% { transform: translate(40px, 10px); }
}
.main-content {
	width: 50%;
	max-width: 500px;
	border-radius: 20px;
	box-shadow: 0 5px 5px rgba(0, 0, 0, .4);
	background: #fff;
	display: flex;
	flex-direction: column;
	overflow: hidden;
}

.company__info {
	background-color: #001F3F;
	color: #fff;
	padding: 20px;
	display: flex;
	flex-direction: column;
	justify-content: center;
	align-items: center;
}

.login_form {
	padding: 20px;
	flex: 1;
	text-align: center;
}

/* Styling for input fields with icons */
.input-group {
    position: relative;
    display: flex;
    align-items: center;
}
.form__input {
    width: 100%;
    padding: 10px 40px 10px 35px; /* Adjust padding for icons */
    margin: 10px 0;
    border: 1px solid #ccc;
    border-radius: 4px;
}
.input-icon {
    position: absolute;
    left: 10px;
    color: #888;
}
.toggle-password {
    position: absolute;
    right: 10px;
    cursor: pointer;
    color: #888;
}
.btn {
	width: 100%;
	padding: 10px;
	background: #001F3F;
	color: #fff;
	border: none;
	border-radius: 10px;
	cursor: pointer;
}

.btn:hover {
	background: #006666;
}
.main-content {
    position: relative;
    z-index: 2;
}
.login_form {
    position: relative;
    z-index: 2;
}

@media ( min-width : 768px) {
	.main-content {
		flex-direction: row;
		max-width: 700px;
	}
	.company__info {
		width: 40%;
		text-align: center;
	}
	.login_form {
		width: 60%;
	}
}
</style>
</head>
<body>
	<div class="bg">
		<%
		for (int i = 1; i <= 75; i++) {
		%>
		<div class="dotWrapper"
			style="top: <%=(int) (Math.random() * 100)%>%; left: <%=(int) (Math.random() * 100)%>%; animation: flying <%=(int) (Math.random() * 50 + 20)%>s ease-in-out <%=(int) (Math.random() * -10)%>s infinite alternate;">
			<div class="dot"
				style="transform-origin: <%=(int) (Math.random() * 30 - 15)%>px <%=(int) (Math.random() * 30 - 15)%>px; animation: rotating <%=(int) (Math.random() * 20 + 10)%>s ease-in-out <%=(int) (Math.random() * -10)%>s infinite;"></div>
		</div>
		<%
		}
		%>
	</div>
	<div class="main-content">
		<div class="company__info">
			<img src="ikontellogot.png" alt="Logo" style="height: 70px;">
			<b><p >Powered By <a href="https://www.ikontel.com/" target="_blank"><b style= "color:#FFC107;">Ikontel</b></a></p></b>
		</div>
		<div class="login_form">
			<h2>Admin Login</h2>
			<form action="loginController.jsp" method="post">
				<div class="input-group">
				    <i class="fas fa-envelope input-icon"></i>
				    <input class="form__input" type="text" id="username" name="username"
					placeholder="Enter your username" required>
				</div>
				
				<div class="input-group">
				    <i class="fas fa-lock input-icon"></i>
				    <input class="form__input" type="password" id="password" name="password"
					placeholder="Enter your password" required> 
				    <i class="fa fa-eye toggle-password" id="togglePassword"></i>
				</div>
				
				<input type="submit" value="Login" class="btn">
			</form>
			<p>
				<a href="#">Forgot password?</a>
			</p>
		</div>
	</div>

	<script>
	// Show/Hide Password Toggle
	document.getElementById("togglePassword").addEventListener("click", function() {
	    let passwordField = document.getElementById("password");
	    if (passwordField.type === "password") {
	        passwordField.type = "text";
	        this.classList.remove("fa-eye");
	        this.classList.add("fa-eye-slash");
	    } else {
	        passwordField.type = "password";
	        this.classList.remove("fa-eye-slash");
	        this.classList.add("fa-eye");
	    }
	});
	</script>
</body>
</html>
