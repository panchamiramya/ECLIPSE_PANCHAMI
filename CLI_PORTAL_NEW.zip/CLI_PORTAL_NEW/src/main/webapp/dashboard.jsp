<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%-- Dashboard Template --%>
<%
String username = (String) session.getAttribute("username");
if (username == null) {
	response.sendRedirect("login.jsp");
}
%>

<%@ page import="java.sql.*"%>
<%@ page import="javax.naming.InitialContext"%>
<%@ page import="javax.naming.Context"%>
<%@ page import="javax.sql.DataSource"%>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>CLI PORTAL</title>
<link rel="stylesheet"
	href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
<link rel="stylesheet"
	href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" type="text/css"
	href="<%=request.getContextPath()%>/css/dashBoard.css">
<link rel="icon" type="image/png" href="assets/img/fav-icon.png">

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script
	src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script
	src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>


</head>
<body>

	<style>
iframe {
	width: 100%;
	height: calc(100vh - 80px);
	border: none;
	border-radius: 10px;
	box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
	transition: opacity 0.5s ease;
}

li {
	display: flex;
	align-items: center;
	gap: 5px;
}
</style>
	<!-- Sidebar -->
	<aside class="sidebar position-fixed top-0 left-0 h-100" id="sidebar"
		style="background-color: #252636">
		<div
			class="sidebar-header d-flex justify-content-center align-items-center p-3">
			<div class="rounded-circle d-flex justify-content-center align-items-center" 
			     style="width: 65px; height: 65px; background-color: #3f4056; color: #FFC107; flex-shrink: 0;">
				<i class="fa-solid fa-user-tie fa-2x"></i>
			</div>
			<div class="ms-2 text-center">
				<img src="ikontellogot.png" alt="Logo" style="height: 70px;">
				<h5 style="color: #FFC107;" class="mt-3 mb-0">CLI PORTAL</h5>
			</div>
		</div>

		<ul class="categories list-unstyled">
			<li><a href="./dashboard.jsp"> Update CallerId</a></li>
			<li><a href="./dailerLog.jsp"> Dailer Log</a></li>
			<% if ("panchami".equalsIgnoreCase(username)) { %>

        <li>
            <a href="./viewCallData.jsp">
                TATACAP DATA
            </a>
        </li>

    <% } %>
		</ul>

	</aside>
	<!-- Main Section -->
	<section id="wrapper">
		<nav class="navbar navbar-expand-lg navbar-dark">
			<div class="container-fluid">
				<!-- Menu Toggle Button (Left) -->
				<button id="menu-toggle" class="btn btn-outline-light">
					<i class="fas fa-bars"></i>
				</button>

				<!-- Dashboard Title -->
				<a class="navbar-brand text-white ms-2" href="#">Dash<span
					class="main-color">board</span></a>

				<!-- Logout Button (Right) -->
				<div class="ms-auto">
					<a style="font-size: 15px; color: #fff;" class="nav-link"
						href="logout.jsp"> Logout <i></i>
					</a>
				</div>
			</div>
		</nav>


		<div class="p-4">
			<div class="welcome">
				<div class="content rounded-3 p-3">
					<h1 class="fs-3">Welcome to Ikontel CLI Portal</h1>
				</div>
			</div>

			<%
			if ("POST".equalsIgnoreCase(request.getMethod())) {
				// Handling AJAX request to update caller ID, A/B Party, or status
				String id = request.getParameter("id");
				String newCallerId = request.getParameter("newCallerId");
				String newAParty = request.getParameter("newAParty");
				String newBParty = request.getParameter("newBParty");
				String newStatus = request.getParameter("newStatus");
				String updateType = request.getParameter("update");
				
				Connection conn = null;
				PreparedStatement ps = null;

				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/callpatch_db", "webapi", "Ikontel@456");
					if ("status".equals(updateType)) {
						String setUserQuery = "SET @current_user = ?";
						PreparedStatement userps = conn.prepareStatement(setUserQuery);
						userps.setString(1, session.getAttribute("username").toString());
						userps.executeUpdate();
						userps.close();
						
						String updateSQL = "UPDATE dialer_servers SET status = ? WHERE id = ?";
						ps = conn.prepareStatement(updateSQL);
						ps.setString(1, newStatus);
						ps.setString(2, id);
						int updated = ps.executeUpdate();
						out.print(updated > 0 ? "Status updated successfully!" : "No records found to update.");
					} else if ("true".equals(updateType)) {
						String setUserQuery = "SET @current_user = ?";
						PreparedStatement userps = conn.prepareStatement(setUserQuery);
						userps.setString(1, session.getAttribute("username").toString());
						userps.executeUpdate();
						userps.close();
						
						String updateSQL = "UPDATE patchcall_no_details SET A_party = ?, B_party = ? WHERE account_id = ?";
						ps = conn.prepareStatement(updateSQL);
						ps.setString(1, newAParty);
						ps.setString(2, newBParty);
						ps.setString(3, id);
						int updated = ps.executeUpdate();
						out.print(updated > 0 ? "A/B Party updated successfully!" : "No records found to update.");
					} else {
						String setUserQuery = "SET @current_user = ?";
						PreparedStatement userps = conn.prepareStatement(setUserQuery);
						userps.setString(1, session.getAttribute("username").toString());
						userps.executeUpdate();
						userps.close();
						
						String updateQuery = "UPDATE dialer_servers SET callerid = ? WHERE id = ?";
						ps = conn.prepareStatement(updateQuery);
						ps.setString(1, newCallerId);
						ps.setString(2, id);

						int rowsAffected = ps.executeUpdate();
						out.print(rowsAffected > 0 ? "Caller ID updated successfully!" : "Failed to update Caller ID.");
					}
				} catch (Exception e) {
					e.printStackTrace();
					out.print("Error: " + e.getMessage());
				} finally {
					if (ps != null)
						ps.close();
					if (conn != null)
						conn.close();
				}
				return;
			}
			%>

			<section class="statistics mt-4">
				<div class="container">
					<h4 class="text-white">Dailer Details</h4>
					<div class="table-responsive">
						<table id="callRequestsTable"
							class="table table-striped table-bordered" style="width: 100%">
							<thead class="table-dark">
								<tr>
									<th>ID</th>
									<th>Server Id</th>
									<th>Account Id</th>
									<th>Account Name</th>
									<th>Caller Id</th>
									<th>Status</th>
									<th>Actions</th>
								</tr>
							</thead>
							<tbody>
								<%
								Connection conn = null;
								PreparedStatement ps = null;
								ResultSet rs = null;
								try {
									Class.forName("com.mysql.cj.jdbc.Driver");
									conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/callpatch_db", "webapi", "Ikontel@456");
									String query = "SELECT d.*, p.A_party, p.B_party " + 
												   "FROM dialer_servers d " +
												   "JOIN patchcall_no_details p ON p.account_id = d.account_id " + "";
									ps = conn.prepareStatement(query);
									rs = ps.executeQuery();

									while (rs.next()) {
										String status = rs.getString("status");
										String statusClass = "active".equalsIgnoreCase(status) ? "success" : "danger";
										String statusText = "active".equalsIgnoreCase(status) ? "Active" : "Inactive";
								%>
								<tr>
									<td><%=rs.getInt("id")%></td>
									<td><%=rs.getString("server_id")%></td>
									<td><%=rs.getString("account_id")%></td>
									<td><%=rs.getString("account_name")%></td>
									<td><%=rs.getString("callerid")%></td>
									<td>
										<span class="badge bg-<%=statusClass%>"><%=statusText%></span>
									</td>
									<td>
										<button style="background: #006666; color: white"
											class="btn edit-btn" data-id="<%=rs.getInt("id")%>"
											data-callerid="<%=rs.getString("callerid")%>">Edit
											CLI</button>
										<button class="btn btn-warning abedit"
											data-id="<%=rs.getString("account_id")%>"
											data-callerid="<%=rs.getString("callerid")%>"
											data-aparty="<%=rs.getString("A_party")%>"
											data-bparty="<%=rs.getString("B_party")%>">Edit A/B
											Party</button>
										<button class="btn btn-info status-toggle"
											data-id="<%=rs.getInt("id")%>"
											data-status="<%=rs.getString("status")%>">
											Update Status
										</button>
										<button class="btn btn-danger callButton"
											data-accountid="<%=rs.getString("account_id")%>"
											data-aparty="<%=rs.getString("A_party")%>"
											data-bparty="<%=rs.getString("B_party")%>">Call</button>
									</td>
								</tr>
								<%
								}
								} catch (Exception e) {
								e.printStackTrace();
								} finally {
								if (rs != null)
								rs.close();
								if (ps != null)
								ps.close();
								if (conn != null)
								conn.close();
								}
								%>
							</tbody>
						</table>
					</div>
				</div>
			</section>

			<!-- Edit Caller ID Modal -->
			<div class="modal fade" id="editModal" tabindex="-1"
				aria-labelledby="editModalLabel" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="editModalLabel">Edit Caller ID</h5>
							<button type="button" class="btn-close" data-bs-dismiss="modal"
								aria-label="Close"></button>
						</div>
						<div class="modal-body">
							<form id="editCallerIdForm">
								<input type="hidden" id="editId">
								<div class="mb-3">
									<label for="CallerId" class="form-label"> Caller ID</label> <input
										type="text" class="form-control" id="callerId">
								</div>
								<button type="button" class="btn btn-primary"
									id="saveChangesBtn">Save Changes</button>
							</form>
						</div>
					</div>
				</div>
			</div>

			<!-- Edit A/B Party Modal -->
			<div class="modal fade" id="editA_B_party" tabindex="-1"
				aria-labelledby="editModalLabel" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="editModalLabel">Edit A and B
								Party</h5>
							<button type="button" class="btn-close" data-bs-dismiss="modal"
								aria-label="Close"></button>
						</div>
						<div class="modal-body">
							<form id="editABPartyForm">
								<input type="hidden" id="editABId">
								<div class="mb-3">
									<label for="A_Party" class="form-label">A Party</label> <input
										type="text" class="form-control" id="aParty">
								</div>
								<div class="mb-3">
									<label for="B_Party" class="form-label">B Party</label> <input
										type="text" class="form-control" id="bParty">
								</div>
								<button type="button" class="btn btn-primary" id="saveABParty">Save
									Changes</button>
							</form>
						</div>
					</div>
				</div>
			</div>

			<script
				src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

			<script>
				$(document).ready(function() {
					// Initialize DataTable
					var table = $('#callRequestsTable').DataTable({
						"pageLength": 10,
						"responsive": true
					});
					
					// EDIT CLI BUTTON - Fixed for all pages
					$(document).on('click', '.edit-btn', function() {
						let id = $(this).data('id');
						let callerid = $(this).data('callerid');
						
						$('#editId').val(id);
						$('#callerId').val(callerid);
						$('#editModal').modal('show');
					});
					
					// SAVE CLI CHANGES
					$('#saveChangesBtn').click(function() {
						let id = $('#editId').val();
						let newCallerId = $('#callerId').val();
						
						if (newCallerId.trim() === '') {
							alert('Please enter a valid Caller ID.');
							return;
						}
						
						$.ajax({
							type: 'POST',
							url: window.location.href,
							data: {
								id: id,
								newCallerId: newCallerId
							},
							success: function(response) {
								alert('Updated Successfully');
								location.reload();
							},
							error: function() {
								alert('Error updating Caller ID.');
							}
						});
					});
					
					// EDIT A/B PARTY BUTTON - Fixed for all pages
					$(document).on('click', '.abedit', function() {
						let id = $(this).data('id');
						let aParty = $(this).data('aparty');
						let bParty = $(this).data('bparty');
						
						$('#editABId').val(id);
						$('#aParty').val(aParty);
						$('#bParty').val(bParty);
						$('#editA_B_party').modal('show');
					});
					
					// SAVE A/B PARTY CHANGES
					$('#saveABParty').click(function() {
						let id = $('#editABId').val();
						let newAParty = $('#aParty').val();
						let newBParty = $('#bParty').val();
						
						$.ajax({
							type: 'POST',
							url: window.location.href,
							data: {
								id: id,
								newAParty: newAParty,
								newBParty: newBParty,
								update: true
							},
							success: function(response) {
								alert('Updated Successfully');
								location.reload();
							},
							error: function() {
								alert('Error updating A/B Party.');
							}
						});
					});
					
					// UPDATE STATUS BUTTON - Fixed for all pages
					$(document).on('click', '.status-toggle', function() {
						let id = $(this).data('id');
						let currentStatus = $(this).data('status');
						let newStatus = currentStatus.toLowerCase() === 'active' ? 'inactive' : 'active';
						
						if(confirm('Are you sure you want to change status to ' + newStatus + '?')) {
							$.ajax({
								type: 'POST',
								url: window.location.href,
								data: {
									id: id,
									newStatus: newStatus,
									update: 'status'
								},
								success: function(response) {
									alert('Status updated successfully!');
									location.reload();
								},
								error: function() {
									alert('Error updating status.');
								}
							});
						}
					});
					
					// CALL BUTTON - Fixed for all pages
					$(document).on('click', '.callButton', function() {
						let accountId = $(this).data('accountid');
						let aParty = $(this).data('aparty');
						let bParty = $(this).data('bparty');
						
						$.ajax({
							type: 'POST',
							url: 'ApiController.jsp',
							data: {
								AccountId: accountId,
								AParty: aParty,
								BParty: bParty
							},
							success: function(response) {
								if(response.includes('Error:')) {
									alert(response);
									location.reload();
								} else {
									alert('Call initiated successfully');
								}
							},
							error: function(xhr, status, error) {
								let errorMessage = 'Error: ' + xhr.status + ' - ' + xhr.statusText;
								alert(errorMessage);
							}
						});
					});
				});
			</script>

			<!-- Include DataTables CSS -->
			<link rel="stylesheet"
				href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">

		</div>
	</section>

	<script>
		document.addEventListener('DOMContentLoaded', function() {
			const menuToggle = document.getElementById('menu-toggle');
			const sidebar = document.getElementById('sidebar');
			
			menuToggle.addEventListener('click', function(event) {
				event.stopPropagation();
				sidebar.classList.toggle('show');
			});
			
			document.addEventListener('click', function(event) {
				if (window.innerWidth <= 768) {
					if (!sidebar.contains(event.target) && event.target !== menuToggle) {
						sidebar.classList.remove('show');
					}
				}
			});
		});
	</script>

	<style>
.sidebar {
	width: 250px;
	background: #343a40;
	color: white;
	position: fixed;
	height: 100%;
	transition: all 0.3s;
	left: -250px;
	overflow-y: auto;
	padding-top: 20px;
}

.sidebar.show {
	left: 0;
}

.categories {
	padding: 0;
	list-style: none;
}

.categories li {
	padding: 12px 20px;
	font-size: 16px;
}

.categories li a {
	color: white;
	text-decoration: none;
	display: block;
}

.categories li:hover {
	background: #495057;
}

.navbar {
	padding: 10px;
}

#menu-toggle {
	border: none;
	background: none;
	color: white;
	font-size: 20px;
	cursor: pointer;
}

.navbar .btn-warning {
	font-size: 15px;
}

@media (max-width: 768px) {
	.navbar .ms-auto {
		text-align: right;
	}
	
	.sidebar {
		left: -250px;
	}
	
	.sidebar.show {
		left: 0;
	}
}

@media (min-width: 769px) {
	#menu-toggle {
		display: none;
	}
	
	.sidebar {
		left: 0 !important;
	}
}
</style>

</body>
</html>