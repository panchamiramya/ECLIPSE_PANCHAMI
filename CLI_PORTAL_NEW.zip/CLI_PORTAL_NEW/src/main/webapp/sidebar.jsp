<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%-- Sidebar Template --%>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>

body{
    margin:0;
    padding:0;
}

/* Sidebar */

.sidebar{
    width:250px;
    height:100vh;
    background:#1e293b;
    color:#ffffff;
    position:fixed;
    left:0;
    top:0;
    overflow-y:auto;
    transition:0.3s;
    z-index:999;
    box-shadow:2px 0 10px rgba(0,0,0,0.1);
}

/* Hide Sidebar */

.sidebar.collapsed{
    width:70px;
}

/* Header */

.sidebar-header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:18px 15px;
    background:#0f172a;
    border-bottom:1px solid rgba(255,255,255,0.1);
}

.logo-text{
    font-size:20px;
    font-weight:bold;
    white-space:nowrap;
}

.sidebar.collapsed .logo-text{
    display:none;
}

/* Toggle Button */

.toggle-btn{
    cursor:pointer;
    font-size:20px;
    color:#fff;
}

/* Menu */

.sidebar-menu{
    padding-top:10px;
}

.sidebar-menu a{
    display:flex;
    align-items:center;
    color:#fff;
    text-decoration:none;
    padding:14px 20px;
    transition:0.3s;
    border-left:4px solid transparent;
    white-space:nowrap;
}

.sidebar-menu a:hover{
    background:#334155;
    border-left:4px solid #0d6efd;
}

.sidebar-menu i{
    min-width:30px;
    font-size:18px;
}

.menu-text{
    transition:0.3s;
}

.sidebar.collapsed .menu-text{
    display:none;
}

/* Logout */

.logout-section{
    padding:20px;
}

.logout-btn{
    background:#dc3545;
    border-radius:6px;
}

.logout-btn:hover{
    background:#bb2d3b !important;
}

/* Main Content */

.main-content{
    margin-left:250px;
    padding:20px;
    transition:0.3s;
}

.main-content.expanded{
    margin-left:70px;
}

/* Hover Expand */
.sidebar.collapsed:hover{
    width:250px;
}

.sidebar.collapsed:hover .menu-text,
.sidebar.collapsed:hover .logo-text{
    display:inline;
}

@media(max-width:768px){

    .sidebar{
        width:70px;
    }

    .sidebar .menu-text,
    .sidebar .logo-text{
        display:none;
    }

    .sidebar:hover{
        width:250px;
    }

    .sidebar:hover .menu-text,
    .sidebar:hover .logo-text{
        display:inline;
    }

    .main-content{
        margin-left:70px;
    }
}

</style>
<div id="sidebar" class="sidebar">

    <div class="sidebar-header">

        <span class="logo-text">
            CALL PATCH
        </span>

        <i class="fa fa-bars toggle-btn"
           onclick="toggleSidebar()"></i>

    </div>

    <div class="sidebar-menu">

        <a href="dashboard.jsp">
            <i class="fa fa-home"></i>
            <span class="menu-text">Dashboard</span>
        </a>
        <%
String username = (String) session.getAttribute("username");
%>

<% if ("panchami".equalsIgnoreCase(username)) { %>

    <a href="viewCallData.jsp">
        <i class="fa fa-phone"></i>
        <span class="menu-text">Outgoing Call Report</span>
    </a>

<% } %>


    </div>


</div>

<script>

function toggleSidebar(){

    var sidebar = document.getElementById("sidebar");

    sidebar.classList.toggle("collapsed");

    document.body.classList.toggle("sidebar-collapsed");
}

</script>



