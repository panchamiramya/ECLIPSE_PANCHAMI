<%@ page import="java.sql.*, java.security.MessageDigest" %>
<%@ page import="javax.naming.InitialContext"%>
<%@ page import="javax.naming.Context"%>
<%@ page import="javax.sql.DataSource"%>
<%
    // Get username and password from the request
    String username = request.getParameter("username");
    String password = request.getParameter("password");

    if (username != null && password != null) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            // Encrypt the entered password using SHA-256
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes("UTF-8"));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {	
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            String encryptedPassword = hexString.toString();
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            /*
            Context ctx = new InitialContext();
        	Context envCtx = (Context) ctx.lookup("java:comp/env");

            DataSource ds =(DataSource)envCtx.lookup("jdbc/journeydb1");

            try{
                   conn = ds.getConnection();
               }catch(Exception ex)
            {
            	   ex.printStackTrace();
            }
			*/

            // Database connection
            
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/callpatch_db", "root", "");

            // Prepare SQL query to verify user
            ps = conn.prepareStatement("SELECT * FROM login WHERE username = ? AND password_hash = ?");
            ps.setString(1, username);
            ps.setString(2, encryptedPassword);

            rs = ps.executeQuery();

            // Check if user exists
            if (rs.next()) {
            	session.setAttribute("username", rs.getString("username"));
%>
                <script>
                    window.location.href = "dashboard.jsp";
                </script>
<%
            } else {
%>
                <script>
                    alert("Invalid username or password.");
                    window.history.back();
                </script>
<%
            }
        } catch (Exception e) {
            e.printStackTrace();
%>
            <script>
                alert("An error occurred: <%= e.getMessage() %>");
            </script>
<%
        } finally {
            // Close resources
            if (rs != null) rs.close();
            if (ps != null) ps.close();
            if (conn != null) conn.close();
        }
    }
%>