import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import org.json.JSONArray;
import org.json.JSONObject;

public class Finnone {
    
    public static void main(String[] args) throws Exception {
    	Class.forName("com.mysql.jdbc.Driver");
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/smartreceiverv1_1", "patch", "patch123");
        Statement st = conn.createStatement();
        Statement st2 = conn.createStatement();
        Statement st3 = conn.createStatement();
        try {
            String id = "", agent_id = "", req_date = "", CLIENT_REFERENCE_NO = "", docObjectID = "";String callback_url="";
            String sql = "select id, req_date, CLIENT_REFERENCE_NO, docObjectID, callback_url from account_outgoing_call_req where account_id=16 and dms_flag_id = 2 limit 100";
            //System.out.println("SQL=" + sql);
            ResultSet rs = st.executeQuery(sql);
            try {
                while (rs.next()) {
                    id = rs.getString("id");
                    req_date = rs.getString("req_date");
                    CLIENT_REFERENCE_NO = rs.getString("CLIENT_REFERENCE_NO");
                    callback_url = rs.getString("callback_url");
                    docObjectID = rs.getString("docObjectID");
                    JSONArray fileDetailsArray = new JSONArray();
                    JSONObject fileDetailsObj = new JSONObject();
                    fileDetailsObj.put("dialerReqNum", CLIENT_REFERENCE_NO);
                    fileDetailsObj.put("dmsObjNum", docObjectID);
                    fileDetailsArray.put(fileDetailsObj);
        			String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(Calendar.getInstance().getTime());

                    SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
                    SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
                    Date date = inputFormat.parse(req_date);
                    req_date = outputFormat.format(date);

                    JSONObject json1 = new JSONObject();
                    json1.put("requestId", id+timeStamp);
                    json1.put("sourceSystem", "IKONTEL");
                    json1.put("requestTime", req_date);
                    json1.put("fileDetails", fileDetailsArray);
               
                    String url = "";
                    String jsinString = json1.toString();
                    System.out.println("API REQUEST::"+jsinString);
                    if(callback_url.contains("hflcollections"))
                    {
                    	url = "https://hflcollections.tatacapital.com/filedetails/rest/save";
                    }
                    else
                    {
                    	url = "https://consumercollections.tatacapital.com/filedetails/rest/save";
                    }
                    String result = "";
                    try {
                    	result = HTTPRequest.getResponse2(url, jsinString);
                    	System.out.println("API RESPONSE::"+result);
                        JSONObject jb = new JSONObject(result);
                        System.out.println("API RESPONSE::"+result);
                        if (jb.getString("errorCode").equals("200")) {
                            st2.executeUpdate("update account_outgoing_call_req set dms_flag_id=3 where id= " + id + " ");
                            System.out.println("RESULT=" + result + (new Date()).toString());
                        } else {
                            st2.executeUpdate("update account_outgoing_call_req set dms_flag_id=10 where id= " + id + " ");
                            st3.executeUpdate("insert into report_failed_log (ac_id, url, data, status, account_id, next_retry_date,no_retries,request) values ('"+id+"','"+url+"','"+result+"','0','16', now(),'0','"+jsinString+"')");
                            System.out.println("API RESPONSE::"+result);
                        }
                    }catch(Exception ex) {
                    	System.out.println("Inside Catch Of Result API call");
                    	st2.executeUpdate("update account_outgoing_call_req set dms_flag_id=10 where id= " + id + " ");
                    	st3.executeUpdate("insert into report_failed_log (ac_id, url, data, status, account_id, next_retry_date,no_retries,request) values ('"+id+"','"+url+"','"+result+"','0','16', now(),'0','"+jsinString+"')");
                    	System.out.println("API RESPONSE::"+result);
                    	ex.printStackTrace();
                        System.exit(-1);
                    }
                    
                }

            } catch (Exception ex) {
                ex.printStackTrace();
                System.exit(-1);

            }

            System.exit(-1);

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
}
