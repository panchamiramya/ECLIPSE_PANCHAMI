import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import javax.mail.Address;
import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class eTeamWiseMail {
  public static void main(String[] args) {
    try {
      Class.forName("com.mysql.jdbc.Driver");
      System.out.println("connection established");
      Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/farmer_registration_fdd_sumitomo", "root", "");
      System.out.println("Connected");
      String regex = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
      String from = "info@ikontel.com";
      String ccmailids = "sikharani.parida@ikontel.com,sudeshna@ikontel.com";
      String filepath = "0";
      String formattedDate = "";
      String strDateFormat = "yyyy-MM-dd";
      Date date = new Date();
      DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
      formattedDate = dateFormat.format(date);
      String sub = "SUMITOMO MISCALL COUNT REPORT FOR ENABLEMENT TEAM " + formattedDate;
      String sql = "SELECT eteam_msisdn, NULL AS eteam2_msisdn, eteam_name, eteam_mail_id, NULL AS eteam2_name, NULL AS eteam2_mail_id\n"
      		+ "FROM staff_detail\n"
      		+ "WHERE eteam_mail_id IS NOT NULL AND eteam_mail_id != ''\n"
      		+ "\n"
      		+ "UNION\n"
      		+ "\n"
      		+ "SELECT NULL AS eteam_msisdn, eteam2_msisdn, NULL AS eteam_name, NULL AS eteam_mail_id, eteam2_name, eteam2_mail_id\n"
      		+ "FROM staff_detail\n"
      		+ "WHERE eteam2_mail_id IS NOT NULL AND eteam2_mail_id != ''; ";      
      Statement stmt = conn.createStatement();
      ResultSet rs = stmt.executeQuery(sql);
      
      while (rs.next()) {
    	  String eteamMsisdn = rs.getString("eteam_msisdn");
          String eteamEmailId = rs.getString("eteam_mail_id");
          String eteamName = rs.getString("eteam_name");
          String eteamMsisdn2 = rs.getString("eteam2_msisdn");
          String eteamEmailId2 = rs.getString("eteam2_mail_id");
          String eteamName2 = rs.getString("eteam2_name");
          String subsql = "SELECT distinct zone, teritory, district, manager_name, manager_msisdn, manager_email_id, state  from staff_detail where eteam_mail_id='" + eteamEmailId + "' OR  eteam2_mail_id='" + eteamEmailId2 + "' group by manager_msisdn,manager_name";
          
        Statement substmt = conn.createStatement();
        ResultSet subrs = substmt.executeQuery(subsql);
        String text = "Dear ";
        if (eteamEmailId != null && !eteamEmailId.isEmpty()) {
            text += eteamName + " (" + eteamEmailId + ")";
        }
        if (eteamEmailId2 != null && !eteamEmailId2.isEmpty()) {
            text += eteamName2 + " (" + eteamEmailId2 + ")";
        }
        text += ",<br /><br />Below is the miscall count.<br /><br />";
        String resultBody = "";
        while (subrs.next()) {
            String managerMsisdn = subrs.getString("manager_msisdn");
            String managerName = subrs.getString("manager_name");
            String managerMailId = subrs.getString("manager_email_id");
            String region = subrs.getString("zone");
            String state = subrs.getString("state");
            String miscallsql = "select count(id) as miscallcount from miscall_unique where manager_msisdn='" + managerMsisdn + "' ";
            Statement miscallstmt = conn.createStatement();
            ResultSet miscallrs = miscallstmt.executeQuery(miscallsql);
            while (miscallrs.next()) {
                String miscallcount = miscallrs.getString("miscallcount");
                resultBody = String.valueOf(String.valueOf(resultBody)) + "<tr>";
                resultBody = String.valueOf(String.valueOf(resultBody)) + "<td>" + region + "</td>";
                resultBody = String.valueOf(String.valueOf(resultBody)) + "<td>" + state + "</td>";
                resultBody = String.valueOf(String.valueOf(resultBody)) + "<td>" + managerName + "</td>";
                resultBody = String.valueOf(String.valueOf(resultBody)) + "<td>" + managerMailId + "</td>";
                resultBody = String.valueOf(String.valueOf(resultBody)) + "<td>" + managerMsisdn + "</td>";
                resultBody = String.valueOf(String.valueOf(resultBody)) + "<td>" + miscallcount + "</td>";
                resultBody = String.valueOf(String.valueOf(resultBody)) + "</tr>";
            }
            miscallstmt.close();
        }
        substmt.close();
        if ((eteamEmailId != null && !eteamEmailId.isEmpty()) || (eteamEmailId2 != null && !eteamEmailId2.isEmpty())) {                    
        	text = String.valueOf(String.valueOf(text)) + "<table border='1' cellpadding='5' cellspacing='0' style='font-size: 9pt;font-family: sans-serif;color:black'>";
            text = String.valueOf(String.valueOf(text)) + "<thead>";
            text = String.valueOf(String.valueOf(text)) + "<tr style='background:lightblue;'>";
            text = String.valueOf(String.valueOf(text)) + "<th>ZONE</th>";
            text = String.valueOf(String.valueOf(text)) + "<th>STATE</th>";
            text = String.valueOf(String.valueOf(text)) + "<th>VP NAME</th>";
            text = String.valueOf(String.valueOf(text)) + "<th>VP MAIL ID</th>";
            text = String.valueOf(String.valueOf(text)) + "<th>VP MSISDN</th>";
            text = String.valueOf(String.valueOf(text)) + "<th>MISCALL COUNT</th>";
            text = String.valueOf(String.valueOf(text)) + "</tr>";
            text = String.valueOf(String.valueOf(text)) + "</thead>";
            text = String.valueOf(String.valueOf(text)) + "<tbody>";
            text = String.valueOf(String.valueOf(text)) + resultBody;
            text = String.valueOf(String.valueOf(text)) + "</tbody>";
            text = String.valueOf(String.valueOf(text)) + "</table>";
            System.out.println(text);
            Transport transport = null;
            String host = "email-smtp.eu-west-1.amazonaws.com";
            Properties props = System.getProperties();
            int PORT = 465;
            props.put("mail.transport.protocol", "smtp");
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.socketFactory.port", Integer.valueOf(465));
            props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.port", "465");
            props.put("mail.smtp.host", "email-smtp.eu-west-1.amazonaws.com");
            props.put("mail.smtp.starttls.enable", "true"); // Enable STARTTLS
            props.put("mail.smtp.ssl.protocols", "TLSv1.2");
            props.put("line.separator", "\r\n");
            props.put("mail.debug", "true");
            String SMTP_USERNAME = "AKIAJXDE5LZYJEHFLACQ";
            String SMTP_PASSWORD = "Ai0zhtdrRG065i8+xdUAAMa9I7U/xvxmJ+Oc3tHlqZCb";
            Session session = Session.getDefaultInstance(props, new Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication("AKIAJXDE5LZYJEHFLACQ", "Ai0zhtdrRG065i8+xdUAAMa9I7U/xvxmJ+Oc3tHlqZCb");
                }
            });
            try {
                transport = session.getTransport();
                MimeMessage message = new MimeMessage(session);
                message.setFrom((Address) new InternetAddress("info@ikontel.com"));
                if (eteamEmailId != null && !eteamEmailId.isEmpty()) {
                    message.addRecipient(Message.RecipientType.TO, new InternetAddress(eteamEmailId));
                }

                if (eteamEmailId2 != null && !eteamEmailId2.isEmpty()) {
                    message.addRecipient(Message.RecipientType.TO, new InternetAddress(eteamEmailId2));
                }
                message.setRecipients(Message.RecipientType.CC, (Address[]) InternetAddress.parse("sikharani.parida@ikontel.com,sudeshna@ikontel.com,panchami.c@ikontel.com,swapnarani@ikontel.com"));
                message.setSubject(sub);
                MimeBodyPart mbp1 = new MimeBodyPart();
                mbp1.setContent(text, "text/html; charset=utf-8");
                MimeMultipart mimeMultipart = new MimeMultipart();
                mimeMultipart.addBodyPart(mbp1);
                message.setContent(mimeMultipart);

                Transport.send(message);
                System.out.println("Success in sending mail");
            } catch (Exception ex) {
                ex.printStackTrace();
                System.out.println("Error in sending mail");
            } finally {
                if (transport != null)
                    try {
                        transport.close();
                    } catch (Exception exception) {
                    }
            }
            if (transport == null)
                continue;
            try {
                transport.close();
            } catch (Exception exception) {
            }
            continue;
        }
        System.out.println("ETEAM email id is not valid");
    }
    conn.close();
} catch (SQLException se) {
    se.printStackTrace();
} catch (Exception e) {
    e.printStackTrace();
}
}
}
