import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.util.HashMap;
import java.util.Map;

public class TextToImageConverter {
    public static void main(String[] args) {
        int width = 700;
        int height = 600;

        // Fetch data from the database (dummy data for demonstration)
        Map<String, String> dataMap = fetchDataFromDatabase(); // Replace with your database retrieval logic

        String text = "Dear <Name>\n"
        		+ "\n"
                + "Please find below activity update for the day –\n"
                + "Product  - <Product>\n"
                + "SMA 0 Performance\n"
                + "Resolution  %                   <Resolution>\n"
                + "Norm %                            <Norm>\n"
                + "Stab %                               <Stab>\n"
                + "\n"
                + "SMA 1 Performance\n"
                + "Resolution %                     <Resolution1>\n"
                + "Norm %                              <Norm1>\n"
                + "Roll Back %                       <RollBack1>\n"
                + "Flow %                               <Flow1>\n"
                + "\n"
                + "SMA 2 Performance\n"
                + "Resolution %                    <Resolution2>\n"
                + "Norm %                            <Norm2>\n"
                + "Roll Back %                      <RollBack2>\n"
                + "Flow %                              <Flow2>\n"
                + "\n"
                + "Thanks & Regards\n"
                + "Receivables Management\n"
                + "Projects & Process Team\n"
                + "BCC- Mumbai\n"
                + "\n"
                + "Kindly contact Rajnish Kumar- 7573984757 in case of any query & discussion.";

        // Replace placeholders with actual data
        for (Map.Entry<String, String> entry : dataMap.entrySet()) {
            text = text.replace(entry.getKey(), entry.getValue());
        }

        // Create a BufferedImage
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics2D graphics = image.createGraphics();
        graphics.setColor(Color.WHITE);
        graphics.fillRect(0, 0, width, height);
        graphics.setColor(Color.BLACK);

        // Set font and size
        Font font = new Font("Arial", Font.PLAIN, 16);
        graphics.setFont(font);

        // Draw text with proper formatting
        FontMetrics fontMetrics = graphics.getFontMetrics();
        int y = 30;
        String[] lines = text.split("\n");
        for (String line : lines) {
            graphics.drawString(line, 30, y);
            y += fontMetrics.getHeight();
        }

        // Save the image to a file
        File outputFile = new File("/home/test/Documents/text_image.png");
        try {
            ImageIO.write(image, "png", outputFile);
            System.out.println("Image saved: " + outputFile.getAbsolutePath());
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            graphics.dispose();
        }
    }

    // Dummy database fetch logic
    private static Map<String, String> fetchDataFromDatabase() {
        Map<String, String> dataMap = new HashMap<>();
        dataMap.put("<Name>", "John Doe");
        dataMap.put("<Product>", "Product XYZ");
        dataMap.put("<Resolution>", "95%");
        dataMap.put("<Norm>", "80%");
        dataMap.put("<Stab>", "85%");
        dataMap.put("<Resolution1>", "90%");
        dataMap.put("<Norm1>", "75%");
        dataMap.put("<RollBack1>", "10%");
        dataMap.put("<Flow1>", "60%");
        dataMap.put("<Resolution2>", "88%");
        dataMap.put("<Norm2>", "70%");
        dataMap.put("<RollBack2>", "15%");
        dataMap.put("<Flow2>", "55%");
        return dataMap;
    }
}
