<%@page import="org.json.JSONObject"%>
<%@page import="helper.MyMenu"%>
<%@page import="java.util.Random"%>
<%@page import="java.util.Calendar"%>
<%@page import="helper.WhatsAppMessage"%>

<%@page import="java.util.UUID"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.text.DateFormat"%>
<%@page import="java.lang.Math.*"%>
<%@page import="java.io.OutputStream"%>
<%@page import="java.io.FileOutputStream"%>
<%@page import="java.io.File"%>
<%@page import="java.io.InputStream"%>
<%@page import="javax.naming.InitialContext"%>
<%@page import="javax.naming.Context"%>
<%@ page import = "java.util.Map" %>
<%@ page import = "java.util.Date" %>


<%@ page import = "java.util.Enumeration" %>
<%@ page import = "java.util.ArrayList" %>

<%@ page import = "org.json.simple.JSONArray" %>




<%@ page import = "org.json.simple.parser.JSONParser" %>






<%@page contentType="text/html" pageEncoding="UTF-8"%> <%@page import="javax.sql.DataSource"%><%@page import="java.io.*"%>  
<%@page import="java.sql.*" %>
<%
response.setContentType("text/html");
response.addHeader("Freeflow","FC");
java.util.Date mydt = new java.util.Date();
response.setDateHeader("Date", mydt.getTime());
 Connection conn = null;
Context ctx = new InitialContext();

 if (ctx == null)
 {
    throw new Exception("Boom - No Context");
 }
 Context envCtx = (Context) ctx.lookup("java:comp/env");

 DataSource ds =(DataSource)envCtx.lookup("jdbc/whatsapp");
 
  
    if (ds != null) {
        try{
        conn = ds.getConnection();
            }catch(Exception ex)
                         {
                           
                       }

 }

%><% 

String user_name="";


try {
DateFormat df=new SimpleDateFormat("yyyy-MM-dd");

Map<String, String[]> parameters = request.getParameterMap();
String challenge="";
String token="";
String authtoken=application.getInitParameter("authtoken");
String account_id=application.getInitParameter("account_id");



/*
hub.mode:subscribe
hub.challenge:6461399
hub.verify_token:Ikontel$987@123
*/
String method="";
for(String parameter : parameters.keySet()) {
	{
        String[] values = parameters.get(parameter);
        System.out.println(parameter+":"+values[0]);
        if ( parameter.equals("hub.mode") && values[0].equals("subscribe"))
        {
        	method="subscribe";
        }
        if (   parameter.equals("hub.verify_token"))
        		{
        	token=values[0];
        		}
        if (   parameter.equals("hub.challenge"))
		{
        	challenge=values[0];
		}
        
        //your code here
    }
}
System.out.println(token);
System.out.println(token);

System.out.println("METHOD="+method);


if ( method.equals("subscribe") && token.equals(authtoken))
{
	System.out.println("challenge="+challenge);
	out.print(challenge);
	
	return;
}

Enumeration<String> headerNames = request.getHeaderNames();

while (headerNames.hasMoreElements()) {
    
    String headerName = headerNames.nextElement();
    System.out.print(headerName + " = ");
    String headerValue = request.getHeader(headerName);
    System.out.println(headerValue);
}
   

String uid = UUID.randomUUID().toString();

String reg_id="";
String msisdn="";
String email_id="";
String report_date="";
//final String account_id="instalpl";


//st= "select wavfilename from upload_wavfile_log"


InputStream is = request.getInputStream();
String  cldfilename="";

JSONParser jsonParser = new JSONParser();
org.json.simple.JSONObject jsonObject = (org.json.simple.JSONObject)jsonParser.parse(
      new InputStreamReader(is, "UTF-8"));

//{"statuses":[{"id":"gBEGkZdBQRCHAglCL08Zx7t5hss","conversation":{"id":"bee2d03aee293c9614298433b48ea479"},"pricing":{"pricing_model":"NBP","billable":true},"recipient_id":"919741411087","status":"delivered","timestamp":"1627904134"}]}
System.out.println(jsonObject.toString());

org.json.simple.JSONArray jarr=null;
try
{
	org.json.JSONObject jbsession=new org.json.JSONObject();
	jbsession =new org.json.JSONObject();
	org.json.simple.JSONArray jenrty=(	org.json.simple.JSONArray) jsonObject.get("entry");
	org.json.simple.JSONObject jb1=(org.json.simple.JSONObject)jenrty.get(0);
	org.json.simple.JSONArray jarr_chgs= (org.json.simple.JSONArray) jb1.get("changes");
	org.json.simple.JSONObject jb2=(org.json.simple.JSONObject)jarr_chgs.get(0);
	org.json.simple.JSONObject values =(org.json.simple.JSONObject)jb2.get("value");

	
//	jarr=(org.json.simple.JSONArray)jsonObject.get("statuses");

		
	
		
		
	jarr=(org.json.simple.JSONArray)values.get("statuses");
	//jarr=(org.json.simple.JSONArray)jb2.get("statuses");

	
	if ( jarr==null)
	{
		
		 jenrty=(	org.json.simple.JSONArray) jsonObject.get("entry");
	jb1=(org.json.simple.JSONObject)jenrty.get(0);
		jarr_chgs= (org.json.simple.JSONArray) jb1.get("changes");
		
		System.out.println("jarr_chgs"+jarr_chgs.toString());
		
		 jb2=(org.json.simple.JSONObject)jarr_chgs.get(0);
		System.out.println("JSONObject"+jb2.toString());
		
	//	((org.json.simple.JSONObject)jarr_chgs.get(0)).get("messages")
		
		 values =(org.json.simple.JSONObject)jb2.get("value");
		
	
		
		
		org.json.simple.JSONArray jarr_msgs=(org.json.simple.JSONArray)values.get("messages");
		
		org.json.simple.JSONObject jb=(org.json.simple.JSONObject)jarr_msgs.get(0);
		String msgid="";
		try
		{
		
		org.json.simple.JSONObject jbcontext=(org.json.simple.JSONObject)jb.get("context");
		 msgid=(String)jbcontext.get("id");
		}
		catch ( Exception ex)
		{
			
		}
		String from=(String)jb.get("from");
		String id="";
		if ( msgid==null)
		{
	      id=(String)jb.get("id");
		}
		else
		{
			id=msgid;
		}
		
		String conversation_id="";
		try
		{
			conversation_id=(String)((org.json.simple.JSONObject)jb.get("conversation")).get("id");
		}
		catch ( Exception ex)
		{
		}

		
	
		
		String body=jb.toJSONString();
		String type="";
		String status="";
		if (jb.get("status")==null )
		{
		   type="incoming";
		   status="";
		}
		else
		{
			type="outgoing";
			status=(String)jb.get("status");
			 WhatsAppMessage wa = new WhatsAppMessage();
			
			 org.json.JSONObject	js= new org.json.JSONObject();
			 if (!conversation_id.equals("") )
			 {
			 js.put("session_id",conversation_id);
			 wa.updateSessionInfo(from, conn, js,account_id);
			 }
				
			
		
			
			
		}

		String sqlrst ="select msg_id from incomig_whatsapp_msg where msg_id='"+id+"'";
		System.out.println("INCOMING SQL="+sqlrst);
		Statement st1= conn.createStatement();
		
		ResultSet rsts=st1.executeQuery(sqlrst);
		//if ( rsts.next())
		//{
		//	return;
		//}
		
		String pssql="insert into incomig_whatsapp_msg(from_msisdn,message,msg_id,call_type,msg_status,session_id,account_id) values(?,?,?,?,?,?,?)";
		PreparedStatement ps=conn.prepareStatement(pssql);
		ps.setString(1,from);
		ps.setString(2,body);
		ps.setString(3,id);
		ps.setString(4,type);
		ps.setString(5,status);
		ps.setString(6,conversation_id);

		ps.setString(7,account_id);

		ps.executeUpdate();
		
		if( type.equals("incoming"))
		{
		  WhatsAppMessage wa = new WhatsAppMessage();
			 String resp=wa.getIntent(body,from,conn,account_id);
			 
			 jbsession= wa.getSessionInfo(from, conn,account_id);
			 
			 System.out.println("RESP="+resp);
			 if ( resp.contains("menu"))
			 {
				 String menu=resp.split("\\:")[1];

				 System.out.println("MENU Selected:"+menu);
				 if ( menu.equals("yes"))
				 {
					
					 String sql="update outgoing_whatsapp_log set user_resp='YES',user_resp_date=now() where msg_id='"+id+"'";
					 Statement st=conn.createStatement();
					 wa.updateCallBackURL(id, "read", from.substring(2), "YES");
					 
					 System.out.println("SQL="+sql);
					 st.executeUpdate(sql);
			    		wa.sendMessage360("121212122", from,"Thanks for choosing Techsquadteam, We will call you back soon", "5XylMcfyYsfqGn13NOicwqrQAK", conn);
                      return;
				 }
				
				 else if ( menu.equals("stop"))
				 {
					//String msg= wa.removeFromWhatsapp(msisdn);
					
					 String sql="update outgoing_whatsapp_log set user_resp='STOP',user_resp_date=now() where msg_id='"+id+"'";
					 System.out.println("SQL="+sql);
					 wa.updateCallBackURL(id, "read", from.substring(2), "STOP");
					 Statement st=conn.createStatement();
					 st.executeUpdate(sql);
					 System.out.println("SQL="+sql);

					 sql="update cust_status set cust_status='"+"STOP"+"' where msisdn='"+msisdn+"' and account_id='"+account_id+"'";
					 int cnt=st.executeUpdate(sql);
					 if ( cnt ==0)
					 {
					 	sql="insert into cust_status(msisdn,status,account_id) values('"+msisdn+"','"+"STOP"+"','"+account_id+"')";
					 }
					 st.executeUpdate(sql);
					 
					
					    String json="";
					    
					    JSONObject jb3 = new JSONObject();
						jb3.put("messaging_product","whatsapp");
						jb3.put("to","91"+from.substring(2));
						jb3.put("type","template");
						JSONObject jtemp= new JSONObject();
						jtemp.put("name","template_subscribeagain");
						JSONObject jlang= new JSONObject();
						jlang.put("code","en");
						
					   jtemp.put("language",jlang);
						
						
						
							
					     jb3.put("template",jtemp);
					     
					     System.out.println("JSON="+jb3.toString());
					     
					     json=jb3.toString();
					     
					
					     wa.sendWhatsappJSONMsgNoUUID(msisdn, json, account_id, conn, "");
					

					 
				 }
				 

				 else if ( menu.equals("subscribe"))
				 {
					//String msg= wa.removeFromWhatsapp(msisdn);
					
					 String sql="update outgoing_whatsapp_log set user_resp='SUBSCRIBE',user_resp_date=now() where msg_id='"+id+"'";
					 System.out.println("SQL="+sql);

					 Statement st=conn.createStatement();
					 st.executeUpdate(sql);
					 
					 wa.updateCallBackURL(id, "read", from.substring(2), "SUBSCRIBE");
					 

					 sql="update cust_status set status='"+"SUBSCRIBE"+"' where msisdn='"+msisdn+"'";
					 int cnt=st.executeUpdate(sql);
					 if ( cnt ==0)
					 {
					 	sql="insert into cust_status(msisdn,status) values('"+msisdn+"','"+"SUBSCRIBE"+"')";
					 }
					 st.executeUpdate(sql);
					 

					 System.out.println("SQL_SUBSCRIBE="+sql);

			    		wa.sendMessage360("121212122", from,"Thanks for choosing Techsquadteam, We will keep updating you about the exiciting offers.", "5XylMcfyYsfqGn13NOicwqrQAK", conn);

					

					 
				 }
					
				
				 else if ( menu.equals("no"))
				 {
					 String sql="update outgoing_whatsapp_log set user_resp='NO',user_resp_date=now() where msg_id='"+id+"'";
					 System.out.println("SQL="+sql);

					 Statement st=conn.createStatement();
					 st.executeUpdate(sql);
					 
					
					 
					 
					 wa.updateCallBackURL(id, "read", from.substring(2), "NO");


					   
                     
					 wa.sendMessage360("121212122", from,"We have noted your choice. In future we will come back with an exiciting offer.", "5XylMcfyYsfqGn13NOicwqrQAK", conn);
					 
                     return;
				 }
					  
					    
							
					 
			 } 
				
			 
				
				
		    
		}

		
		
		//org.json.simple.JSONArray jarr1=(org.json.simple.JSONArray)jsonObject.get("contacts");
		
	}
	else
	{
		
		org.json.simple.JSONObject jb=(org.json.simple.JSONObject)jarr.get(0);
		String msg_id=(String)jb.get("id");
		String body=jb.toJSONString();
		String to_num="";
		try
		{
		  to_num=(String)jb.get("recipient_id");
		}
		catch ( Exception ex)
		{
		}
		String status=(String)jb.get("status");
		
		String conversation_id="";
		
		try
		{
		conversation_id=(String)((org.json.simple.JSONObject)jb.get("conversation")).get("id");
		}
		catch ( Exception ex)
		{
		}
		
		if ( body.contains("user_initiated") ||  body.contains("business_initiated"))
		{
		
		/* WhatsAppMessage wa = new WhatsAppMessage();
		 org.json.JSONObject js= wa.getSessionInfo(to_num, conn,account_id);
		 if ( js==null)
		 {
			
			js= new org.json.JSONObject();
		  js.put("session_id",conversation_id);
		   wa.updateSessionInfo(to_num, conn, js,account_id);
		}*/
		 
		 
		 
		 
		}
		String sql="select * from outgoing_whatsapp_log where msg_id='"+msg_id+"'";
		Statement st= conn.createStatement();
		ResultSet rs= st.executeQuery(sql);
		if ( !rs.next())
		{
		
		String pssql="insert into outgoing_whatsapp_log(to_msisdn,message,msg_id,call_type,msg_status,conversation_id,account_id) values(?,?,?,?,?,?,?)";
		PreparedStatement ps=conn.prepareStatement(pssql);
		ps.setString(1,to_num);
		ps.setString(2,body);
		ps.setString(3,msg_id);
		ps.setString(4,"outgoing");
		ps.setString(5,status);
		ps.setString(6,conversation_id);
		ps.setString(7,account_id);

		

		ps.executeUpdate();
		}
		else
		{
			  WhatsAppMessage wa = new WhatsAppMessage();

		
			 wa.updateCallBackURL(msg_id,status, to_num.substring(2), "NA");

		
	    sql="update outgoing_whatsapp_log set conversation_id='"+conversation_id+"', msg_status='"+status+"' where msg_id='"+msg_id+"'";
	    
		Statement stupd=conn.createStatement();
		stupd.executeUpdate(sql);
		
		}

		
		
		
		
		
	}
}
catch ( Exception ex)
{
	ex.printStackTrace();
	
}



              
                
                               
                                
                                  
                                   
           
                
               
} catch (Exception e) {

e.printStackTrace();
JSONObject jstat =new JSONObject();
JSONObject jres = new JSONObject();
JSONObject jout = new JSONObject();


jstat.put("statusCode", "1");
           jstat.put("errorCode","101");
           jstat.put("errorMessage","UNKNOWN_ERROR");
           jres.put("status", jstat);
           jout.put("result", jres);
          out.println( jout.toString());

/* 18 */
/*    */     }finally{
                        try{
                        	conn.close();
                        }catch(Exception exx)
                                                               {
                            
                        }
                    }



%>

