package helper;
import java.io.BufferedInputStream;
import java.io.FileOutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Calendar;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import com.itextpdf.text.Document;
import com.itextpdf.text.io.RandomAccessSourceFactory;
import com.itextpdf.text.pdf.PdfCopy;
import com.itextpdf.text.pdf.PdfDictionary;
import com.itextpdf.text.pdf.PdfImportedPage;
import com.itextpdf.text.pdf.PdfName;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.RandomAccessFileOrArray;

public class Utility {

final int BLANK_THRESHOLD=160;
	
	boolean checkBlankPdfImage(String source, String destination)
    
    {
		//URLEncoder.encode("xx","utf8");
        PdfReader r = null;
        RandomAccessSourceFactory rasf = null;
        RandomAccessFileOrArray raf = null;
        Document document = null;
        PdfCopy writer = null;

        try {
            r = new PdfReader(source);
            // deprecated
            //    RandomAccessFileOrArray raf
            //           = new RandomAccessFileOrArray(pdfSourceFile);
            // itext 5.4.1
            rasf = new RandomAccessSourceFactory();
            raf = new RandomAccessFileOrArray(rasf.createBestSource(source));
            document = new Document(r.getPageSizeWithRotation(1));
           
            document.open();
            PdfImportedPage page = null;

            for (int i=1; i<=r.getNumberOfPages(); i++) {
                // first check, examine the resource dictionary for /Font or
                // /XObject keys.  If either are present -> not blank.
                PdfDictionary pageDict = r.getPageN(i);
                PdfDictionary resDict = (PdfDictionary) pageDict.get( PdfName.RESOURCES );
                boolean noFontsOrImages = true;
                if (resDict != null) {
                  noFontsOrImages = resDict.get( PdfName.FONT ) == null &&
                                    resDict.get( PdfName.XOBJECT ) == null;
             
                }
                System.out.println("source ="+source+" "+noFontsOrImages);
                if ( !noFontsOrImages)
                {
                	return true;
                }
                else
                {
                	return false;
                }
               
            }
        }
        catch ( Exception ex)
        {
        	ex.printStackTrace();
        	return false;
        }
        return false;
       
    }
	
	public void 
	sendDuplicateBill(String msisdn,String canumber,String key,String session_id, String account_id,
			String mylang,Connection conn) throws Exception
	
	{
		Calendar ca= Calendar.getInstance();
		
		String sql="select prompt from prompt_detail where account_id='"+account_id+"' and lang='"+mylang+"' and prompt_type='CONTEXT_WAITING'";
		Statement st=conn.createStatement();
		ResultSet rs=st.executeQuery(sql);
		String prompt="";
		if ( rs.next())
		{
			prompt=rs.getString("prompt");
			WhatsAppMessage wa=new WhatsAppMessage();
			//wa.sendMessage(session_id, msisdn, prompt, key, conn);
		}
		
		
		

		
		String reading=getMeterReading(ca.get(Calendar.MONTH)+"",ca.get(Calendar.YEAR)+"" ,canumber+".pdf", "/home/tpwodl_images/", canumber);
		
		if ( reading.equals("sucess"))
		{
String json="{\n"
	+ "	\"to\": \""+msisdn+"\",\n"
	+ "	\"type\": \"document\",\n"
	+ "	\"recipient_type\": \"individual\",\n"
	+ "	\"document\": {\n"
	+ "		\"provider\": {\n"
	+ "			\"name\": \"\"\n"
	+ "		},\n"
	+ "		\"caption\": \"Meter Detail\",\n"
	+ "		\"link\": \"https://ha1.msg2all.com:8443/tpwodl_images/"+canumber+".pdf"+"\",\n"
	+ "		\"filename\": \"bill\"\n"
	+ "	}\n"
	+ "}";

WhatsAppMessage wa=new WhatsAppMessage();
wa.getResponseWhatsapp(session_id, json, key);

//sendWhatsappMsg(session_id, json,msisdn);
//HTTPRequest.getResponseWhatsapp(getMycallid(),json);
			
		}
		else
		{
			/*String json="{\n"
					+ "  \"recipient_type\": \"individual\",\n"
					+ "   \"type\": \"text\",\n"
					+ "  \"to\": \""+msisdn+"\",\n"
					+ "\"text\": {\n"
					+ "    \"body\": \"Sorry.. We are not able to fetch the data. Please try after sometime\"\n"
					+ "  }\n"
					+ "  \n"
					+ "  \n"
					+ "  \n"
					+ " \n"
					+ "  \n"
					+ "}";*/
		//	sendWhatsappMsg(getMycallid(), json,msisdn);

			//HTTPRequest.getResponseWhatsapp(getMycallid(),json);
			
			 sql="select prompt from prompt_detail where account_id='"+account_id+"' and lang='"+mylang+"' and prompt_type='CONTEXT_WAITING'";
			 st=conn.createStatement();
			 rs=st.executeQuery(sql);
			 prompt="";
			if ( rs.next())
			{
				prompt=rs.getString("prompt");
				WhatsAppMessage wa=new WhatsAppMessage();
			//	wa.sendMessage(session_id, msisdn, prompt, key, conn);
			}
			

		}
	
			
	
	}
	
	public String getMeterReading(String month,String year,String filename, String filepath,String ca)
	{
		try
		{
		TrustManager[] trustAllCerts = new TrustManager[] {
		        new X509TrustManager() {
		          public java.security.cert.X509Certificate[] getAcceptedIssuers() {
		           return null;
		          }
		         
				@Override
				public void checkClientTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
					// TODO Auto-generated method stub
					
				}
				
				

				@Override
				public void checkServerTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
					// TODO Auto-generated method stub
					
				}
		          }
		     };

		  SSLContext sc=null;
		  try {
		   sc = SSLContext.getInstance("SSL");
		  } catch (NoSuchAlgorithmException e) {
		   e.printStackTrace();
		  }
		  try {
		   sc.init(null, trustAllCerts, new java.security.SecureRandom());
		  } catch (KeyManagementException e) {
		   e.printStackTrace();
		  }
		  HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
		  // Create all-trusting host name verifier
		  HostnameVerifier validHosts = new HostnameVerifier() {
		  @Override
		  public boolean verify(String arg0, SSLSession arg1) {
		   return true;
		  }
		  };
		  // All hosts will be valid
		  HttpsURLConnection.setDefaultHostnameVerifier(validHosts);
		String url="https://tpwodlwss.tpodisha.com/fgweb/web/json/plugin/com.flg.jcu.plugin.DynamicReportGenerator/service?name=billPrint&month="+month+"&year="+year+"&scno="+ca+"&discom=WESCO&contractLoad=2.00%20KW&loadType=L";
		System.out.println("URL="+url);
		URL url1 = new URL(url);
		URLConnection connection = url1.openConnection();
		HttpsURLConnection  httpConn = ((HttpsURLConnection)connection);
		BufferedInputStream in = new BufferedInputStream(
				httpConn.getInputStream());
		
		
				  FileOutputStream fileOutputStream = new FileOutputStream(filepath+"/"+filename) ;
				    byte dataBuffer[] = new byte[1024];
				    int bytesRead;
				    while ((bytesRead = in.read(dataBuffer, 0, 1024)) != -1) {
				        fileOutputStream.write(dataBuffer, 0, bytesRead);
				    }
				    
				   
				   if (  !checkBlankPdfImage(filepath+"/"+filename,filepath+"/"+filename))
				   {
					   int newyear=Integer.parseInt(year);
					   
					   int newmonth=Integer.parseInt(month);
					   if ( newmonth !=1)
					   {
						   newmonth=newmonth-1;
					   }
					   else
					   {
						   newmonth=12;
						   newyear=newyear-1;
						   
					   }
					    url="https://tpwodlwss.tpodisha.com/fgweb/web/json/plugin/com.flg.jcu.plugin.DynamicReportGenerator/service?name=billPrint&month="+newmonth+"&year="+newyear+"&scno="+ca+"&discom=WESCO&contractLoad=2.00%20KW&loadType=L";
						System.out.println("URL="+url);
						 url1 = new URL(url);
						 connection = url1.openConnection();
						  httpConn = ((HttpsURLConnection)connection);
						 in = new BufferedInputStream(
								httpConn.getInputStream());
						
						
								   fileOutputStream = new FileOutputStream(filepath+"/"+filename) ;
								      byte dataBuffer1[] = new byte[1024];
								    while ((bytesRead = in.read(dataBuffer1, 0, 1024)) != -1) {
								        fileOutputStream.write(dataBuffer1, 0, bytesRead);
								    }
					   
				   }
				    return "sucess";
				
		}
		catch ( Exception ex)
		{
			ex.printStackTrace();
			return "fail";
		}
		
	}
}
