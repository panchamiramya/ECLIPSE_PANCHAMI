package helper;

import org.json.simple.parser.JSONParser;

public class Main1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try
		{
		String myresp="{\n"
				+ "   \"entry\":[\n"
				+ "      {\n"
				+ "         \"changes\":[\n"
				+ "            {\n"
				+ "               \"field\":\"messages\",\n"
				+ "               \"value\":{\n"
				+ "                  \"metadata\":{\n"
				+ "                     \"phone_number_id\":\"103721232450852\",\n"
				+ "                     \"display_phone_number\":\"918792326060\"\n"
				+ "                  },\n"
				+ "                  \"messaging_product\":\"whatsapp\",\n"
				+ "                  \"messages\":[\n"
				+ "                     {\n"
				+ "                        \"from\":\"918073131344\",\n"
				+ "                        \"id\":\"wamid.HBgMOTE4MDczMTMxMzQ0FQIAEhggNjRGQzFEQ0QwREYxNURCNTBFOEVEQzJERkY1MTQxRkEA\",\n"
				+ "                        \"text\":{\n"
				+ "                           \"body\":\"Hi\"\n"
				+ "                        },\n"
				+ "                        \"type\":\"text\",\n"
				+ "                        \"timestamp\":\"1660205970\"\n"
				+ "                     }\n"
				+ "                  ],\n"
				+ "                  \"contacts\":[\n"
				+ "                     {\n"
				+ "                        \"profile\":{\n"
				+ "                           \"name\":\"Bank Of Baroda\"\n"
				+ "                        },\n"
				+ "                        \"wa_id\":\"918073131344\"\n"
				+ "                     }\n"
				+ "                  ]\n"
				+ "               }\n"
				+ "            }\n"
				+ "         ],\n"
				+ "         \"id\":\"100938666067856\"\n"
				+ "      }\n"
				+ "   ],\n"
				+ "   \"object\":\"whatsapp_business_account\"\n"
				+ "}\n";
				
		JSONParser jsonParser = new JSONParser();



		org.json.simple.JSONObject jsonObject = (org.json.simple.JSONObject)jsonParser.parse(myresp);

			org.json.simple.JSONArray jenrty=(	org.json.simple.JSONArray) jsonObject.get("entry");
			org.json.simple.JSONObject jb1=(org.json.simple.JSONObject)jenrty.get(0);
			org.json.simple.JSONArray jarr_chgs= (org.json.simple.JSONArray) jb1.get("changes");
			
			System.out.println("jarr_chgs"+jarr_chgs.toString());
			
			org.json.simple.JSONObject jb2=(org.json.simple.JSONObject)jarr_chgs.get(0);
			System.out.println("JSONObject"+jb2.toString());
			
		//	((org.json.simple.JSONObject)jarr_chgs.get(0)).get("messages")
			
			org.json.simple.JSONObject values =(org.json.simple.JSONObject)jb2.get("value");
			
		
			
			
			org.json.simple.JSONArray jarr_msgs=(org.json.simple.JSONArray)values.get("messages");
			
			org.json.simple.JSONObject jb=(org.json.simple.JSONObject)jarr_msgs.get(0);
			
			System.out.println(jb.toString());
			
		}
		catch ( Exception ex)
		{
			ex.printStackTrace();
		}

	}

}
