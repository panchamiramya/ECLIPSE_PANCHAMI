import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;

public class MainMIS {
  public static void main(String[] args) {
    String sql = "";
    Connection conn = null;
    try {
      Class.forName("com.mysql.jdbc.Driver").newInstance();
      conn = DriverManager.getConnection("jdbc:mysql://localhost/whatsapp_yes_bank", "root", "");
      Statement st = conn.createStatement();
      Statement st1 = conn.createStatement();
      ResultSet rs = null;
      ResultSet rs1 = null;
      String resp = "";  
      System.out.println("Daily MIS for YES BANK");
      st1 = conn.createStatement();
      String mymsg = "";
        sql = "select staff_mobileno from staff_info where staff_id NOT IN(SELECT DISTINCT(collector_id) FROM case_study where date(created_on) = CURDATE()) ";
        rs = st.executeQuery(sql);
        while (rs.next())
        {
        	String  staff_mobileno = rs.getString("staff_mobileno");	
        	String mymsg_h = "You have not filled up todays data. Kindly fill up today itself without any fail. Thanks. IKNTEL";
        	mymsg = String.valueOf(mymsg_h);
        	System.out.println(mymsg);
        	String url = "http://msg2all.com/TRANSAPI/sendsms.jsp?login=ikonteldemo&passwd=demo%40321&version=v1.0&msg_type=text&msisdn=" + staff_mobileno + "&sender_id=IKNTEL" + "&msg=" + URLEncoder.encode(mymsg, "utf8");
        	System.out.println(url);
        	if (args[1].equals("yesy"))
        		resp = HTTPRequest.getResponse(url); 
        		System.out.println("RESP=" + resp);
        		mymsg = "";
        		System.out.println("XXXXXXXXXXX         if (transport == null)\r\n"
        		+ "            continue; XXXXXXXXXXXXXXXXXXXXXXXXX");
    
        }
    } 
    catch (Exception ex) 
    {
      ex.printStackTrace();
    } 
  }
}
