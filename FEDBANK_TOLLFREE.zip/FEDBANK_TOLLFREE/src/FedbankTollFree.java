import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.StringWriter;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.Base64;
import java.util.Date;
import java.util.Properties;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.net.ssl.HttpsURLConnection;
import org.json.JSONArray;
import org.json.JSONObject;
//import org.apache.commons.codec.binary.Base64;


public class FedbankTollFree {
	
	
	
	
	public static void main(String[] args) throws Exception
	  {
		  
		try
		{	
			 Class.forName("com.mysql.jdbc.Driver");
			 Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/iqhhosp","root","");
			 Statement st = conn.createStatement();
		
			 String msg = "";
			 String id = "";
			 String errorMessage="";
			 String passwd = "fed@321";
			 
			 String sql = "select id,msisdn, fedbank_flag, mylang from cust_resp where app_id = 'fedbank_tollfree' and fedbank_flag = 0 and call_end_time is NOT NULL limit 100";	
			 
			 System.out.println("SQL="+sql);
			 ResultSet rs=st.executeQuery(sql);
				
			 try
			 {
			 Statement st2 = conn.createStatement();
			 JSONObject jb = new JSONObject();
			 while(rs.next())
			 {	
				 	 id = rs.getString("id");
			         String msisdn = rs.getString("msisdn");
			         String fedbank_flag = rs.getString("fedbank_flag");
			         String mylang = rs.getString("mylang");
			         
			         msg = "Dear Customer, thank you for your interest in Gold Loans with FEDBANK. For more details visit our website www.fedfina.com";
			         String url="http://msg2all.com/TRANSAPI/sendsms.jsp?msisdn="+msisdn+"&login=fedmisscall&passwd="+URLEncoder.encode(passwd, "utf8")+"&version=1.0&msg_type=text&sender_id=FEDFIN&msg="+URLEncoder.encode(msg, "utf8");  
			           
			            String result="";
			            
			            result=HTTPRequest.getResponse2(url,jb.toString());
			            JSONObject jb1 = new JSONObject(result);
			            System.out.println( jb1.getJSONObject("result").getJSONObject("status").getString("statusCode"));
			            if ( jb1.getJSONObject("result").getJSONObject("status").getString("statusCode").equals("0"))
			            {
			            	String url2="https://mydialer.123ivr.in/fedbank_dgl/insert_misscall.php?msisdn="+msisdn+"&account_id=38&account_name=fedbank&miscall_no=48685494&mapped_miscall_no=48685494&miscall_server_src=airtel_bng&mylang="+mylang;
			            	String result2=HTTPRequest.getResponse2(url2,jb.toString());
			            	JSONObject jb2 = new JSONObject(result2);
			            	
			            	if ( jb2.getJSONObject("result").getJSONObject("status").getString("statusCode").equals("0"))
				            {
			            		st2.executeUpdate("update cust_resp set fedbank_flag=2 where id= "+id+" ");
			            		System.out.println("RESULT="+result2+(new Date()).toString());
				            }
			            	else
			            	{
			            		errorMessage = jb2.getJSONObject("result").getJSONObject("status").getString("errorMessage");
			            		st2.executeUpdate("update cust_resp set fedbank_flag=10, dispute='"+errorMessage+"' where id= "+id+" ");
			            	}
			            }
			            else
			            {
			            	st2.executeUpdate("update cust_resp set fedbank_flag=12, dispute='"+errorMessage+"' where id= "+id+" ");
			            }
			         }

				 }
				 catch ( Exception ex)
				 {
					ex.printStackTrace();
					System.exit(-1);
					 
				 }
			
			 System.exit(-1);
				 
				
					}
					catch ( Exception ex)
					{
						ex.printStackTrace();
					}
				  }
				
}
