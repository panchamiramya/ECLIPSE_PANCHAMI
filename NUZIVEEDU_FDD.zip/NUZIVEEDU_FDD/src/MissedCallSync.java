import java.sql.*;
import java.util.*;
import java.net.*;
import java.io.*;
import org.json.JSONArray;
import org.json.JSONObject;

public class MissedCallSync {

    // DB Config
    static final String DB_URL = "jdbc:mysql://localhost:3306/farmer_registration_nuziveedu";
    static final String DB_USER = "root";
    static final String DB_PASS = "";

    // Salesforce OAuth (from PDF)
    static final String TOKEN_URL = "https://test.salesforce.com/services/oauth2/token";
    static final String CLIENT_ID = "3MVG9qT0j3YAi4EsvWFi3tXPx7yEVjYmMXnGOMa6BGcqEkjKtktn1zO9vEsRn.Vj8L_5ShaAQQg35BQ85cZBI";
    static final String CLIENT_SECRET = "AA4C2CC29AE65F4A8D9EE95D82E7568561BDD21B8B32CCF506DED577875B4D9C";
    static final String USERNAME = "integrationuser@nsluat.com";
    static final String PASSWORD = "nsl@1234";

    public static void main(String[] args) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {

            String token = getAccessToken();
            if (token == null) {
                System.out.println("Failed to get token");
                return;
            }

            List<Map<String, String>> records = fetchPendingRecords(conn);

            if (records.isEmpty()) {
                System.out.println("No pending records.");
                return;
            }

            // Salesforce allows max 25 records per request (PDF point)
            int batchSize = 25;
            for (int i = 0; i < records.size(); i += batchSize) {
                List<Map<String, String>> batch = records.subList(i, Math.min(i + batchSize, records.size()));
                sendToSalesforce(conn, token, batch);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Step 1: Fetch sync_flag = 0 records
    public static List<Map<String, String>> fetchPendingRecords(Connection conn) throws SQLException {
        List<Map<String, String>> list = new ArrayList<>();

        String sql = "SELECT id,farmer_msisdn, event_code as miscall_no FROM miscall_unique WHERE sync_flag = 0";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            Map<String, String> map = new HashMap<>();
            map.put("id", rs.getString("id"));
            map.put("farmer_msisdn", rs.getString("farmer_msisdn"));
            map.put("miscall_no", rs.getString("miscall_no"));
            list.add(map);
        }
        return list;
    }

    // Step 2: Get OAuth Token
    public static String getAccessToken() {
        try {
            URL url = new URL(TOKEN_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);

            String params = "grant_type=password"
                    + "&client_id=" + URLEncoder.encode(CLIENT_ID, "UTF-8")
                    + "&client_secret=" + URLEncoder.encode(CLIENT_SECRET, "UTF-8")
                    + "&username=" + URLEncoder.encode(USERNAME, "UTF-8")
                    + "&password=" + URLEncoder.encode(PASSWORD, "UTF-8");

            OutputStream os = conn.getOutputStream();
            os.write(params.getBytes());
            os.flush();

            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line, response = "";
            while ((line = br.readLine()) != null) {
                response += line;
            }

            JSONObject json = new JSONObject(response);
            return json.getString("access_token");

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // Step 3: Send Data to Salesforce API
    public static void sendToSalesforce(Connection dbConn, String token, List<Map<String, String>> records) {
        try {
            String apiUrl = "https://nuziveeduseeds--nsluat.sandbox.my.salesforce.com/services/data/v62.0/composite";

            JSONObject mainObj = new JSONObject();
            mainObj.put("allOrNone", false);

            JSONArray compositeArr = new JSONArray();

            for (Map<String, String> rec : records) {
                JSONObject body = new JSONObject();
                
                body.put("Contact_Number__c", rec.get("farmer_msisdn"));

                JSONObject visit = new JSONObject();
                visit.put("External_ID__c", rec.get("miscall_no"));
                body.put("Visit__r", visit);

                JSONObject obj = new JSONObject();
                obj.put("method", "POST");
                obj.put("url", "/services/data/v62.0/sobjects/iKonTel_Details__c");
                obj.put("referenceId", rec.get("id"));
                obj.put("body", body);
                
                compositeArr.put(obj);
            }

            mainObj.put("compositeRequest", compositeArr);

            URL url = new URL(apiUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Authorization", "Bearer " + token);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);

            String payload = mainObj.toString();

            OutputStream os = conn.getOutputStream();
            os.write(payload.getBytes());
            os.flush();

            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line, response = "";
            while ((line = br.readLine()) != null) {
                response += line;
            }
            System.out.println("TOKEN RESPONSE: " + response);
            boolean success = response.contains("\"success\":true");

            // Update DB & Log
            for (Map<String, String> rec : records) {
                updateStatusAndLog(dbConn, rec, payload, response, success);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Step 4: Update sync_flag + retry_count + Log
    public static void updateStatusAndLog(Connection conn, Map<String, String> rec,
                                          String request, String response, boolean success) throws SQLException {

        String updateSql;
        if (success) {
            updateSql = "UPDATE miscall_unique SET sync_flag=2 WHERE id=?";
        } else {
            updateSql = "UPDATE miscall_unique SET sync_flag=9, retry_count=retry_count+1 WHERE id=?";
        }

        PreparedStatement ps = conn.prepareStatement(updateSql);
        ps.setString(1, rec.get("id"));
        ps.executeUpdate();

        String logSql = "INSERT INTO miscall_sync_log (farmer_msisdn, miscall_no, request_payload, response_payload, status, miscall_id) VALUES (?,?,?,?,?,?)";
        PreparedStatement logPs = conn.prepareStatement(logSql);
        logPs.setString(1, rec.get("farmer_msisdn"));
        logPs.setString(2, rec.get("miscall_no"));
        logPs.setString(3, request);
        logPs.setString(4, response);
        logPs.setString(5, success ? "SUCCESS" : "FAILED");
        logPs.setString(6, rec.get("miscall_id"));
        logPs.executeUpdate();
    }
}