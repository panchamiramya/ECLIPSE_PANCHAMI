import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;

import javax.net.ssl.HttpsURLConnection;

public class HTTPRequest {
  public static String getResponse(String url) {
    String res = "";
    BufferedReader in = null;
    OutputStream out = null;
    Writer wout = null;
    try {
      URL url1 = new URL(url);
      System.out.println("url=" + url);
      URLConnection connection = url1.openConnection();
      HttpURLConnection httpConn = (HttpURLConnection)connection;
      httpConn.setReadTimeout(50000);
      httpConn.setConnectTimeout(50000);
      httpConn.setRequestProperty("Accept", "text/html");
      httpConn.setRequestProperty("Content-Type", "text/html");
      httpConn.setRequestMethod("POST");
      httpConn.setDoInput(true);
      httpConn.setDoOutput(true);
      OutputStream out1 = httpConn.getOutputStream();
      out1.write("".getBytes());
      System.out.println("code=" + httpConn.getResponseCode());
      if (httpConn.getResponseCode() == 200) {
        InputStreamReader isr = new InputStreamReader(httpConn.getInputStream());
        in = new BufferedReader(isr);
        String temp = "";
        res = "";
        while ((temp = in.readLine()) != null)
          res = String.valueOf(res) + temp; 
        System.out.println("res_ok=" + res);
      } else {
        InputStreamReader isr = new InputStreamReader(httpConn.getErrorStream());
        in = new BufferedReader(isr);
        String temp = "";
        res = "";
        while ((temp = in.readLine()) != null)
          res = String.valueOf(res) + temp; 
        System.out.println("res_err=" + res);
      } 
    } catch (Exception ex) {
      ex.printStackTrace();
      return "servererror";
    } finally {
      try {
        in.close();
        wout.close();
        out.close();
      } catch (Exception exception) {}
    } 
    String decoderes = "";
    try {
      decoderes = URLDecoder.decode(res, "utf8");
      System.out.println("decoderes" + decoderes);
    } catch (Exception ex) {
      ex.printStackTrace();
    } 
    return decoderes;
  }
  public static String getResponse1(String url,String json1) {
		System.out.println("URL="+url);
		String res = "";
		URLConnection connection = null;
		HttpsURLConnection httpConn=null;
		//HttpURLConnection httpConn = null;
		// HttpClient hc = new DefaultHttpClient();
		BufferedReader in = null;
		// OutputStream out=null;
		// Writer wout=null;
		try {
			URL url1 = new URL(url);
			connection = url1.openConnection();
		   httpConn = ((HttpsURLConnection)connection);
			//httpConn = ((HttpURLConnection) connection);
		   httpConn.setRequestProperty("Accept", "application/json");
		   httpConn.setRequestProperty("Content-Type", "application/json");
			httpConn.setReadTimeout(30000);
			httpConn.setConnectTimeout(30000);
			httpConn.setRequestMethod("POST");
			httpConn.setDoInput(true);
			httpConn.setDoOutput(true);
			
			DataOutputStream wr = new DataOutputStream (
		              connection.getOutputStream ());
		  wr.writeBytes (json1);
		  wr.flush ();
		  wr.close ();

			if (httpConn.getResponseCode() == httpConn.HTTP_OK) {
				InputStreamReader isr = new InputStreamReader(
						httpConn.getInputStream());
				in = new BufferedReader(isr);
				String temp = "";
				res = "";
				while ((temp = in.readLine()) != null)
					res += temp;
				//System.out.println("ok :" + res);
			} else {
				InputStreamReader isr = new InputStreamReader(
						httpConn.getErrorStream());
				in = new BufferedReader(isr);
				String temp = "";
				res = "";
				while ((temp = in.readLine()) != null)
					res += temp;
				//System.out.println("error :" + res);
			}

		} catch (Exception ex) {
			ex.printStackTrace();
			return "IOEXP";
		} finally {
			try {
				in.close();
				// wout.close();
				// out.close();
				httpConn.disconnect();

			} catch (Exception tx) {
				tx.printStackTrace();
			}
		}

		return res;
	}  
  
  public static String getResponse2(String url, String json1) {
      System.out.println("URL=" + url);
      String res = "";
      HttpURLConnection httpConn = null;
      BufferedReader in = null;
      try {
          URL url1 = new URL(url);
          httpConn = (HttpURLConnection) url1.openConnection();
          httpConn.setRequestProperty("Accept", "application/json");
          httpConn.setRequestProperty("Content-Type", "application/json");
          httpConn.setReadTimeout(30000);
          httpConn.setConnectTimeout(30000);
          httpConn.setRequestMethod("POST");
          httpConn.setDoInput(true);
          httpConn.setDoOutput(true);

          DataOutputStream wr = new DataOutputStream(httpConn.getOutputStream());
          wr.writeBytes(json1);
          wr.flush();
          wr.close();

          if (httpConn.getResponseCode() == httpConn.HTTP_OK) {
              InputStreamReader isr = new InputStreamReader(httpConn.getInputStream());
              in = new BufferedReader(isr);
              String temp = "";
              res = "";
              while ((temp = in.readLine()) != null)
                  res += temp;
          } else {
              InputStreamReader isr = new InputStreamReader(httpConn.getErrorStream());
              in = new BufferedReader(isr);
              String temp = "";
              res = "";
              while ((temp = in.readLine()) != null)
                  res += temp;
          }

      } catch (Exception ex) {
          ex.printStackTrace();
          return "IOEXP";
      } finally {
          try {
              if (in != null)
                  in.close();
              if (httpConn != null)
                  httpConn.disconnect();
          } catch (Exception tx) {
              tx.printStackTrace();
          }
      }
      return res;
  }

	
}

