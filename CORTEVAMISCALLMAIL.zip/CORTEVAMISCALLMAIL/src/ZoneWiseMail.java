import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import javax.mail.Address;
import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class ZoneWiseMail {
  public static void main(String[] args) {
    try {
      Class.forName("com.mysql.jdbc.Driver");
      System.out.println("connection established");
      Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/miscall_generic", "miscall_generic", "#ikontel@123");
      System.out.println("Connected");
      String regex = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
      String from = "info@ikontel.com";
      String ccmailids = "sikharani.parida@ikontel.com,sudeshna@ikontel.com,panchami.c@ikontel.com";
      String filepath = "0";
      String formattedDate = "";
      String strDateFormat = "yyyy-MM-dd";
      Date date = new Date();
      DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
      formattedDate = dateFormat.format(date);
      String sub = "CORTEVA MISCALL REPORT FOR " + formattedDate;
      String sql = "SELECT msisdn,miscall_time FROM miscall_tab WHERE shortcode = '918045014000' and DATE(miscall_time) = CURDATE() ";
      System.out.println(sql);
      Statement stmt = conn.createStatement();
      ResultSet rs=stmt.executeQuery(sql);
      String resultBody = "";
      while (rs.next()) {
    	  String msisdn = rs.getString("msisdn");
	      String miscall_time = rs.getString("miscall_time");
	      
	      String miscallsql = "SELECT msisdn,miscall_time FROM miscall_tab WHERE shortcode = '918045014000' and DATE(miscall_time) = CURDATE() ";
	      System.out.println(miscallsql);
	      Statement miscallstmt = conn.createStatement();
          ResultSet miscallrs = miscallstmt.executeQuery(miscallsql);
          if (miscallrs.next()) {
        	  resultBody = String.valueOf(String.valueOf(resultBody)) + "<tr>";
        	  resultBody = String.valueOf(String.valueOf(resultBody)) + "<td>" + msisdn + "</td>";
        	  resultBody = String.valueOf(String.valueOf(resultBody)) + "<td>" + miscall_time + "</td>";
        	  resultBody = String.valueOf(String.valueOf(resultBody)) + "</tr>";
           
          } 
        
      } 
      String mailids = "hima.reddy@corteva.com,rudraraju.verma@corteva.com,nishtha.arora@corteva.com,ankit.sharma@corteva.com";
      String[] emailAddresses = mailids.split(",");
      InternetAddress[] recipients = new InternetAddress[emailAddresses.length];
      for (int i = 0; i < emailAddresses.length; i++) {
          recipients[i] = new InternetAddress(emailAddresses[i]);
      }
      
      String text = "Hi Team" + " ,<br /><br >Below is the miscall report for " + formattedDate + ".<br /><br />";
      boolean validEmails = true;
      for (String emailAddress : emailAddresses) {
          if (!emailAddress.matches("^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$")) {
              System.out.println("Invalid email address: " + emailAddress);
              validEmails = false;
              break;
          }
      }
      if (validEmails) {
          text = String.valueOf(String.valueOf(text)) + "<table border='1' cellpadding='5' cellspacing='0' style='font-size: 9pt;font-family: sans-serif;color:black'>";
          text = String.valueOf(String.valueOf(text)) + "<thead>";
          text = String.valueOf(String.valueOf(text)) + "<tr style='background:lightblue;'>";
          text = String.valueOf(String.valueOf(text)) + "<th>MSISDN</th>";
          text = String.valueOf(String.valueOf(text)) + "<th>MISCALL DATE</th>"; 
          text = String.valueOf(String.valueOf(text)) + "</tr>";
          text = String.valueOf(String.valueOf(text)) + "</thead>";
          text = String.valueOf(String.valueOf(text)) + "<tbody>";
          text = String.valueOf(String.valueOf(text)) + resultBody;
          text = String.valueOf(String.valueOf(text)) + "</tbody>";
          text = String.valueOf(String.valueOf(text)) + "</table>";
          System.out.println(text);
          Transport transport = null;
          String host = "email-smtp.eu-west-1.amazonaws.com";
          Properties props = System.getProperties();
          int PORT = 465;
          props.put("mail.transport.protocol", "smtp");
          props.put("mail.smtp.auth", "true");
          props.put("mail.smtp.socketFactory.port", Integer.valueOf(465));
          props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
          props.put("mail.smtp.auth", "true");
          props.put("mail.smtp.port", "465");
          props.put("mail.smtp.host", "email-smtp.eu-west-1.amazonaws.com");
          props.put("mail.smtp.starttls.enable", "true");
          props.put("line.separator", "\r\n");
          props.put("mail.debug", "true");
          String SMTP_USERNAME = "AKIAJXDE5LZYJEHFLACQ";
          String SMTP_PASSWORD = "Ai0zhtdrRG065i8+xdUAAMa9I7U/xvxmJ+Oc3tHlqZCb";
          Session session = Session.getDefaultInstance(props, new Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                  return new PasswordAuthentication("AKIAJXDE5LZYJEHFLACQ", "Ai0zhtdrRG065i8+xdUAAMa9I7U/xvxmJ+Oc3tHlqZCb");
                }
              });
          try {
            transport = session.getTransport();
            MimeMessage message = new MimeMessage(session);
            message.setFrom((Address)new InternetAddress("info@ikontel.com"));
            message.addRecipients(Message.RecipientType.TO, recipients);
            message.setRecipients(Message.RecipientType.CC, (Address[])InternetAddress.parse("sikharani.parida@ikontel.com,sudeshna@ikontel.com,panchami.c@ikontel.com"));
            message.setSubject(sub);
            MimeBodyPart mbp1 = new MimeBodyPart();
            mbp1.setContent(text, "text/html; charset=utf-8");
            MimeMultipart mimeMultipart = new MimeMultipart();
            mimeMultipart.addBodyPart((BodyPart)mbp1);
            message.setContent((Multipart)mimeMultipart);
            Transport.send((Message)message);
            System.out.println("success in sending mail");
          } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Error in sending mail");
          } finally {
            if (transport != null)
              try {
                transport.close();
              } catch (Exception exception) {} 
          } 
          try {
            transport.close();
          } catch (Exception exception) {}
          
        } 
        else
        {
        	System.out.println("Email id is not valid");
        }	
      conn.close();
    } catch (SQLException se) {
      se.printStackTrace();
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
}
