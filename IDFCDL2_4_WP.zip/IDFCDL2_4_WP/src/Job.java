import java.net.URLEncoder;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.json.JSONObject;

public class Job implements Runnable {
  String id;
  
  String lanNo;
  
  String customerName;
  
  String msisdn;
  
  String referNumber;
  
  String productType;
  
  String dueAmt;
  
  String dunningType;
  
  String languageType;
  
  String recordId;
  
  String branchAddress;
  
  String customerAddress;
  
  String noticeDate;
  
  String msg;
  
  ThreadPool tp = null;
  
  MyDBPool dp;
  
  public Job(DunningInfo dnobj, ThreadPool tp, MyDBPool dp, String id, String recordId) {
    this.lanNo = dnobj.getLanNo();
    this.dunningType = dnobj.getDunningType();
    this.languageType = dnobj.getlanguageType();
    this.dueAmt = dnobj.getDueAmt();
    this.productType = dnobj.getProductType();
    this.referNumber = dnobj.getRefNumber();
    this.msisdn = dnobj.getMsisdn();
    this.customerName = dnobj.getCustomerName();
    this.recordId = recordId;
    this.branchAddress = dnobj.getBranchAddress();
    this.customerAddress = dnobj.getCustomerAddress();
    this.noticeDate = dnobj.getNoticeDate();
    this.msg = dnobj.getMsg();
    this.tp = tp;
    this.dp = dp;
    this.id = id;
  }
  
  public void run() {
    try {
      System.out.println("CALLING TEMPLATE PROCESSING METHOD: " + this.id);
      Connection conn = null;
      conn = this.dp.getConnection();
      String processTemplateResponse = processTemplate(this.lanNo, this.customerName, this.dunningType, this.languageType, this.dueAmt, this.productType, 
          this.referNumber, this.recordId, this.id, this.msisdn, this.branchAddress, this.noticeDate, conn);
      String sql = "";
      if (processTemplateResponse.equals("SUCCESS")) {
        sql = "UPDATE dunning SET process_flag = 1, modified_on = NOW() WHERE id = '" + this.id + "'";
      } else {
        sql = "UPDATE dunning SET process_flag = 2, modified_on = NOW() WHERE id = '" + this.id + "'";
      } 
      try {
        Statement stmt = conn.createStatement();
        int statusRs = stmt.executeUpdate(sql);
        System.out.println("STATUS RESULT = " + statusRs);
        stmt.close();
      } catch (Exception e) {
        e.printStackTrace();
      } finally {
        conn.close();
      } 
      System.out.println("COMPLETED JOB");
      this.tp.setNoOfCompletedTasks();
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  public static String currentDate() {
    Date dateTime = new Date();
    String strDateFormat = "dd-MMM-yyyy";
    DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
    return dateFormat.format(dateTime);
  }
  
  public static String formatNoticeDate(String noticeDate) {
    try {
      SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");
      Date date = inputFormat.parse(noticeDate);
      SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MMM-yyyy");
      return outputFormat.format(date);
    } catch (ParseException e) {
      e.printStackTrace();
      return noticeDate;
    } 
  }
  
  public LinkInfo generateQuicklink2(String account_id, String myurl, String filename) throws Exception {
    String va = "";
    String name = "";
    String amount = "";
    String url = "http://api.anymsg.in/ALLLINKS/createQuick.jsp?myurl=" + URLEncoder.encode(myurl, "utf8") + "&filename=" + 
      URLEncoder.encode(filename, "utf8");
    String resp = HTTPRequest.getResponse(url);
    System.out.println("RESP=" + resp);
    JSONObject jb = new JSONObject(resp);
    String tinyurl = "";
    if (jb.getJSONObject("result").getJSONObject("status").getString("statusCode").equals("0"))
      tinyurl = jb.getJSONObject("result").getString("tinyurl"); 
    String msg = "";
    if (tinyurl.length() != 0) {
      LinkInfo li = new LinkInfo();
      li.quicklink_part1 = "http://q.ikns.biz/" + tinyurl;
      li.quicklink_part2 = tinyurl;
      System.out.println("URL Generated =" + tinyurl);
      return li;
    } 
    return null;
  }
  
  public static String currentDateFormat() {
    Date dateTime = new Date();
    String strDateFormat = "ddMMyyyyHHmmss";
    DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
    return dateFormat.format(dateTime);
  }
  
  public String generateQuicklink(String myurl, String filename) throws Exception {
    String url = "https://api.anymsg.in/ALLLINKS/createQuick.jsp?myurl=" + URLEncoder.encode(myurl, "utf8") + "&filename=" + 
      URLEncoder.encode(filename, "utf8");
    String resp = HTTPRequest.getResponse(url);
    System.out.println("RESP=" + resp);
    JSONObject jb = new JSONObject(resp);
    String tinyurl = "";
    if (jb.getJSONObject("result").getJSONObject("status").getString("statusCode").equals("0"))
      tinyurl = jb.getJSONObject("result").getString("tinyurl"); 
    if (tinyurl.length() != 0) {
      System.out.println("URL Generated =" + tinyurl);
      return tinyurl;
    } 
    return "";
  }
  
  public String processTemplate(String lanNo, String customerName, String dunningType, String languageType, String dueAmt, String productType, String referNumber, String recordId, String id, String msisdn, String branchAddress, String noticeDate, Connection conn) {
    String response = "";
    try {
      String sql = "SELECT template FROM template WHERE letter_type = '" + dunningType + "' and language_type= '"+languageType+"'LIMIT 1";
      Statement stmt = conn.createStatement();
      ResultSet rs = stmt.executeQuery(sql);
      String template = "";
      while (rs.next())
        template = rs.getString("template"); 
      template = template.replaceAll("#EMIAMT", dueAmt);
      template = template.replaceAll("#PRODUCTTYPE", productType);
      template = template.replaceAll("#NAME", customerName);
      template = template.replaceAll("#REFNUM", referNumber);
      template = template.replaceAll("#LANNO", lanNo);
      template = template.replaceAll("#DATE", formatNoticeDate(noticeDate));
      template = template.replaceAll("#BRANCHADDRESS", branchAddress);
      String pdfDateFormat = currentDateFormat();

      String htmlFile = String.valueOf(String.valueOf(lanNo)) + "_" + pdfDateFormat + "_DUNNING-" + msisdn + ".html";
      Files.write(Paths.get(
            "/data/idfc/" + htmlFile, 
            new String[0]), template.getBytes("UTF-8"), new java.nio.file.OpenOption[0]);
      String updateSql = "UPDATE dunning SET pdf_file_name = '" + String.valueOf(lanNo) + "_" + pdfDateFormat + "_DUNNING.pdf' WHERE id = '" + 
        id + "'";
      Statement stmtUp = conn.createStatement();
      Statement stmtUp2 = conn.createStatement();
      int upRs = stmtUp.executeUpdate(updateSql);
      stmtUp.close();
      System.out.println("UPDATE SQL = " + upRs);
      response = "SUCCESS";
      String qlink = "";
      String myurl = "https://api.anymsg.in/MYPDF/" + String.valueOf(lanNo) + "_" + pdfDateFormat + "_DUNNING.pdf";
      String li = generateQuicklink(myurl, "DUNNING");
      System.out.println("LINK INFO = " + li);
      qlink = "https://q.ikns.biz/" + li;
      String sms = "Dear " + customerName + ", A notice is sent to you due to non payment of your " + productType + 
        "  LAN " + lanNo + " outstanding " + dueAmt + " in the link " + qlink + 
        ". Please click the link to view the notice. ";
      sql = "update dunning set msg='" + sms + "' where id=" + id;
      System.out.println("ABBBB" + sql);
      stmtUp2.executeUpdate(sql);
      stmtUp2.close();
    } catch (Exception e) {
      e.printStackTrace();
      response = "ERROR";
    } 
    return response;
  }
}
