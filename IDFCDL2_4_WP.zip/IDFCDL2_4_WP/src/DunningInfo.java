public class DunningInfo {
  String lanNo;
  
  String id;
  
  String customerName;
  
  String productType;
  
  String refNumber;
  
  String noticeDate;
  
  String dueAmt;
  
  String msisdn;
  
  String dunningType;
  
  String languageType;
  
  String recordId;
  
  String branchAddress;
  
  String customerAddress;
  
  String msg;
  
  String reqId;
  
  public void setRecordId(String recordId) {
    this.recordId = recordId;
  }
  
  public void setRefNumber(String refNumber) {
    this.refNumber = refNumber;
  }
  
  public void setID(String id) {
    this.id = id;
  }
  
  public void setLanNo(String lanNo) {
    this.lanNo = lanNo;
  }
  
  public void setCustomerName(String customerName) {
    this.customerName = customerName;
  }
  
  public void setProductType(String productType) {
    this.productType = productType;
  }
  
  public void setDueAmt(String dueAmt) {
    this.dueAmt = dueAmt;
  }
  
  public void setMsisdn(String msisdn) {
    this.msisdn = msisdn;
  }
  
  public void setDunningType(String dunningType) {
    this.dunningType = dunningType;
  }
  
  public void setLanguageType(String languageType) {
	    this.languageType = languageType;
	  }
  
  public void setNoticeDate(String noticeDate) {
    this.noticeDate = noticeDate;
  }
  
  public void setBranchAddress(String branchAddress) {
    this.branchAddress = branchAddress;
  }
  
  public void setCustomerAddress(String customerAddress) {
    this.customerAddress = customerAddress;
  }
  
  public void setMsg(String msg) {
    this.msg = msg;
  }
  
  public String getLanNo() {
    return this.lanNo;
  }
  
  public String getCustomerName() {
    return this.customerName;
  }
  
  public String getMsisdn() {
    return this.msisdn;
  }
  
  public String getDueAmt() {
    return this.dueAmt;
  }
  
  public String getProductType() {
    return this.productType;
  }
  
  public String getID() {
    return this.id;
  }
  
  public String getRefNumber() {
    return this.refNumber;
  }
  
  public String getNoticeDate() {
    return this.noticeDate;
  }
  
  public String getDunningType() {
    return this.dunningType;
  }
  
  public String getlanguageType() {
	    return this.languageType;
	  }
  
  public String getRecordId() {
    return this.recordId;
  }
  
  public String getCustomerAddress() {
    return this.customerAddress;
  }
  
  public String getBranchAddress() {
    return this.branchAddress;
  }
  
  public String getMsg() {
    return this.msg;
  }
  
  public void setReqId(String reqId) {
    this.reqId = reqId;
  }
  
  public String getReqId() {
    return this.reqId;
  }
}
