import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.json.JSONObject;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class DataPushAPI {
    public static void main(String[] args) {
        String accessToken = "";
        String agencyName = "ikontel";
       
        //String apiUrl = "https://call-admin.smartcoin.co.in/bot_api/pushcalldata";
        String apiUrl = "https://collection-agents.smartcoin.co.in/pushDispositionData";
        Connection conn1 = null;
        Connection conn = null;

        try {
            //Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/smartcoin", "root", "");
            conn1 = DriverManager.getConnection("jdbc:mysql://172.31.43.6:3306/smartcoin", "smartcoinlog", "India@456");
            String accessTokenQuery = "SELECT access_token FROM smartcoin.account_info_sm WHERE flag=1";
            try (PreparedStatement preparedStatement = conn.prepareStatement(accessTokenQuery);
                 ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    accessToken = resultSet.getString("access_token");
                    //System.out.println("Access Token: " + accessToken);
                } else {
                    System.out.println("No access token found in the database.");
                    return;
                }
            }

            if (!accessToken.isEmpty()) {
              //  String query = "SELECT id, crn, outgoing_no as phone, disposition_name as disposition, callback_comments as remark, ptpdate, recording_file_name as call_recording_mapping, req_date as callDate, agent_id as agent FROM account_outgoing_call_req WHERE account_id=116 and sc_flag=0 order by id desc limit 2";
                String query = "SELECT id, channel_id as sessionId, crn, customer_msisdn as phone, disposition, remarks as remark, when_do as ptpdate, recording_file_name as call_recording_mapping, created_on as callDate, created_by as agent FROM customer_info_call_history WHERE sc_flag=0 order by id desc limit 100";

            	//System.out.println(query);
                

                try (PreparedStatement preparedStatement = conn1.prepareStatement(query);
                     ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        JSONObject requestBody = new JSONObject();
                        requestBody.put("sessionId", resultSet.getString("sessionId"));
                        requestBody.put("crn", resultSet.getString("crn"));
                        requestBody.put("phone", resultSet.getString("phone"));
                        requestBody.put("disposition", resultSet.getString("disposition"));
                        requestBody.put("remark", resultSet.getString("remark"));
                        requestBody.put("ptpdate", resultSet.getString("ptpdate"));
                        //requestBody.put("call_recording_mapping", resultSet.getString("call_recording_mapping"));
                        requestBody.put("call_recording_mapping", convertToMp3(resultSet.getString("call_recording_mapping")));
                        requestBody.put("callDate", resultSet.getString("callDate"));
                        requestBody.put("agent", resultSet.getString("agent"));
                        requestBody.put("agency", "Ikontel.Api");
                        
                        String jsonInputString = requestBody.toString();
                        System.out.println("Input:" + jsonInputString);
                        int id = resultSet.getInt("id");
                        
                        //OkHttpClient client = new OkHttpClient();
                        OkHttpClient client = new OkHttpClient.Builder()
                                .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS) // connection setup
                                .writeTimeout(30, java.util.concurrent.TimeUnit.SECONDS)   // sending data
                                .readTimeout(60, java.util.concurrent.TimeUnit.SECONDS)    // waiting for server response
                                .build();
                        MediaType mediaType = MediaType.parse("application/json");
                        RequestBody body = RequestBody.create(mediaType, jsonInputString);
                        Request request = new Request.Builder()
                                .url(apiUrl)
                                .method("POST", body)
                                .addHeader("Content-Type", "application/json")
                                .addHeader("Authorization", accessToken)
                                .addHeader("agency_name", agencyName)
                                .build();

                        Response response = client.newCall(request).execute();
                        //String responseBody = response.body().string();
                        String responseBody = (response.body() != null) ? response.body().string() : "";
                        System.out.println("Response:" + responseBody);
                        
                        int code = response.code();
                        System.out.println("Code:" + code);
                        if (code == 200) {
                            JSONObject jsonResponse = new JSONObject(responseBody);
                            System.out.println("jsonResponse:" + jsonResponse);
                            String message = jsonResponse.getString("message");
                            ////boolean isTokenValid = jsonResponse.getBoolean("is_token_valid");
                            //int validityInSecs = jsonResponse.getInt("validity_in_secs");

                            System.out.println("Message: " + message);
                            ////System.out.println("Is Token Valid: " + isTokenValid);
                            //System.out.println("Validity in Seconds: " + validityInSecs);

                            if (message.equals("Record pushed successfully")) {
                                updateFlagTo1(conn, id, 1, responseBody);
                            }
                        } else {
                        	updateFlagTo1(conn, id, 10, responseBody);
                            System.out.println("Error Response Code: " + code);
                            System.out.println("Error Response: " + responseBody);
                        }
                    }
                }
            } else {
                System.out.println("Access token not found or empty.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    private static void updateFlagTo1(Connection connection, int id, int flag, String message) throws Exception {
    	String updateQuery = "UPDATE customer_info_call_history SET sc_flag = ?, message = ? WHERE id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(updateQuery)) {
            preparedStatement.setInt(1, flag);
            preparedStatement.setString(2, message);
            preparedStatement.setInt(3, id);
            preparedStatement.executeUpdate();
        }
    }
    
    private static String convertToMp3(String fileName) {
        if (fileName != null && fileName.endsWith(".gsm")) {
            return fileName.substring(0, fileName.length() - 4) + ".mp3";
        }
        return fileName;
    }
}
