import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.json.JSONObject;

public class PushAPI {
    public static void main(String[] args) {
        String accessToken = "";
        String agencyName = "ikontel";
        String apiUrl = "https://qa115-admin.rebase.in/bot_api/pushcalldata";

        String dbUrl = "jdbc:mysql://localhost:3306/smartivr_cloud";
        String dbUser = "oditata";
        String dbPassword = "PowTata@987";

        Connection dbConnection = null;
        Connection conn = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            dbConnection = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/smartcoin", "root", "");
            String accessTokenQuery = "SELECT access_token FROM smartcoin.account_info_sm WHERE flag=1"; 
            try (PreparedStatement preparedStatement = conn.prepareStatement(accessTokenQuery)) {
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                     if (resultSet.next()) {
                         accessToken = resultSet.getString("access_token");
                         System.out.println("Access Token: " + accessToken);
                     } else {
                         System.out.println("No access token found in the database.");
                         return;
                     }
                }
            }

            if (!accessToken.isEmpty()) {
                String query = "SELECT id, crn, outgoing_no as phone, disposition_name as disposition, callback_comments as remark, ptpdate, recording_file_name as call_recording_mapping, req_date as callDate, agent_id as agent FROM account_outgoing_call_req WHERE account_id=116 and sc_flag=0 order by id desc limit 1";
                System.out.println(query);

                try (PreparedStatement preparedStatement = dbConnection.prepareStatement(query)) {
                    try (ResultSet resultSet = preparedStatement.executeQuery()) {
                        while (resultSet.next()) {
                            JSONObject requestBody = new JSONObject();
                            requestBody.put("crn", resultSet.getString("crn"));
                            requestBody.put("phone", resultSet.getString("phone"));
                            requestBody.put("disposition", resultSet.getString("disposition"));
                            requestBody.put("remark", resultSet.getString("remark"));
                            requestBody.put("ptpdate", resultSet.getString("ptpdate"));
                            requestBody.put("call_recording_mapping", resultSet.getString("call_recording_mapping"));
                            requestBody.put("callDate", resultSet.getString("callDate"));
                            requestBody.put("agent", resultSet.getString("agent"));

                            String jsonInputString = requestBody.toString();
                            System.out.println("Input:"+jsonInputString);
                            URL url = new URL(apiUrl);
                            System.out.println("URL:"+url);
                            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                            System.out.println("HTTPURL:"+httpURLConnection);
                            httpURLConnection.setRequestMethod("POST");
                            httpURLConnection.setRequestProperty("Authorization", "Bearer " + accessToken);
                            httpURLConnection.setRequestProperty("agency_name", agencyName);
                            httpURLConnection.setRequestProperty("Content-Type", "application/json");
                            httpURLConnection.setDoOutput(true);

                            try (OutputStream os = httpURLConnection.getOutputStream();
                                 OutputStreamWriter osw = new OutputStreamWriter(os, StandardCharsets.UTF_8)) {
                                osw.write(jsonInputString);
                                osw.flush();
                            }

                            int responseCode = httpURLConnection.getResponseCode();
                            System.out.println("Response:" + responseCode);
                            if (responseCode == HttpURLConnection.HTTP_OK) {
                                try (BufferedReader br = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()))) {
                                    StringBuilder responseContent = new StringBuilder();
                                    String line;
                                    while ((line = br.readLine()) != null) {
                                        responseContent.append(line);
                                    }

                                    JSONObject jsonResponse = new JSONObject(responseContent.toString());

                                    String message = jsonResponse.getString("message");
                                    boolean isTokenValid = jsonResponse.getBoolean("is_token_valid");
                                    int validityInSecs = jsonResponse.getInt("validity_in_secs");

                                    System.out.println("Message: " + message);
                                    System.out.println("Is Token Valid: " + isTokenValid);
                                    System.out.println("Validity in Seconds: " + validityInSecs);

                                    if (message.equals("Data has been received")) {
                                        int id = resultSet.getInt("id");
                                        updateElfagTo1(dbConnection, id);
                                    }
                                }
                            } else {
                                try (BufferedReader br = new BufferedReader(new InputStreamReader(httpURLConnection.getErrorStream()))) {
                                    StringBuilder errorContent = new StringBuilder();
                                    String line;
                                    while ((line = br.readLine()) != null) {
                                        errorContent.append(line);
                                    }

                                    System.out.println("Error Response: " + errorContent.toString());
                                }
                            }
                        }
                    }
                }
            } else {
                System.out.println("Access token not found or empty.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (dbConnection != null) {
                    dbConnection.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    private static void updateElfagTo1(Connection connection, int id) throws Exception {
        String updateQuery = "UPDATE account_outgoing_call_req SET sc_flag = 1 WHERE account_id=116 and id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(updateQuery)) {
            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();
        }
    }
}
