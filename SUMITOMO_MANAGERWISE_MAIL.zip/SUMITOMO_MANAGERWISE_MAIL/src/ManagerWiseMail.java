import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import javax.mail.Address;
import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class ManagerWiseMail {
  public static void main(String[] args) {
    try {
      Class.forName("com.mysql.jdbc.Driver");
      System.out.println("connection established");
      Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/farmer_registration_fdd_sumitomo", "root", "");
      System.out.println("Connected");
      String regex = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
      String from = "info@ikontel.com";
      String ccmailids = "sikharani.parida@ikontel.com,sudeshna@ikontel.com";
      String filepath = "0";
      String formattedDate = "";
      String strDateFormat = "yyyy-MM-dd";
      Date date = new Date();
      DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
      formattedDate = dateFormat.format(date);
      String sub = "SUMITOMO MISCALL COUNT REPORT FOR VP " + formattedDate;
      String sql = "SELECT DISTINCT manager_msisdn,manager_name,manager_email_id,state FROM staff_detail WHERE manager_email_id != '' AND manager_email_id !='NULL' AND manager_email_id IS NOT NULL";
      Statement stmt = conn.createStatement();
      ResultSet rs = stmt.executeQuery("SELECT DISTINCT manager_msisdn,manager_name,manager_email_id,state FROM staff_detail WHERE manager_email_id != '' AND manager_email_id !='NULL' AND manager_email_id IS NOT NULL");
      String managerMsisdn = "";
      String managerEmailId = "";
      String managerName = "";
      while (rs.next()) {
        managerMsisdn = rs.getString("manager_msisdn");
        managerEmailId = rs.getString("manager_email_id");
        managerName = rs.getString("manager_name");
        String subsql = "SELECT staff_msisdn, staff_name, staff_email_id, state from staff_detail where manager_email_id='" + managerEmailId + "' group by staff_msisdn";
        Statement substmt = conn.createStatement();
        ResultSet subrs = substmt.executeQuery(subsql);
        String text = "Dear " + managerName + "(" + managerEmailId + ") ,<br /><br >Below is the miscall count of your DG .<br /><br />";
        String resultBody = "";
        while (subrs.next()) {
          String staffMsisdn = subrs.getString("staff_msisdn");
          String staffName = subrs.getString("staff_name");
          String staffMailId = subrs.getString("staff_email_id");
          String teritory = subrs.getString("state");
          String miscallsql = "select count(id) as miscallcount from miscall_unique where staff_msisdn='" + staffMsisdn + "'";
          Statement miscallstmt = conn.createStatement();
          ResultSet miscallrs = miscallstmt.executeQuery(miscallsql);
          while (miscallrs.next()) {
            String miscallcount = miscallrs.getString("miscallcount");
            resultBody = String.valueOf(String.valueOf(String.valueOf(resultBody))) + "<tr>";
            //resultBody = String.valueOf(String.valueOf(String.valueOf(resultBody))) + "<td>" + area + "</td>";
            //resultBody = String.valueOf(String.valueOf(String.valueOf(resultBody))) + "<td>" + region + "</td>";
            resultBody = String.valueOf(String.valueOf(String.valueOf(resultBody))) + "<td>" + teritory + "</td>";
            resultBody = String.valueOf(String.valueOf(String.valueOf(resultBody))) + "<td>" + staffName + "</td>";
            resultBody = String.valueOf(String.valueOf(String.valueOf(resultBody))) + "<td>" + staffMailId + "</td>";
            resultBody = String.valueOf(String.valueOf(String.valueOf(resultBody))) + "<td>" + staffMsisdn + "</td>";
            resultBody = String.valueOf(String.valueOf(String.valueOf(resultBody))) + "<td>" + miscallcount + "</td>";
            resultBody = String.valueOf(String.valueOf(String.valueOf(resultBody))) + "</tr>";
          } 
        } 
        if (managerEmailId.matches("^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$")) {
          text = String.valueOf(String.valueOf(String.valueOf(text))) + "<table border='1' cellpadding='5' cellspacing='0' style='font-size: 9pt;font-family: sans-serif;color:black'>";
          text = String.valueOf(String.valueOf(String.valueOf(text))) + "<thead>";
          text = String.valueOf(String.valueOf(String.valueOf(text))) + "<tr style='background:lightblue;'>";
          //text = String.valueOf(String.valueOf(String.valueOf(text))) + "<th>BLOCK</th>";
          //text = String.valueOf(String.valueOf(String.valueOf(text))) + "<th>REGION</th>";
          text = String.valueOf(String.valueOf(String.valueOf(text))) + "<th>STATE</th>";
          text = String.valueOf(String.valueOf(String.valueOf(text))) + "<th>DG NAME</th>";
          text = String.valueOf(String.valueOf(String.valueOf(text))) + "<th>DG MAIL ID</th>";
          text = String.valueOf(String.valueOf(String.valueOf(text))) + "<th>DG MSISDN</th>";
          text = String.valueOf(String.valueOf(String.valueOf(text))) + "<th>MISCALL COUNT</th>";
          text = String.valueOf(String.valueOf(String.valueOf(text))) + "</tr>";
          text = String.valueOf(String.valueOf(String.valueOf(text))) + "</thead>";
          text = String.valueOf(String.valueOf(String.valueOf(text))) + "<tbody>";
          text = String.valueOf(String.valueOf(String.valueOf(text))) + resultBody;
          text = String.valueOf(String.valueOf(String.valueOf(text))) + "</tbody>";
          text = String.valueOf(String.valueOf(String.valueOf(text))) + "</table>";
          System.out.println(text);
          Transport transport = null;
          String host = "email-smtp.eu-west-1.amazonaws.com";
          Properties props = System.getProperties();
          int PORT = 465;
          props.put("mail.transport.protocol", "smtp");
          props.put("mail.smtp.auth", "true");
          props.put("mail.smtp.socketFactory.port", Integer.valueOf(465));
          props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
          props.put("mail.smtp.auth", "true");
          props.put("mail.smtp.port", "465");
          props.put("mail.smtp.host", "email-smtp.eu-west-1.amazonaws.com");
          props.put("mail.smtp.starttls.enable", "true"); // Enable STARTTLS
          props.put("mail.smtp.ssl.protocols", "TLSv1.2");
          props.put("line.separator", "\r\n");
          props.put("mail.debug", "true");
          String SMTP_USERNAME = "AKIAJXDE5LZYJEHFLACQ";
          String SMTP_PASSWORD = "Ai0zhtdrRG065i8+xdUAAMa9I7U/xvxmJ+Oc3tHlqZCb";
          Session session = Session.getDefaultInstance(props, new Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                  return new PasswordAuthentication("AKIAJXDE5LZYJEHFLACQ", "Ai0zhtdrRG065i8+xdUAAMa9I7U/xvxmJ+Oc3tHlqZCb");
                }
              });
          try {
            transport = session.getTransport();
            MimeMessage message = new MimeMessage(session);
            message.setFrom((Address)new InternetAddress("info@ikontel.com"));
            message.addRecipient(Message.RecipientType.TO, (Address)new InternetAddress(managerEmailId));
            message.setRecipients(Message.RecipientType.CC, (Address[])InternetAddress.parse("sikharani.parida@ikontel.com,sudeshna@ikontel.com,panchami.c@ikontel.com,swapnarani@ikontel.com"));
            message.setSubject(sub);
            MimeBodyPart mbp1 = new MimeBodyPart();
            mbp1.setContent(text, "text/html; charset=utf-8");
            MimeMultipart mimeMultipart = new MimeMultipart();
            mimeMultipart.addBodyPart((BodyPart)mbp1);
            message.setContent((Multipart)mimeMultipart);
            Transport.send((Message)message);
            System.out.println("success in sending mail");
          } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Error in sending mail");
          } finally {
            if (transport != null)
              try {
                transport.close();
              } catch (Exception exception) {} 
          } 
          if (transport == null)
            continue; 
          try {
            transport.close();
          } catch (Exception exception) {}
          continue;
        } 
        System.out.println("Manager email id is not valid");
      } 
      conn.close();
    } catch (SQLException se) {
      se.printStackTrace();
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
}
