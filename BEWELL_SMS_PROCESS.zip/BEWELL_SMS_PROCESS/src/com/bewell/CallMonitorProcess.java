package com.bewell;

import java.io.File;
import java.io.FileInputStream;
import java.sql.*;
import java.time.LocalDate;
import java.util.Properties;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CallMonitorProcess {

    public static void main(String[] args) {
        try {
            // Load configuration from properties file
            File file = new File(args[0]);
            FileInputStream fileInput = new FileInputStream(file);

            Properties props = new Properties();
            props.load(fileInput);
            fileInput.close();

            // Thread pool size from properties
            int poolSize = Integer.parseInt(props.getProperty("thread.pool.size", "5"));
            ExecutorService executor = Executors.newFixedThreadPool(poolSize);

            // DB properties
            String dbUrl = props.getProperty("db.url");
            String dbUser = props.getProperty("db.user");
            String dbPassword = props.getProperty("db.password");
            
            String dbUrl1 = props.getProperty("db.url1");
            String dbUser1 = props.getProperty("db.user1");
            String dbPassword1 = props.getProperty("db.password1");

            // SMS properties
            String smsUrl = props.getProperty("sms.url");
            String smsLogin = props.getProperty("sms.login");
            String smsPass = props.getProperty("sms.password");
            String smsVersion = props.getProperty("sms.version");
            String smsSender = props.getProperty("sms.sender_id");
            String smsTemplate = props.getProperty("sms.template_id");

            int accountId = Integer.parseInt(props.getProperty("account.id"));

            
            Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
            
            Connection conn1 = DriverManager.getConnection(dbUrl1, dbUser1, dbPassword1);
            
            while (true) {
                // Submit task to thread pool
                executor.submit(() -> {
                    try {
                        LocalDate today = LocalDate.now();

                        // Query latest call for account_id
                        String sql = "SELECT * FROM incoming_call_log " +
                                "WHERE account_id = ? " +
                                "AND status = 'answered' " +
                                "AND start_call_date >= ? AND start_call_date <= ? " +
                                "AND update_flag = 0 ORDER BY ID LIMIT 100" ;
                        PreparedStatement ps = conn1.prepareStatement(sql);
                        ps.setInt(1, accountId);
                        ps.setString(2, today + " 00:00:00");
                        ps.setString(3, today + " 23:59:59");
                        ResultSet rs = ps.executeQuery();

                        while (rs.next()) {
                            long id = rs.getLong("id");
                            String status = rs.getString("status");
                            Date endCallDate = rs.getDate("end_call_date");
                            String mobile = rs.getString("incoming_number");

                            //if ("answered".equalsIgnoreCase(status)
                              //      && endCallDate != null
                                //    && endCallDate.toLocalDate().equals(today)) {

                                System.out.println("Match found → Updating flag and sending SMS for id=" + id);

                                // Update flag
                                String updateSql = "UPDATE incoming_call_log SET update_flag = 1 WHERE id = ?";
                                PreparedStatement upd = conn.prepareStatement(updateSql);
                                upd.setLong(1, id);
                                upd.executeUpdate();
                                upd.close();

                                // Prepare SMS
                                String message = "Thanks for calling Be Well Hospitals, 24 Hrs Neighbourhood Emergency Care Hospitals, "
                                        + "for Emergency & Appointment Call:+919698300300, https://www.bewellhospitals.in";

                                sendSms(smsUrl, smsLogin, smsPass, smsVersion, smsSender, smsTemplate, mobile, message);

                           // } else {
                             //   System.out.println("No matching record to update.");
                           // }
                        } 

                        rs.close();
                        ps.close();

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });

                // Sleep before next poll
                Thread.sleep(300000);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void sendSms(String smsUrl, String login, String passwd, String version,
                                String senderId, String templateId, String mobile, String message) {
        try {
            String urlStr = smsUrl + "?login=" + URLEncoder.encode(login, "UTF-8")
                    + "&passwd=" + URLEncoder.encode(passwd, "UTF-8")
                    + "&version=" + URLEncoder.encode(version, "UTF-8")
                    + "&msisdn=" + URLEncoder.encode(mobile, "UTF-8")
                    + "&msg_type=text"
                    + "&msg=" + URLEncoder.encode(message, "UTF-8")
                    + "&sender_id=" + URLEncoder.encode(senderId, "UTF-8")
                    + "&template_id=" + URLEncoder.encode(templateId, "UTF-8");

            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            int responseCode = conn.getResponseCode();
            System.out.println("SMS API Response Code: " + responseCode);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
