<%@ page language="java" contentType="application/json; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.*" %>
<%@ page import="java.sql.*" %>
<%@ page import="org.json.JSONObject" %>

<%
    response.setContentType("application/json");
    response.setCharacterEncoding("UTF-8");

    String CRN = request.getParameter("crn");
    String auth_token = request.getParameter("auth_token");
    String secret_token = "543a32ad321afe222e1asd1";
    System.out.println(secret_token);

    try {
        System.out.println("Received auth_token: " + auth_token);
        System.out.println("Expected secret_token: " + secret_token);
        if (auth_token == null || !auth_token.equals(secret_token)) {
            JSONObject authErrorResponse = new JSONObject();
            authErrorResponse.put("status", "error");
            authErrorResponse.put("message", "Invalid auth token");
            out.print(authErrorResponse.toString());
        } else {
            Class.forName("com.mysql.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/smartivr_cloud", "oditata", "PowTata@987");

            String sql = "SELECT crn, duration, req_date, recording_file_name, outgoing_no, callback_comments, disposition_name FROM account_outgoing_call_req WHERE crn = ? and account_id=116";
            System.out.println("Panchamiiiiiiiiiiiii"+sql);
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, CRN);
            ResultSet resultSet = preparedStatement.executeQuery();
            System.out.println("eeeeeeeeeee"+resultSet);
            JSONObject jsonObject = new JSONObject();

            if (resultSet.next()) {
                System.out.println("eeeeeeeeeee"+CRN);
                String recordingFileName = resultSet.getString("recording_file_name");
                 System.out.println("eeeeeeeeeee"+recordingFileName);
                if (recordingFileName != null) {
                        String[] myarr = recordingFileName.split("_");
                        String accId = myarr[0];
                        String dateFolder = myarr[1];
                        String newRecordingFileName = recordingFileName.replace("wav", "mp3");

                        String recordFileLink = "https://ikontel.123ivr.in/TPCLOUD/outgoing_direct_download.php?file=../smartreceiverv1/RECORDING/116/" + dateFolder + "/" + newRecordingFileName;
                        System.out.println("ppppppp"+recordFileLink);
                        String music = "<audio controls preload='none'><source src='" + recordFileLink + "' type='audio/ogg'></audio>";
                        System.out.println("ppppppp"+music);
                        jsonObject.put("crn", resultSet.getString("crn"));
                        jsonObject.put("outgoing_no", resultSet.getString("outgoing_no"));
                        jsonObject.put("disposition_name", resultSet.getString("disposition_name"));
                        jsonObject.put("callback_comments", resultSet.getString("callback_comments"));
                        jsonObject.put("req_date", resultSet.getString("req_date"));
                        jsonObject.put("recording_file_name", recordFileLink);
                        jsonObject.put("duration", resultSet.getString("duration"));
                }
                else
                {
                        jsonObject.put("crn", resultSet.getString("crn"));
                        jsonObject.put("outgoing_no", resultSet.getString("outgoing_no"));
                        jsonObject.put("disposition_name", resultSet.getString("disposition_name"));
                        jsonObject.put("callback_comments", resultSet.getString("callback_comments"));
                        jsonObject.put("req_date", resultSet.getString("req_date"));
                        jsonObject.put("recording_file_name", "NA");
                        jsonObject.put("duration", resultSet.getString("duration"));


                }
            } else {
                jsonObject.put("status", "error");
                jsonObject.put("message", "CRN not found");
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();

            out.print(jsonObject.toString());
        }

    } catch (Exception e) {
        JSONObject errorResponse = new JSONObject();
        errorResponse.put("status", "error");
        errorResponse.put("message", "An error occurred: " + e.getMessage());
        out.print(errorResponse.toString());
    }
%>
                        