import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import javax.mail.Address;
import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class ZSMMAIL {
    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("connection established");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/farmer_registration_iplbio", "root", "");
            System.out.println("Connected");
            String regex = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
            String from = "info@ikontel.com";
            String ccmailids = "sikharani.parida@ikontel.com,sudeshna@ikontel.com";
            String filepath = "0";
            String formattedDate = "";
            String strDateFormat = "yyyy-MM-dd";
            Date date = new Date();
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            formattedDate = dateFormat.format(date);
            String sub = "IPLBIO MISCALL COUNT Report For " + formattedDate;
            String sql = "SELECT zsm_msisdn, NULL AS zsm2_msisdn, zsm_name, zsm_mail_id, NULL AS zsm2_name, NULL AS zsm2_mail_id\n"
            		+ "FROM staff_detail\n"
            		+ "WHERE zsm_mail_id IS NOT NULL AND zsm_mail_id != ''\n"
            		+ "\n"
            		+ "UNION\n"
            		+ "\n"
            		+ "SELECT NULL AS zsm_msisdn, zsm2_msisdn, NULL AS zsm_name, NULL AS zsm_mail_id, zsm2_name, zsm2_mail_id\n"
            		+ "FROM staff_detail\n"
            		+ "WHERE zsm2_mail_id IS NOT NULL AND zsm2_mail_id != ''; ";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                String zmanagerMsisdn = rs.getString("zsm_msisdn");
                String zmanagerEmailId = rs.getString("zsm_mail_id");
                String zmanagerName = rs.getString("zsm_name");
                String zmanagerMsisdn2 = rs.getString("zsm2_msisdn");
                String zmanagerEmailId2 = rs.getString("zsm2_mail_id");
                String zmanagerName2 = rs.getString("zsm2_name");
                String subsql = "SELECT distinct manager_msisdn, manager_name, manager_email_id, zone, teritory, district  from staff_detail where zsm_mail_id='" + zmanagerEmailId + "' OR  zsm2_mail_id='" + zmanagerEmailId2 + "' group by manager_msisdn";
                Statement substmt = conn.createStatement();
                ResultSet subrs = substmt.executeQuery(subsql);
                String text = "Dear ";
                if (zmanagerEmailId != null && !zmanagerEmailId.isEmpty()) {
                    text += zmanagerName + " (" + zmanagerEmailId + ")";
                }
                if (zmanagerEmailId2 != null && !zmanagerEmailId2.isEmpty()) {
                    text += " and " + zmanagerName2 + " (" + zmanagerEmailId2 + ")";
                }
                text += ",<br /><br />Below is the miscall count of your Manager.<br /><br />";
                String resultBody = "";
                while (subrs.next()) {
                    String managerMsisdn = subrs.getString("manager_msisdn");
                    String managerName = subrs.getString("manager_name");
                    String managerMailId = subrs.getString("manager_email_id");
                    String area = subrs.getString("district");
                    String region = subrs.getString("zone");
                    String teritory = subrs.getString("teritory");
                    String miscallsql = "select count(id) as miscallcount from miscall_unique where manager_msisdn='" + managerMsisdn + "'";
                    Statement miscallstmt = conn.createStatement();
                    ResultSet miscallrs = miscallstmt.executeQuery(miscallsql);
                    while (miscallrs.next()) {
                        String miscallcount = miscallrs.getString("miscallcount");
                        resultBody = String.valueOf(String.valueOf(resultBody)) + "<tr>";
                        resultBody = String.valueOf(String.valueOf(resultBody)) + "<td>" + area + "</td>";
                        resultBody = String.valueOf(String.valueOf(resultBody)) + "<td>" + region + "</td>";
                        resultBody = String.valueOf(String.valueOf(resultBody)) + "<td>" + teritory + "</td>";
                        resultBody = String.valueOf(String.valueOf(resultBody)) + "<td>" + managerName + "</td>";
                        resultBody = String.valueOf(String.valueOf(resultBody)) + "<td>" + managerMailId + "</td>";
                        resultBody = String.valueOf(String.valueOf(resultBody)) + "<td>" + managerMsisdn + "</td>";
                        resultBody = String.valueOf(String.valueOf(resultBody)) + "<td>" + miscallcount + "</td>";
                        resultBody = String.valueOf(String.valueOf(resultBody)) + "</tr>";
                    }
                    miscallstmt.close();
                }
                substmt.close();
                if ((zmanagerEmailId != null && !zmanagerEmailId.isEmpty()) || (zmanagerEmailId2 != null && !zmanagerEmailId2.isEmpty())) {                    text = String.valueOf(String.valueOf(text)) + "<table border='1' cellpadding='5' cellspacing='0' style='font-size: 9pt;font-family: sans-serif;color:black'>";
                    text = String.valueOf(String.valueOf(text)) + "<thead>";
                    text = String.valueOf(String.valueOf(text)) + "<tr style='background:lightblue;'>";
                    text = String.valueOf(String.valueOf(text)) + "<th>DISTRICT</th>";
                    text = String.valueOf(String.valueOf(text)) + "<th>ZONE</th>";
                    text = String.valueOf(String.valueOf(text)) + "<th>TERITORY</th>";
                    text = String.valueOf(String.valueOf(text)) + "<th>MANAGER NAME</th>";
                    text = String.valueOf(String.valueOf(text)) + "<th>MANAGER MAIL ID</th>";
                    text = String.valueOf(String.valueOf(text)) + "<th>MANAGER MSISDN</th>";
                    text = String.valueOf(String.valueOf(text)) + "<th>MISCALL COUNT</th>";
                    text = String.valueOf(String.valueOf(text)) + "</tr>";
                    text = String.valueOf(String.valueOf(text)) + "</thead>";
                    text = String.valueOf(String.valueOf(text)) + "<tbody>";
                    text = String.valueOf(String.valueOf(text)) + resultBody;
                    text = String.valueOf(String.valueOf(text)) + "</tbody>";
                    text = String.valueOf(String.valueOf(text)) + "</table>";
                    System.out.println(text);
                    Transport transport = null;
                    String host = "email-smtp.eu-west-1.amazonaws.com";
                    Properties props = System.getProperties();
                    int PORT = 465;
                    props.put("mail.transport.protocol", "smtp");
                    props.put("mail.smtp.auth", "true");
                    props.put("mail.smtp.socketFactory.port", Integer.valueOf(465));
                    props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
                    props.put("mail.smtp.auth", "true");
                    props.put("mail.smtp.port", "465");
                    props.put("mail.smtp.host", "email-smtp.eu-west-1.amazonaws.com");
                    props.put("mail.smtp.starttls.enable", "true");
                    props.put("line.separator", "\r\n");
                    props.put("mail.debug", "true");
                    String SMTP_USERNAME = "AKIAJXDE5LZYJEHFLACQ";
                    String SMTP_PASSWORD = "Ai0zhtdrRG065i8+xdUAAMa9I7U/xvxmJ+Oc3tHlqZCb";
                    Session session = Session.getDefaultInstance(props, new Authenticator() {
                        protected PasswordAuthentication getPasswordAuthentication() {
                            return new PasswordAuthentication("AKIAJXDE5LZYJEHFLACQ", "Ai0zhtdrRG065i8+xdUAAMa9I7U/xvxmJ+Oc3tHlqZCb");
                        }
                    });
                    try {
                        transport = session.getTransport();
                        MimeMessage message = new MimeMessage(session);
                        message.setFrom((Address) new InternetAddress("info@ikontel.com"));
                        if (zmanagerEmailId != null && !zmanagerEmailId.isEmpty()) {
                            message.addRecipient(Message.RecipientType.TO, new InternetAddress(zmanagerEmailId));
                        }

                        if (zmanagerEmailId2 != null && !zmanagerEmailId2.isEmpty()) {
                            message.addRecipient(Message.RecipientType.TO, new InternetAddress(zmanagerEmailId2));
                        }
                        message.setRecipients(Message.RecipientType.CC, (Address[]) InternetAddress.parse("sikharani.parida@ikontel.com,sudeshna@ikontel.com,panchami.c@ikontel.com"));
                        message.setSubject(sub);
                        MimeBodyPart mbp1 = new MimeBodyPart();
                        mbp1.setContent(text, "text/html; charset=utf-8");
                        MimeMultipart mimeMultipart = new MimeMultipart();
                        mimeMultipart.addBodyPart(mbp1);
                        message.setContent(mimeMultipart);

                        Transport.send(message);
                        System.out.println("Success in sending mail");
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        System.out.println("Error in sending mail");
                    } finally {
                        if (transport != null)
                            try {
                                transport.close();
                            } catch (Exception exception) {
                            }
                    }
                    if (transport == null)
                        continue;
                    try {
                        transport.close();
                    } catch (Exception exception) {
                    }
                    continue;
                }
                System.out.println("ZDGM email id is not valid");
            }
            conn.close();
        } catch (SQLException se) {
            se.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
