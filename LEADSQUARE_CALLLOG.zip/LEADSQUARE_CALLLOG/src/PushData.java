import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.JSONObject;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class PushData {

    private static final String SECRET_KEY = "AGHJUYLIOPHTELIGHSQHTUQDFGHPOBVGFDSQ_@_123";
    private static final String DOWNLOAD_BASE_URL = "https://ikontel.123ivr.in/TPCLOUD/outgoing_direct_download_pl.php";

    public static void main(String[] args) {

        Connection conn1 = null;
        Connection conn2 = null;

        try {

            conn1 = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/smartivr_cloud",
                    "oditata",
                    "PowTata@987");

            conn2 = DriverManager.getConnection(
                    "jdbc:mysql://172.31.43.6:3306/smartivr_cloud",
                    "reportnha",
                    "India@456");

            OkHttpClient client = new OkHttpClient();

            String configQuery =
                    "SELECT account_id, api_url FROM leadsquare_config WHERE status=1";

            PreparedStatement configStmt = conn1.prepareStatement(configQuery);
            ResultSet configRs = configStmt.executeQuery();

            while (configRs.next()) {

                String account_id = configRs.getString("account_id");
                String apiUrl = configRs.getString("api_url");

                System.out.println("Processing account: " + account_id);

                processAccount(conn1, conn2, client, account_id, apiUrl);
            }

            configRs.close();
            configStmt.close();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {

            try { if (conn1 != null) conn1.close(); } catch (Exception e) {}
            try { if (conn2 != null) conn2.close(); } catch (Exception e) {}
        }
    }

    private static void processAccount(Connection conn1, Connection conn2,
                                       OkHttpClient client,
                                       String account_id,
                                       String apiUrl) {

        try {

            String query =
                    "SELECT id, agent_msisdn AS SourceNumber, outgoing_no AS DestinationNumber, " +
                    "queue_no AS DisplayNumber, IFNULL(agent_connect_time, NOW()) AS StartTime, " +
                    "agent_end_time AS EndTime, IFNULL(duration,'0') AS CallDuration, " +
                    "IF(cust_status='success','Answered',IF(cust_status='init' OR cust_status='fail','call_failure',cust_status)) AS Status, " +
                    "channel_id AS CallSessionId, recording_file_name, req_date, record_id AS OpportunityId, agent_id AS AgentName " +
                    "FROM account_outgoing_call_req " +
                    "WHERE account_id=? AND sc_flag=0 AND agent_end_time IS NOT NULL " +
                    "ORDER BY id DESC LIMIT 100";

            PreparedStatement stmt = conn2.prepareStatement(query);
            stmt.setString(1, account_id);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                String fileName = rs.getString("recording_file_name");
                String reqDateTime = rs.getString("req_date");

                SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                Date date = inputFormat.parse(reqDateTime);

                SimpleDateFormat outputFormat = new SimpleDateFormat("yyyyMMdd");
                String dateFolder = outputFormat.format(date);

                String resourceUrl = "";

                // ✅ Generate URL only if recording exists
                if (fileName != null && !fileName.trim().isEmpty()) {

                    String newFileName = fileName.replace(".wav", ".mp3");

                    String relativePath = account_id + "/" + dateFolder + "/" + newFileName;

                    long expiryTime = (System.currentTimeMillis() / 1000) + 3600;

                    try {
                        resourceUrl = generateRecordingUrl(relativePath, expiryTime);
                        System.out.println("Generated URL: " + resourceUrl);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                JSONObject requestBody = new JSONObject();

                requestBody.put("SourceNumber", rs.getString("SourceNumber"));
                requestBody.put("DestinationNumber", rs.getString("DestinationNumber"));
                requestBody.put("DisplayNumber", rs.getString("DisplayNumber"));
                requestBody.put("StartTime", rs.getString("StartTime"));
                requestBody.put("EndTime", rs.getString("EndTime"));
                requestBody.put("Status", rs.getString("Status"));
                requestBody.put("CallNotes", "");
                requestBody.put("ResourceURL", resourceUrl);
                requestBody.put("Direction", "callAndConnect");
                requestBody.put("CallSessionId", rs.getString("CallSessionId"));
                requestBody.put("AgentName", rs.getString("AgentName"));
                requestBody.put("CallDuration", rs.getString("CallDuration"));

                String oppId = rs.getString("OpportunityId");

                if (oppId != null && oppId.contains("_")) {
                    oppId = oppId.substring(oppId.indexOf("_") + 1);
                }

                requestBody.put("OpportunityId", oppId);

                String jsonInputString = requestBody.toString();
                System.out.println("Input: " + jsonInputString);

                int id = rs.getInt("id");

                MediaType mediaType = MediaType.parse("application/json");
                RequestBody body = RequestBody.create(mediaType, jsonInputString);

                Request request = new Request.Builder()
                        .url(apiUrl)
                        .post(body)
                        .addHeader("Content-Type", "application/json")
                        .build();

                try (Response response = client.newCall(request).execute()) {

                    String responseBody =
                            response.body() != null ? response.body().string() : "";

                    System.out.println("API Response: " + responseBody);
                    int code = response.code();

                    if (code == 200) {

                        JSONObject jsonResponse = new JSONObject(responseBody);
                        String status = jsonResponse.optString("Status");

                        if ("Success".equalsIgnoreCase(status)) {
                            updateFlag(conn1, id, 1);
                        } else {
                            updateFlag(conn1, id, 10);
                        }

                    } else {
                        updateFlag(conn1, id, 20);
                    }
                }
            }

            rs.close();
            stmt.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void updateFlag(Connection conn, int id, int flag)
            throws Exception {

        String updateQuery =
            "UPDATE account_outgoing_call_req SET sc_flag=? WHERE id=?";

        PreparedStatement ps = conn.prepareStatement(updateQuery);

        ps.setInt(1, flag);
        ps.setInt(2, id);

        ps.executeUpdate();
        ps.close();
    }

    // 🔐 Generate secure recording URL
    public static String generateRecordingUrl(String relativeFilePath, long expiryEpochSeconds) throws Exception {

        if (relativeFilePath == null || relativeFilePath.trim().isEmpty()) {
            return "";
        }

        String cleanPath = relativeFilePath.replace("\\", "/");

        while (cleanPath.startsWith("/")) {
            cleanPath = cleanPath.substring(1);
        }

        String token = generateHmacSha256(cleanPath + "|" + expiryEpochSeconds, SECRET_KEY);

        return DOWNLOAD_BASE_URL
                + "?file=" + URLEncoder.encode(cleanPath, "UTF-8")
                + "&exp=" + expiryEpochSeconds
                + "&token=" + URLEncoder.encode(token, "UTF-8");
    }

    private static String generateHmacSha256(String data, String secret) throws Exception {

        Mac sha256Hmac = Mac.getInstance("HmacSHA256");

        SecretKeySpec secretKey =
                new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256");

        sha256Hmac.init(secretKey);

        byte[] hash = sha256Hmac.doFinal(data.getBytes(StandardCharsets.UTF_8));

        StringBuilder hex = new StringBuilder();

        for (byte b : hash) {
            String h = Integer.toHexString(0xff & b);
            if (h.length() == 1) hex.append('0');
            hex.append(h);
        }

        return hex.toString();
    }
}