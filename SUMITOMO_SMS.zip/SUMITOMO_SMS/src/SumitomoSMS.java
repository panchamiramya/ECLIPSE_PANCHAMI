import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;

public class SumitomoSMS {
    public static void main(String[] args) {
        Connection conn = null;
        String callback_url  = "https://dial.123ivr.in:5443/SUMITOMO_FDD_CRM/saveSMSStatus.php";
        Map<String, String> smsTemplates = new HashMap<>();
        smsTemplates.put("tel:excaliamax", "ఎక్స్కెలియా మ్యాక్స్ | INDIFLIN ఇండెప్లిన్ ద్వారా ఆధారితం భవిష్యత్తుకు ఆరంభం ఇక్కడనుండి... జపాన్ వారి టెక్నాలజీ పాముపొడ తెగులును ప్రభావంతంగా నియంత్రిస్తుంది శక్తివంతమైన పిలకలు ఆరోగ్యమైన పంట మరియు అధిక పచ్చదనం .Sumitomo Visit Website: https://sumichem.co.in/landing-pages/excalia-max/telugu/");
        smsTemplates.put("kan:excaliamax", "ಎಕ್ಸ್ ಕೇಲಿಯಾ ಎಕ್ಸ್ ಕೇಲಿಯಾ ಕ್ಷೇತ್ರೋತ್ಸವಕ್ಕೆ ಬಾಗವಹಿಸಿದ ಎಲ್ಲರಿಗೂ ಧನ್ಯವಾದಗಳು. ಮುಂದಿನ ಪೀಳಿಗೆಯ ಶಿಲೀಂಧ್ರನಾಶಕ ಹಾಗು ಸರಿಸಾಟಿಯಿಲ್ಲದ ಹೊಸ ಹೊಚ್ಚ ತಂತ್ರಜ್ಞಾನ ಒಳಗೊಂಡು ಬೆಳೆ ರಕ್ಷಣೆ ಮಾಡುತ್ತದೆ . ನಿಮ್ಮ ವಿಶ್ವಾಸ ಮತ್ತು ನಂಬಿಕೆಯು ನಮಗೆ ಆರೋಗ್ಯಕರ ಮತ್ತು ಸಂಪತ್ಭರಿತ ಬೆಳೆಗಳಿಗಾಗಿ ಉತ್ತಮ ಪರಿಹಾರಗಳನ್ನು ತರಲು ಸ್ಫೂರ್ತಿ ನೀಡುತ್ತದೆ. ಇದು ಸುಮಿಟೊಮೊ ಕೆಮಿಕಲ್, ಜಪಾನ್ ನವರ ನೂತನ ಆವಿಷ್ಕಾರ .");
        smsTemplates.put("tam:excaliamax", "வயல் விழாவில் கலந்து கொண்டதற்கு நன்றி எக்ஸ்காலியா ஒரு அடுத்த தலைமுறை பூஞ்சானக் கொல்லி. இது அதிநவீன தொழில்நுட்பத்தையும் பயிர் பாதுகாப்பில் ஒப்பிடமுடியாத புதுமையையும் உள்ளடக்கியது. புதுமையின் மீதான உங்களது நம்பிக்கை, எங்களை ஆரோக்கியமான மற்றும் மிகவும் உறுதியான பயிர்களுக்கான சிறந்த தீர்வுகளைக் கொண்டுவர தூண்டுகிறது.Sumitomo");
        smsTemplates.put("mar:excaliamax", "एक्सकॅलियाच्या फील्ड डेला उपस्थित राहिल्याबद्दल धन्यवाद !पुढील पिढीचे बुरशीनाशक जे अत्याधुनिक तंत्रज्ञान आणि पीक संरक्षणातील अतुलनीय नाविन्य दर्शवते. नावीन्यपूर्णतेवरील तुमचा विश्वास आम्हाला निरोगी, अधिक लवचिक पिकांसाठी सर्वोत्तम उपाय आणण्यास प्रेरित करतो ! सुमितोमो केमिकल");
        smsTemplates.put("pun:excaliamax", "ਐਕਸਕੇਲਿਯਾ ਮੈਕਸ | ਇੰਡੀਫਲਿਨ ਦੀ ਸ਼ਕਤੀ ਦੁਆਰਾ ਸੰਚਾਲਿਤ ਭਵਿੱਖ ਦੀ ਸ਼ੁਰੂਆਤ... ਜਾਪਾਨੀ ਟੈਕਨਾਲੋਜੀ ਮਜ਼ਬੂਤ ਟਿਲਰ ਵਧੀਆ ਫਾਈਟੋਟੋਨਿਕ ਪ੍ਰਭਾਵ ਸ਼ੀਥ ਬਲਾਈਟ ਤੇ ਪ੍ਰਭਾਵਸ਼ਾਲੀ ਨਿਯੰਤਰਣ !ਸੁਮਿਤੋਮੋ ਕਾਮਿਕਲ");
        smsTemplates.put("hin:excaliamax", "एक्सकेलिया मैक्स | इंडीफ्लिन की शक्ति द्वारा संचालित भविष्य की शुरुआत... जापानी तकनीक मजबूत कल्ले बेहतरीन फायटोटॉनिक प्रभाव शीथ ब्लाइट का प्रभावी नियंत्रण ! सुमितोमो केमिकल");
        smsTemplates.put("ben:excaliamax", "এক্সকালিয়া প্রোডাক্ট এর এই ফিল্ড ডে তে উপস্থিত থাকার জন্য আপনাকে ধন্যবাদ জানাই। এক্সকালিয়া, পরবর্তী প্রজন্মের ছত্রাকনাশক ... সুমিতোমো কেমিক্যাল, জাপান এর একটি নতুন উদ্ভাবন।।।Sumitomo");
        smsTemplates.put("tel:excaliamax", "ఎక్స్కాలియా మ్యాక్స్ ఇండెప్లిన్ ద్వారా ఆధారితం భవిష్యత్తుకు ఆరంభం ఇక్కడనుండి జపాన్ వారి టెక్నాలజీ 1. శక్తివంతమైన మరియు బలమైన పంట. 2. ఆరోగ్యమైన పంట మరియు అధిక పచ్చదనం. 3. ప్రభావవంతమైన తెగుల నియంత్రణ మరింత సమాచారం కోసం దయచేసి సంప్రదించండి - 9985437448 Sumitomo");
        //smsTemplates.put("tel:Excaliamax", "ఎక్స్ కేలియా ఎక్స్ కేలియ పంట క్షేత్ర ప్రదర్శనలో పాలుపంచుకున్న మీకు మా ధన్యవాదములు ఎక్స్ కేలీయ అనేది నూతన తరానికి చెందిన తెగుళ్ల నివారిణి. ఇది సుమిటోమో వారి నూతన ఉత్పత్తి.( జపాన్ టెక్నాలజి),Sumitomo");
        //smsTemplates.put("pun:Excaliamax", "ਐਕਸਕੇਲਿਯਾ ਦੇ ਫੀਲਡ ਡੇਅ ਵਿੱਚ ਸ਼ਾਮਲ ਹੋਣ ਲਈ ਤੁਹਾਡਾ ਧੰਨਵਾਦ ਐਕਸਕੇਲਿਯਾ ਅਗਲੀ ਪੀੜ੍ਹੀ ਦਾ ਵਰਤਿਆ ਜਾਂਣ ਵਾਲਾ ਉਲੀਨਾਸ਼ਕ ਸੁਮਿਟੋਮੋ ਕੈਮੀਕਲ, ਜਾਪਾਨ ਵੱਲੋਂ ਹੈ।Sumitomo");
        //smsTemplates.put("hin:Excaliamax", "एक्सकेलिया के फील्ड डे में भाग लेने के लिए धन्यवाद अगली पीढ़ी का कवकनाशी जो फसल सुरक्षा में अत्याधुनिक तकनीक और बेजोड़ नवीनता का प्रतीक है। नवाचार में आपका विश्वास हमें स्वस्थ, अधिक लचीली फसलों के लिए सर्वोत्तम समाधान लाने के लिए प्रेरित करता है। सुमितोमो केमिकल,");
        smsTemplates.put("mar:lentigo", "लेंटिगो पुढील पिढीतील उदयपूर्व तणनाशक जपानमधील सुमितोमो केमिकलचा एक नवीन उपक्रम या क्षेत्र दिनाला उपस्थित राहिल्याबद्दल धन्यवाद !Sumitomo");
        smsTemplates.put("tel:lentigo", "లెంటిగొ మోతాదు: 3 కిలోలు/ ఎకరాకు • ప్రీ-ఎమర్జెంట్ శ్రేణిలో ఆధునిక తరానికి చెందిన వరి కలుపునాశిని. • అన్ని రకాల కలుపు మొక్కలను నియంత్రిస్తుంది. • ఒకసారి ఉపయోగిస్తే ఎక్కువ కాలం వరకు ప్రభావం ఉంటుంది. • పంట మరియు పర్యావరణం కోసం సురక్షితమైనది. Contact- 9985437448 Sumitomo");
        //smsTemplates.put("hin:lentigo", "लेंटिगो के किसान संगोष्ठी में भाग लेने के लिए धन्यवाद ! अगली पीढ़ी का प्री-इमर्जेंस हर्बिसाइड सुमितोमो केमिकल, जापान का एक नवीनीकरण !");
        smsTemplates.put("tam:lentigo", "லென்டிகோ வயல் விழாவில் கலந்து கொண்டதற்கு நன்றி. லென்டிகோ ஒரு அடுத்த தலைமுறை நெற்பயிர் களைக்கொல்லி. லென்டிகோ ஜப்பானின் சுமிட்டோமோ கெமிக்கலின் ஒரு புதிய கண்டுபிடிப்பு Sumitomo");
        //smsTemplates.put("pun:lentigo", "ਲੈਂਟੀਗੋ ਲੈਂਟੀਗੋ ਦੇ ਫੀਲਡ ਡੇਅ ਵਿੱਚ ਸ਼ਾਮਲ ਹੋਣ ਲਈ ਤੁਹਾਡਾ ਧੰਨਵਾਦ ਅਗਲੀ ਪੀੜ੍ਹੀ ਦਾ ਪਹਿਲਾਂ ਵਰਤਿਆ ਜਾਂਣ ਵਾਲਾ ਹਰਬੀਸਾਈਡ ਸੁਮਿਟੋਮੋ ਕੈਮੀਕਲ, ਜਾਪਾਨ ਦੀ ਇੱਕ ਨਵੀਂ ਖੋਜ ਹੈ।Sumitomo");
        smsTemplates.put("ben:lentigo", "লেন্টিগো প্রোডাক্ট এর এই ফিল্ড ডে তে উপস্থিত থাকার জন্য আপনাকে ধন্যবাদ জানাই। লেন্টিগো, পরবর্তী প্রজন্মের প্রি ইমার্জেন্স আগাছানাশক... সুমিতোমো কেমিক্যাল, জাপান এর একটি নতুন উদ্ভাবন।।।Sumitomo");
        smsTemplates.put("pun:lentigo", "ਖੇਤ ਵਿੱਚ ਰਹੇ ਸਿਰਫ਼ ਫਸਲ ਦਾ ਹੱਕ ਲੈਂਟਿਗੋ ਖਰਪਤਵਾਰ ਨਾਸ਼ਕ ਮਾਤਰਾ: 3 ਕਿਲੋ/ਏਕੜ ਹੋਰ ਜਾਣਕਾਰੀ ਲਈ ਸੰਪਰਕ ਕਰੋ: 9814236182, 9814236182 SUMITOMO");
        smsTemplates.put("hin:lentigo", "खेत में रहे सिर्फ फसल का अधिकार लेंटिगो खरपतवारनाशक मात्रा: 3 किलो/एकड़ अधिक जानकारी हेतु संपर्क करें: 8222855155 SUMITOMO");
        smsTemplates.put("tel:topgrain", "పంట పండగ శుభాకాంక్షలు టాప్ గ్రేయిన్ పంట క్షేత్ర ప్రదర్శనలో పాలుపంచుకున్న మీకు మా ధన్యవాదములు. టాప్ గ్రేయిన్ అనేది ధాన్యం నిండుకునే టెక్నాలజి ( గ్రైయిన్ ఫిల్లింగ్ టెక్నోలజి). టాప్ గ్రేయిన్ అనేది ధాన్యాన్ని సంపూర్ణంగా నింపి మన వరి పంటలో దిగుబడి మరియు నాణ్యతను పెంపొందిస్తుంది. టాప్ గ్రేయిన్, గ్రేయిన్ ఫిల్లింగ్ టెక్నోలజి.Sumitomo");
        smsTemplates.put("kan:topgrain", "ಕೊಯ್ಲಿನ ಆನಂದ ಆಚರಿಸಿ.. ಟಾಪ್ ಗ್ರೇನ್ ಕ್ಷೆತ್ರೋತ್ಸವಕೆ ಆಗಮಿಸದಕ್ಕಾಗಿ ಧನ್ಯವಾದಗಳು. ಟಾಪ್ ಗ್ರೇನ್ ಕಾಳು ತುಂಬುವ ತಂತ್ರಜ್ಞಾನವು ನಿಮಗೆ ಹೆಚ್ಚಿನ ಇಳುವರಿ ಹಾಗೂ ಉತ್ತಮ ಕಾಲುಗಳನ್ನು ನಿಡುತ್ತದೆ. ಟಾಪ್ ಗ್ರೇನ್, ಕಾಳು ತುಂಬುವ ತಂತ್ರಜ್ಞಾನ.. ಸುಮಿಟೊಮೊ");
        smsTemplates.put("tam:topgrain","அறுவடைத் திருநாள் நல்வாழ்த்துக்கள். டாப்கிரெயின் அறுவடை திருநாளில் கலந்து கொண்டதற்கு நன்றி. டாப்கிரெயின் என்பது தானியத்தின் தரம் மற்றும் ஒட்டுமொத்த மகசூலை மேம்படுத்த உதவும் தானிய நிரப்புதல் தொழில்நுட்பமாகும். டாப்கிரெயின், சுமிட்டோமோ கம்பனியின் தானிய நிரப்புதல் தொழில்நுட்பம்.");
        smsTemplates.put("hin:topgrain", "फसल उत्सव की शुभकामनाएँ। टॉपग्रेन फसल दिवस में भाग लेने के लिए धन्यवाद। टॉपग्रेन एक दाने भरने की तकनीक है जो अनाज की समग्र उपज और गुणवत्ता में सुधार करने में मदद करती है। टॉपग्रेन, दाने भरने की तकनीक।Sumitomo");
        smsTemplates.put("ben:topgrain", "শুভ ফসল উত্তোলন উৎসব।।। টপগ্রেন প্রোডাক্ট এর এই ফিল্ড ডে তে উপস্থিত থাকার জন্য আপনাকে ধন্যবাদ জানাই। টপগ্রেন, এটি একটি শস্য ভরাট প্রযুক্তি, যা সামগ্রিক ফলন ও ফলন এর গুণমান এর উন্নতি তে সাহায্য করে... টপগ্রেন, শস্য ভরাট প্রযুক্তি।।।Sumitomo");
        smsTemplates.put("pun:topgrain", "ਵਾਢੀ ਦਾ ਤਿਉਹਾਰ ਮੁਬਾਰਕ। ਟੌਪਗ੍ਰੇਨ ਵਾਢੀ ਦਿਵਸ ਵਿੱਚ ਸ਼ਾਮਲ ਹੋਣ ਲਈ ਤੁਹਾਡਾ ਧੰਨਵਾਦ। ਟੌਪਗ੍ਰੇਨ ਇੱਕ ਅਨਾਜ ਭਰਨ ਵਾਲੀ ਤਕਨੀਕ ਹੈ ਜੋ ਅਨਾਜ ਦੀ ਸਮੁੱਚੀ ਉਪਜ ਅਤੇ ਗੁਣਵੱਤਾ ਵਿੱਚ ਸੁਧਾਰ ਕਰਨ ਵਿੱਚ ਮਦਦ ਕਰਦੀ ਹੈ। ਟੌਪਗ੍ਰੇਨ, ਅਨਾਜ ਭਰਨ ਦੀ ਤਕਨੀਕ।Sumitomo");
        smsTemplates.put("tam:topgrain", "அறுவடைத் திருநாள் நல்வாழ்த்துக்கள். டாப்கிரெயின் அறுவடை திருநாளில் கலந்து கொண்டதற்கு நன்றி. டாப்கிரெயின் என்பது தானியத்தின் தரம் மற்றும் ஒட்டுமொத்த மகசூலை மேம்படுத்த உதவும் தானிய நிரப்புதல் தொழில்நுட்பமாகும். டாப்கிரெயின், சுமிட்டோமோ கம்பனியின் தானிய நிரப்புதல் தொழில்நுட்பம்.");
        //smsTemplates.put("hin:santana", "सैन्टाना डालो दानेदार नया जापानी दानेदार कीटनाशक फसल शुरू से ही बने दमदार ज़्यादा जानकारी के लिए सुमिटोमो प्रतिनिधि से संपर्क करें करनाल - 9991110012 कैथल - 9639391366 मुक्तसर - 9592232688 बठिंडा - 9779476078 कुरुक्षेत्र - 8077057028 फतेहाबाद - 9050211427");
        smsTemplates.put("hin:santana", "सैन्टाना सुमिटोमो का नया जापानी दानेदार कीटनाशक फसल शुरू से ही बने दमदार अधिक जानकारी के लिए संपर्क करें : 9759133854, 8222855155");
        smsTemplates.put("pun:santana", "ਸੰਤਾਨਾ ਸੁਮਿਟੋਮੋ ਦਾ ਨਵਾਂ ਜਾਪਾਨੀ ਦਾਣੇਦਾਰ ਕੀਟਨਾਸ਼ਕ ਸ਼ੁਰੂ ਤੋਂ ਹੀ ਮਜ਼ਬੂਤ ਫਸਲਾਂ ਵਧੇਰੇ ਜਾਣਕਾਰੀ ਲਈ, ਸੰਪਰਕ ਕਰੋ: 9917154588, 9814236182");
        smsTemplates.put("mar:sumimax", "सोयाबीन पेरणी सोबत चे तणनाशक- सुमी मॅक्स सोयाबीन पेरणी केल्या नंतर 2 दिवसाच्या आत फवारणी करावी. अधिक माहितीसाठी आपल्या जिल्ह्याचे नाव सांगा आणि 9650054616 या नंबर वरती Max लिहून व्हॉट्स अप करा");
        smsTemplates.put("pun:sumibluediamond", "ਸੁਮੀ ਬਲੂ ਡਾਇਮੰਡ, ਝੋਨੇ ਦਾ ਗਹਿਣਾ ਜੋ ਵਧਾਵੇ ਸਿਖਾਵਾ ਦੀ ਸੰਖਿਆ, ਕਰੇ ਜੜ ਮਜ਼ਬੂਤ ਅਤੇ ਵਧਾਵੇ ਝੋਨੇ ਦੀ ਪੈਦਾਵਾਰ");
        smsTemplates.put("hin:sumibluediamond", "सुमी ब्लु डायमंड, धान का गहना जो बढ़ाए कल्लों की संख्या , करे जड़ मजबुत और और बढ़ाए धान की पैदावार");
        smsTemplates.put("ben:sumibluediamond", "সুমি ব্লু ডায়মন্ড ধরুন হাত, সফলতার নতুন শুরুয়াত.Sumitomo");
        smsTemplates.put("odia:sumibluediamond", "ସୁମୀ ବ୍ଲୁ ଡାୟମଣ୍ଡ - ହାତ ଧରନ୍ତୁ, ସଫଳତା ଆରମ୍ଭ କରନ୍ତୁ! ଫସଲ ବଢ଼ାନ୍ତୁ, ଚାଷର ସଫଳତା ନିଶ୍ଚିତ କରନ୍ତୁ.Sumitomo");
        smsTemplates.put("mar:sumibluediamond", "सुमी ब्लू डायमंड हातात घ्या हात, यशस्वितेची नवी सुरुवात-7720090860 Sumitomo");
        smsTemplates.put("hin:meshi", "नई तकनीक नई दिशा - प्रोजिब ईजी दमदार दाने बड़े भुट्टे बेहतर उत्पादन जीत की पहली सीढ़ी - मेशी फसल का सुरक्षा चक्र द्वि-शक्ति रासायनिक ताकत प्रारंभिक संक्रमण पर लागू,Sumitomo अधिक जानकारी के लिए, आज ही संपर्क करें - 9939255411");
        smsTemplates.put("tel:meshi", "1. మీ వరి లో కాండం తొలుచు పురుగు మరియు ఆకు చుట్టు పురుగు కి సమర్థవంతమైన పరిష్కారం పొందండి *సుమిటోమో* వారి *మేషి* తో 2. చీడ పురుగుల జీవన దశలలో - అనగా గ్రుడ్డు, లార్వా మరియు చిన్న పురుగు దశలలో సమర్థవంతమైన నివారణ కలిపించి మీ వరి పంట ని సురక్షితంగా ఉంచుతుంది. 3. వరి లో వచ్చు కంకి నల్లి ని కుడా సమర్ధవంతంగ నియంత్రణ చెస్తుంది నేడే *మేషి* వాడండి మరియు మీ పొలానికి కల్పించండి *మేషి* రక్షణ Sumitomo");
        smsTemplates.put("ben:meshi", "মেসি জয়ের প্রথম সিঁড়ি ফসলের সুরক্ষা চক্র দ্বিমুখী রাসায়নিক শক্তি প্রারম্ভিক সংক্রমণের ওপর প্রযোজ্য.Sumitomo");
        smsTemplates.put("ben:kitoshi", "ফসলের জন্যে চিন্তামুক্ত থাকুন! মরসুমী ছত্রাক আর রোগের চিকিৎসায় কিটোশী. Sumitomo");
        smsTemplates.put("tel:taboli", "టాబోలీ ఇస్తుంది అధిక పూత మరియు అధిక కాతా టాబోలీ = TABOLI ఫ్లవరింగ్ హార్మోన్ పంటలో పూత మొదలయ్యే దశలో ఉపయోగించాలి మరింత సమాచారం కోసం సంప్రదించండి ఆదిలాబాద్ - 9989200927 Sumitomo");
        smsTemplates.put("tel:portion", "పోర్షన్ నల్లి నుండి లభిస్తుంది తక్షణమే దీర్ఘకాల ఉపశమనం => అన్ని దశలను నియంత్రిస్తుంది. => దీర్ఘకాల నియంత్రణ. => తక్షణ చర్య. => నియంత్రణ ఖర్చు తగ్గిస్తుంది. మరింత సమాచారం కోసం సంప్రదించండి మిర్యాలగూడ - 8237415699 నిజామాబాద్ - 7661081899 ఆదిలాబాద్ - 9989200927 హైదరాబాద్ - 9585095123 జడ్చర్ల - 8019318134 కరీంనగర్ - 6281608114 వరంగల్ - 9502638298 మంచేరియల్ - 9492900040 పార్కల్ - 9908777810 భద్రాచలం - 9618648384 Sumitomo");
        smsTemplates.put("eng:portion", "Get instant, long-lasting relief from spiders. PORTION - Control all stages -Instant kill -Long-term control -Low cost control per day SUMITOMO");
        smsTemplates.put("ben:derecho", "ডেরেকো লেট ব্লাইট, ডাউনী মাইল্ডিই নিরাময়, আমাদের শস্য আধিপত্য করবে দীর্ঘ সময় পর্যন্ত নিয়ন্ত্রণ সবুজ ফসল নতুন জাপানি প্রযুক্তি সম্পূর্ণ সুরক্ষা. Sumitomo");
        smsTemplates.put("ben:cuflow", "প্রত্যেকটি কণা শক্তিশালী কুফ্লোর অসাধারণ ছড়িয়ে যাওয়া প্রণালী, ফসলের প্রতিটি কোণাকে রাখে ছত্রাক থেকে সুরক্ষিত.Sumitomo");
        smsTemplates.put("eng:hoshi", "Organic Crop Tonic - Hoshi Complete Crop Nutrition! Dosage: Spray 2 ml/Ltr of water for more details contact- 9797972770 SUMITOMO");
        
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            conn = DriverManager.getConnection("jdbc:mysql://localhost/farmer_registration_fdd_sumitomo", "root", "");
            Statement st = conn.createStatement();
            Statement stLang = conn.createStatement();
            Statement stUpdate = conn.createStatement();

            String sql = "SELECT id, farmer_msisdn, product_name, staff_msisdn FROM miscall_detail WHERE sms_flag = 1";
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                int id = rs.getInt("id");
                String farmerNo = rs.getString("farmer_msisdn");
                String rawProduct = rs.getString("product_name");
                String staffMsisdn = rs.getString("staff_msisdn");
                String product = rawProduct.toLowerCase().replaceAll("\\s+", "");
                String lang = "";
                ResultSet langRs = stLang.executeQuery("SELECT his_lang FROM staff_detail WHERE staff_msisdn = '" + staffMsisdn + "'");
                if (langRs.next()) {
                    lang = langRs.getString("his_lang").toLowerCase();
                }

                String key = lang + ":" + product;
                if (smsTemplates.containsKey(key)) {
                    String message = smsTemplates.get(key);
                    String encodedMessage = URLEncoder.encode(message, "UTF-8");

                    String url = "http://ikontel.msg2all.com/TRANSAPI/sendsms.jsp?login=sumitomofdd&passwd=sumitomo%40321"
                            + "&version=v1.0&msg_type=unicode_text"
                            + "&msisdn=" + farmerNo
                            + "&sender_id=SUMIHO"
                            + "&msg=" + encodedMessage
                            + "&callback_url=" + URLEncoder.encode(callback_url, "utf8");

                    System.out.println("[" + new Date() + "] Sending SMS to " + farmerNo + ": " + url);

                    String resp = HTTPRequest.getResponse(url); 
                    System.out.println("Response: " + resp);

                    try {
                        JSONObject jsonResp = new JSONObject(resp);
                        JSONObject result = jsonResp.getJSONObject("result");
                        JSONObject status = result.getJSONObject("status");
                        String statusCode = status.getString("statusCode");
                        String reqId = result.getString("req_id");

                        if ("0".equals(statusCode)) {
                            stUpdate.executeUpdate("UPDATE miscall_detail SET sms_flag = 2, sms_id = '" + reqId + "' WHERE id = " + id);
                            System.out.println("✅ SMS sent successfully for ID: " + id);
                        } else {
                            stUpdate.executeUpdate("UPDATE miscall_detail SET sms_flag = 10 WHERE id = " + id);
                            System.out.println("❌ SMS failed (Status Code: " + statusCode + ") for ID: " + id);
                        }
                    } catch (Exception jsonEx) {
                        stUpdate.executeUpdate("UPDATE miscall_detail SET sms_flag = 10 WHERE id = " + id);
                        System.err.println("❌ JSON parsing error for ID: " + id + " – " + jsonEx.getMessage());
                    }

                } else {
                    stUpdate.executeUpdate("UPDATE miscall_detail SET sms_flag = 11 WHERE id = " + id);
                    System.out.println("⚠️ No template found for key: " + key + ", ID: " + id);
                }
            }

            conn.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
