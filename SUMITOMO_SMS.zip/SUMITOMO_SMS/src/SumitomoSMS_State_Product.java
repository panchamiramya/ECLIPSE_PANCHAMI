import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;

import org.json.JSONObject;

public class SumitomoSMS_State_Product {

    public static void main(String[] args) {

        Connection conn = null;

        String callback_url =
                "https://dial.123ivr.in:5443/SUMITOMO_FDD_CRM/saveSMSStatus.php";

        try {

            Class.forName("com.mysql.jdbc.Driver").newInstance();

            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost/farmer_registration_fdd_sumitomo",
                    "root",
                    ""
            );

            Statement st = conn.createStatement();
            Statement stState = conn.createStatement();
            Statement stTemplate = conn.createStatement();
            Statement stUpdate = conn.createStatement();

            String sql =
                    "SELECT id, farmer_msisdn, product_name, staff_msisdn " +
                    "FROM miscall_detail " +
                    "WHERE sms_flag = 1";

            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {

                int id = rs.getInt("id");

                String farmerNo = rs.getString("farmer_msisdn");

                String rawProduct = rs.getString("product_name");

                String staffMsisdn = rs.getString("staff_msisdn");

                String product = "";

                if (rawProduct != null) {
                    product = rawProduct
                            .toLowerCase()
                            .replaceAll("\\s+", "");
                }

                System.out.println("------------------------------------------------");
                System.out.println("ID            : " + id);
                System.out.println("Farmer No     : " + farmerNo);
                System.out.println("Raw Product   : " + rawProduct);
                System.out.println("Formatted Prod: " + product);
                System.out.println("Staff MSISDN  : " + staffMsisdn);

                String state = "";

                String stateQuery =
                        "SELECT state " +
                        "FROM staff_detail " +
                        "WHERE staff_msisdn='" + staffMsisdn + "' " +
                        "LIMIT 1";

                ResultSet stateRs = stState.executeQuery(stateQuery);

                if (stateRs.next()) {

                    state = stateRs.getString("state");

                    if (state == null) {
                        state = "";
                    }

                    state = state.trim();
                }

                System.out.println("State         : " + state);

                String smsMessage = "";

                String smsTempId = "";

                String templateQuery =
                        "SELECT sms_script, sms_temp_id " +
                        "FROM state_product_mapping " +
                        "WHERE LOWER(REPLACE(product,' ',''))='" + product + "' " +
                        "AND LOWER(TRIM(state))=LOWER(TRIM('" + state + "')) " +
                        "LIMIT 1";

                System.out.println("Template Query: " + templateQuery);

                ResultSet tempRs = stTemplate.executeQuery(templateQuery);

                if (tempRs.next()) {

                    smsMessage = tempRs.getString("sms_script");

                    smsTempId = tempRs.getString("sms_temp_id");

                    if (smsMessage == null) {
                        smsMessage = "";
                    }

                    if (smsTempId == null) {
                        smsTempId = "";
                    }
                }

                System.out.println("SMS Temp ID   : " + smsTempId);
                System.out.println("SMS Message   : " + smsMessage);

                if (smsMessage != null && !smsMessage.trim().equals("")) {

                    String encodedMessage =
                            URLEncoder.encode(smsMessage, "UTF-8");

                    String url =
                            "http://ikontel.msg2all.com/TRANSAPI/sendsms.jsp"
                                    + "?login=sumitomofdd"
                                    + "&passwd=sumitomo%40321"
                                    + "&version=v1.0"
                                    + "&msg_type=unicode_text"
                                    + "&msisdn=" + farmerNo
                                    + "&sender_id=SUMIHO"
                                    + "&msg=" + encodedMessage
                                    + "&template_id=" + smsTempId
                                    + "&callback_url="
                                    + URLEncoder.encode(callback_url, "UTF-8");

                    System.out.println(
                            "[" + new Date() + "] Sending SMS : " + url
                    );

                    String resp = HTTPRequest.getResponse(url);

                    System.out.println("API Response : " + resp);

                    try {

                        JSONObject jsonResp = new JSONObject(resp);

                        JSONObject result =
                                jsonResp.getJSONObject("result");

                        JSONObject status =
                                result.getJSONObject("status");

                        String statusCode =
                                status.getString("statusCode");

                        String reqId =
                                result.getString("req_id");

                        if ("0".equals(statusCode)) {

                            stUpdate.executeUpdate(
                                    "UPDATE miscall_detail " +
                                    "SET sms_flag = 2, " +
                                    "sms_id = '" + reqId + "' " +
                                    "WHERE id = " + id
                            );

                            System.out.println(
                                    "SMS Sent Successfully : " + id
                            );

                        } else {

                            stUpdate.executeUpdate(
                                    "UPDATE miscall_detail " +
                                    "SET sms_flag = 10 " +
                                    "WHERE id = " + id
                            );

                            System.out.println(
                                    "SMS Failed : " + id
                            );
                        }

                    } catch (Exception jsonEx) {

                        stUpdate.executeUpdate(
                                "UPDATE miscall_detail " +
                                "SET sms_flag = 10 " +
                                "WHERE id = " + id
                        );

                        System.out.println(
                                "JSON Parsing Error : " + jsonEx.getMessage()
                        );
                    }

                } else {

                    stUpdate.executeUpdate(
                            "UPDATE miscall_detail " +
                            "SET sms_flag = 11 " +
                            "WHERE id = " + id
                    );

                    System.out.println(
                            "NO SMS TEMPLATE FOUND"
                    );
                }
            }

            conn.close();

        } catch (Exception ex) {

            ex.printStackTrace();
        }
    }
}