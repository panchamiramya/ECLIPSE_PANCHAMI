import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;
public class SUMITOMO_OLD
{
	public static void main(String[] args) {
        Connection conn = null;
        String callback_url  = "https://dial.123ivr.in:5443/SUMITOMO_FDD_CRM/saveSMSStatus.php";
        Map<String, String> smsTemplates = new HashMap<>();
        smsTemplates.put("tam:Lentigo", "லென்டிகோ வயல் விழாவில் கலந்து கொண்டதற்கு நன்றி. லென்டிகோ ஒரு அடுத்த தலைமுறை நெற்பயிர் களைக்கொல்லி. லென்டிகோ ஜப்பானின் சுமிட்டோமோ கெமிக்கலின் ஒரு புதிய கண்டுபிடிப்பு Sumitomo");
        smsTemplates.put("pun:Lentigo", "ਲੈਂਟੀਗੋ ਲੈਂਟੀਗੋ ਦੇ ਫੀਲਡ ਡੇਅ ਵਿੱਚ ਸ਼ਾਮਲ ਹੋਣ ਲਈ ਤੁਹਾਡਾ ਧੰਨਵਾਦ ਅਗਲੀ ਪੀੜ੍ਹੀ ਦਾ ਪਹਿਲਾਂ ਵਰਤਿਆ ਜਾਂਣ ਵਾਲਾ ਹਰਬੀਸਾਈਡ ਸੁਮਿਟੋਮੋ ਕੈਮੀਕਲ, ਜਾਪਾਨ ਦੀ ਇੱਕ ਨਵੀਂ ਖੋਜ ਹੈ।Sumitomo");
        smsTemplates.put("hin:Top grain", "फसल उत्सव की शुभकामनाएँ। टॉपग्रेन फसल दिवस में भाग लेने के लिए धन्यवाद। टॉपग्रेन एक दाने भरने की तकनीक है जो अनाज की समग्र उपज और गुणवत्ता में सुधार करने में मदद करती है। टॉपग्रेन, दाने भरने की तकनीक।Sumitomo");
        smsTemplates.put("pun:Excaliamax", "ਐਕਸਕੇਲਿਯਾ ਦੇ ਫੀਲਡ ਡੇਅ ਵਿੱਚ ਸ਼ਾਮਲ ਹੋਣ ਲਈ ਤੁਹਾਡਾ ਧੰਨਵਾਦ ਐਕਸਕੇਲਿਯਾ ਅਗਲੀ ਪੀੜ੍ਹੀ ਦਾ ਵਰਤਿਆ ਜਾਂਣ ਵਾਲਾ ਉਲੀਨਾਸ਼ਕ ਸੁਮਿਟੋਮੋ ਕੈਮੀਕਲ, ਜਾਪਾਨ ਵੱਲੋਂ ਹੈ।Sumitomo");
        smsTemplates.put("ben:Top grain", "শুভ ফসল উত্তোলন উৎসব।।। টপগ্রেন প্রোডাক্ট এর এই ফিল্ড ডে তে উপস্থিত থাকার জন্য আপনাকে ধন্যবাদ জানাই। টপগ্রেন, এটি একটি শস্য ভরাট প্রযুক্তি, যা সামগ্রিক ফলন ও ফলন এর গুণমান এর উন্নতি তে সাহায্য করে... টপগ্রেন, শস্য ভরাট প্রযুক্তি।।।Sumitomo");
        smsTemplates.put("pun:Top grain", "ਵਾਢੀ ਦਾ ਤਿਉਹਾਰ ਮੁਬਾਰਕ। ਟੌਪਗ੍ਰੇਨ ਵਾਢੀ ਦਿਵਸ ਵਿੱਚ ਸ਼ਾਮਲ ਹੋਣ ਲਈ ਤੁਹਾਡਾ ਧੰਨਵਾਦ। ਟੌਪਗ੍ਰੇਨ ਇੱਕ ਅਨਾਜ ਭਰਨ ਵਾਲੀ ਤਕਨੀਕ ਹੈ ਜੋ ਅਨਾਜ ਦੀ ਸਮੁੱਚੀ ਉਪਜ ਅਤੇ ਗੁਣਵੱਤਾ ਵਿੱਚ ਸੁਧਾਰ ਕਰਨ ਵਿੱਚ ਮਦਦ ਕਰਦੀ ਹੈ। ਟੌਪਗ੍ਰੇਨ, ਅਨਾਜ ਭਰਨ ਦੀ ਤਕਨੀਕ।Sumitomo");
        smsTemplates.put("ben:Lentigo", "লেন্টিগো প্রোডাক্ট এর এই ফিল্ড ডে তে উপস্থিত থাকার জন্য আপনাকে ধন্যবাদ জানাই। লেন্টিগো, পরবর্তী প্রজন্মের প্রি ইমার্জেন্স আগাছানাশক... সুমিতোমো কেমিক্যাল, জাপান এর একটি নতুন উদ্ভাবন।।।Sumitomo");
        smsTemplates.put("ben:Excaliamax", "এক্সকালিয়া প্রোডাক্ট এর এই ফিল্ড ডে তে উপস্থিত থাকার জন্য আপনাকে ধন্যবাদ জানাই। এক্সকালিয়া, পরবর্তী প্রজন্মের ছত্রাকনাশক ... সুমিতোমো কেমিক্যাল, জাপান এর একটি নতুন উদ্ভাবন।।।Sumitomo");
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            conn = DriverManager.getConnection("jdbc:mysql://localhost/farmer_registration_fdd_sumitomo", "root", "");
            Statement st = conn.createStatement();
            Statement stLang = conn.createStatement();
            Statement stUpdate = conn.createStatement();
            String sql = "SELECT id, farmer_msisdn, product_name, staff_msisdn FROM miscall_detail WHERE sms_flag = 1";
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                int id = rs.getInt("id");
                String farmerNo = rs.getString("farmer_msisdn");
                String product = rs.getString("product_name");
                String staffMsisdn = rs.getString("staff_msisdn");
                String lang = "";

                ResultSet langRs = stLang.executeQuery("SELECT his_lang FROM staff_detail WHERE staff_msisdn = '" + staffMsisdn + "'");
                if (langRs.next()) {
                    lang = langRs.getString("his_lang").toLowerCase();
                }

                String key = lang + ":" + product;

                if (smsTemplates.containsKey(key)) {
                    String message = smsTemplates.get(key);
                    System.out.println(message + "MESSAGE");
                    String encodedMessage = URLEncoder.encode(message, "UTF-8");

                    String url = "http://ikontel.msg2all.com/TRANSAPI/sendsms.jsp?login=sumitomofdd&passwd=sumitomo%40321"
                            + "&version=v1.0&msg_type=unicode_text"
                            + "&msisdn=" + farmerNo
                            + "&sender_id=SUMIHO"
                            + "&msg=" + encodedMessage + "&callback_url=" + URLEncoder.encode(callback_url, "utf8");

                    System.out.println("[" + new Date() + "] Sending SMS to " + farmerNo + ": " + url);

                    String resp = HTTPRequest.getResponse(url);
                    System.out.println("Response: " + resp);

                    try {
                        JSONObject jsonResp = new JSONObject(resp);
                        JSONObject result = jsonResp.getJSONObject("result");
                        JSONObject status = result.getJSONObject("status");
                        String statusCode = status.getString("statusCode");
                        String reqId = result.getString("req_id");

                        if ("0".equals(statusCode)) {
                            String updateQuery = "UPDATE miscall_detail SET sms_flag = 2, sms_id = '" + reqId + "' WHERE id = " + id;
                            stUpdate.executeUpdate(updateQuery);
                            System.out.println("SMS sent successfully, record updated  " + id);
                        } else {
                            String updateQuery = "UPDATE miscall_detail SET sms_flag = 10 WHERE id = " + id;
                            stUpdate.executeUpdate(updateQuery);
                            System.out.println("SMS failed!!!! " + id);
                        }

                    } catch (Exception jsonEx) {
                        System.err.println("Failed to parse response JSON for id " + id + ": " + jsonEx.getMessage());
                        stUpdate.executeUpdate("UPDATE miscall_detail SET sms_flag = 10 WHERE id = " + id);
                    }

                } else {
                    System.out.println("[" + new Date() + "] No SMS template for " + key + " – Updating sms_flag to 11 for farmer: " + farmerNo);
                    String updateQuery = "UPDATE miscall_detail SET sms_flag = 11 WHERE id = " + id;
                    stUpdate.executeUpdate(updateQuery);
                }
            }

            conn.close();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}