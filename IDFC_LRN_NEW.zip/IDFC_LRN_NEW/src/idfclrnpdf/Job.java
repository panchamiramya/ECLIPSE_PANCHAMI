package idfclrnpdf;

import java.net.URLEncoder;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.json.JSONObject;

public class Job implements Runnable {
	String id;
	String lanNo;
	String customerName;
	String msisdn;
	String referNumber;
	String productType;
	String dueAmt;
	String branchAddress;
	String customerAddress;
	String msg;
	String accountType;
	String languageType;
	String noticeDate;
	String dueDate;
	String bankContactNo;
	String mailingCity;
	String mailingState;
	String mailingZipCode;
	String customerEmail;
	String noticeID;
	
	ThreadPool tp = null;
	MyDBPool dp;

	public Job(LRNInfo dnobj, ThreadPool tp, MyDBPool dp, String id) {
		
		this.tp = tp;
		this.dp = dp;
		this.id = id;
	}

	public void run() {
		try {
			System.out.println("CALLING TEMPLATE PROCESSING METHOD: " + this.id);
			Connection conn = null;
			conn = this.dp.getConnection();
			String pdfDataSql = "SELECT * FROM lrn_pdf_master WHERE ID = '"+this.id+"'";
			Statement pdfStmt = conn.createStatement();
			ResultSet pdfRs = pdfStmt.executeQuery(pdfDataSql);
			if (pdfRs.next()) {
				this.lanNo = pdfRs.getString("REFER_NO");
				this.accountType = pdfRs.getString("ACCOUNT_TYPE");
				this.branchAddress = pdfRs.getString("BRANCH_ADDRESS");
				this.customerAddress = pdfRs.getString("MAILINGADDRESS");
				this.customerName = pdfRs.getString("CUSTOMERNAME");
				this.referNumber = pdfRs.getString("REFERENCE_NO");
				this.noticeDate = pdfRs.getString("NOTICE_DATE");
				this.productType = pdfRs.getString("PRODUCT");
				this.dueAmt = pdfRs.getString("OVERDUE_EMI_AMOUNT");
				this.dueDate = pdfRs.getString("DUE_DATE");
				this.msisdn = pdfRs.getString("MSISDN");
				this.mailingCity = pdfRs.getString("MAILINGCITY");
				this.mailingState = pdfRs.getString("MAILINGSTATE");
				this.mailingZipCode = pdfRs.getString("MAILINGZIPCODE");
				this.bankContactNo = pdfRs.getString("CONTACT_NUMBER_1");
				this.customerEmail = pdfRs.getString("CUSTOMER_EMAIL");
				this.noticeID = pdfRs.getString("GUARANTOR_1");
			}
			String processTemplateResponse = processTemplate(this.lanNo, this.customerName, this.accountType, this.branchAddress, this.customerAddress, this.referNumber, this.noticeDate, this.productType, this.dueAmt,
					this.dueDate, this.msisdn, this.bankContactNo, this.mailingCity, this.mailingState, this.mailingZipCode, this.noticeID, conn);
			String sql = "";
			if (processTemplateResponse.equals("SUCCESS")) {
				sql = "UPDATE lrn_pdf_master SET PROCESS_FLAG = 2 WHERE ID = '" + this.id + "'";
			} else {
				sql = "UPDATE lrn_pdf_master SET PROCESS_FLAG = 10 WHERE ID = '" + this.id + "'";
			}
			try {
				Statement stmt = conn.createStatement();
				int statusRs = stmt.executeUpdate(sql);
				System.out.println("STATUS RESULT = " + statusRs);
				stmt.close();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				conn.close();
			}
			System.out.println("COMPLETED JOB");
			this.tp.setNoOfCompletedTasks();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static String currentDate() {
		Date dateTime = new Date();
		String strDateFormat = "dd-MMM-yyyy";
		DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
		return dateFormat.format(dateTime);
	}

	public static String currentDateFormat() {
		Date dateTime = new Date();
		String strDateFormat = "ddMMyyyyHHmmss";
		DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
		return dateFormat.format(dateTime);
	}
	
	public static String randomDateFormat(String offsetDate, String endDate) throws ParseException {
		long offset = Timestamp.valueOf(offsetDate).getTime();
		long end = Timestamp.valueOf(endDate).getTime();
		long diff = end - offset + 1;
		Timestamp rand = new Timestamp(offset + (long)(Math.random() * diff));
		String randomDateString = rand.toString();
		String strDateFormat = "ddMMyyyyHHmmss";
		String inputStrDateFormat = "yyyy-MM-dd HH:mm:ss";
		DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
		DateFormat inputDateFormat = new SimpleDateFormat(inputStrDateFormat);
		String outputData = dateFormat.format(inputDateFormat.parse(randomDateString));
		System.out.println("OUTPUT DATA="+outputData);
		return outputData;
	}
	
	public static String formatNoticeDate(String noticeDate) throws ParseException {
		String strDateFormat = "dd.MM.yyyy";
		String inputStrDateFormat = "dd-MMM-yy";
		DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
		DateFormat inputDateFormat = new SimpleDateFormat(inputStrDateFormat);
		String outputData = dateFormat.format(inputDateFormat.parse(noticeDate)).toString();
		System.out.println("OUTPUT DATA="+outputData);
		return outputData;
	}
	
	public static String formatNoticeMonth(String noticeDate) throws ParseException {
		String strDateFormat = "MMM yy";
		String inputStrDateFormat = "dd-MMM-yy";
		DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
		DateFormat inputDateFormat = new SimpleDateFormat(inputStrDateFormat);
		String outputData = dateFormat.format(inputDateFormat.parse(noticeDate)).toString();
		System.out.println("OUTPUT DATA="+outputData);
		return outputData;
	}

	public String generateQuicklink(String myurl, String filename) throws Exception {
		String url = "https://api.anymsg.in/ALLLINKS/createQuick.jsp?myurl=" + URLEncoder.encode(myurl, "utf8") + "&filename="
				+ URLEncoder.encode(filename, "utf8");
		String resp = HTTPRequest.getResponse(url);
		System.out.println("RESP=" + resp);
		JSONObject jb = new JSONObject(resp);
		String tinyurl = "";
		if (jb.getJSONObject("result").getJSONObject("status").getString("statusCode").equals("0"))
			tinyurl = jb.getJSONObject("result").getString("tinyurl");
		if (tinyurl.length() != 0) {
			System.out.println("URL Generated =" + tinyurl);
			return tinyurl;
		}
		return "";
	}

	public String getMessageTemplate(String language, Connection conn) {
		String sql = "SELECT sms_script FROM sms_template WHERE language = '" + language + "' LIMIT 1";
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			if (rs.next())
				return rs.getString("sms_script");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return "NA";
	}

	public String processTemplate(String lanNo, String customerName, String accountType, String branchAddress, String customerAddress, String referNumber, String noticeDate, String productType, String dueAmt,
			String dueDate, String msisdn, String bankContactNo, String mailingCity, String mailingState, String mailingZipCode, String noticeID, Connection conn) {
		String response = "";
		try {
			String sql = "SELECT template FROM template WHERE letter_type = 'IDFC_LRN' AND language_type = 'ENGLISH' LIMIT 1";
			System.out.println("SQL = " + sql);
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			String template = "";
			while (rs.next()) {
				template = rs.getString("template");
			}
				
			System.out.println("TEMPLATE LENGTH = " + template.length());
			if (template.equals("") || template.length() == 0) {
				response = "ERROR";
			} else {
				template = template.replaceAll("#LANNO#", lanNo);
				template = template.replaceAll("#CUSTOMERNAME#", customerName);
				template = template.replaceAll("#DUEDATE#", dueDate);
				template = template.replaceAll("#REFNUMBER#", referNumber);
				template = template.replaceAll("#DUEAMT#", dueAmt);
				template = template.replaceAll("#NOTICEDATE#", formatNoticeDate(noticeDate));
				template = template.replaceAll("#CUSTOMERADDRESS#", customerAddress);
				template = template.replaceAll("#BRANCHADDRESS#", branchAddress);
				template = template.replaceAll("#PRODUCTTYPE#", productType);
				template = template.replaceAll("#MAILINGCITY#", mailingCity);
				template = template.replaceAll("#MAILINGSTATE#", mailingState);
				template = template.replaceAll("#MAILINGZIPCODE#", mailingZipCode);
				template = template.replaceAll("#BANKCONTACTNO#", bankContactNo);
				template = template.replaceAll("#REGDNUM#", noticeID);
				
				String pdfDateFormat = currentDateFormat();
				
				System.out.println("LAN NO=" + lanNo);
				String lastTwoDigitsLanNo = "";
				if (lanNo.length() > 2) {
					lastTwoDigitsLanNo = lanNo.substring(lanNo.length() - 2);
				} else {
					lastTwoDigitsLanNo = lanNo;
				}
				System.out.println("MSISDN = " + msisdn);
				String lastFourDigitsMobileNo = "";
				if (msisdn.length() >= 10 && msisdn.length() <= 11) {
					if (msisdn.length() > 4) {
						lastFourDigitsMobileNo = msisdn.substring(msisdn.length() - 4);
					} else {
						lastFourDigitsMobileNo = msisdn;
					}
				} else {
					lastFourDigitsMobileNo = "####";
				}
				
				String passWord = String.valueOf(lastFourDigitsMobileNo) + lastTwoDigitsLanNo;
				System.out.println("PASSWORD" + passWord);
				String htmlFile = lanNo + "_" + pdfDateFormat + "_LRN-" + passWord + ".html";
				String pdfFile = lanNo + "_" + pdfDateFormat + "_LRN.pdf";
				Files.write(Paths.get(
						"/data/idfc_html/" + htmlFile,
						new String[0]), template.getBytes("UTF-8"), new java.nio.file.OpenOption[0]);
				String updateSql = "UPDATE lrn_pdf_master SET PDF_FILE = '" +pdfFile+ "', HTML_FILE = '"+htmlFile+"' WHERE ID = '" + id + "'";
				Statement stmtUp = conn.createStatement();
				int upRs = stmtUp.executeUpdate(updateSql);
				System.out.println("UPDATE SQL = " + upRs);
				String myurl = "https://api.anymsg.in/MYPDF/"+pdfFile;
				String li = generateQuicklink(myurl, "IDFC_LRN_LETTER");
				System.out.println("LINK INFO = " + li);
				String qlink = "https://q.ikns.biz/"+li;
				String sms = "Dear "+customerName+", due to non payment of your overdue emi amount of Rs."+dueAmt+" on your Loan A/c No. "+lanNo+". A Loan Recall Notice has been issued to you, Please click the link "+qlink+" to view your notice. Your password is the last 4 digits of your mobile number followed by the last two digits of your Loan A/c No. IDFC FIRST Bank";
				sql = "update lrn_pdf_master SET MSG = '" + sms + "', QLINK = '"+qlink+"' WHERE ID = " + id;
				System.out.println("SQL = " + sql);
				stmtUp.executeUpdate(sql);
				stmtUp.close();
				response = "SUCCESS";
			}
		} catch (Exception e) {
			e.printStackTrace();
			response = "ERROR";
		}
		return response;
	}
}
