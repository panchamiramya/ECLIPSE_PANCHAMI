package idfclrnpdf;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;

public class HTTPRequest {

	@SuppressWarnings("null")
	public static String getResponse(String url) {

		String res = "";
		BufferedReader in = null;
		OutputStream out = null;
		Writer wout = null;
		try {
			URL url1 = new URL(url);
			System.out.println("url=" + url);
			URLConnection connection = url1.openConnection();
			HttpURLConnection httpConn = ((HttpURLConnection) connection);
			httpConn.setReadTimeout(20000);
			httpConn.setConnectTimeout(20000);
			httpConn.setRequestProperty("Accept", "text/html");
			httpConn.setRequestProperty("Content-Type", "text/html");
			httpConn.setRequestMethod("GET");
			httpConn.setDoInput(true);
			httpConn.setDoOutput(true);
			System.out.println("code=" + httpConn.getResponseCode());
			if (httpConn.getResponseCode() == HttpURLConnection.HTTP_OK) {
				InputStreamReader isr = new InputStreamReader(httpConn.getInputStream());

				in = new BufferedReader(isr);
				String temp = "";
				res = "";
				while ((temp = in.readLine()) != null)
					res += temp;
				System.out.println("res_ok=" + res);
			} else {
				InputStreamReader isr = new InputStreamReader(httpConn.getErrorStream());

				in = new BufferedReader(isr);
				String temp = "";
				res = "";
				while ((temp = in.readLine()) != null)
					res += temp;
				System.out.println("res_err=" + res);
			}

		} catch (Exception ex) {

			ex.printStackTrace();
			return "IOEXP";

		} finally {
			try {
				in.close();
				wout.close();
				out.close();
			} catch (Exception tx) {
			}
		}

		String decoderes = "";
		try {
			decoderes = URLDecoder.decode(res, "utf8");
			System.out.println("decoderes" + decoderes);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return decoderes;

	}
	
	public static String postRawRequest(String apiURL, String body) {
		
		try {
			URL url = new URL (apiURL);
			HttpURLConnection con = (HttpURLConnection)url.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty("Content-Type", "application/json; utf-8");
			con.setRequestProperty("Accept", "application/json");
			
			con.setDoOutput(true);
			String jsonInputString = body;
			OutputStream os = con.getOutputStream();
			byte[] input = jsonInputString.getBytes("utf-8");
			os.write(input, 0, input.length);
			int code = con.getResponseCode();
			System.out.println(code);
			StringBuilder response = new StringBuilder();
			String responseLine = null;
			BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(), "utf-8"));
			while ((responseLine = br.readLine()) != null) {
				response.append(responseLine.trim());
			}
			System.out.println(response.toString());
			return response.toString();
		} catch (Exception e) {
			e.printStackTrace();
			return "ERROR";
		}
		
	}

}