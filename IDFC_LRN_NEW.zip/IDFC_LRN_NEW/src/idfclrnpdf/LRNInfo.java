package idfclrnpdf;

public class LRNInfo {

	String id;
	String msisdn;
	
	public void setID(String id) {
		this.id = id;
	}
	
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	
	public String getMsisdn() {
		return this.msisdn;
	}

}
