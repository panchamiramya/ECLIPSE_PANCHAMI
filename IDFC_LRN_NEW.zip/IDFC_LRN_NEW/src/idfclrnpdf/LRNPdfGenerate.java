package idfclrnpdf;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Hashtable;
import java.util.Properties;


public class LRNPdfGenerate {
	static public Hashtable<String, String> ht = new Hashtable<String, String>();

	public static void main(String[] args) {
		if (args.length <= 0) {
			System.out.println("ARGUMENTS REQUIRED");
			System.exit(1);
		}
		
		Properties pr = new Properties();

		InputStream input;
		try {
			input = new FileInputStream(args[0]);
			pr.load(input);
		} catch (IOException e1) {
			e1.printStackTrace();
			System.exit(-1);
		}
		

		System.out.println("Loaded the property file successfully");

		String dbuserid = pr.getProperty("dbuser");
		String dbpasswd = pr.getProperty("dbpasswd");
		String dburl = pr.getProperty("dburl");
		String tpvalue = pr.getProperty("threadpool");
		String minvalue = pr.getProperty("minvalue");
		String maxvalue = pr.getProperty("maxvalue");
		
		
		System.out.println("New Farmer Data For Communication CRM Panel Process Started");
		ThreadPool tp = new ThreadPool(Integer.parseInt(tpvalue));

		long starttime = System.currentTimeMillis();
		System.out.println("TP started");

		MyDBPool dp = null;
		Connection conn = null;
		try {
			dp = new MyDBPool(Integer.parseInt(minvalue), Integer.parseInt(maxvalue), dbuserid, dbpasswd, dburl);
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("Exiting the process.. Errr creating DB pool");
			System.exit(-1);
		}
		String sql = "SELECT ID, MSISDN FROM lrn_pdf_master WHERE PROCESS_FLAG = 0  ORDER BY ID ASC LIMIT 3000";

		System.out.println("SQL=" + sql);
		System.out.println("DB POOL started");

		try {
			conn = dp.getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		try {
			Statement st2 = conn.createStatement();
			ResultSet rs2 = st2.executeQuery(sql);
			while (rs2.next()) {
				ht.put(rs2.getString("ID"), rs2.getString("MSISDN"));
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("Exiting the system..");
			System.exit(-1);

		}

		try {

			int cnt = 0;
			int no_of_jobs = 0;
			while (true) {
				conn = dp.getConnection();
				try {

					Statement st = conn.createStatement();
					Statement st1 = conn.createStatement();
					ResultSet rs = st.executeQuery(sql);
					System.out.println("DB Execution completed");

					while (rs.next()) {
						cnt++;
						LRNInfo lrnObject = new LRNInfo();
						lrnObject.setID(rs.getString("ID"));
						lrnObject.setMsisdn(rs.getString("MSISDN"));
						String id = rs.getString("ID");
						
						try {
							Statement stmtUpdate = conn.createStatement();
							int cnts = stmtUpdate.executeUpdate("UPDATE lrn_pdf_master SET PROCESS_FLAG = 1 WHERE ID = '" + id + "'");
							if (cnts == 0) {
								System.exit(-1);
							}
							stmtUpdate.close();
						} catch (Exception e) {
							e.printStackTrace();
							System.exit(-1);
						}
						System.out.println(no_of_jobs);
						
						Job jb = new Job(lrnObject, tp, dp, id);
						tp.run(jb);
					}
					rs.close();
					st.close();
					st1.close();
					st = null;
					st1 = null;
					rs = null;

					long present = System.currentTimeMillis();
					long interval = present - starttime;
					if (cnt > 1000000 || interval > 3600 * 24 * 1000) {
						ThreadPool.stopflag = 1;
						try {
							Thread.sleep(1000L);
						} catch (Exception ex) {

						}
						tp.notifyall();
						System.out.println("Stop is requested");
						while (ThreadPool.noofstops < 25) {
							try {
								System.out.println("Sleeping for a refresh");
								System.out.println("NOSTOPS=" + ThreadPool.noofstops);
								Thread.sleep(5);

							} catch (Exception ex) {
								ex.printStackTrace();
							}

						}
						System.out.println("Every body synced to stop.. Exiting now");
						System.exit(-1);

					}

					File f = new File("/tmp/stopcallback");
					if (f.exists()) {
						System.out.println("Stop request received");

						if (tp.getNoTasks() == 0) {
							System.out.println("Stop request received");
							System.exit(-1);

						} else {
							while (true) {
								try {
									System.out.println("Waiting all process to be completed");
									System.out.println("wait for 1 sec");
									Thread.sleep(1000);
								} catch (Exception ex1) {

								}
								System.out.println("No of tasks remaining-" + tp.getNoTasks());

							}

						}

					}
					f = null;
					conn.close();
				} catch (Exception ex) {
					ex.printStackTrace();
					System.exit(-1);
				}

				try {
					System.out.println("waiting for a while at 2000");
					Thread.sleep(2000L);
				} catch (Exception localException4) {
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			System.exit(-1);
		}
	}
}