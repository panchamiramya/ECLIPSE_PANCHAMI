package helper;

public class MyMenu {
	public String id;
	public String description;
	public String msisdn;
	public String product;
	public String gc_id;
	public String contract_id;


}
