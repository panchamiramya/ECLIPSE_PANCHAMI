package helper;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;

import javax.net.ssl.HttpsURLConnection;

import org.apache.commons.codec.binary.Base64;

public class HTTPRequest
{
  
	 public static String getResponseShort(String url)
	    {

	        String res="";
	         BufferedReader in=null;
	/*    */       OutputStream out=null;
	/*    */       Writer wout=null;
	        try {
	               URL url1 = new URL(url);
	               System.out.println("url="+url);
	/* 50 */       URLConnection connection = url1.openConnection();
	/* 51 */       HttpsURLConnection httpConn = ((HttpsURLConnection)connection);
	/* 52 */       httpConn.setReadTimeout(30000);
	/* 53 */       httpConn.setConnectTimeout(30000);
	/* 54 */       httpConn.setRequestProperty("Accept", "text/html");
	/* 55 */       httpConn.setRequestProperty("Content-Type", "text/html");
	/* 56 */       httpConn.setRequestMethod("POST");
	/* 57 */       //httpConn.setDoOutput(true);
	               //httpConn.connect();
	/* 58 */       httpConn.setDoInput(true);

	/*    */
	/* 60 */      // out = httpConn.getOutputStream();
	/* 61 */      // wout = new OutputStreamWriter(out);
	/* 62 */      // wout.flush();
	               System.out.println("code="+httpConn.getResponseCode());
	               if(httpConn.getResponseCode() == httpConn.HTTP_OK)
	               {
	/* 64 */       InputStreamReader isr = new InputStreamReader(httpConn.getInputStream());
	/*    */
	/* 66 */       in = new BufferedReader(isr);
	/* 67 */       String temp = "";
	/* 68 */       res = "";
	/* 69 */       while ((temp = in.readLine()) != null)
	/* 70 */         res += temp;
	               System.out.println("res_ok="+res);
	               }
	               else
	               {
	                    InputStreamReader isr = new InputStreamReader(httpConn.getErrorStream());
	/*    */
	/* 66 */       in = new BufferedReader(isr);
	/* 67 */       String temp = "";
	/* 68 */       res = "";
	/* 69 */       while ((temp = in.readLine()) != null)
	/* 70 */         res += temp;
	System.out.println("res_err="+res);
	               }

	/*    */     }
	/*    */     catch (Exception ex) {
	/* 73 */       ex.printStackTrace();
	/* 74 */
	/*    */     }
	/*    */     finally
	/*    */     {
	/*    */       try {
	/* 79 */         in.close();
	/* 80 */         wout.close();
	/* 81 */         out.close();
	/*    */       }
	/*    */       catch (Exception tx)
	/*    */       {
	/*    */       }
	/*    */     }
	/*    */
	    String decoderes="";
	    try
	    {
	    decoderes=URLDecoder.decode(res, "utf8");
	    System.out.println("decoderes"+decoderes);
	    }
	    catch(Exception ex)
	    {
	       ex.printStackTrace();
	    }
	    return decoderes;
	/*    */



	}
	public static String getResponse(String url)
  {
    String res = "";
    BufferedReader in = null;
    OutputStream out = null;
    Writer wout = null;
    try {
      URL url1 = new URL(url);
      System.out.println("url=" + url);
      URLConnection connection = url1.openConnection();
      HttpsURLConnection httpConn = (HttpsURLConnection)connection;
      httpConn.setReadTimeout(10000);
      httpConn.setConnectTimeout(10000);
      httpConn.setRequestProperty("Accept", "text/html");
      httpConn.setRequestProperty("Content-Type", "text/html");
      httpConn.setRequestMethod("GET");

      httpConn.setDoInput(true);

      System.out.println("code=" + httpConn.getResponseCode());
      if (httpConn.getResponseCode() == 200)
      {
        InputStreamReader isr = new InputStreamReader(httpConn.getInputStream());

        in = new BufferedReader(isr);
        String temp = "";
        res = "";
        while ((temp = in.readLine()) != null)
          res = res + temp;
        System.out.println("res_ok=" + res);
      }
      else
      {
        InputStreamReader isr = new InputStreamReader(httpConn.getErrorStream());

        in = new BufferedReader(isr);
        String temp = "";
        res = "";
        while ((temp = in.readLine()) != null)
          res = res + temp;
        System.out.println("res_err=" + res);
      }
    }
    catch (Exception ex)
    {
      ex.printStackTrace();
      return "servererror";
    }
    finally
    {
      try
      {
        in.close();
        wout.close();
        out.close();
      }
      catch (Exception localException2)
      {
      }
    }

    String decoderes = "";
    try
    {
      decoderes = URLDecoder.decode(res, "utf8");
      System.out.println("decoderes" + decoderes);
    }
    catch (Exception ex)
    {
      ex.printStackTrace();
    }
    return decoderes;
  }
  
  
  
  public static String getBankApiResponse(String msisdn,String url,String json)
  {
    String res = "";
    BufferedReader in = null;
    OutputStream out = null;
    Writer wout = null;
    
    try {
      URL url1 = new URL(url);
      System.out.println("url=" + url);
      URLConnection connection = url1.openConnection();
      HttpsURLConnection httpConn = (HttpsURLConnection)connection;
      httpConn.setReadTimeout(10000);
      httpConn.setConnectTimeout(10000);
      httpConn.setRequestProperty("Accept", "text/html");
      httpConn.setRequestProperty("Content-Type", "content-type: application/json");
      httpConn.setRequestMethod("POST");

      httpConn.setDoInput(true);
      httpConn.setDoOutput(true);
      
      out = httpConn.getOutputStream();
  	out.write(json.getBytes());


      System.out.println("code=" + httpConn.getResponseCode());
      if (httpConn.getResponseCode() == 200)
      {
        InputStreamReader isr = new InputStreamReader(httpConn.getInputStream());

        in = new BufferedReader(isr);
        String temp = "";
        res = "";
        while ((temp = in.readLine()) != null)
          res = res + temp;
        System.out.println("res_ok=" + res);
      }
      else
      {
        InputStreamReader isr = new InputStreamReader(httpConn.getErrorStream());

        in = new BufferedReader(isr);
        String temp = "";
        res = "";
        while ((temp = in.readLine()) != null)
          res = res + temp;
        System.out.println("res_err=" + res);
      }
    }
    catch (Exception ex)
    {
      ex.printStackTrace();
      return "servererror";
    }
    finally
    {
      try
      {
        in.close();
        wout.close();
        out.close();
      }
      catch (Exception localException2)
      {
      }
    }

    String decoderes = "";
    try
    {
     decoderes = res;
      //System.out.println("decoderes" + decoderes);
    	//return res;
    }
    catch (Exception ex)
    {
      ex.printStackTrace();
    }
    return decoderes;
  }
  
  
  public static String getPGApiResponse(String url,String json,String userid, String passwd,String conversation_id)
  {
    String res = "";
    BufferedReader in = null;
    OutputStream out = null;
    Writer wout = null;
    
    try {
      URL url1 = new URL(url);
      System.out.println("url=" + url);
      URLConnection connection = url1.openConnection();
      HttpsURLConnection httpConn = (HttpsURLConnection)connection;
      httpConn.setReadTimeout(10000);
      httpConn.setConnectTimeout(10000);
      
      final String auth = userid + ":" + passwd; 
  	String returnValue="NA";
  	String authentication = new String(Base64.encodeBase64(auth.getBytes())); 
  	httpConn.setRequestProperty("Authorization", "Basic " + "Basic MTA3ZTU1OWU6d2hhdHNhcHB1YXQ="); 

      httpConn.setRequestProperty("Accept", "text/html");
      
      httpConn.setRequestProperty("Content-Type", "application/json");
      httpConn.setRequestProperty("ConversationID",conversation_id);
      httpConn.setRequestProperty("SourceName","whatsapp");


    
      httpConn.setRequestProperty("Accept-Encoding", "gzip,deflate");

      httpConn.setRequestMethod("POST");

      httpConn.setDoInput(true);
      httpConn.setDoOutput(true);
      
      out = httpConn.getOutputStream();
  	out.write(json.getBytes());


      System.out.println("code=" + httpConn.getResponseCode());
      if (httpConn.getResponseCode() == 200)
      {
        InputStreamReader isr = new InputStreamReader(httpConn.getInputStream());

        in = new BufferedReader(isr);
        String temp = "";
        res = "";
        while ((temp = in.readLine()) != null)
          res = res + temp;
        System.out.println("res_ok=" + res);
      }
      else
      {
        InputStreamReader isr = new InputStreamReader(httpConn.getErrorStream());

        in = new BufferedReader(isr);
        String temp = "";
        res = "";
        while ((temp = in.readLine()) != null)
          res = res + temp;
        System.out.println("res_err=" + res);
      }
    }
    catch (Exception ex)
    {
      ex.printStackTrace();
      return "servererror";
    }
    finally
    {
      try
      {
        in.close();
        wout.close();
        out.close();
      }
      catch (Exception localException2)
      {
      }
    }

    String decoderes = "";
    try
    {
      decoderes = res;
      //System.out.println("decoderes" + decoderes);
    }
    catch (Exception ex)
    {
      ex.printStackTrace();
    }
    return decoderes;
  }
}