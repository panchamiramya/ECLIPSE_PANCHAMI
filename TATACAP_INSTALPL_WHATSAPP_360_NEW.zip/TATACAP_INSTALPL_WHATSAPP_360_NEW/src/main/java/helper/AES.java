package helper;


import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class AES {

  private static SecretKeySpec secretKey;
  private static byte[] key;

  public   String setKey(final String myKey) {
    MessageDigest md = null;
    try {
      key = myKey.getBytes("UTF-8");
      md = MessageDigest.getInstance("MD5");	
      key = md.digest(key);
      key = Arrays.copyOf(key, 16);
      secretKey = new SecretKeySpec(key, "AES");
      
    } catch (NoSuchAlgorithmException | UnsupportedEncodingException e) {
      e.printStackTrace();
    }
    return "";
  }

  public  String encrypt(final String strToEncrypt, final String secret) {
    try {
      setKey(secret);
      Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
      cipher.init(Cipher.ENCRYPT_MODE, secretKey);
      byte [] b= cipher.doFinal(strToEncrypt.getBytes("UTF-8"));
      String base64=Base64.getEncoder()
    	        .encodeToString(b);
      System.out.println("BASE64="+base64);
      
      return URLEncoder.encode(base64,"UTF-8");
    } catch (Exception e) {
      System.out.println("Error while encrypting: " + e.toString());
    }
    return null;
  }

  
  public static void main(final String[] args) {
	   // final String secretKey = "ssshhhhhhhhhhh!!!!";
	  

	    String originalString = "coding";
	    
	    String msg="{  \n"
	    		+ "   \"customerName\":\"abc\",\n"
	    		+ "   \"contractNo\":\"TCHHL0269000100007162\",\n"
	    		+ "   \"emailId\":\"abc@GMAIL.COM\",\n"
	    		+ "   \"mobileNo\":\"9876543210\",\n"
	    		+ "   \"productName\":\"CD_Product\",\n"
	    		+ "   \"company\":\"TCFSL\",\n"
	    		+ "   \"productCode\":\"CD\",\n"
	    		+ "   \"sourceSystem\":\"FINONE\",\n"
	    		+ "   \"odAmount\":\"0.00\",\n"
	    		+ "   \"odCharges\":\"3.00\",\n"
	    		+ "   \"totalAmount\":\"3.00\",\n"
	    		+ "   \"paidTotal\":3.00,\n"
	    		+ "   \"transactionType\":\"Overdue EMI and LatePayment Charges\",\n"
	    		+ "   \"channel\":\"whatsapp\",\n"
	    		+ "           \"uniqueTransactionId\":\"21221212\",\n"
	    		+ "   \"returnURL\":\"www.abc.com\",\n"
	    		+ "   \"timestamp\":\"28-04-2020 17:37:25\",\n"
	    		+ "   \"altMobileNo\": \"9999090900\", \n"
	    		+ "   \"altEmailId\":\"xyz@abc.com\"\n"
	    		+ "\n"
	    		+ "}";
	 //   String encryptedString = AES.encrypt(msg, "ajqzplsmlqfaofqmtzjpq-pgs-WH") ;

	   // System.out.println(originalString);
	    //System.out.println(encryptedString);
	  }
}