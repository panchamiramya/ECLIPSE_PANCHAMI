<%@page import="java.util.Random"%>
<%@page import="java.util.Calendar"%>
<%@page import="java.util.UUID"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.text.DateFormat"%>
<%@page import="java.lang.Math.*"%>
<%@page import="java.io.OutputStream"%>
<%@page import="java.io.FileOutputStream"%>
<%@page import="java.io.File"%>
<%@page import="java.io.InputStream"%>
<%@page import="javax.naming.InitialContext"%>
<%@page import="javax.naming.Context"%>
<%@ page import = "java.util.Map" %>
<%@ page import = "java.util.Enumeration" %>
<%@ page import = "org.json.simple.JSONObject" %>
<%@ page import = "org.json.simple.JSONArray" %>

<%@ page import = "org.json.simple.parser.JSONParser" %>







<%@page contentType="text/html" pageEncoding="UTF-8"%> <%@page import="javax.sql.DataSource"%><%@page import="java.io.*"%>  <%@page import="java.sql.*" %><%@page import="org.json.*" %>
<%
response.setContentType("text/html");
response.addHeader("Freeflow","FC");
java.util.Date mydt = new java.util.Date();
response.setDateHeader("Date", mydt.getTime());
Connection conn=null;
Context ctx = new InitialContext();

 if (ctx == null)
 {
    throw new Exception("Boom - No Context");
 }
 Context envCtx = (Context) ctx.lookup("java:comp/env");

 DataSource ds =(DataSource)envCtx.lookup("jdbc/whatsapp");
 
  
    if (ds != null) {
        try{
        conn = ds.getConnection();
            }catch(Exception ex)
                         {
                           
                       }

 }

%><% 

String user_name="";
JSONObject jstat =new JSONObject();
JSONObject jres = new JSONObject();
JSONObject jout = new JSONObject();

try {

String uid = UUID.randomUUID().toString();

String reg_id="";
String msisdn="";
String email_id="";
String report_date="";


//st= "select wavfilename from upload_wavfile_log"

String session_id=request.getParameter("session_id");
String agent_id=request.getParameter("agent_id");

Statement st= conn.createStatement();
String sql="update chat_session set status='queue' ,"+" retry_agents=concat(retry_agent,'|','"+agent_id+"') where session_id='"+session_id+"'";
st.executeUpdate(sql);

sql="update agent_detail set agent_status='ACW',call_disconnect_time=now() where agent_id='"+agent_id+"'";
st.executeUpdate(sql);

jstat.put("statusCode", "0");

jres.put("status", jstat);
jout.put("result", jres);
out.println( jout.toString());
return;





              
                
                               
                                
                                  
                                   
           
                
               
} catch (Exception e) {

e.printStackTrace();


jstat.put("statusCode", "1");
           jstat.put("errorCode","101");
           jstat.put("errorMessage","UNKNOWN_ERROR");
           jres.put("status", jstat);
           jout.put("result", jres);
          out.println( jout.toString());

/* 18 */
/*    */     }finally{
                        try{
                        	conn.close();
                        }catch(Exception exx)
                                                               {
                            
                        }
                    }



%>

