<%@page import="java.util.Random"%>
<%@page import="java.util.Calendar"%>
<%@page import="java.util.UUID"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.text.DateFormat"%>
<%@page import="java.lang.Math.*"%>
<%@page import="java.io.OutputStream"%>
<%@page import="java.io.FileOutputStream"%>
<%@page import="java.io.File"%>
<%@page import="java.io.InputStream"%>
<%@page import="javax.naming.InitialContext"%>
<%@page import="javax.naming.Context"%>
<%@ page import = "java.util.Map" %>
<%@ page import = "java.util.Enumeration" %>
<%@ page import = "org.json.simple.JSONObject" %>
<%@ page import = "org.json.simple.JSONArray" %>
<%@ page import = "helper.MyMenu" %>


<%@ page import = "org.json.simple.parser.JSONParser" %>







<%@page contentType="text/html" pageEncoding="UTF-8"%> <%@page import="javax.sql.DataSource"%><%@page import="java.io.*"%>  <%@page import="java.sql.*" %><%@page import="org.json.*" %>
<%
response.setContentType("text/html");
response.addHeader("Freeflow","FC");
java.util.Date mydt = new java.util.Date();
response.setDateHeader("Date", mydt.getTime());
Connection conn=null;
Context ctx = new InitialContext();

 if (ctx == null)
 {
    throw new Exception("Boom - No Context");
 }
 Context envCtx = (Context) ctx.lookup("java:comp/env");

 DataSource ds =(DataSource)envCtx.lookup("jdbc/whatsapp");
 
  
    if (ds != null) {
        try{
        conn = ds.getConnection();
            }catch(Exception ex)
                         {
                           
                       }

 }

%><% 

String user_name="";
try {
DateFormat df=new SimpleDateFormat("yyyy-MM-dd");

Map<String, String[]> parameters = request.getParameterMap();
for(String parameter : parameters.keySet()) {
	{
        String[] values = parameters.get(parameter);
        System.out.println(values[0]);
        //your code here
    }
}


Enumeration<String> headerNames = request.getHeaderNames();

while (headerNames.hasMoreElements()) {
    
    String headerName = headerNames.nextElement();
    System.out.print(headerName + " = ");
    String headerValue = request.getHeader(headerName);
    System.out.println(headerValue);
}
   

String uid = UUID.randomUUID().toString();

String reg_id="";
String msisdn="";
String email_id="";
String report_date="";


//st= "select wavfilename from upload_wavfile_log"


InputStream is = request.getInputStream();
String  cldfilename="";

JSONParser jsonParser = new JSONParser();
org.json.simple.JSONObject jsonObject = (org.json.simple.JSONObject)jsonParser.parse(
      new InputStreamReader(is, "UTF-8"));

//{"statuses":[{"id":"gBEGkZdBQRCHAglCL08Zx7t5hss","conversation":{"id":"bee2d03aee293c9614298433b48ea479"},"pricing":{"pricing_model":"NBP","billable":true},"recipient_id":"919741411087","status":"delivered","timestamp":"1627904134"}]}
System.out.println(jsonObject.toString());
org.json.simple.JSONArray jarr=null;
try
{
	
	jarr=(org.json.simple.JSONArray)jsonObject.get("statuses");
	
	if ( jarr==null)
	{
		jarr=(org.json.simple.JSONArray)jsonObject.get("messages");
		org.json.simple.JSONObject jb=(org.json.simple.JSONObject)jarr.get(0);
		String from=(String)jb.get("from");
		String id=(String)jb.get("id");
		
		String body=jb.toJSONString();
		String type="";
		String status="";
		if (jb.get("status")==null )
		{
		   type="incoming";
		   status="";
		}
		else
		{
			type="outgoing";
			status=(String)jb.get("status");
			
		}

		String pssql="insert into incoming_message(from_msisdn,message,msg_id,call_type,msg_status) values(?,?,?,?,?)";
		PreparedStatement ps=conn.prepareStatement(pssql);
		ps.setString(1,from);
		ps.setString(2,body);
		ps.setString(3,id);
		ps.setString(4,type);
		ps.setString(5,status);
		ps.executeUpdate();
		
		if( type.equals("incoming"))
		{
			String sql="select session_id,agent_id from chat_session where msisdn='"+from+"' and last_message_received_at > now() - interval 5 minute  and flag !=99 ";
		    Statement st = conn.createStatement();
		    ResultSet rs=st.executeQuery(sql);
		    String session_id="";
		    String agent_id="";
		    if ( rs.next())
		    {
		    	session_id=rs.getString("session_id");
		    	agent_id=rs.getString("agent_id");
		    	String sqlupd="update incoming_message set session_id='"+session_id+"',agent_id='"+agent_id+"' where msg_id='"+id+"'";
		    	Statement stupd=conn.createStatement();
		    	stupd.executeUpdate(sqlupd);
		    	sqlupd="update chat_session set last_message_received_at=now(), last_msg_id= now() where session_id='"+session_id+"'";
		    	stupd.executeUpdate(sqlupd);
		    	

		    }
		    else
		    {
		    	//create a new session.
		    	String mysql="select max(id) as maxid from chat_session where msisdn='"+from+"'";
		    	Statement stsql= conn.createStatement();
		    	ResultSet rsset=stsql.executeQuery(mysql);
		    	String prev_id="";
		    	if ( rsset.next())
		    	{
		    		prev_id=rsset.getString("maxid");
		    		
		    	}
		    	
		    	mysql="update chat_session set status='hangup' ,session_end_time=now() where id="+prev_id+" and status !='hangup'";
		    	stsql.executeUpdate(mysql);
		    	
		    		
		    	
		    	
		    	
		    	if ( body.toLowerCase().contains("thank") || body.toLowerCase().contains("bye"))
		    	{
		    		return;
		    	}
		    	session_id=UUID.randomUUID().toString();
		    	
		    	String sqlinsert="insert into chat_session(session_id,last_message_received_at,last_msg_id,msisdn,created_on) values('"+session_id+"',now(),'"+id+"','"+from+"',now())";
		    	Statement stinsert=conn.createStatement();
		    	stinsert.executeUpdate(sqlinsert);
		    	String sqlu="update chat_session set account_id=1, campaign_name='whatsapp_campaign',group_name='whatsapp_group',queue_name='whatsapp_queue',queue_id=54 where session_id ='"+session_id+"'";
		    	stinsert.executeUpdate(sqlu);
		    	
		    	String sqlupd="update incoming_message set session_id='"+session_id+"',flag=5 where msg_id='"+id+"'";
		    	Statement stupd=conn.createStatement();
		    	stupd.executeUpdate(sqlupd);

		    	
		    }
		    
		}

		
		
		//org.json.simple.JSONArray jarr1=(org.json.simple.JSONArray)jsonObject.get("contacts");
		
	}
	else
	{
		//"statuses":[{"id":"gBEGkZdBQRCHAgnKpPfNAmsHdUA","type":"message","conversation":{"id":"8891a5c7dc85633757b9281e9f83119a"},"pricing":{"pricing_model":"NBP","billable":false},"recipient_id":"919741411087","status":"delivered","timestamp":"1636536278"}]}
		org.json.simple.JSONObject jb=(org.json.simple.JSONObject)jarr.get(0);
		String msg_id=(String)jb.get("id");
		String body=jb.toJSONString();
		String to_num=(String)jb.get("recipient_id");
		String status=(String)jb.get("status");
		
		String pssql="insert into outgoing_message_log(to_msisdn,message,msg_id,call_type,msg_status) values(?,?,?,?,?)";
		PreparedStatement ps=conn.prepareStatement(pssql);
		ps.setString(1,to_num);
		ps.setString(2,body);
		ps.setString(3,msg_id);
		ps.setString(4,"outgoing");
		ps.setString(5,status);
		ps.executeUpdate();
		
		
		String sql="update outgoing_message set msg_status='"+status+"' where msg_id='"+msg_id+"'";
		Statement stupd=conn.createStatement();
		stupd.executeUpdate(sql);
		
		
		
		
		
		
		
	}
}
catch ( Exception ex)
{
	ex.printStackTrace();
	
}



              
                
                               
                                
                                  
                                   
           
                
               
} catch (Exception e) {

e.printStackTrace();
JSONObject jstat =new JSONObject();
JSONObject jres = new JSONObject();
JSONObject jout = new JSONObject();


jstat.put("statusCode", "1");
           jstat.put("errorCode","101");
           jstat.put("errorMessage","UNKNOWN_ERROR");
           jres.put("status", jstat);
           jout.put("result", jres);
          out.println( jout.toString());

/* 18 */
/*    */     }finally{
                        try{
                        	conn.close();
                        }catch(Exception exx)
                                                               {
                            
                        }
                    }



%>

