<%@page import="helper.WhatsAppMessage"%>
<%@page import="java.util.Random"%>
<%@page import="java.util.Calendar"%>
<%@page import="java.util.UUID"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.text.DateFormat"%>
<%@page import="java.lang.Math.*"%>
<%@page import="java.io.OutputStream"%>
<%@page import="java.io.FileOutputStream"%>
<%@page import="java.io.File"%>
<%@page import="java.io.InputStream"%>
<%@page import="javax.naming.InitialContext"%>
<%@page import="javax.naming.Context"%>
<%@ page import = "java.util.Map" %>
<%@ page import = "java.util.Enumeration" %>
<%@ page import = "org.json.simple.JSONObject" %>
<%@ page import = "org.json.simple.JSONArray" %>

<%@ page import = "org.json.simple.parser.JSONParser" %>
<%@ page import = "java.net.URLEncoder" %>








<%@page contentType="text/html" pageEncoding="UTF-8"%> <%@page import="javax.sql.DataSource"%><%@page import="java.io.*"%>  <%@page import="java.sql.*" %><%@page import="org.json.*" %>
<%
response.setContentType("text/html");
response.addHeader("Freeflow","FC");
java.util.Date mydt = new java.util.Date();
response.setDateHeader("Date", mydt.getTime());
Connection conn=null;
Context ctx = new InitialContext();

 if (ctx == null)
 {
    throw new Exception("Boom - No Context");
 }
 Context envCtx = (Context) ctx.lookup("java:comp/env");

 DataSource ds =(DataSource)envCtx.lookup("jdbc/whatsapp");
 
  
    if (ds != null) {
        try{
        conn = ds.getConnection();
            }catch(Exception ex)
                         {
                           
                       }

 }

%><% 

String user_name="";
try {
DateFormat df=new SimpleDateFormat("yyyy-MM-dd");

Map<String, String[]> parameters = request.getParameterMap();
for(String parameter : parameters.keySet()) {
	{
        String[] values = parameters.get(parameter);
        System.out.println(values[0]);
        //your code here
    }
}


Enumeration<String> headerNames = request.getHeaderNames();

while (headerNames.hasMoreElements()) {
    
    String headerName = headerNames.nextElement();
    System.out.print(headerName + " = ");
    String headerValue = request.getHeader(headerName);
    System.out.println(headerValue);
}
   

String uid = UUID.randomUUID().toString();

String reg_id="";
String msisdn="";
String email_id="";
String report_date="";


//st= "select wavfilename from upload_wavfile_log"


InputStream is = request.getInputStream();
String  cldfilename="";

JSONParser jsonParser = new JSONParser();
org.json.simple.JSONObject jsonObject = (org.json.simple.JSONObject)jsonParser.parse(
      new InputStreamReader(is, "UTF-8"));

//{"statuses":[{"id":"gBEGkZdBQRCHAglCL08Zx7t5hss","conversation":{"id":"bee2d03aee293c9614298433b48ea479"},"pricing":{"pricing_model":"NBP","billable":true},"recipient_id":"919741411087","status":"delivered","timestamp":"1627904134"}]}
System.out.println(jsonObject.toString());
org.json.simple.JSONArray jarr=null;
//{"integrationName":"One API for Test Profile","integrationId":"af444fdd00284ea0858383f8aed56349","event":{"moText":[{"whatsapp":{"profileName":"Sanjit Pradhan"},"charset":null,"relatedMessageId":null,"channel":"whatsapp","sms":{"udh":null,"network":null},"messageId":"452a2d6399cd432fa6146e5824b1b2c6","from":"919741411087","to":"27219107820","encryptionKey":null,"relatedClientMessageId":null,"content":"ready","timestamp":1638401819000}]}}
try
{
	JSONObject event =(org.json.simple.JSONObject)jsonObject.get("event");
	
	jarr=(org.json.simple.JSONArray)event.get("moText");
	System.out.println(jarr.size());
	JSONObject jprof=(org.json.simple.JSONObject)jarr.get(0);
	JSONObject whatsapp=(org.json.simple.JSONObject)jprof.get("whatsapp");
	String name=(String)whatsapp.get("profileName");
	String from=(String)jprof.get("from");
	String to=(String)jprof.get("to");
	String content=(String)jprof.get("content");
	String msgid=(String)jprof.get("messageId");



	
	
	
		String pssql="insert into incoming_message_axis(from_msisdn,message,msg_id,call_type,msg_status) values(?,?,?,?,?)";
		PreparedStatement ps=conn.prepareStatement(pssql);
		ps.setString(1,from);
		ps.setString(2,content);
		ps.setString(3,msgid);
		ps.setString(4,"incoming");
		ps.setString(5,"success");
		ps.executeUpdate();
		
	
		  WhatsAppMessage wa = new WhatsAppMessage();
		
		if ( content.toLowerCase().equals("next"))
		{
		    String sql="select next_msisdn,id,name,due_amt,lan,due_date from msisdn_list where from_msisdn='"+from+"' and status ='init' limit 1";
		    Statement st= conn.createStatement();
		    ResultSet rs=st.executeQuery(sql);
		   String next_msisdn="";
		   String id="";
		  
		    if ( rs.next())
		    {
		    	 next_msisdn=rs.getString("next_msisdn");
		    	 id=rs.getString("id");

		    	
		    	
		    	String res=wa.call("0"+from.substring(2),"0"+next_msisdn);
		    	System.out.println(res);
		    	
		    	if ( res.toLowerCase().equals("ioexp"))
		    	{
		    		wa.sendMessage("121222", from, "Error in callling", "mkq46_wVSNGUMPpxr837Iw==", conn);
		    	}
		    	else
		    	{
		    		JSONParser jp = new JSONParser();
		    		JSONObject jb=(JSONObject)jp.parse(res);
		    		JSONObject jbres=(JSONObject)jb.get("result");
		    		String req_id=(String)jbres.get("req_id");
		    		String cust_name=rs.getString("name");
		    		String due_amt=rs.getString("due_amt");
		    		String lan=rs.getString("lan");
		    		String due_date=rs.getString("due_date");
		    		




		    		
		    		Statement st1=conn.createStatement();
		    		st1.executeUpdate("update msisdn_list set req_id='"+req_id+"', status='called' where id="+id);
		    		wa.sendMessage("121222", from, "*Cust Name* "+cust_name+" *Due Amt* "+due_amt+" *LAN* "+lan+" "+"*Due Date* "+due_date, "mkq46_wVSNGUMPpxr837Iw==", conn);

		    		
		    		wa.sendMessage("121222", from, "Call initiated .. Wait for a while", "mkq46_wVSNGUMPpxr837Iw==", conn);
		    	}
		   
		    	
		    }
		    else
		    {
	    		wa.sendMessage("121222", from, "No records to Dial", "mkq46_wVSNGUMPpxr837Iw==", conn);

		    }
			
			
		}
		else if ( content.toLowerCase().startsWith("hi") || content.toLowerCase().startsWith("hello") )
		{
			wa.sendMessage("121222", from, "Hi, Welcome Mr "+name+" to Axis whatsapp Dialing. To start dialing type *next*", "mkq46_wVSNGUMPpxr837Iw==", conn);
		}
		else if (content.toLowerCase().startsWith("d"))
		{
			String sql="select max(id) as maxid from where from_msisdn='"+from+"'";
			Statement st1=conn.createStatement();
			ResultSet rs=st1.executeQuery(sql);
			String maxid="";
		if ( rs.next())
		{
			 maxid=rs.getString("maxid");
		}
		//sql="select status from msisdn_list where id="+maxid";
			st1.executeUpdate("update msisdn_list set dispostion ='"+content.substring(1)+"',  where id='"+maxid+"'");
		}
		else if ( content.toLowerCase().equals("notready"))
		{
			wa.sendMessage("121222", from, "You are paused calling", "mkq46_wVSNGUMPpxr837Iw==", conn);
		}
		
		
		
		
}
catch ( Exception ex)
{
	ex.printStackTrace();
	
}



              
                
                               
                                
                                  
                                   
           
                
               
} catch (Exception e) {

e.printStackTrace();
JSONObject jstat =new JSONObject();
JSONObject jres = new JSONObject();
JSONObject jout = new JSONObject();


jstat.put("statusCode", "1");
           jstat.put("errorCode","101");
           jstat.put("errorMessage","UNKNOWN_ERROR");
           jres.put("status", jstat);
           jout.put("result", jres);
          out.println( jout.toString());

/* 18 */
/*    */     }finally{
                        try{
                        	conn.close();
                        }catch(Exception exx)
                                                               {
                            
                        }
                    }



%>

