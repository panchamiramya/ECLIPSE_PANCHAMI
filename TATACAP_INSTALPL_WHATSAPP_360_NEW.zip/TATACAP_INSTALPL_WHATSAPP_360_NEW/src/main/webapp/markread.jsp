<%@page import="org.apache.catalina.ha.tcp.SendMessageData"%>
<%@page import="java.util.Random"%>
<%@page import="java.util.Calendar"%>
<%@page import="java.util.UUID"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.text.DateFormat"%>
<%@page import="java.lang.Math.*"%>
<%@page import="java.io.OutputStream"%>
<%@page import="java.io.FileOutputStream"%>
<%@page import="java.io.File"%>
<%@page import="java.io.InputStream"%>
<%@page import="javax.naming.InitialContext"%>
<%@page import="javax.naming.Context"%>
<%@ page import = "java.util.Map" %>
<%@ page import = "java.util.Enumeration" %>
<%@ page import = "org.json.simple.JSONObject" %>
<%@ page import = "org.json.simple.JSONArray" %>
<%@ page import = "helper.WhatsAppMessage" %>


<%@ page import = "org.json.simple.parser.JSONParser" %>







<%@page contentType="text/html" pageEncoding="UTF-8"%> <%@page import="javax.sql.DataSource"%><%@page import="java.io.*"%>  <%@page import="java.sql.*" %><%@page import="org.json.*" %>
<%
response.setContentType("text/html");
response.addHeader("Freeflow","FC");
java.util.Date mydt = new java.util.Date();
response.setDateHeader("Date", mydt.getTime());
Connection conn=null;
Context ctx = new InitialContext();

 if (ctx == null)
 {
    throw new Exception("Boom - No Context");
 }
 Context envCtx = (Context) ctx.lookup("java:comp/env");

 DataSource ds =(DataSource)envCtx.lookup("jdbc/whatsapp");
 
  
    if (ds != null) {
        try{
        conn = ds.getConnection();
            }catch(Exception ex)
                         {
                           
                       }

 }

%><% 

String user_name="";
JSONObject jstat =new JSONObject();
JSONObject jres = new JSONObject();
JSONObject jout = new JSONObject();

try {
	


String reg_id="";
String msisdn="";
String email_id="";
String report_date="";


//st= "select wavfilename from upload_wavfile_log"

String session_id=request.getParameter("message_id");
String agent_id=request.getParameter("agent_id");
String msg_id=request.getParameter("agent_id");


String account_id="";
String whatsapp_key="";

Statement st= conn.createStatement();

	String sql="select account_id,msisdn from chat_session where session_id='"+session_id+"'";
	ResultSet rs=st.executeQuery(sql);
	if ( rs.next())
	{
		account_id=rs.getString("account_id");
		msisdn=rs.getString("msisdn");
		
	
	}
	sql="select whatsapp_key from account_info where account_id='"+account_id+"'";
	rs=st.executeQuery(sql);
	if ( rs.next())
	{
		whatsapp_key=rs.getString("whatsapp_key");
		
		
	
	}
	

	WhatsAppMessage wa= new WhatsAppMessage();
	wa.markRead(whatsapp_key, msg_id, conn);
	
	
	

jstat.put("statusCode", "0");

jres.put("status", jstat);
jout.put("result", jres);
out.println( jout.toString());
return;




              
                
                               
                                
                                  
                                   
           
                
               
} catch (Exception e) {

e.printStackTrace();


jstat.put("statusCode", "1");
           jstat.put("errorCode","101");
           jstat.put("errorMessage","UNKNOWN_ERROR");
           jres.put("status", jstat);
           jout.put("result", jres);
          out.println( jout.toString());

/* 18 */
/*    */     }finally{
                        try{
                        	conn.close();
                        }catch(Exception exx)
                                                               {
                            
                        }
                    }



%>

