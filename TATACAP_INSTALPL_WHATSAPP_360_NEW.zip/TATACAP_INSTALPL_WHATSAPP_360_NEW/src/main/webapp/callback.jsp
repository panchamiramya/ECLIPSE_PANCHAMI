<%@page import="helper.WhatsAppMessage"%>
<%@page import="java.util.Random"%>
<%@page import="java.util.Calendar"%>
<%@page import="java.util.UUID"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.text.DateFormat"%>
<%@page import="java.lang.Math.*"%>
<%@page import="java.io.OutputStream"%>
<%@page import="java.io.FileOutputStream"%>
<%@page import="java.io.File"%>
<%@page import="java.io.InputStream"%>
<%@page import="javax.naming.InitialContext"%>
<%@page import="javax.naming.Context"%>
<%@ page import = "java.util.Map" %>
<%@ page import = "java.util.Enumeration" %>
<%@ page import = "org.json.simple.JSONObject" %>
<%@ page import = "org.json.simple.JSONArray" %>
<%@ page import = "java.util.ArrayList" %>


<%@ page import = "org.json.simple.parser.JSONParser" %>







<%@page contentType="text/html" pageEncoding="UTF-8"%> <%@page import="javax.sql.DataSource"%><%@page import="java.io.*"%>  <%@page import="java.sql.*" %><%@page import="org.json.*" %>
<%
response.setContentType("text/html");
response.addHeader("Freeflow","FC");
java.util.Date mydt = new java.util.Date();
response.setDateHeader("Date", mydt.getTime());
Connection conn=null;
Context ctx = new InitialContext();

 if (ctx == null)
 {
    throw new Exception("Boom - No Context");
 }
 Context envCtx = (Context) ctx.lookup("java:comp/env");

 DataSource ds =(DataSource)envCtx.lookup("jdbc/whatsapp");
 
  
    if (ds != null) {
        try{
        conn = ds.getConnection();
            }catch(Exception ex)
                         {
                           
                       }

 }

%><% 

String user_name="";
JSONObject jstat =new JSONObject();
JSONObject jres = new JSONObject();
JSONObject jout = new JSONObject();

try {

	
	InputStream is = request.getInputStream();
	String  cldfilename="";

	JSONParser jsonParser = new JSONParser();
	org.json.simple.JSONObject jsonObject = (org.json.simple.JSONObject)jsonParser.parse(
	      new InputStreamReader(is, "UTF-8"));
	/*{"req_id":"442ff2ce-65be-45d4-a018- 
		6e325b1b8b81_13082021091251613_fedbank","Event_details":[{"event_answer_time":"2021-08-13  09:12:57.0","event_type":"A_PARTY_HANGUP","call_status":"success","event__ringtime":"2021-08-13  09:12:53.0","event_hangup_time":"2021-08-13 09:13:08.0","eventTime":"08-13-2021  09:13:08","cause":"16","a_party_call_status":"success"}],"MethodName":"IkontelCall"}
*/

	//{"statuses":[{"id":"gBEGkZdBQRCHAglCL08Zx7t5hss","conversation":{"id":"bee2d03aee293c9614298433b48ea479"},"pricing":{"pricing_model":"NBP","billable":true},"recipient_id":"919741411087","status":"delivered","timestamp":"1627904134"}]}
	System.out.println(jsonObject.toString());
	String req_id=(String)jsonObject.get("req_id");
	JSONArray jarr=(JSONArray)jsonObject.get("Event_details");
	JSONObject EventObject= (JSONObject)jarr.get(0);
	String event_type=(String)EventObject.get("event_type");
	if ( event_type.equals("A_PARTY_HANGUP"))
	{
		String call_status=(String)EventObject.get("call_status");
		Statement st=conn.createStatement();
		int cnt=st.executeUpdate("update msisdn_list set call_status='success' where req_id='"+req_id+"' and call_start_date is not null");
		if ( cnt==1)
		
				{
			call_status="success";
			       //String event_answer_time=(String)EventObject.get("event_answer_time");
			     //  st.executeUpdate("update msisdn_list set call_start_date='"+event_answer_time+"' where req_id='"+req_id+"'");
			       st.executeUpdate("update msisdn_list set duration=unix_timestamp(now())-unix_timestamp(call_start_date) where req_id='"+req_id+"'");

				}
		else
		{
			call_status="fail";
		       st.executeUpdate("update msisdn_list set call_status='fail' where req_id='"+req_id+"'");

		}
		String sql="select duration, from_msisdn,call_status from msisdn_list where req_id='"+req_id+"'";
		ResultSet rs=st.executeQuery(sql);
		String duration="";
		String from_msisdn="";
		
		if ( rs.next())
		{
			from_msisdn=rs.getString("from_msisdn");
			duration=rs.getString("duration");
		    WhatsAppMessage wa= new WhatsAppMessage();
		    if (call_status.equals("success") )
		    {
		    wa.sendMessage360("121212", from_msisdn, "CallStatus "+call_status+" Duration "+duration, "5XylMcfyYsfqGn13NOicwqrQAK", conn);
		    ArrayList al=new ArrayList();
		    al.add("Promise To Pay");
		    al.add("Refused To Pay");
		    al.add("Call disconnected");
		    al.add("Call back");
		    
		    
		    String json1=wa.formPromptId(from_msisdn, "save ", al, "select Disposition",req_id);
		    wa.sendWhatsappMsg("121212", json1, from_msisdn, "5XylMcfyYsfqGn13NOicwqrQAK", conn);

		    }
		    else
		    {
			    wa.sendMessage360("121212", from_msisdn, "CallStatus "+call_status, "5XylMcfyYsfqGn13NOicwqrQAK", conn);
			    ArrayList al=new ArrayList();

			    al.add("Switch off");
			    al.add("Wrong Number");
			    al.add("Busy");
			    al.add("Ringing No answer");
			    
			    
			    String json1=wa.formPromptId(from_msisdn, "save ", al, "select Disposition",req_id);
			    wa.sendWhatsappMsg("121212", json1, from_msisdn, "5XylMcfyYsfqGn13NOicwqrQAK", conn);

		    }
		    }
		
		
	}
	else if ( event_type.equals("B_PARTY_RINGING"))
	{
		Statement st= conn.createStatement();
		String sql="select duration, from_msisdn from msisdn_list where req_id='"+req_id+"'";
		ResultSet rs=st.executeQuery(sql);
		String duration="";
		String from_msisdn="";
		
		if ( rs.next())
		{
			from_msisdn=rs.getString("from_msisdn");
			duration=rs.getString("duration");
		    WhatsAppMessage wa= new WhatsAppMessage();
		
		    wa.sendMessage360("121212", from_msisdn, "Customer Ringing...", "5XylMcfyYsfqGn13NOicwqrQAK", conn);
		}
		
		
	}
	else if ( event_type.equals("B_PARTY_ANSWER"))
	{
		Statement st=conn.createStatement();
		st.executeUpdate("update msisdn_list set call_start_date=now()  where req_id='"+req_id+"'");
		String sql="select duration, from_msisdn from msisdn_list where req_id='"+req_id+"'";
		ResultSet rs=st.executeQuery(sql);
		String duration="";
		String from_msisdn="";
		
		if ( rs.next())
		{
			from_msisdn=rs.getString("from_msisdn");
			duration=rs.getString("duration");
		    WhatsAppMessage wa= new WhatsAppMessage();
		
		    wa.sendMessage360("121212", from_msisdn, "Customer Answered...", "5XylMcfyYsfqGn13NOicwqrQAK", conn);
		}
		
	}
	
	
	


              
                
                               
                                
                                  
                                   
           
                
               
} catch (Exception e) {

e.printStackTrace();


jstat.put("statusCode", "1");
           jstat.put("errorCode","101");
           jstat.put("errorMessage","UNKNOWN_ERROR");
           jres.put("status", jstat);
           jout.put("result", jres);
          out.println( jout.toString());

/* 18 */
/*    */     }finally{
                        try{
                        	conn.close();
                        }catch(Exception exx)
                                                               {
                            
                        }
                    }



%>

