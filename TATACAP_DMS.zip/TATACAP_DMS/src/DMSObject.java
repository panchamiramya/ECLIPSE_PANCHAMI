import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Base64;
import javax.sound.sampled.*;
import org.json.JSONObject;

public class DMSObject {

    public static void main(String[] args) {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/smartreceiverv1_1", "root", "Ikontel@987");
             Statement st = conn.createStatement();
             Statement st2 = conn.createStatement();
             Statement st3 = conn.createStatement()) {

            //String sql = "SELECT ID, agent_id, recording_file_name, dms_flag_id, CLIENT_REFERENCE_NO, IFNULL(duration, 0) as duration FROM account_outgoing_call_req WHERE agent_end_time IS NOT NULL AND recording_file_name IS NOT NULL AND dms_flag_id = 1 AND account_id='16' LIMIT 1000";
        	String sql = "SELECT ID, agent_id, recording_file_name, dms_flag_id, CLIENT_REFERENCE_NO,        IFNULL(duration, 0) AS duration FROM account_outgoing_call_req WHERE agent_end_time IS NOT NULL AND recording_file_name IS NOT NULL AND dms_flag_id = 1   AND account_id = '16' AND req_date >= \"2026-03-01 00:00:00\"  AND req_date <= NOW() - INTERVAL 1 HOUR LIMIT 1000";
            System.out.println("SQL: " + sql);

            try (ResultSet rs = st.executeQuery(sql)) {
                while (rs.next()) {
                    String id = rs.getString("ID");
                    String agent_id = rs.getString("agent_id");
                    System.out.println("Processing record ID: " + id);

                    String recording_file_name = rs.getString("recording_file_name");
                    String client_reference_no = rs.getString("CLIENT_REFERENCE_NO");
                    int duration = Integer.parseInt(rs.getString("duration"));
                    
                    if (recording_file_name == null || recording_file_name.trim().isEmpty()) {
                        System.out.println("Skipping record " + id + " because recording_file_name is NULL or empty.");
                        continue; 
                    }
                    String outputFileName = recording_file_name.endsWith(".wav") 
                          ? recording_file_name 
                          : recording_file_name + ".wav";
//                    if (duration <= 0) {
//                        String outputFileName = recording_file_name.endsWith(".wav") 
//                                ? recording_file_name 
//                                : recording_file_name + ".wav";
//                        createBlankWavFile("/home/recording/16/" + outputFileName);
//                        System.out.println("Blank WAV file created: " + outputFileName);
//                    }

                    File recordingFile = new File("/home/recording/16/" + outputFileName);

                    if (!recordingFile.exists() || duration <= 0) {
                    	createBlankWavFile(recordingFile.getAbsolutePath());
                    	System.out.println("Blank WAV file created: " + outputFileName);
                    }
                 
                    JSONObject json1 = new JSONObject();
                    json1.put("cabinateName", "MCollectDoc");
                    json1.put("folderName", client_reference_no);
                    json1.put("companyName", "");
                    json1.put("folderAttribute1", "");
                    json1.put("folderAttribute2", "");
                    json1.put("folderAttribute3", "");
                    json1.put("documentName", recording_file_name);
                    json1.put("MimeType", "audio/wav");
                    File attachment = new File("/home/recording/16/" + recording_file_name);
                    byte[] byteData = Files.readAllBytes(attachment.toPath());
                    String base64String = Base64.getEncoder().encodeToString(byteData);
                    json1.put("binary", base64String);

                    String requestBody = json1.toString();
                    //String url = "https://dms-prod-apicast.apps.prdservices.tatacapital.com:12443/rest/v1.0/dms/uploadDocumentTDS";
                    String url = "https://dms-prod-apicast.apps.prdservices.tatacapital.com/rest/v1.0/dms/uploadDocumentTDS";

                    //System.out.println("REQUEST JSON: " + requestBody);
                    boolean success = false;
                    for (int attempt = 1; attempt <= 3; attempt++) {
                    	System.out.println("ATTEMPT..................." + attempt);
                        try {
                            String result = sendPostRequest(url, requestBody, agent_id);
                            JSONObject jsonResponse = new JSONObject(result);
                            System.out.println("Response JSON: " + jsonResponse);

                            String statusCode = jsonResponse.optString("retStatus");
                            String folderObjectID = jsonResponse.optString("folderObjectID");
                            String docObjectID = jsonResponse.optString("docObjectID");

                            if ("SUCCESS".equals(statusCode) && folderObjectID != null && !folderObjectID.isEmpty() && docObjectID != null) {
                                st2.executeUpdate("UPDATE account_outgoing_call_req SET dms_flag_id = 2, folderObjectID = '" + folderObjectID + "', docObjectID = '" + docObjectID + "' WHERE id = " + id);
                                System.out.println("Updation done for ID- " + id);
                                success = true;
                                break;
                            } else {
                                st2.executeUpdate("UPDATE account_outgoing_call_req SET dms_flag_id = 20, dms_retry_count = dms_retry_count + 1 WHERE id = " + id);
                                st3.executeUpdate("INSERT INTO report_failed_log (ac_id, url, data, status, account_id, next_retry_date, no_retries, request) VALUES ('" + id + "', '" + url + "', '" + result + "', '0', '16', NOW(), '0', '" + requestBody + "')");
                                System.out.println("Updation failed for null data for ID- " + id);
                            }
                        } catch (IOException e) {
                            System.out.println("Error on attempt " + attempt + " for record ID: " + id);
                            if (attempt == 3) {
                                st2.executeUpdate("UPDATE account_outgoing_call_req SET dms_flag_id = 29, dms_retry_count = dms_retry_count + 1 WHERE id = " + id);
                                st3.executeUpdate("INSERT INTO report_failed_log (ac_id, url, data, status, account_id, next_retry_date, no_retries, request) VALUES ('" + id + "', '" + url + "', '', '0', '16', NOW(), '" + attempt + "', '" + requestBody + "')");
                                
                            }
                        }
                    }

                    if (!success) {
                        System.out.println("Failed after retries for ID- " + id);
                    }
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void createBlankWavFile(String fileName) {
        AudioFormat format = new AudioFormat(
            44100, // Sample rate
            16,    // Sample size in bits
            1,     // Channels (1 = mono, 2 = stereo)
            true,  // Signed
            false  // Little-endian
        );

        try (AudioInputStream emptyStream = new AudioInputStream(
                new ByteArrayInputStream(new byte[0]), format, 0)) {
            File wavFile = new File(fileName);
            AudioSystem.write(emptyStream, AudioFileFormat.Type.WAVE, wavFile);
            System.out.println("Created blank WAV file: " + wavFile.getAbsolutePath());
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Failed to create blank WAV file: " + e.getMessage());
        }
    }

    private static String sendPostRequest(String url, String requestBody, String agentId) throws IOException {
        HttpURLConnection connection = null;
        BufferedReader in = null;
        try {
            URL apiUrl = new URL(url);
            connection = (HttpURLConnection) apiUrl.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("Authorization", "Basic aWtvbnRlbHByb2Q6aWtvbnRlbHByb2Q=");
            connection.setRequestProperty("SourceName", "ikontel");
            connection.setRequestProperty("ConversationId", agentId);
            connection.setConnectTimeout(10000); // 10 seconds
            connection.setReadTimeout(15000);   // 15 seconds
            connection.setDoOutput(true);

            try (OutputStream os = connection.getOutputStream()) {
                byte[] input = requestBody.getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }
            StringBuilder response = new StringBuilder();
            if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                in = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8));
            } else {
                in = new BufferedReader(new InputStreamReader(connection.getErrorStream(), StandardCharsets.UTF_8));
            }

            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            return response.toString();
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
            if (in != null) {
                in.close();
            }	
        }
    }
}