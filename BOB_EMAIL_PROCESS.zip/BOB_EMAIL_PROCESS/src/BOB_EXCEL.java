import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.awt.*;
import java.awt.Color;
import java.awt.Font;
import java.awt.image.BufferedImage;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.imageio.ImageIO;

public class BOB_EXCEL {

    public static class CloseableWorkbook implements AutoCloseable {
        private final Workbook workbook;

        public CloseableWorkbook(Workbook workbook) {
            this.workbook = workbook;
        }

        public Workbook getWorkbook() {
            return workbook;
        }

        @Override
        public void close() throws Exception {
            workbook.close();
        }
    }

    public static void main(String[] args) {
        try (CloseableWorkbook closeableWorkbook = new CloseableWorkbook(new XSSFWorkbook(new FileInputStream("/home/test/Documents/test_bot.xlsx")))) {
            Workbook workbook = closeableWorkbook.getWorkbook();
            Sheet sheet = workbook.getSheetAt(0); // Assuming you're working with the first sheet

            int width = 4000; // Width of the image
            int height = 500; // Height of the image

           BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
            Graphics2D graphics = image.createGraphics();


            int x = 10; // Starting x-coordinate for drawing cells
            int y = 20; // Starting y-coordinate for drawing cells
            int cellWidth = 200; // Width of each cell
            int cellHeight = 50; // Height of each cell

            
            graphics.setColor(Color.WHITE);
            graphics.fillRect(0, 0, width, height); // Draw the white background
            
            graphics.setColor(Color.BLACK); // Set font color to black
            Font font = new Font("Arial", Font.PLAIN, 22); // Set font properties
            graphics.setFont(font);

            boolean isFirstRow = true;
            
            for (Row row : sheet) {
                for (Cell cell : row) {
                    String cellValue = "";
                    if (cell.getCellType() == CellType.STRING) {
                        cellValue = cell.getStringCellValue();
                    } else if (cell.getCellType() == CellType.NUMERIC) {
                        double numericValue = cell.getNumericCellValue();
                        cellValue = String.valueOf(numericValue);
                    }
                    graphics.drawString(cellValue, x, y);
                    graphics.drawRect(x, y, cellWidth, cellHeight);
                    x += cellWidth; // Move to the next column
                }
                x = 10; // Reset x-coordinate for the next row
                y += cellHeight; // Move to the next row
                
            }

            //graphics.setColor(Color.BLUE);
            //graphics.fillRect(0, 0, width, height); // Draw the red background

            graphics.dispose();

            File imageFile = new File("/home/test/Documents/test_bot.png");
            ImageIO.write(image, "png", imageFile);

            System.out.println("Excel data converted to image successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
