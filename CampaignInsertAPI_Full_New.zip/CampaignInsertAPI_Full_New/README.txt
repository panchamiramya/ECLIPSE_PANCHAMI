Project: CampaignInsertAPI_Full

This is a JSP-based API project for Eclipse Dynamic Web Project / Tomcat.

API URL after deployment:
http://localhost:8080/CampaignInsertAPI_Full/insertCampaignData.jsp

Required JAR files:
- gson-2.10.1.jar
- mysql-connector-j-8.0.33.jar

Put them in:
WebContent/WEB-INF/lib/

Main flow:
- auth_token validation from smartivr_cloud.api_authtoken
- predictive campaign validation + insert in campaign_cloud
- progressive campaign validation + insert in campaign_leadsquare
- mobile validation: exactly 10 digits
- batch insert used
- transaction rollback on failure

DB files included:
- src/db/DBConnection.java

Model files included:
- src/model/CampaignRequest.java
- src/model/CampaignData.java
- src/model/RecordData.java

Service files included:
- src/service/AuthService.java
- src/service/CampaignValidationService.java
- src/service/InsertService.java

Utility files included:
- src/util/DBUtil.java
- src/util/ValidationUtil.java
- src/util/ResponseUtil.java

JSP entry file:
- WebContent/insertCampaignData.jsp
