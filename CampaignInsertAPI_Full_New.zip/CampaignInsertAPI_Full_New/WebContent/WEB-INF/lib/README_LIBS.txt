Add these two JAR files here before running the project:

1. gson-2.10.1.jar
2. mysql-connector-j-8.0.33.jar

I could not bundle the actual JAR files in this environment because external downloads are unavailable here.
