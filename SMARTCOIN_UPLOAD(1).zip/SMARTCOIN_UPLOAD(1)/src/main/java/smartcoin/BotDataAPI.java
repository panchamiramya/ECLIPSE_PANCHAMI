package smartcoin;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.mysql.jdbc.exceptions.MySQLIntegrityConstraintViolationException;


import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BotDataAPI extends HttpServlet {

	private static final long serialVersionUID = 1L;
	String currentDateTime = getCurrentTimeStamp();
	SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd HH:mm:SS");
	public static String getCurrentTimeStamp() {
		Date dateTime = new Date();
		String strDateFormat = "ddMMyyHHmmss";
		DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
		return dateFormat.format(dateTime);
	}

	public String getRecordId() {

		return currentDateTime + "-" + UUID.randomUUID().toString().toUpperCase();
	}
	public static String getCurrentDateTime() {
		Date dateTime = new Date();
		String strDateFormat = "yyyy-MM-dd HH:mm:ss";
		DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
		return dateFormat.format(dateTime);
	}

	public static String getCurrentDateFromString(String datetimeString) {
		String datetime = datetimeString;
		String[] datetimeArray = datetime.split("T");
		String date = datetimeArray[0];
		System.out.println(date);
		return date.toUpperCase();
	}

	public static String getCurrentDateTimeFromString(String datetimeString) {
		String datetime = datetimeString;
		String[] datetimeArray = datetime.split("T");
		String date = datetimeArray[0];
		String[] timeArray = datetimeArray[1].split(":");
		String time = timeArray[0] + ":" + timeArray[1] + ":" + timeArray[2].substring(0, 2);
		System.out.println(date + " " + time);
		return date + " " + time;
	}

	public static boolean checkPattern(String dateTimeString) {
		try {
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:SS");
			format.parse(dateTimeString);
			return true;
		} catch (ParseException e) {
			return false;
		}
	}

	public static boolean checkDatePattern(String dateTimeString) {
		try {
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			format.parse(dateTimeString);
			return true;
		} catch (ParseException e) {
			return false;
		}
	}
	public String processBotData(String authtoken, String leadData, Connection conn) {

		try {
			if (leadData == null || leadData.trim().isEmpty()) {
				return "{\"result\": {\"status\": {\"statusCode\": 100, \"status\": \"error\", \"message\": \"Empty JSON data.\"}}}";
			}

			JSONParser parser = new JSONParser();
			JSONObject jsonData = (JSONObject) parser.parse(leadData);
			System.out.println("Parsed JSON Data: " + jsonData.toString());

			String authTokenFromRequest = (String) jsonData.get("authtoken");
			JSONArray leadsArray = (JSONArray) jsonData.get("leads");

			if (!authtoken.equals(authTokenFromRequest) ) {
				return "{\"result\": {\"status\": {\"statusCode\": 101, \"status\": \"error\", \"message\": \"Invalid authtoken or campaign_name.\"}}}";
			}
			
			for (Object leadObject : leadsArray) {
				JSONObject lead = (JSONObject) leadObject;

				String msisdn = (lead.containsKey("msisdn")) ? (String) lead.get("msisdn") : null;
				if (msisdn == null || msisdn.trim().isEmpty() || !msisdn.matches("\\d{10}")) {
					return "{\"result\": {\"status\": {\"statusCode\": 106, \"status\": \"error\", \"message\": \"Invalid msisdn field.\"}}}";
				}
				String recordId=getRecordId();
				insertLeadIntoDatabase(lead, conn, recordId);
			}

			return "{\"result\": {\"status\": {\"statusCode\": 0, \"status\": \"success\", \"message\": \"Leads inserted successfully.\"}}}";
		} catch (Exception e) {
			e.printStackTrace();
			return "{\"result\": {\"status\": {\"statusCode\": 102, \"status\": \"error\", \"message\": \"Invalid JSON data.\"}}}";
		}
	}

	private String getCurrentDate() {
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		return now.format(formatter);
	}

	private String getCurrentDateAndTime() {
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		return now.format(formatter);
	}


	private void insertLeadIntoDatabase(JSONObject lead, Connection conn, String recordId) {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			PreparedStatement ps = conn.prepareStatement("INSERT INTO upload_base (cust_name, msisdn, EMI, due_date, helpline_number, language, loan_type, application_id, cust_type, bot_type,"
					+ " bounce_reason, bounce_charge, LAN, voice_type, avtar, callerid, server, link, created_on, upload_by ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '8069393108', 'bng', 'google.com' , now(), 'API')");

			System.out.println(ps);
			ps.setString(1, (lead.containsKey("cust_name")) ? (String) lead.get("cust_name") : null);
			ps.setString(2, (lead.containsKey("msisdn")) ? (String) lead.get("msisdn") : null);
			ps.setString(3, (lead.containsKey("EMI")) ? (String) lead.get("EMI") : null);
			ps.setString(4, (lead.containsKey("due_date")) ? (String) lead.get("due_date") : null);
			ps.setString(5, (lead.containsKey("helpline_number")) ? (String) lead.get("helpline_number") : null);
			ps.setString(6, (lead.containsKey("language")) ? (String) lead.get("language") : null);
			ps.setString(7, (lead.containsKey("loan_type")) ? (String) lead.get("loan_type") : null);
			ps.setString(8, (lead.containsKey("application_id")) ? (String) lead.get("application_id") : null);
			ps.setString(9, (lead.containsKey("cust_type")) ? (String) lead.get("cust_type") : null);
			ps.setString(10, (lead.containsKey("bot_type")) ? (String) lead.get("bot_type") : null);
			ps.setString(11, (lead.containsKey("bounce_reason")) ? (String) lead.get("bounce_reason") : null);
			ps.setString(12, (lead.containsKey("bounce_charge")) ? (String) lead.get("bounce_charge") : null);
			ps.setString(13, (lead.containsKey("LAN")) ? (String) lead.get("LAN") : null);
			ps.setString(14, (lead.containsKey("voice_type")) ? (String) lead.get("voice_type") : null);
			ps.setString(15, (lead.containsKey("avtar")) ? (String) lead.get("avtar") : null);
			ps.executeUpdate();
		} catch (MySQLIntegrityConstraintViolationException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
