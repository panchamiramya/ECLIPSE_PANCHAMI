package helper;



import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;

import javax.net.ssl.HttpsURLConnection;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.parser.*;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;



public class WhatsAppMessage {
	
	 public static final String ACCOUNT_SID ="AC01f0c97858ce79906d4855d840ef32cc";
	  public static final String AUTH_TOKEN = "59bfedb7bd610fc04cf9ea98f01ca22a";
	 // public static final String WHATSAPP_URL="https://graph.facebook.com/v13.0/103721232450852/messages";
	  public static final String WHATSAPP_URL="https://graph.facebook.com/v13.0/108933708674108/messages";
	  
	  
	  public static String whatsapp_key="EAAN7A581WsIBAJz2t25iLqUbjpJH8hurZAdEPY2PtJVnOJV8McJHjEbDT7iP92sMBNSicqNhtQF3slGp5fHOoyGohTAoTnALGjcR6JEpzAfXZAxDvo8wSK4YMooRrB5QoxL61RAHC2U2DdV0Iz73H0RJiE5yGFmofiiaa8Tfc8T3vmVGtKFI8QTpJiJ2dilhZAF9tBbWAZDZD";

	
	
	public String sendMenu(String msisdn, String msg, String whatsapp_token, Connection conn)
	{
		return null;
	}
	

    public void updateCallBackURL(String msg_id,String status,String msisdn, String remark)
    {
    	try
    	{
    	//String url="https://connect.123ivr.in/whatsapp_upload/saveStatus.php?msg_id="+URLEncoder.encode(msg_id,"utf8")+"&msisdn="+msisdn+"&status="+status+"&remark="+URLEncoder.encode(remark,"utf8");
    		String url = "https://api.anymsg.in/DUNNINGPDFAPI/callbackWhatsapp.jsp?req_id="+URLEncoder.encode(msg_id,"utf8")+"&msisdn="+msisdn+"&status="+status;
    		System.out.println(url+"SSSSSSSSSSSSSSSSSSSSSS");
    		String resp=HTTPRequest.getResponse(url);
    	}
    	catch ( Exception ex)
    	{
    		ex.printStackTrace();
    	}
    }
	
	public JSONObject getSessionInfo(String from_msisdn,Connection conn,String account_id)
	{
		 JSONObject jsinfo=null;
		try
		{
		 String sql="select session_var from session_info where from_msisdn='"+from_msisdn+"' and account_id='"+account_id+"'";
         Statement st= conn.createStatement();
         ResultSet rs=st.executeQuery(sql);
         String session_json=null;
         String offset="0";
          jsinfo = new JSONObject();
         if (rs.next())
         {
        	 session_json=rs.getString("session_var");
        	 try
        	 {
        		 JSONObject jb = new JSONObject(session_json);
        		 return jb;
        		 
        		 
        	 }
        	 catch ( Exception ex)
        	 {
        		 return null;

        	 }
        	 
         }
         else
         {
        	 return null;

         }
		}
		catch ( Exception ex)
		{
			ex.printStackTrace();
			
		}
		return null;
		
	}
	
	public JSONObject updateSessionInfo(String from_msisdn,Connection conn,JSONObject jb2,String account_id)
	{
		 JSONObject jsinfo= null;
		 System.out.println("SESSION="+jb2.toString());
		try
		{
		String sql="select session_var from session_info where from_msisdn='"+from_msisdn+"'";
         Statement st= conn.createStatement();
         ResultSet rs=st.executeQuery(sql);
         String session_json=null;
         String offset="0";
          jsinfo = new JSONObject();
         if (rs.next())
         {
        	
			
			 sql="update session_info set session_var=? where from_msisdn='"+from_msisdn+"'";
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1,jb2.toString());
			ps.executeUpdate();
			return jb2;
        	 
         }
         else
         {
        	 sql="insert  session_info (session_var,from_msisdn,account_id) values(?,?,?)";
 			PreparedStatement ps=conn.prepareStatement(sql);
 			ps.setString(1,jb2.toString());
 			ps.setString(2,from_msisdn);
 			ps.setString(3,account_id);

 			ps.executeUpdate();
 			return jb2;

         }
		}
		catch ( Exception ex)
		{
			ex.printStackTrace();
			
		}
		return null;
		
	}
	
	
	public String getIntent(String resp,String msisdn,Connection conn,String account_id)
	{
		try
		{
//	{"messages":[{"button":{"text":"Pay Now"},"context":{"from":"917777892222","id":"gBEGkZdBQRCHAgnooWiepw2TJFo"},"from":"919741411087","id":"ABEGkZdBQRCHAhDajiTTG8EizKgtoeUPhh4S","type":"button","timestamp":"1650592034"}],"contacts":[{"profile":{"name":"Sanjit Pradhan"},"wa_id":"919741411087"}]}
		//	{"from":"918073131344","id":"wamid.HBgMOTE4MDczMTMxMzQ0FQIAEhggNjRGQzFEQ0QwREYxNURCNTBFOEVEQzJERkY1MTQxRkEA","text":{"body":"Hi"},"type":"text","timestamp":"1660205970"}

			JSONObject js= getSessionInfo(msisdn, conn,account_id);
			String menuchoosen="";
			String text="";
			System.out.println("INTENTRESP="+resp);
			try
			{
				text=new JSONObject(resp).getJSONObject("button").getString("text");
				
			
				
			//	menuchoosen=js.getString("menu_choosen");
				
				
				
			}
			catch ( Exception ex)
			{
				ex.printStackTrace();
				System.out.println("RESP1="+resp);
			}
			
			if (text.toLowerCase().equals("yes"))
			{
				return "menu:yes";
			}
			else if ( text.equals("NO"))
			{
				
					return "menu:no";
				
			}
			
			else if ( text.equals("STOP"))
			{
				
					return "menu:stop";
				
			}
			else if ( text.equals("Subscribe"))
			{
				
					return "menu:subscribe";
				
			}
			else if ( menuchoosen.equals("hindimain"))
			{
				if ( text.equals("4"))
				{
					return "menu:hindisendotp";
				}
			}
			else if (menuchoosen.equals("engsendotp") )
			{
				String otp = text;
				if ( otp.equals("2"))
				{
					return "menu:engsendotp";
				}
				else
				{
					return "menu:engvalidateotp:"+text;
					
				}
						
			}
			
		
			else if (menuchoosen.equals("enterpan"))
			{
				return "menu:validatepan:"+text;
				
			}
			else if (menuchoosen.equals("validatepan"))
			{
				return "menu:issalaried:"+text;
				
			}
			else if (menuchoosen.equals("issalaried"))
			{
				return "menu:"+"selectcompany"+":"+text;
				
			}
			else if (menuchoosen.equals("selectcompany"))
			{
				return "menu:choosecompany:"+text;
				
			}
			else if (menuchoosen.equals("choosecompany"))
			{
				return "menu:enterpan"+":"+text;
				
			}
			
			else if (menuchoosen.equals("presentoffer"))
			{
				if ( text.equals("2"))
				{
				return "menu:enterofferamount"+":"+text;
				}
				
			}
			else if (menuchoosen.equals("enterofferamount"))
			{
				if ( text.equals("2"))
				{
				return "menu:presentoffer"+":"+text;
				}
				
			}
			
			
			
		}
			
		catch ( Exception ex)
		{
			ex.printStackTrace();
			return "error";
		}
		return "error";
	}


	public String formPrompt(String msisdn,String body,ArrayList jarrmenu,String button)
	{
		
		String body_text=body;
		JSONObject jb = new JSONObject();
		jb.put("recipient_type", "individual");
		jb.put("to", msisdn);
		jb.put("type", "interactive");
		JSONObject jbinteractive=new JSONObject();
		jbinteractive.put("type", "list");
		JSONObject jbheader=new JSONObject();
		jbheader.put("type","text");
		jbheader.put("text","");
		
		JSONObject jbbody=new JSONObject();
		
		jbbody.put("text",body_text);
        JSONObject jbfoot=new JSONObject();
		
		jbfoot.put("text","");
		
		JSONObject jbaction=new JSONObject();
		jbaction.put("button", button);
		JSONArray jbsections=new JSONArray();
		JSONObject jbsection= new JSONObject();
		
		JSONArray rows = new JSONArray();
		
		for ( int i=0 ;i< jarrmenu.size();i++)
		{
			
			String  menu=(String)jarrmenu.get(i);
			JSONObject row= new JSONObject();

			
			row.put("id",i+"");
			row.put("title", (i+1)+"");
			row.put("description",menu);
			rows.put(row);
			if ( i >8)
			{
				break;
			}
			


			
		}
		
		jbsection.put("title", " ");
		jbsection.put("rows", rows);
		jbsections.put(jbsection);
		
		 rows = new JSONArray();

		/*for ( int i=10 ;i< jarr.length();i++)
		{
			
			JSONObject ca=jarr.getJSONObject(i);
			JSONObject row= new JSONObject();

			
			row.put("id",i+ca.getString("complaint_type"));
			row.put("title", (i+1)+"");
			row.put("description", ca.getString("complaint_type"));
			rows.put(row);
			

			
		}
		
       jbsection= new JSONObject();
        jbsection.put("title", "PART-2");
		jbsection.put("rows", rows);
		jbsections.put(jbsection);*/

		
		
		
		
		
		
		jbaction.put("sections", jbsections);
		jbinteractive.put("action", jbaction);
		jbinteractive.put("header", jbheader);
		jbinteractive.put("body", jbbody);
		jbinteractive.put("footer", jbfoot);
		jb.put("interactive", jbinteractive);
		System.out.println(jb.toString());
	    return jb.toString();
		//HTTPRequest.getResponseWhatsapp(getMycallid(),jb.toString());
	    
		
	}
	
	public String formPrompt(String msisdn,String body,ArrayList jarrmenu,String button,String menu_note)
	{
		
		String body_text=body;
		JSONObject jb = new JSONObject();
		jb.put("recipient_type", "individual");
		jb.put("to", msisdn);
		jb.put("type", "interactive");
		JSONObject jbinteractive=new JSONObject();
		jbinteractive.put("type", "list");
		JSONObject jbheader=new JSONObject();
		jbheader.put("type","text");
		jbheader.put("text","");
		
		JSONObject jbbody=new JSONObject();
		
		jbbody.put("text",body_text);
        JSONObject jbfoot=new JSONObject();
		
		jbfoot.put("text","");
		
		JSONObject jbaction=new JSONObject();
		jbaction.put("button", button);
		JSONArray jbsections=new JSONArray();
		JSONObject jbsection= new JSONObject();
		
		JSONArray rows = new JSONArray();
		
		for ( int i=0 ;i< jarrmenu.size();i++)
		{
			
			String  menu=(String)jarrmenu.get(i);
			JSONObject row= new JSONObject();

			
			row.put("id",i+menu_note);
			row.put("title", (i+1)+"");
			row.put("description",menu);
			rows.put(row);
			if ( i >8)
			{
				break;
			}
			


			
		}
		
		jbsection.put("title", " ");
		jbsection.put("rows", rows);
		jbsections.put(jbsection);
		
		 rows = new JSONArray();

		/*for ( int i=10 ;i< jarr.length();i++)
		{
			
			JSONObject ca=jarr.getJSONObject(i);
			JSONObject row= new JSONObject();

			
			row.put("id",i+ca.getString("complaint_type"));
			row.put("title", (i+1)+"");
			row.put("description", ca.getString("complaint_type"));
			rows.put(row);
			

			
		}
		
       jbsection= new JSONObject();
        jbsection.put("title", "PART-2");
		jbsection.put("rows", rows);
		jbsections.put(jbsection);*/

		
		
		
		
		
		
		jbaction.put("sections", jbsections);
		jbinteractive.put("action", jbaction);
		jbinteractive.put("header", jbheader);
		jbinteractive.put("body", jbbody);
		jbinteractive.put("footer", jbfoot);
		jb.put("interactive", jbinteractive);
		System.out.println(jb.toString());
	    return jb.toString();
		//HTTPRequest.getResponseWhatsapp(getMycallid(),jb.toString());
	    
		
	}
	
	public String formPromptId(String msisdn,String body,ArrayList jarrmenu,String button,String id)
	{
		
		String body_text=body;
		JSONObject jb = new JSONObject();
		jb.put("recipient_type", "individual");
		jb.put("to", msisdn);
		jb.put("type", "interactive");
		JSONObject jbinteractive=new JSONObject();
		jbinteractive.put("type", "list");
		JSONObject jbheader=new JSONObject();
		jbheader.put("type","text");
		jbheader.put("text","");
		
		JSONObject jbbody=new JSONObject();
		
		jbbody.put("text",body_text);
        JSONObject jbfoot=new JSONObject();
		
		jbfoot.put("text","");
		
		JSONObject jbaction=new JSONObject();
		jbaction.put("button", button);
		JSONArray jbsections=new JSONArray();
		JSONObject jbsection= new JSONObject();
		
		JSONArray rows = new JSONArray();
		
		for ( int i=0 ;i< jarrmenu.size();i++)
		{
			
			String  menu=(String)jarrmenu.get(i);
			JSONObject row= new JSONObject();

			
			row.put("id",i+"X"+id.toLowerCase());
			row.put("title", (i+1)+"");
			row.put("description",menu);
			rows.put(row);
			if ( i >8)
			{
				break;
			}
			


			
		}
		
		jbsection.put("title", " ");
		jbsection.put("rows", rows);
		jbsections.put(jbsection);
		
		 rows = new JSONArray();

		/*for ( int i=10 ;i< jarr.length();i++)
		{
			
			JSONObject ca=jarr.getJSONObject(i);
			JSONObject row= new JSONObject();

			
			row.put("id",i+ca.getString("complaint_type"));
			row.put("title", (i+1)+"");
			row.put("description", ca.getString("complaint_type"));
			rows.put(row);
			

			
		}
		
       jbsection= new JSONObject();
        jbsection.put("title", "PART-2");
		jbsection.put("rows", rows);
		jbsections.put(jbsection);*/

		
		
		
		
		
		
		jbaction.put("sections", jbsections);
		jbinteractive.put("action", jbaction);
		jbinteractive.put("header", jbheader);
		jbinteractive.put("body", jbbody);
		jbinteractive.put("footer", jbfoot);
		jb.put("interactive", jbinteractive);
		System.out.println(jb.toString());
	    return jb.toString();
		//HTTPRequest.getResponseWhatsapp(getMycallid(),jb.toString());
	    
		
	}
	
	
	
	
	
	
	
	

	
	
	
	
	public String markRead(String whatsapp_key,String msg_id,Connection conn)
	{
		String url="https://waba.360dialog.io/v1/messages";
		//   OutputStream out=null;
		    try {
		           URL url1 = new URL(url);
		          
		/* 50 */       URLConnection connection = url1.openConnection();
		/* 51 */       HttpsURLConnection httpConn = ((HttpsURLConnection)connection);
		/* 52 */       httpConn.setReadTimeout(20000);
		/* 53 */       httpConn.setConnectTimeout(20000);
		/* 55 */       httpConn.setRequestProperty("d360-api-key", whatsapp_key);
		/* 55 */       httpConn.setRequestProperty("cache-control", "no-cache");
		httpConn.setRequestMethod("PUT");
		Statement st=conn.createStatement();
		String sql="update whatsapp.incoming_message set msg_status='read' where msg_id='"+msg_id+"'";
		st.executeUpdate(sql);
		
		// InputStreamReader isr = new InputStreamReader(httpConn.getInputStream());
		 
		    }
		    catch ( Exception ex)
		    {
		    	ex.printStackTrace();
		    }
		    return "";
		            
		
	}
	
	
	


	
	public String sendMessage360(String session_id,String msisdn, String msg,String whatsapp_token,Connection conn)
	{
		 
			  String contact_id=msisdn;
		
	      String json="{\n"
	      		+ "  \"recipient_type\": \"individual\",\n"
	      		+ "   \"type\": \"text\",\n"
	      		+ "  \"to\": \""+contact_id+"\",\n"
	      		+ "\"text\": {\n"
	      		+ "    \"body\": \""+org.json.simple.JSONObject.escape(msg)+"\"\n"
	      		+ "  }\n"
	      		+ "  \n"
	      		+ "  \n"
	      		+ "  \n"
	      		+ " \n"
	      		+ "  \n"
	      		+ "}";
	    
	 //     return getResponseWhatsapp(session_id, json,msisdn,whatsapp_token,conn);
	      
	      return sendWhatsappJSONMsg(msisdn, json, "90", conn, session_id);

	  }
	

	

	

	
	




	



	public  String getResponseWhatsapp(String session_id,String json,String whatsapp_key,String phoneid)
	{
		
		System.out.println("SENDING .."+json);
		JSONObject jb=null;
		try
		{
		 jb = new JSONObject(json);
		 jb.put("messaging_product","whatsapp");
		}
		catch ( Exception ex)
		{
			ex.printStackTrace();
		}
		
		OkHttpClient client = new OkHttpClient();

		MediaType mediaType = MediaType.parse("application/json");
		RequestBody body = RequestBody.create(mediaType,jb.toString());
		Request request = new Request.Builder()
		 // .url("https://waba.360dialog.io/v1/messages")
       // .url("https://graph.facebook.com/v15.0/110340415133033/messages")
	   //.url("https://graph.facebook.com/v15.0/108933708674108/messages")
	   .url("https://graph.facebook.com/v15.0/"+phoneid+"/messages")


        

		  .post(body)
		  .addHeader("content-type", "application/json")
		 
		  .addHeader("cache-control", "no-cache")
		//  .addHeader("Authorization","Bearer EAAdprOSjVZAcBAHhnGXpriIj0x8GJMZAAzlw4LsXOF8Dd7dYb4rIZCAIVatmpiN0VTIwVikimcF7r8XDGOvR9vLvDpcXA44UflJiSxrlCnN2HF0nctCfcfnT91ClAXfFfU1RMBPic1Miv4SxESXUWxP8VFGPS1dKYCgFleLFU6BDIHR9xrhaPah9b24anZBZB19ne7AFH3WDuLCfZBiAEW")
		  .addHeader("Authorization",whatsapp_key)

		  .build();
		try
		{

		Response response = client.newCall(request).execute();
		String resp=response.body().string();
		System.out.println("RESP="+resp);
		return resp;
		}
		catch ( Exception ex)
		{
			ex.printStackTrace();
			return "error";
		}
		
		
	  



	}


	public String  sendWhatsappJSONMsgNoUUID(String msisdn,String json,String account_id,Connection conn,String session_id)
	{
		try
		{
			
        String uuid=UUID.randomUUID().toString();
		String sqlinsert="insert into outgoing_whatsapp_log(to_msisdn,message,account_id,session_id,uuid) values(?,?,?,?,?)";
		PreparedStatement ps=conn.prepareStatement(sqlinsert);
		ps.setString(1,msisdn);
		ps.setString(2,json);

		ps.setString(3,account_id);

		ps.setString(4,session_id);
		ps.setString(5,uuid);

		ps.executeUpdate();

		String whatsapp_token="";
		String sql="select whatsapp_key,phoneid from account_info where account_id='"+account_id+"'";
		Statement st =conn.createStatement();
		ResultSet rs=st.executeQuery(sql);
		String phoneid="";
		if ( rs.next())
		{
			whatsapp_token=rs.getString("whatsapp_key");
			phoneid=rs.getString("phoneid");
		}
				
		
		
		String resp= getResponseWhatsapp(session_id, json,whatsapp_token,phoneid);
		
		
		 JSONObject jb = new JSONObject(resp);
		
		 String msgid=jb.getJSONArray("messages").getJSONObject(0).getString("id");
		 sql="update outgoing_whatsapp_log set msg_id='"+msgid+"' where uuid='"+uuid+"'";
		 st.executeUpdate(sql);
		 
	
		 return msgid;
		  
		}
		catch( Exception ex)
		{
			ex.printStackTrace();
			return "error";
		}
		
	}
	
	public String  sendWhatsappJSONMsg(String msisdn,String json,String account_id,Connection conn,String session_id)
	{
		try
		{
			
        String uuid=UUID.randomUUID().toString();
		String sqlinsert="insert into outgoing_whatsapp_log(to_msisdn,message,account_id,session_id,uuid) values(?,?,?,?,?)";
		PreparedStatement ps=conn.prepareStatement(sqlinsert);
		ps.setString(1,msisdn);
		ps.setString(2,json);

		ps.setString(3,account_id);

		ps.setString(4,session_id);
		ps.setString(5,uuid);

		ps.executeUpdate();

		String whatsapp_token="";
		String sql="select whatsapp_key,phoneid from account_info where account_id='"+account_id+"'";
		Statement st =conn.createStatement();
		ResultSet rs=st.executeQuery(sql);
		String phoneid="";
		if ( rs.next())
		{
			whatsapp_token=rs.getString("whatsapp_key");
			phoneid=rs.getString("phoneid");

		}
				
		
		
  		String resp= getResponseWhatsapp(session_id, json,whatsapp_token,phoneid);
		 JSONObject jb = new JSONObject(resp);
		
		 String msgid=jb.getJSONArray("messages").getJSONObject(0).getString("id");
		 sql="update outgoing_whatsapp_log set msg_id='"+msgid+"' where uuid='"+uuid+"'";
		 st.executeUpdate(sql);
		 
		 sql="update account_daily_info set no_of_sent= no_of_sent where account_id='"+account_id+"' and sent_date=date(now())";
		 int cnt=st.executeUpdate(sql);
		 if ( cnt==0)
		 {
			 sql="insert into account_daily_info(account_id,sent_date,no_of_sent) values(account_id,date(now()),1)";
			 st.executeUpdate(sql);
		 }
		 return msgid;
		  
		}
		catch( Exception ex)
		{
			ex.printStackTrace();
			return "error";
		}
		
	}

}
