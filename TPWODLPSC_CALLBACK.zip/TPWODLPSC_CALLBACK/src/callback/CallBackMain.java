package callback;

import java.sql.*;
import java.util.Date;
import java.util.Hashtable;
import java.util.UUID;

public class CallBackMain {
    public static void main(String[] args) {
        System.out.println("New version CallBack");

        try (
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/smartivr_cloud", "oditata", "PowTata@987");
            Statement st = conn.createStatement();
           // ResultSet rs = st.executeQuery("SELECT id, channel_id FROM smartivr_cloud.dtmf_channel WHERE account_id = 108 AND digit = 2 AND pflag = 0");
        ) {
           // while (rs.next()) {
              //  String channel_id = rs.getString("channel_id");
             //   String id = rs.getString("id");

                try (
                    Connection conn1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/campaign_tpwodlop", "tpwodlop", "tpwodlop");
                    Statement st1 = conn1.createStatement();
                        ResultSet rs2 = st1.executeQuery("SELECT id, incoming_number, group_name, start_call_date,status FROM smartivr_cloud.incoming_call_log WHERE update_flag=0 and start_call_date < now() - interval 30 SECOND and account_id=159 limit 100");
                ) {
                    if (rs2.next()) {
                        String incoming_number = rs2.getString("incoming_number");
                        String group_name = rs2.getString("group_name");
                        String start_call_date = rs2.getString("start_call_date");
                        String id = rs2.getString("id");
                        
                        String call_status=rs2.getString("status");;
                        if ("NA".equals(call_status)) 
                        {

                        System.out.println("Processed " + incoming_number);

                        String record_id = UUID.randomUUID().toString();
                        
                        //String sql4="select count(1) as cnt, record_status from campaign_tpcodlop.account_outbound where msisdn='"+incoming_number+"' and account_id=108 and request_date > now() - interval 1 HOUR";
                        String sql4="select count(1) as cnt, record_status from campaign_tpwodlop.account_outbound where msisdn='"+incoming_number+"' and account_id=159 and record_status = 'active'";

                        ResultSet rs4=st1.executeQuery(sql4);
                        int cnt2=0;
                        if ( rs4.next())
                        {
                        	String ggg = "";
                        cnt2=rs4.getInt("cnt");
                        if ( cnt2  < 1)
                        {
                        	System.out.println("Count is < 1");
                        	ggg = "yes";
                        }else{
                        	String status = rs4.getString("record_status");
                        	if(status.equals("finished"))
                        	{System.out.println("Count is > 1 and finished");
                        		ggg = "yes";
                        	}else {
                        		System.out.println("Count is > 1 and not finished");
                        		ggg = "no";
                        	}
                        }
                        String sql3 = "";
                        if ("yes".equals(ggg)) 
                        {
                        	System.out.println("Now DB POOL started sql4-------");
	                        String sql1 = "INSERT INTO campaign_tpwodlop.callback_tab(account_id, msisdn, callback_date_time, record_status, record_id, campaign, created_on, created_by, agent_group) VALUES (159, ?, ?, 'active', ?, 'callback', NOW(), 'system', ?)";
	                        try (PreparedStatement pst1 = conn1.prepareStatement(sql1)) {
	                            pst1.setString(1, incoming_number);
	                            pst1.setString(2, start_call_date);
	                            pst1.setString(3, record_id);
	                            pst1.setString(4, group_name);
	                            pst1.executeUpdate();
	                        }
	
	                        String sql2 = "INSERT INTO campaign_tpwodlop.account_outbound(account_id, msisdn, record_status, record_id, campaign_name, request_date, agent_group) VALUES (159, ?, 'active', ?, 'callback', NOW(), ?)";
	                        try (PreparedStatement pst2 = conn1.prepareStatement(sql2)) {
	                            pst2.setString(1, incoming_number);
	                            pst2.setString(2, record_id);
	                            pst2.setString(3, group_name);
	                            pst2.executeUpdate();
	                        }
	                        sql3 = "UPDATE smartivr_cloud.incoming_call_log SET update_flag = 5 WHERE id = ?";
                        }else {
	                        sql3 = "UPDATE smartivr_cloud.incoming_call_log SET update_flag = 1 WHERE id = ?";
                        }
	                        try (PreparedStatement pst3 = conn.prepareStatement(sql3)) {
	                            pst3.setString(1, id);
	                            pst3.executeUpdate();
	                        }										
                        
                        }
                        }
                        else
                        {
                        	Statement st3=conn1.createStatement();
	                       String sql3 = "UPDATE smartivr_cloud.incoming_call_log SET update_flag = 1 WHERE id = "+id;

		                       st3.executeUpdate(sql3);
		                        sql3 = "update campaign_tpwodlop.account_outbound set record_status='inactive' where msisdn='"+incoming_number+"' and record_status='active'";
		                        st3.executeUpdate(sql3);
                        }
                    }
                }
           // }
                
                System.exit(0);

            System.out.println("Now DB POOL started");
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Exiting the system..");
        }
    }
}